import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { authService } from "./authService";

const userExist = JSON.parse(localStorage.getItem("userTowingMen"));

const initialState = {
  user: userExist ? userExist : null,
  isLoading: false,
  isSuccess: false,
  isError: false,
  message: "",
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
  },
  // extraReducers: (builder) => {
  //   builder
  //     // Log in user
  //     .addCase(loginUser.pending, (state) => {
  //       state.isLoading = true;
  //     })
  //     .addCase(loginUser.fulfilled, (state, action) => {
  //       state.isLoading = false;
  //       state.isSuccess = true;
  //       state.isError = false;
  //       state.user = action.payload;
  //     })
  //     .addCase(loginUser.rejected, (state, action) => {
  //       state.isError = true;
  //       state.isSuccess = false;
  //       state.isLoading = false;
  //       state.user = null;
  //       state.message = action.payload;
  //     });
  // },
});

export default authSlice.reducer;

export const signinUser = createAsyncThunk(
  "SIGNIN/USER",
  async (formData, thunkAPI) => {
    console.log("Formdata:-", formData);
    try {
      const response = await authService.signup(formData);
      return response;
    } catch (error) {
      const message = error.response
        ? error.response.data.message
        : error.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);
