import axios from "axios";

// const API_URL = "http://localhost:8000";
const API_URL = 'http://193.203.161.2:8000'

const signup = async (formData) => {
  const response = await axios.post(`${API_URL}/towing/register`, formData);
  return response.data;
};

const login = async (formData) => {
  const response = await axios.post(`${API_URL}/towing/login`, formData);
  console.log("Response data", response.data);
  return response.data;
};

const passwordChange = async (formData) => {
  const response = await axios.post(
    `${API_URL}/mechanic/change-password`,
    formData
  );
  console.log(response.data);
  return response.data;
};

const updateUserProfile = async (formData) => {
  try {
    const response = await axios.put(
      `${API_URL}/mechanic/update-profile/${formData.userId}`,
      formData
    );
    console.log("Profile updated successfully:", response.data);
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Error response from server:", error.response.data);
      console.error("Status code:", error.response.status);
    } else if (error.request) {
      console.error("No response from server:", error.request);
    } else {
      console.error("Error in request setup:", error.message);
    }

    throw error;
  }
};

const addInspectionDetails = async (profileData) => {
  try {
    const response = await axios.post(
      `${API_URL}/mechanic/service-details/${profileData.userId}`,
      profileData
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Server responded with error:", error.response.data);
      throw new Error(
        error.response.data.message || "Failed to update inspection details"
      );
    } else if (error.request) {
      console.error("No response received:", error.request);
      throw new Error("No response from server. Please try again later.");
    } else {
      console.error("Error during request setup:", error.message);
      throw new Error("An unexpected error occurred. Please try again.");
    }
  }
};

export const authService = {
  login,
  passwordChange,
  updateUserProfile,
  addInspectionDetails,
  signup,
};
