import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import "./App.css";
import Header from "./components/Header";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home";
import PaymentPending from "../src/pages/PaymentPending";
import NotFound from "./components/NotFound";
import ChangePassword from "./pages/ChangePassword";
import BillingDetails from "./pages/BillingDetails";
import Login from "./pages/Login";
import SalesReport from "./pages/SalesReport";
import SignUp from "./pages/SignUp";
import AboutUs from "./pages/AboutUs";
import Contact from "./pages/Contact";
import AllRequests from "./pages/AllRequests";
import TrackTowings from "./pages/TrackTowings";
import TrackingStatusUpdate from "./pages/TrackingStatusUpdate";

const App = () => {
  return (
    <Router>
      {/* // <Router basename="/towing/"> */}
      <ConditionalHeader />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />

        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          }
        />
        <Route
          path="/all-requests"
          element={
            <ProtectedRoute>
              <AllRequests />
            </ProtectedRoute>
          }
        />
        <Route
          path="/payment-request"
          element={
            <ProtectedRoute>
              <PaymentPending />
            </ProtectedRoute>
          }
        />
        <Route
          path="/track-towings"
          element={
            <ProtectedRoute>
              <TrackTowings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/track-towings/tracking-status-update/:id"
          element={
            <ProtectedRoute>
              <TrackingStatusUpdate />
            </ProtectedRoute>
          }
        />
        <Route
          path="/billing"
          element={
            <ProtectedRoute>
              <BillingDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/contact-us"
          element={
            <ProtectedRoute>
              <Contact />
            </ProtectedRoute>
          }
        />
        <Route
          path="/about-us"
          element={
            <ProtectedRoute>
              <AboutUs />
            </ProtectedRoute>
          }
        />
        <Route
          path="/change-password"
          element={
            <ProtectedRoute>
              <ChangePassword />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-report"
          element={
            <ProtectedRoute>
              <SalesReport />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
};

// Conditional Header Logic
const ConditionalHeader = () => {
  const location = useLocation();
  const noHeaderRoutes = ["/login", "/signup"];
  return !noHeaderRoutes.includes(location.pathname) ? <Header /> : null;
};

export default App;
