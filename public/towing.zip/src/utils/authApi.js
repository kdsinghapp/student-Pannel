import axios from "axios";

const API_URL = "http://193.203.161.2:8000";
const userToken = JSON.parse(localStorage.getItem("userToken"));
const user = localStorage.getItem("userTowingMen");
const userId = localStorage.getItem("userId");

export const registerTowingMan = async (data) => {
  try {
    const response = await axios.post(`${API_URL}/towing/register`, data);
    console.log("Response:-", response.data);

    return response.data;
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const loginTowingMan = async (data) => {
  try {
    const response = await axios.post(`${API_URL}/towing/login`, data);
    console.log("Data========>>>>>>>", response);
    if (
      response.data.data.adminVerification.status !== "Pending" ||
      response.data.data.adminVerification.status !== "Rejected"
    ) {
      console.log("Response token", response.data);
      localStorage.setItem("userToken", JSON.stringify(response.data.token));
      localStorage.setItem("userTowingMen", JSON.stringify(response.data.data));
      localStorage.setItem("userId", JSON.stringify(response.data.data.id));
      return response;
    }
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const changePasswordTowmen = async (data) => {
  console.log("User Id", userId);
  const cleanUserId = userId.replace(/^"|"$/g, "");
  try {
    const response = await axios.post(
      `${API_URL}/towing/change-password/${cleanUserId}`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      }
    );
    console.log("Response:-", response.data);
    return response.data;
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const getUserById = async (userId) => {
  console.log("getUserById", userId, typeof userId);

  const cleanUserId = userId.replace(/^"|"$/g, "");

  try {
    const response = await axios.get(
      `${API_URL}/towing/get-towman/${cleanUserId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      }
    );
    if (response.status) {
      console.log("Response", response.data);
      return response.data;
    }
  } catch (error) {
    console.error("Error in API call:", error);
  }
};

export const getTowingRequest = async () => {
  const cleanUserId = userId.replace(/^"|"$/g, "");
  try {
    const response = await axios.post(
      `${API_URL}/towing/all-requests/${cleanUserId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const getTowingRequestById = async (id) => {
  try {
    const response = await axios.post(`${API_URL}/towing/get-requests/${id}`);
    return response.data;
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const updateTowMan = async (data) => {
  const cleanUserId = userId.replace(/^"|"$/g, "");
  try {
    const response = await axios.post(
      `${API_URL}/towing/update-towman/${cleanUserId}`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      }
    );
    console.log("Response", response.data);

    return response.data;
  } catch (error) {
    console.error("Error in Register:-", error);
  }
};

export const findUserById = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/buyer/find-user`, data, {
      headers: {
        "Content-Type": "application/json",
        //   Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching User:-", error);
    throw error;
  }
};

export const acceptRejectRequest = async (data) => {
  console.log(userToken);
  console.log("User Id", userId);
  const cleanUserId = userId.replace(/^"|"$/g, "");
  console.log("Data========>>>>>>>>>", data);
  const allData = {
    towmanId: cleanUserId,
    action: data.action,
  };
  try {
    const res = await axios.post(
      `${API_URL}/towing/request/${data?.id}`,
      allData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
      }
    );
    return res.data;
  } catch (error) {
    console.error("Error fetching Requests:-", error);
    throw error;
  }
};
