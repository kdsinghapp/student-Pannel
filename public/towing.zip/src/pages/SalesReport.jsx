import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import SalesMechanic from "../components/SalesMechanic";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getTowingRequest } from "../utils/authApi";
import { useNavigate } from "react-router-dom";
import TalkClientRequest from "../components/TalkClientRequest";
// import img1 from "../../assets/img/notfounddata.png";
import * as XLSX from "xlsx";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

export default function SalesReport() {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});

  const [currentPage, setCurrentPage] = useState(1);
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);
  const [isCooldown, setIsCooldown] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const handleOpenModal = (data) => {
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await getTowingRequest();
        setRequests(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      }
    };
    fetchRequests();
  }, [user]);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleDownloadReport = () => {
    if (isCooldown) {
      alert(`Please wait ${countdown} seconds before downloading again.`);
      return;
    }

    if (allRequests.length === 0) {
      alert("No data available to download.");
      return;
    }

    const worksheetData = allRequests.map((request) => ({
      "Owner Name": request?.user?.name || "N/A",
      Email: request?.user?.email || "N/A",
      Address: request?.user?.address || "N/A",
      Brand: request?.car?.car_name || "N/A",
      "Vehicle Price": request?.car?.car_price || "N/A",
      "Inspection Location":
        request?.locationType === "UserPlace"
          ? "User Location"
          : request?.locationType === "Shop"
          ? "Shop"
          : "N/A",
      "Inspection Charges": request?.amount || "N/A",
      "Payment Status": request?.paymentId ? "Received" : "Pending",
      "Inspection Date": request?.createdAt
        ? new Date(request.createdAt).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })
        : "N/A",
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sales Report");

    XLSX.writeFile(workbook, "SalesReport.xlsx");

    setIsCooldown(true);
    setCountdown(30);
  };

  useEffect(() => {
    if (isCooldown && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);

      return () => clearTimeout(timer);
    }

    if (countdown === 0) {
      setIsCooldown(false);
    }
  }, [isCooldown, countdown]);

  return (
    <>
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">Billing</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div
                        className="d-flex"
                        style={{
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        <h4 className="user-profile-card-title">
                          Sales Report:
                        </h4>
                        <button
                          className="btn-group btn btn-primary"
                          onClick={handleDownloadReport}
                          style={{
                            alignItems: "center",
                            justifyContent: "space-between",
                            cursor: isCooldown ? "not-allowed" : "pointer",
                            opacity: isCooldown ? 0.6 : 1,
                          }}
                          disabled={isCooldown}
                        >
                          <i
                            class="fa-regular fa-file-excel"
                            style={{ marginRight: "10px" }}
                          ></i>
                          {isCooldown
                            ? `Wait ${countdown}s`
                            : "Download Report"}
                        </button>
                      </div>
                      <div className="table-responsive">
                        <table className="table text-nowrap">
                          <thead>
                            <tr>
                              <th>Owner Name</th>
                              <th>Email</th>
                              <th>Address</th>
                              <th>Brand</th>
                              <th>Vehicle Price</th>
                              <th>Tow Charges</th>
                              <th>Payment Status</th>
                              <th>Tow Status</th>
                              <th>Request Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <SalesMechanic allRequests={allRequests} />
                          </tbody>
                        </table>
                      </div>
                      {totalPages > 1 && (
                        <div className="pagination-area">
                          <ul className="pagination">
                            <li
                              className={`page-item ${
                                currentPage === 1 ? "disabled" : ""
                              }`}
                            >
                              <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (currentPage > 1)
                                    handlePageChange(currentPage - 1);
                                }}
                                aria-label="Previous"
                              >
                                <i className="far fa-arrow-left" />
                              </a>
                            </li>

                            {Array.from(
                              { length: totalPages },
                              (_, i) => i + 1
                            ).map((pageNumber) => (
                              <li
                                key={pageNumber}
                                className={`page-item ${
                                  pageNumber === currentPage ? "active" : ""
                                }`}
                              >
                                <a
                                  className="page-link"
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handlePageChange(pageNumber);
                                  }}
                                >
                                  {pageNumber}
                                </a>
                              </li>
                            ))}

                            <li
                              className={`page-item ${
                                currentPage === totalPages ? "disabled" : ""
                              }`}
                            >
                              <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (currentPage < totalPages)
                                    handlePageChange(currentPage + 1);
                                }}
                                aria-label="Next"
                              >
                                <i className="far fa-arrow-right" />
                              </a>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
}
