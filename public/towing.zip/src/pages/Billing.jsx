import React from 'react'
import Sidebar from '../components/Sidebar'
import img1 from "../assets/img/car/01.jpg"
import img2 from "../assets/img/car/02.jpg"
import img3 from "../assets/img/car/03.jpg"
import img4 from "../assets/img/car/04.jpg"
import img5 from "../assets/img/car/05.jpg"
import img6 from "../assets/img/car/06.jpg"

const Billing = () => {
    return (
        <>
            {/* <div className="preloader">
                <div className="loader-ripple">
                    <div></div>
                    <div></div>
                </div>
            </div> */}
            <div class="user-profile py-120">
                <div class="container">
                    <div class="row">
                        <Sidebar />
                        <div class="col-lg-9">
                            <div class="user-profile-wrapper">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="table-responsive">
                                            <table class="table text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Car Info</th>
                                                        <th>Brand</th>

                                                        <th>Towing Amount</th>
                                                        <th>Due date</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img1} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img2} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img3} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img4} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img5} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#"><img alt="" src={img6} />
                                                                    <div class="table-list-content">
                                                                        <h6>Mercedes Benz Car</h6><span>Car ID: #123456</span>
                                                                    </div></a>
                                                            </div>
                                                        </td>
                                                        <td>Ferrari</td>

                                                        <td>$50,650</td>
                                                        <td> May 08, 2024 </td>
                                                        <td><span class="badge badge-success">Received</span></td>
                                                        <td>
                                                            <a aria-label="Details" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-eye"></i></a> <a aria-label="Edit" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-pen"></i></a> <a aria-label="Delete" class="btn btn-outline-danger btn-sm rounded-2" data-bs-toggle="tooltip" href="#"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="pagination-area">
                                            <div aria-label="Page navigation example">
                                                <ul class="pagination my-3">
                                                    <li class="page-item">
                                                        <a aria-label="Previous" class="page-link" href="#"><span aria-hidden="true"><i class="far fa-angle-double-left"></i></span></a>
                                                    </li>
                                                    <li class="page-item active">
                                                        <a class="page-link" href="#">1</a>
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">2</a>
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">3</a>
                                                    </li>
                                                    <li class="page-item">
                                                        <a aria-label="Next" class="page-link" href="#"><span aria-hidden="true"><i class="far fa-angle-double-right"></i></span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Billing