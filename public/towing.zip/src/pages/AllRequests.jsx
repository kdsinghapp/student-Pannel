import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
// import img1 from "../../assets/img/notfounddata.png";
import { acceptRejectRequest, getTowingRequest } from "../utils/authApi";
import Sidebar from "../components/Sidebar";
import TalkClientRequest from "../components/TalkClientRequest";
import Footer from "../components/Footer";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

const AllRequests = () => {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);

  const handleOpenModal = (data) => {
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      setLoading(true);
      try {
        const response = await getTowingRequest();
        setRequests(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchRequests();
  }, []);

  const handleAcceptReject = async (id, action) => {

    Swal.fire({
      title: `Are you sure you want to ${
        action.toLowerCase() === "accepted" ? "accept" : "reject"
      } this request?`,
      text: "This action cannot be undone!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: action === "Accepted" ? "#28a745" : "#dc3545",
      cancelButtonColor: "#6c757d",
      confirmButtonText: `Yes, ${
        action.toLowerCase() === "accepted" ? "accept" : "reject"
      }`,
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const previousRequests = [...allRequests];

        setRequests((prevRequests) =>
          prevRequests.map((request) =>
            request._id === id ? { ...request, status: action } : request
          )
        );

        try {
          const payload = {
            id,
            towmanId: user?.id,
            action,
          };

          const res = await acceptRejectRequest(payload);

          Swal.fire(
            `${action} Successful!`,
            `The request has been ${action.toLowerCase()} successfully.`,
            "success"
          );
        } catch (error) {
          console.error("Error updating request:", error);
          setRequests(previousRequests);
          Swal.fire(
            "Error",
            `Failed to ${action.toLowerCase()} the request. Please try again.`,
            "error"
          );
        }
      }
    });
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const image = allRequests[0]?.car?.image;
  const imageUrl = `/path/to/images/${image}`;

  return (
    <>
      <main className="main">
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="user-profile-card">
                    <div
                      className="d-flex w-100 user-profile-card-title"
                      style={{
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <h4 className="">All Requests Received for Towing</h4>
                      <h4 className="">
                        Total Requests:- {allRequests?.length}
                      </h4>
                    </div>
                    <div className="row">
                      {currentData.length ? (
                        currentData.map((allRequest, index) => (
                          <div className="col-lg-12" key={index}>
                            <div className="car-item d-flex align-items-center">
                              <div className="col-md-3">
                                <img
                                  alt="Car Image"
                                  src={`http://193.203.161.2:8000/images/${allRequest?.carId?.image}`}
                                  
                                  style={{
                                    width: "100%",
                                    borderRadius: 10,
                                  }}
                                />
                              </div>
                              <div className="car-content sideborder col-md-6">
                                <h6>
                                  <a className="me-3" href="#">
                                    {allRequest?.carId?.car_name || "Car Model"}
                                  </a>
                                </h6>
                                <ul className="car-list">
                                  <li>
                                    <strong style={{ color: "black" }}>
                                      Car Type:
                                    </strong>{" "}
                                    {allRequest?.carDetails?.type ||
                                      "No inspection points"}
                                  </li>
                                  <li>
                                    <strong style={{ color: "black" }}>
                                      Car Size:
                                    </strong>{" "}
                                    {allRequest?.carDetails?.size ||
                                      "No inspection points"}
                                  </li>
                                </ul>
                                <div className="d-flex">
                                  <h6>
                                    <strong className="text-primary">
                                      Car Price:
                                    </strong>{" "}
                                    $ {allRequest?.carId?.car_price || "N/A"}.00
                                  </h6>
                                  &nbsp;
                                  <h6>
                                    <strong className="text-primary">
                                      Service Cost:
                                    </strong>{" "}
                                    {allRequest.amount
                                      ? new Intl.NumberFormat("en-US", {
                                          style: "currency",
                                          currency: "USD",
                                        }).format(allRequest.amount)
                                      : "N/A"}
                                  </h6>
                                </div>
                              </div>
                              <div className="btnns col-md-3 p-2">
                                <div
                                  className="mb-2"
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    padding: "0px 5px",
                                  }}
                                >
                                  {allRequest.status === "Accepted" ? (
                                    <button
                                      className="btn btn-warning w-100"
                                      disabled
                                    >
                                      Accepted
                                    </button>
                                  ) : allRequest.status !== "Rejected" ? (
                                    <button
                                      className="btn text-white btn-warning"
                                      onClick={() =>
                                        handleAcceptReject(
                                          allRequest._id,
                                          "Accepted"
                                        )
                                      }
                                    >
                                      Accept
                                    </button>
                                  ) : null}

                                  {allRequest.status === "Rejected" ? (
                                    <button
                                      className="btn btn-danger w-100"
                                      disabled
                                    >
                                      Rejected
                                    </button>
                                  ) : allRequest.status !== "Accepted" ? (
                                    <button
                                      className="btn btn-danger"
                                      onClick={() =>
                                        handleAcceptReject(
                                          allRequest._id,
                                          "Rejected"
                                        )
                                      }
                                      style={{ marginLeft: "10px" }}
                                    >
                                      Reject
                                    </button>
                                  ) : null}
                                </div>
                                <div className="mb-2 mt-2 w-100">
                                  <button
                                    className="btn btn-primary w-100"
                                    onClick={() => handleOpenModal(allRequest)}
                                  >
                                    Talk to Client
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: "100%",
                            height: "60vh",
                          }}
                        >
                          {/* <div className=""><img src={img1} /></div> */}
                        </div>
                      )}
                    </div>
                    {totalPages > 1 && (
                      <div className="pagination-area">
                        <ul className="pagination">
                          <li
                            className={`page-item ${
                              currentPage === 1 ? "disabled" : ""
                            }`}
                          >
                            <a
                              className="page-link"
                              href="#"
                              onClick={(e) => {
                                e.preventDefault();
                                if (currentPage > 1)
                                  handlePageChange(currentPage - 1);
                              }}
                              aria-label="Previous"
                            >
                              <i className="far fa-arrow-left" />
                            </a>
                          </li>

                          {Array.from(
                            { length: totalPages },
                            (_, i) => i + 1
                          ).map((pageNumber) => (
                            <li
                              key={pageNumber}
                              className={`page-item ${
                                pageNumber === currentPage ? "active" : ""
                              }`}
                            >
                              <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  handlePageChange(pageNumber);
                                }}
                              >
                                {pageNumber}
                              </a>
                            </li>
                          ))}

                          <li
                            className={`page-item ${
                              currentPage === totalPages ? "disabled" : ""
                            }`}
                          >
                            <a
                              className="page-link"
                              href="#"
                              onClick={(e) => {
                                e.preventDefault();
                                if (currentPage < totalPages)
                                  handlePageChange(currentPage + 1);
                              }}
                              aria-label="Next"
                            >
                              <i className="far fa-arrow-right" />
                            </a>
                          </li>
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
};

export default AllRequests;
