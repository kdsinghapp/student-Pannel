import React from 'react'
import Sidebar from '../components/Sidebar'
import img1 from "../assets/img/car/01.jpg"
import img2 from "../assets/img/car/02.jpg"
import img3 from "../assets/img/car/03.jpg"
import img4 from "../assets/img/car/04.jpg"
import img5 from "../assets/img/car/05.jpg"
import img6 from "../assets/img/car/06.jpg"

const TransportList = () => {
    return (
        <>
            {/* <div className="preloader">
                <div className="loader-ripple">
                    <div></div>
                    <div></div>
                </div>
            </div> */}
            <div class="user-profile py-120">
                <div class="container">
                    <div class="row">
                        <Sidebar />
                        <div class="col-lg-9">
                            <div class="user-profile-wrapper">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="user-profile-card">
                                            <h4 class="user-profile-card-title">Vehicle needs transport List</h4>
                                            <div class="car-area list p-0">
                                                <div class="container">
                                                    <div class="row justify-content-center">
                                                        <div class="col-lg-12">
                                                            <div class="row">
                                                                <div class="col-md-6 col-lg-12">
                                                                    <div class="car-item">
                                                                        <div class="col-md-3">

                                                                            <div class="pt-2"><img alt="" src={img3} style={{ width: "100%", borderRadius: "10px" }} /></div>
                                                                        </div>
                                                                        <div class="car-content sideborder col-md-6">
                                                                            <h6><a class="me-3" href="#">Shipping 2022 Chrysler 300 C </a></h6>
                                                                            <ul class="car-list">
                                                                                <li><span class="text-danger"><strong>Origin:</strong></span> 2200 Fountain view Houston, <br /> TX 77057 713-987-9876</li>
                                                                                <li><span class="text-success"><strong>Destination:</strong></span> 2222 Settlers way BlvdSugar Land, <br />TX 77478281-999-9999</li>

                                                                            </ul>

                                                                        </div>
                                                                        <div class="btnns col-md-3">

                                                                            <div class="mb-2 mt-2">
                                                                                <a class="btn btn-primary w-100" href="#">Talk to Client</a>
                                                                            </div>
                                                                            <div class="mb-2">
                                                                                <a class="btn btn-warning w-100" href="#">Send Quote to Client</a>
                                                                            </div>
                                                                            <div>
                                                                                <a class="btn btn-default border w-100" href="#">Acquire & Accept Shipping</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6 col-lg-12">
                                                                    <div class="car-item">
                                                                        <div class="col-md-3">

                                                                            <div class="pt-2"><img alt="" src={img4} style={{ width: "100%", borderRadius: "10px" }} /></div>
                                                                        </div>
                                                                        <div class="car-content sideborder col-md-6">
                                                                            <h6><a class="me-3" href="#">Shipping 2022 Chrysler 300 C </a></h6>
                                                                            <ul class="car-list">
                                                                                <li><span class="text-danger"><strong>Origin:</strong></span> 2200 Fountain viewHouston, <br />TX 77057713-987-9876</li>
                                                                                <li><span class="text-success"><strong>Destination:</strong></span> 4115 Alsafa Khobar, <br />34222 05-999-9999</li>

                                                                            </ul>

                                                                        </div>
                                                                        <div class="btnns col-md-3">

                                                                            <div class="mb-2 mt-2">
                                                                                <a class="btn btn-primary w-100" href="#">Talk to Client</a>
                                                                            </div>
                                                                            <div class="mb-2">
                                                                                <a class="btn btn-warning w-100" href="#">Send Quote to Client</a>
                                                                            </div>
                                                                            <div>
                                                                                <a class="btn btn-default border w-100" href="#">Acquire & Accept Shipping</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6 col-lg-12">
                                                                    <div class="car-item">
                                                                        <div class="col-md-3">

                                                                            <div class="pt-2"><img alt="" src={img5} style={{ width: "100%", borderRadius: "10px" }} /></div>
                                                                        </div>
                                                                        <div class="car-content sideborder col-md-6">
                                                                            <h6><a class="me-3" href="#">Shipping 2022 Chrysler 300 C </a></h6>
                                                                            <ul class="car-list">
                                                                                <li><span class="text-danger"><strong>Origin:</strong></span> 2200 Fountain view <br />Houston, TX 77057 713-987-9876</li>
                                                                                <li><span class="text-success"><strong>Destination:</strong></span> 2222 Settlers way Blvd <br /> Sugar Land, TX 77478 281-999-9999</li>

                                                                            </ul>

                                                                        </div>
                                                                        <div class="btnns col-md-3">

                                                                            <div class="mb-2 mt-2">
                                                                                <a class="btn btn-primary w-100" href="#">Talk to Client</a>
                                                                            </div>
                                                                            <div class="mb-2">
                                                                                <a class="btn btn-warning w-100" href="#">Send Quote to Client</a>
                                                                            </div>
                                                                            <div>
                                                                                <a class="btn btn-default border w-100" href="#">Acquire & Accept Shipping</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="pagination-area">
                                                                <span class="text-danger"></span>
                                                                <div aria-label="Page navigation example">
                                                                    <span class="text-danger"></span>
                                                                    <ul class="pagination">
                                                                        <li class="page-item"><span class="text-danger"><a aria-label="Previous" class="page-link" href="#"><span aria-hidden="true"><i class="far fa-arrow-left"></i></span></a></span></li>
                                                                        <li style={{ listStyle: "none" }}></li>
                                                                        <li class="page-item active">
                                                                            <a class="page-link" href="#">1</a>
                                                                        </li>
                                                                        <li class="page-item">
                                                                            <a class="page-link" href="#">2</a>
                                                                        </li>
                                                                        <li class="page-item">
                                                                            <a class="page-link" href="#">3</a>
                                                                        </li>
                                                                        <li class="page-item">
                                                                            <a aria-label="Next" class="page-link" href="#"><span aria-hidden="true"><i class="far fa-arrow-right"></i></span></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default TransportList