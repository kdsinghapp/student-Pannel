import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerTowingMan } from "../utils/authApi";
import { signinUser } from "../store/features/auth/authSlice";
import { useDispatch, useSelector } from "react-redux";

const SignUp = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    vehicleType: "",
    drivingLicense: "",
    mainServiceLocation: "",
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [isAlertVisible, setIsAlertVisible] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isLoading, isSuccess, isError, message, user } = useSelector(
    (state) => state.auth
  );

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Name is required.";
    if (!formData.email.includes("@")) newErrors.email = "Invalid email.";
    if (formData.password.length < 8)
      newErrors.password = "Password must be at least 8 characters.";
    if (!/^\d{10}$/.test(formData.phone))
      newErrors.phone = "Phone must be 10 digits.";
    if (!formData.vehicleType.trim())
      newErrors.vehicleType = "Vehicle Type is required.";
    if (!formData.drivingLicense.trim())
      newErrors.drivingLicense = "Driving License is required.";
    if (!formData.mainServiceLocation.trim())
      newErrors.mainServiceLocation = "Service Location is required.";

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      dispatch(signinUser(formData));
      navigate('/login')
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-area mt-5 mb-5">
      <div className="container">
        <div className="col-md-5 mx-auto">
          <div className="login-form">
            <div className="login-header">
              <h3>Sign Up</h3>
              <p>Create your account</p>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Name</label>
                <input
                  className={`form-control ${errors.name ? "is-invalid" : ""}`}
                  placeholder="Your Name"
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
                {errors.name && (
                  <small className="text-danger">{errors.name}</small>
                )}
              </div>
              <div className="form-group">
                <label>Email Address</label>
                <input
                  className={`form-control ${errors.email ? "is-invalid" : ""}`}
                  placeholder="Your Email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                {errors.email && (
                  <small className="text-danger">{errors.email}</small>
                )}
              </div>
              <div className="form-group">
                <label>Password</label>
                <input
                  className={`form-control ${
                    errors.password ? "is-invalid" : ""
                  }`}
                  placeholder="Your Password"
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                />
                {errors.password && (
                  <small className="text-danger">{errors.password}</small>
                )}
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input
                  className={`form-control ${errors.phone ? "is-invalid" : ""}`}
                  placeholder="Your Phone"
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                />
                {errors.phone && (
                  <small className="text-danger">{errors.phone}</small>
                )}
              </div>
              <div className="form-group">
                <label>Vehicle Type</label>
                <input
                  className={`form-control ${
                    errors.vehicleType ? "is-invalid" : ""
                  }`}
                  placeholder="Vehicle Type"
                  type="text"
                  name="vehicleType"
                  value={formData.vehicleType}
                  onChange={handleChange}
                />
                {errors.vehicleType && (
                  <small className="text-danger">{errors.vehicleType}</small>
                )}
              </div>
              <div className="form-group">
                <label>Driving License</label>
                <input
                  className={`form-control ${
                    errors.drivingLicense ? "is-invalid" : ""
                  }`}
                  placeholder="Driving License"
                  type="text"
                  name="drivingLicense"
                  value={formData.drivingLicense}
                  onChange={handleChange}
                />
                {errors.drivingLicense && (
                  <small className="text-danger">{errors.drivingLicense}</small>
                )}
              </div>
              <div className="form-group">
                <label>Main Service Location</label>
                <input
                  className={`form-control ${
                    errors.mainServiceLocation ? "is-invalid" : ""
                  }`}
                  placeholder="Service Location"
                  type="text"
                  name="mainServiceLocation"
                  value={formData.mainServiceLocation}
                  onChange={handleChange}
                />
                {errors.mainServiceLocation && (
                  <small className="text-danger">
                    {errors.mainServiceLocation}
                  </small>
                )}
              </div>
              <div className="d-flex align-items-center">
                <button
                  className="theme-btn btn btn-primary"
                  type="submit"
                  disabled={loading}
                >
                  {loading ? (
                    <span
                      className="spinner-border spinner-border-sm"
                      role="status"
                      aria-hidden="true"
                    ></span>
                  ) : (
                    "Sign Up"
                  )}
                </button>
              </div>
              {isAlertVisible && (
                <div className="alert alert-dismissible alert-danger mt-3">
                  <strong>{error}</strong>
                </div>
              )}
            </form>
            <div
              className="d-flex"
              style={{ alignItems: "center", justifyContent: "center" }}
            >
              <hr class="custom-line" />
              x
              <hr class="custom-line" />
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Link
                to="/login"
                className="theme-btn btn btn-primary"
                style={{ border: "none" }}
              >
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
