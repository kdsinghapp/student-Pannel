import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import TalkClientRequest from "../components/TalkClientRequest";
import Navbar from "../components/Navbar";
import { getTowingRequest } from "../utils/authApi";
// import img1 from "../../assets/img/notfounddata.png";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

const PaymentPending = () => {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);

  const handleOpenModal = (data) => {
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      setLoading(true);
      try {
        const response = await getTowingRequest();
        setRequests(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchRequests();
  }, []);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <>
      <main className="main">
        <Navbar />
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Vehicle Needs Tow Payment Pending:
                        </h4>
                        <div className="car-area list p-0">
                          <div className="container">
                            <div className="row justify-content-center">
                              <div className="col-lg-12">
                                <div className="row">
                                  {currentData.length ? (
                                    currentData.filter(
                                      (allRequest) =>
                                        allRequest?.paymentId === ""
                                    ).length ? (
                                      currentData
                                        .filter(
                                          (allRequest) =>
                                            (allRequest.paymentId === "" &&
                                              allRequest.paymentStatus ===
                                                "Pending") ||
                                            allRequest.paymentStatus ===
                                              "Failed"
                                        )
                                        .map((allRequest) => (
                                          <div
                                            className="col-lg-12"
                                            key={allRequest._id}
                                          >
                                            <div
                                              className="car-item d-flex"
                                              style={{
                                                alignItems: "center",
                                                justifyContent: "space-between",
                                                flexDirection: "row",
                                              }}
                                            >
                                              <div className="col-md-3">
                                                <div>
                                                  <img
                                                    alt={
                                                      allRequest?.carId?.car_name ||
                                                      "Car Image"
                                                    }
                                                    src={
                                                      `http://193.203.161.2:8000/images/${allRequest.carId?.image}` ||
                                                      "../assets/img/car/03.jpg"
                                                    }
                                                    style={{
                                                      width: "100%",
                                                      borderRadius: 10,
                                                    }}
                                                  />
                                                </div>
                                              </div>
                                              <div className="car-content sideborder col-md-6">
                                                <h6>
                                                  <a className="me-3" href="#">
                                                    {allRequest?.carId
                                                      ?.car_name || "Car Model"}
                                                  </a>
                                                </h6>
                                                <ul className="car-list">
                                                  <li>
                                                    <strong
                                                      style={{ color: "black" }}
                                                    >
                                                      Car Type:
                                                    </strong>{" "}
                                                    {allRequest?.carDetails
                                                      ?.type ||
                                                      "No inspection points"}
                                                  </li>
                                                  <li>
                                                    <strong
                                                      style={{ color: "black" }}
                                                    >
                                                      Car Size:
                                                    </strong>{" "}
                                                    {allRequest?.carDetails
                                                      ?.size ||
                                                      "No inspection points"}
                                                  </li>
                                                </ul>
                                                <div
                                                  className="d-flex"
                                                  style={{
                                                    alignItems: "flex-start",
                                                    flexDirection: "column",
                                                  }}
                                                >
                                                  <h6>
                                                    <strong className="text-primary">
                                                      Car Price:
                                                    </strong>
                                                    ${" "}
                                                    {allRequest?.carId
                                                      ?.car_price || "N/A"}
                                                    .00
                                                  </h6>
                                                  <h6 className="mt-1">
                                                    <strong className="text-primary">
                                                      Service Cost:
                                                    </strong>{" "}
                                                    {allRequest.amount
                                                      ? new Intl.NumberFormat(
                                                          "en-US",
                                                          {
                                                            style: "currency",
                                                            currency: "USD",
                                                          }
                                                        ).format(
                                                          allRequest.amount
                                                        )
                                                      : "N/A"}
                                                  </h6>
                                                </div>
                                              </div>
                                              <div className="btnns col-md-3">
                                                <div className="mb-2 mt-2">
                                                  <button
                                                    className="btn text-white btn-primary w-100"
                                                    onClick={() =>
                                                      handleOpenModal(
                                                        allRequest
                                                      )
                                                    }
                                                  >
                                                    Contact Owner
                                                  </button>
                                                  <button className="btn btn-danger w-100 mt-4">
                                                    Payment Pending
                                                  </button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        ))
                                    ) : (
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "center",
                                          width: "100%",
                                          height: "60vh",
                                        }}
                                      >
                                        <div>
                                          {/* <img src={img1} alt="No Data Found" /> */}
                                          <h3>No Data Found</h3>
                                        </div>
                                      </div>
                                    )
                                  ) : (
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        width: "100%",
                                        height: "60vh",
                                      }}
                                    >
                                      <div>
                                        {/* <img src={img1} alt="No Data Found" /> */}
                                        <h3>No Data Found</h3>
                                      </div>
                                    </div>
                                  )}
                                </div>
                                {totalPages > 1 && (
                                  <div className="pagination-area">
                                    <ul className="pagination">
                                      <li
                                        className={`page-item ${
                                          currentPage === 1 ? "disabled" : ""
                                        }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage > 1)
                                              handlePageChange(currentPage - 1);
                                          }}
                                          aria-label="Previous"
                                        >
                                          <i className="far fa-arrow-left" />
                                        </a>
                                      </li>

                                      {Array.from(
                                        { length: totalPages },
                                        (_, i) => i + 1
                                      ).map((pageNumber) => (
                                        <li
                                          key={pageNumber}
                                          className={`page-item ${
                                            pageNumber === currentPage
                                              ? "active"
                                              : ""
                                          }`}
                                        >
                                          <a
                                            className="page-link"
                                            href="#"
                                            onClick={(e) => {
                                              e.preventDefault();
                                              handlePageChange(pageNumber);
                                            }}
                                          >
                                            {pageNumber}
                                          </a>
                                        </li>
                                      ))}

                                      <li
                                        className={`page-item ${
                                          currentPage === totalPages
                                            ? "disabled"
                                            : ""
                                        }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage < totalPages)
                                              handlePageChange(currentPage + 1);
                                          }}
                                          aria-label="Next"
                                        >
                                          <i className="far fa-arrow-right" />
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
};

export default PaymentPending;
