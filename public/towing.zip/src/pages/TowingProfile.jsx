import React from 'react'
import Sidebar from '../components/Sidebar'

const TowingProfile = () => {

    return (
        <>
            <div class="user-profile py-120">
                <div class="container">
                    <div class="row">
                        <Sidebar />
                        <div className="col-lg-9">
                            <div className="user-profile-wrapper">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="user-profile-card">
                                            <h4 className="user-profile-card-title">Edit Profile</h4>
                                            <div className="user-profile-form">
                                                <form action="#">
                                                    <div className="row">
                                                        <div className="col-md-6">
                                                            <div className="form-group">
                                                                <label>First Name</label> <input className="form-control" placeholder="First Name" type="text" value="Michel" />
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6">
                                                            <div className="form-group">
                                                                <label>Last Name</label> <input className="form-control" placeholder="Last Name" type="text" value="jones" />
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6">
                                                            <div className="form-group">
                                                                <label>Email</label> <input className="form-control" placeholder="Email" type="text" value="test@mail.com" />
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6">
                                                            <div className="form-group">
                                                                <label>Phone</label> <input className="form-control" placeholder="Phone" type="text" value="+X XXX XXX XXX" />
                                                            </div>
                                                        </div>
                                                        <div className="col-md-12">
                                                            <div className="form-group">
                                                                <label>Address</label> <input className="form-control" placeholder="Address" type="text" value="123, New City, REW" />
                                                            </div>
                                                        </div>
                                                    </div><button className="theme-btn my-3" type="button"><span className="far fa-user"></span> Save Changes</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default TowingProfile
