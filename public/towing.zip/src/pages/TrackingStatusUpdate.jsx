import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { getTowingRequestById } from "../utils/authApi";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

const TrackingStatusUpdate = () => {
  const [formData, setFormData] = useState({
    trackingId: "",
    driverName: "",
    phone: "",
    drivingLicense: "",
    reachingTime: "",
    updateStatus: "",
    pickupStatus: "",
  });
  const [requestData, setRequestData] = useState({});
  const [errors, setErrors] = useState({});
  const id = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    setErrors({ ...errors, [e.target.name]: "" });
  };

  const validateForm = () => {
    let newErrors = {};
    if (!formData.driverName.trim())
      newErrors.driverName = "Driver name is required";
    if (!formData.trackingId.trim())
      newErrors.trackingId = "Tracking ID is required";
    if (!formData.updateStatus)
      newErrors.updateStatus = "Please select a status";
    if (!formData.phone.trim()) newErrors.phone = "Phone number is required";
    if (!formData.drivingLicense.trim())
      newErrors.drivingLicense = "Driving license is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to update this request?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, update it!",
      cancelButtonText: "No, cancel",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const response = await axios.put(
            `http://193.203.161.2:8000/towing/update-requests/${id.id}`,
            formData,
            {
              headers: {
                "Content-Type": "application/json",
              },
            }
          );

          Swal.fire({
            icon: "success",
            title: "Updated!",
            text: "Request updated successfully!",
            confirmButtonColor: "#3085d6",
          }).then(() => {
            navigate("/track-towings");
          });
        } catch (error) {
          console.error("Error updating request:", error);

          // Show error alert
          Swal.fire({
            icon: "error",
            title: "Error",
            text: "Failed to update request. Please try again!",
            confirmButtonColor: "#d33",
          });
        }
      }
    });
  };

  const fetchRequests = async () => {
    try {
      const requestId = id.id || id;
      const response = await getTowingRequestById(requestId);
      setRequestData(response.data);
      setFormData({
        trackingId: response?.data?._id,
        driverName: response?.data?.dispatchDetails?.driverName || "",
        phone: response?.data?.dispatchDetails?.phone || "",
        drivingLicense: response?.data?.dispatchDetails?.drivingLicense || "",
        reachingTime: response?.data?.dispatchDetails?.reachingTime || "",
        updateStatus: response?.data?.dispatchDetails?.updateStatus || "",
        pickupStatus: response?.data?.dispatchDetails?.pickupStatus || "",
      });
    } catch (error) {
      console.error("Error in Fetching Requests:", error.message);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  return (
    <main className="main">
      <div className="user-profile py-120">
        <div className="container">
          <div className="row">
            <Sidebar />
            <div className="col-lg-9">
              <div className="user-profile-wrapper">
                <div className="user-profile-card">
                  <div
                    className="d-flex w-100 user-profile-card-title"
                    style={{
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h4 className="">Update Vehicle Status:</h4>
                    <h5>
                      Current Status:{" "}
                      {formData.updateStatus
                        ? formData.updateStatus.charAt(0).toUpperCase() +
                          formData.updateStatus.slice(1)
                        : ""}
                    </h5>
                  </div>
                  <div className="row">
                    {/* Owner Details */}
                    <h5>Owner Details</h5>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Vehicle Owner Name:-
                        </label>
                        <input
                          className="form-control"
                          placeholder="Owner"
                          disabled
                          value={requestData?.user?.name}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Vehicle Owner Email:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.user?.email}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Vehicle Owner Address:-
                        </label>
                        <input
                          className="form-control"
                          placeholder="Address"
                          disabled
                          value={requestData?.user?.address}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Payment Status:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={
                            requestData.paymentStatus === "Pending"
                              ? "Pending"
                              : "Completed"
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Payment Id:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.paymentId}
                        />
                      </div>
                    </div>

                    {/* Car Details */}
                    <h5 className="mt-3">Car Details</h5>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Pickup Car Name:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.carId?.car_name}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Pickup Location:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.pickupLocation || ""}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Vehicle Type:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.carDetails?.type || "Not Found"}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Pickup Car Size:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.carDetails?.size || "Not Found"}
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mt-2">
                      <div className="form-group">
                        <label
                          className="text-black"
                          style={{ fontWeight: "500", fontSize: "15px" }}
                        >
                          Pickup Car Price:-
                        </label>
                        <input
                          className="form-control"
                          disabled
                          value={requestData?.carId?.car_price || "Not Found"}
                        />
                      </div>
                    </div>
                    <form onSubmit={handleSubmit}>
                      {/* Towing Details */}
                      <h5 className="mt-3">Towing Details</h5>
                      <div className="row">
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Tracking ID:-
                            </label>
                            <input
                              disabled
                              className="form-control"
                              value={requestData._id}
                            />
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Driver Name:-
                            </label>
                            <input
                              className={`form-control ${
                                errors.driverName ? "is-invalid" : ""
                              }`}
                              placeholder="Driver name"
                              type="text"
                              name="driverName"
                              value={formData.driverName}
                              onChange={handleChange}
                            />
                            {errors.driverName && (
                              <small className="text-danger">
                                {errors.driverName}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Phone:-
                            </label>
                            <input
                              className={`form-control ${
                                errors.phone ? "is-invalid" : ""
                              }`}
                              placeholder="Driver Phone"
                              type="text"
                              name="phone"
                              value={formData.phone}
                              onChange={handleChange}
                            />
                            {errors.phone && (
                              <small className="text-danger">
                                {errors.phone}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Driving License:-
                            </label>
                            <input
                              className={`form-control ${
                                errors.drivingLicense ? "is-invalid" : ""
                              }`}
                              placeholder="Driving License"
                              type="text"
                              name="drivingLicense"
                              value={formData.drivingLicense}
                              onChange={handleChange}
                            />
                            {errors.drivingLicense && (
                              <small className="text-danger">
                                {errors.drivingLicense}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Reaching Time:-
                            </label>
                            <input
                              className={`form-control ${
                                errors.reachingTime ? "is-invalid" : ""
                              }`}
                              type="time"
                              name="reachingTime"
                              value={formData.reachingTime}
                              onChange={handleChange}
                            />
                            {errors.reachingTime && (
                              <small className="text-danger">
                                {errors.reachingTime}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Update Status:-
                            </label>
                            <select
                              className={`form-control ${
                                errors.updateStatus ? "is-invalid" : ""
                              }`}
                              name="updateStatus"
                              value={formData.updateStatus}
                              onChange={handleChange}
                            >
                              <option value="">Select Status</option>
                              <option value="pending">Pending</option>
                              <option value="in transit">In Transit</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                            {errors.updateStatus && (
                              <small className="text-danger">
                                {errors.updateStatus}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6 mt-2">
                          <div className="form-group">
                            <label
                              className="text-black"
                              style={{ fontWeight: "500", fontSize: "15px" }}
                            >
                              Pickup Status:-
                            </label>
                            <select
                              className={`form-control ${
                                errors.pickupStatus ? "is-invalid" : ""
                              }`}
                              name="pickupStatus"
                              value={formData.pickupStatus}
                              onChange={handleChange}
                            >
                              <option value="">Select Status</option>
                              <option value="true">Yes</option>
                              <option value="false">No</option>
                            </select>
                            {errors.pickupStatus && (
                              <small className="text-danger">
                                {errors.pickupStatus}
                              </small>
                            )}
                          </div>
                        </div>
                        <div className="d-flex align-items-center mt-2">
                          <button
                            className="theme-btn w-100 btn btn-primary"
                            type="submit"
                          >
                            Submit Status
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default TrackingStatusUpdate;
