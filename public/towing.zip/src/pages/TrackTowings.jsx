import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { getTowingRequest } from "../utils/authApi";
import { useNavigate } from "react-router-dom";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

const TrackTowings = () => {
  const [trackingStatus, setTrackingStatus] = useState([]);
  const [loading, setLoading] = useState(true);
  const dataPerPage = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = trackingStatus.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(trackingStatus.length / dataPerPage);
  const navigate = useNavigate();
  const [filterType, setFilterType] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);

  const handleOpenModal = (data) => {
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      setLoading(true);
      try {
        const response = await getTowingRequest();
        if (response.data) setTrackingStatus(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchRequests();
  }, []);

  const handleClickStatus = (id) => {
    navigate(`/track-towings/tracking-status-update/${id}`);
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  // Filter data based on the selected filter type
  const filteredData = currentData.filter((trackingStatus) => {
    if (filterType === "All") {
      return (
        trackingStatus.paymentStatus === "Completed" &&
        trackingStatus.paymentId &&
        trackingStatus.status === "Accepted"
      );
    } else if (filterType === "Delivered") {
      return (
        trackingStatus.paymentStatus === "Completed" &&
        trackingStatus.paymentId &&
        trackingStatus.status === "Accepted" &&
        trackingStatus.dispatchDetails?.updateStatus === "delivered"
      );
    } else if (filterType === "In Transit") {
      return (
        trackingStatus.paymentStatus === "Completed" &&
        trackingStatus.paymentId &&
        trackingStatus.status === "Accepted" &&
        trackingStatus.dispatchDetails?.updateStatus === "in transit"
      );
    } else if (filterType === "Pending") {
      return (
        trackingStatus.paymentStatus === "Completed" &&
        trackingStatus.paymentId &&
        trackingStatus.status === "Accepted" &&
        trackingStatus.dispatchDetails?.updateStatus === ""
      );
    }
    return false;
  });

  return (
    <main className="main">
      <div className="user-profile py-120">
        <div className="container">
          <div className="row">
            <Sidebar />
            <div className="col-lg-9">
              <div className="user-profile-wrapper">
                <div className="user-profile-card">
                  <div
                    className="d-flex w-100 user-profile-card-title"
                    style={{
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h4 className="">Track All Vehicles:</h4>
                    <div className="btn-group">
                      <button
                        style={{ width: "200px" }}
                        type="button"
                        className="btn btn-warning dropdown-toggle"
                        data-bs-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        {filterType === "All"
                          ? "All"
                          : filterType === "Delivered"
                          ? "Delivered"
                          : filterType === "In Transit"
                          ? "In Transit"
                          : filterType === "Pending"
                          ? "Pending"
                          : ""}
                      </button>
                      <ul className="dropdown-menu dropdown-menu-right">
                        <li>
                          <button
                            className="dropdown-item"
                            type="button"
                            onClick={() => setFilterType("All")}
                          >
                            All
                          </button>
                        </li>
                        <li>
                          <button
                            className="dropdown-item"
                            type="button"
                            onClick={() => setFilterType("Delivered")}
                          >
                            Delivered
                          </button>
                        </li>
                        <li>
                          <button
                            className="dropdown-item"
                            type="button"
                            onClick={() => setFilterType("In Transit")}
                          >
                            In Transit
                          </button>
                        </li>
                        <li>
                          <button
                            className="dropdown-item"
                            type="button"
                            onClick={() => setFilterType("Pending")}
                          >
                            Pending
                          </button>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="row">
                    {filteredData.length ? (
                      filteredData.map((trackingStatus, index) => (
                        <div className="col-lg-12" key={index}>
                          <div className="car-item d-flex align-items-center">
                            <div className="col-md-3">
                              <img
                                alt="Car Image"
                                src={`http://193.203.161.2:8000/images/${trackingStatus?.carId?.image}`}
                                style={{
                                  width: "100%",
                                  borderRadius: 10,
                                }}
                              />
                            </div>
                            <div className="car-content sideborder col-md-6">
                              <h6>
                                <a className="me-3" href="#">
                                  {trackingStatus?.carId?.car_name ||
                                    "Car Model"}
                                </a>
                              </h6>
                              <ul className="car-list">
                                <li>
                                  <strong style={{ color: "black" }}>
                                    Car Type:
                                  </strong>{" "}
                                  {trackingStatus?.carDetails?.type ||
                                    "No inspection points"}
                                </li>
                                <li>
                                  <strong style={{ color: "black" }}>
                                    Car Size:
                                  </strong>{" "}
                                  {trackingStatus?.carDetails?.size ||
                                    "No inspection points"}
                                </li>
                              </ul>
                              <div className="d-flex">
                                <h6>
                                  <strong className="text-primary">
                                    Car Price:
                                  </strong>{" "}
                                  ${trackingStatus?.carId?.car_price || "N/A"}
                                  .00
                                </h6>
                                &nbsp;
                                <h6>
                                  <strong className="text-primary">
                                    Service Cost:
                                  </strong>{" "}
                                  {trackingStatus.amount
                                    ? new Intl.NumberFormat("en-US", {
                                        style: "currency",
                                        currency: "USD",
                                      }).format(trackingStatus.amount)
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                            <div className="btnns col-md-3 p-2 position-relative">
                              <p
                                className="text-white rounded position-absolute"
                                style={{
                                  backgroundColor: "red",
                                  top: "0px",
                                  right: "10px",
                                  fontSize: "13px",
                                  padding: "0px 10px",
                                }}
                              >
                                {trackingStatus?.dispatchDetails
                                  ?.updateStatus || "Pending"}
                              </p>
                              <div
                                className="mt-4"
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  padding: "0px 5px",
                                }}
                              >
                                <button
                                  className="btn btn-primary w-100"
                                  onClick={() =>
                                    handleClickStatus(trackingStatus._id)
                                  }
                                >
                                  Update Status
                                </button>
                              </div>
                              <div className="mb-2 mt-2 w-100">
                                <button
                                  className="btn btn-warning w-100"
                                  onClick={() =>
                                    handleOpenModal(trackingStatus)
                                  }
                                >
                                  Talk to Client
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          width: "100%",
                          height: "60vh",
                        }}
                      >
                        <h5>No Vehicles Found</h5>
                      </div>
                    )}
                  </div>
                  {totalPages > 1 && (
                    <div className="pagination-area">
                      <ul className="pagination">
                        <li
                          className={`page-item ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                        >
                          <a
                            className="page-link"
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (currentPage > 1)
                                handlePageChange(currentPage - 1);
                            }}
                            aria-label="Previous"
                          >
                            <i className="far fa-arrow-left" />
                          </a>
                        </li>

                        {Array.from(
                          { length: totalPages },
                          (_, i) => i + 1
                        ).map((pageNumber) => (
                          <li
                            key={pageNumber}
                            className={`page-item ${
                              pageNumber === currentPage ? "active" : ""
                            }`}
                          >
                            <a
                              className="page-link"
                              href="#"
                              onClick={(e) => {
                                e.preventDefault();
                                handlePageChange(pageNumber);
                              }}
                            >
                              {pageNumber}
                            </a>
                          </li>
                        ))}

                        <li
                          className={`page-item ${
                            currentPage === totalPages ? "disabled" : ""
                          }`}
                        >
                          <a
                            className="page-link"
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (currentPage < totalPages)
                                handlePageChange(currentPage + 1);
                            }}
                            aria-label="Next"
                          >
                            <i className="far fa-arrow-right" />
                          </a>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal show={showModal} onClose={handleCloseModal}>
        {selectedRequest && (
          <div>
            <h3>Talk to Client</h3>
            <p>Client: {selectedRequest.clientName}</p>
            <p>Phone: {selectedRequest.clientPhone}</p>
          </div>
        )}
      </Modal>
    </main>
  );
};

export default TrackTowings;
