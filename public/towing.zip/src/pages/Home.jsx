import React from "react";
import Footer from "../components/Footer";
import Sidebar from "../components/Sidebar";
import ProfileDetails from "../components/ProfileDetails";
import Navbar from "../components/Navbar";

const Home = () => {

  return (
    <>
      <main className="main">
        <Navbar/>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <ProfileDetails />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default Home;
