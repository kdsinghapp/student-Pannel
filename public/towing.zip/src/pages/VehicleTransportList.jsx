import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { getTowingRequest } from "../utils/authApi";

const VehicleTransportList = () => {
  const [requests, setRequests] = useState([]);

  const getTowRequest = async () => {
    try {
      const res = await getTowingRequest();
      setRequests(res.data);
    } catch (error) {}
  };

  useEffect(() => {
    getTowRequest();
  }, []);

  return (
    <>
      <main class="main">
        <Navbar />
        <div class="user-profile py-120">
          <div class="container">
            <div class="row">
              <Sidebar />
              <div class="col-lg-9">
                <div class="user-profile-wrapper">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="user-profile-card">
                        <h4 class="user-profile-card-title">
                          Vehicle needs transport List
                        </h4>
                        <div class="car-area list p-0">
                          <div class="container">
                            <div class="row justify-content-center">
                              <div class="col-lg-12">
                                <div class="row">
                                  {requests?.map(() => (
                                    <div class="col-md-6 col-lg-12">
                                      <div class="car-item">
                                        <div class="col-md-3">
                                          <div class="pt-2">
                                            <img
                                              alt=""
                                              src="../assets/img/car/03.jpg"
                                              style={{
                                                width: "100%",
                                                borderRadius: "10px",
                                              }}
                                            />
                                          </div>
                                        </div>
                                        <div class="car-content sideborder col-md-6">
                                          <h6>
                                            <a class="me-3" href="#">
                                              Shipping 2022 Chrysler 300 C{" "}
                                            </a>
                                          </h6>
                                          <ul class="car-list">
                                            <li>
                                              <span class="text-danger">
                                                <strong>Origin:</strong>
                                              </span>{" "}
                                              2200 Fountain view Houston, <br />{" "}
                                              TX 77057 713-987-9876
                                            </li>
                                            <li>
                                              <span class="text-success">
                                                <strong>Destination:</strong>
                                              </span>{" "}
                                              2222 Settlers way BlvdSugar Land,{" "}
                                              <br />
                                              TX 77478281-999-9999
                                            </li>
                                          </ul>
                                        </div>
                                        <div class="btnns col-md-3">
                                          <div class="mb-2 mt-2">
                                            <a
                                              class="btn btn-primary w-100"
                                              href="#"
                                            >
                                              Talk to Client
                                            </a>
                                          </div>
                                          <div class="mb-2">
                                            <a
                                              class="btn btn-warning w-100"
                                              href="#"
                                            >
                                              Send Quote to Client
                                            </a>
                                          </div>
                                          <div>
                                            <a
                                              class="btn btn-default border w-100"
                                              href="#"
                                            >
                                              Acquire & Accept Shipping
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                <div class="pagination-area">
                                  <span class="text-danger"></span>
                                  <div aria-label="Page navigation example">
                                    <span class="text-danger"></span>
                                    <ul class="pagination">
                                      <li class="page-item">
                                        <span class="text-danger">
                                          <a
                                            aria-label="Previous"
                                            class="page-link"
                                            href="#"
                                          >
                                            <span aria-hidden="true">
                                              <i class="far fa-arrow-left"></i>
                                            </span>
                                          </a>
                                        </span>
                                      </li>
                                      <li style={{ listStyle: "none" }}></li>
                                      <li class="page-item active">
                                        <a class="page-link" href="#">
                                          1
                                        </a>
                                      </li>
                                      <li class="page-item">
                                        <a class="page-link" href="#">
                                          2
                                        </a>
                                      </li>
                                      <li class="page-item">
                                        <a class="page-link" href="#">
                                          3
                                        </a>
                                      </li>
                                      <li class="page-item">
                                        <a
                                          aria-label="Next"
                                          class="page-link"
                                          href="#"
                                        >
                                          <span aria-hidden="true">
                                            <i class="far fa-arrow-right"></i>
                                          </span>
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <div class="modal" id="myModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Mercedes Benz Car</h4>
              <button
                class="btn-close"
                data-bs-dismiss="modal"
                type="button"
              ></button>
            </div>
            <div class="modal-body">
              <div class="row pb-4">
                <div class="col-lg-5">
                  <h5 class="mb-2">Price: $45,360</h5>
                  <div class="card mb-5" style={{ border: "1px solid #eee" }}>
                    <div class="card-body">
                      <p>
                        <strong>Dealer Name:</strong> John Doe
                      </p>
                      <p>
                        <strong>Address:</strong> 123A/21, Near old garden,
                        Indore
                      </p>
                      <p>
                        <strong>Phone:</strong> 7798797XXXXX
                      </p>
                    </div>
                  </div>
                  <a class="theme-btn" href="details.html">
                    Click For Full Details
                  </a>
                </div>
                <div class="col-lg-7">
                  <div class="carousel slide" data-bs-ride="carousel" id="demo">
                    <div class="carousel-indicators">
                      <button
                        class="active"
                        data-bs-slide-to="0"
                        data-bs-target="#demo"
                        type="button"
                      ></button>{" "}
                      <button
                        data-bs-slide-to="1"
                        data-bs-target="#demo"
                        type="button"
                      ></button>{" "}
                      <button
                        data-bs-slide-to="2"
                        data-bs-target="#demo"
                        type="button"
                      ></button>
                    </div>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/01.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div class="carousel-item">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/02.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div class="carousel-item">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/03.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
      <a href="#" id="scroll-top">
        <i class="far fa-arrow-up"></i>
      </a>
    </>
  );
};

export default VehicleTransportList;
