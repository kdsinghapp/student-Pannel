import React, { useState } from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Swal from "sweetalert2";
import { changePasswordTowmen } from "../utils/authApi";

const ChangePassword = () => {
  const [formData, setFormData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
  };

  const validateForm = () => {
    const { oldPassword, newPassword, confirmPassword } = formData;
    const newErrors = {};

    if (!oldPassword) newErrors.oldPassword = "Old password is required.";
    if (!newPassword) newErrors.newPassword = "New password is required.";
    else if (newPassword.length < 8)
      newErrors.newPassword = "Password must be at least 8 characters long.";
    if (newPassword !== confirmPassword)
      newErrors.confirmPassword = "Passwords do not match.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    const result = await Swal.fire({
      icon: "warning",
      title: "Are you sure?",
      text: "Do you really want to change your password?",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "No, cancel",
    });

    if (result.isConfirmed) {
      try {
        const response = await changePasswordTowmen(formData);
        if (response.status) {
          Swal.fire({
            icon: "success",
            title: "Password Changed",
            text: "Your password has been updated successfully.",
            confirmButtonText: "OK",
          });
          setFormData({
            oldPassword: "",
            newPassword: "",
            confirmPassword: "",
          });
        } else {
          Swal.fire({
            icon: "error",
            title: "Error",
            text: response?.data?.message || "Failed to change password.",
            confirmButtonText: "Try Again",
          });
          setFormData({
            oldPassword: "",
            newPassword: "",
            confirmPassword: "",
          });
        }
      } catch (error) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "An unexpected error occurred. Please try again later.",
          confirmButtonText: "OK",
        });
        setFormData({
          oldPassword: "",
          newPassword: "",
          confirmPassword: "",
        });
        console.error("Error changing password:", error);
      }
    } else {
      Swal.fire({
        icon: "info",
        title: "Canceled",
        text: "Password change has been canceled.",
        confirmButtonText: "OK",
      });
    }
  };

  return (
    <>
      <main className="main">
        <Navbar />
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Change Password
                        </h4>
                        <div className="col-lg-12">
                          <div className="user-profile-form">
                            <form onSubmit={handlePasswordChange}>
                              <div className="form-group">
                                <label>Old Password</label>
                                <input
                                  className={`form-control ${
                                    errors.oldPassword ? "is-invalid" : ""
                                  }`}
                                  placeholder="Old Password"
                                  type="password"
                                  name="oldPassword"
                                  value={formData.oldPassword}
                                  onChange={handleChange}
                                />
                                {errors.oldPassword && (
                                  <small className="text-danger">
                                    {errors.oldPassword}
                                  </small>
                                )}
                              </div>
                              <div className="form-group">
                                <label>New Password</label>
                                <input
                                  className={`form-control ${
                                    errors.newPassword ? "is-invalid" : ""
                                  }`}
                                  placeholder="New Password"
                                  type="password"
                                  name="newPassword"
                                  value={formData.newPassword}
                                  onChange={handleChange}
                                />
                                {errors.newPassword && (
                                  <small className="text-danger">
                                    {errors.newPassword}
                                  </small>
                                )}
                              </div>
                              <div className="form-group">
                                <label>Re-Type Password</label>
                                <input
                                  className={`form-control ${
                                    errors.confirmPassword ? "is-invalid" : ""
                                  }`}
                                  placeholder="Re-Type Password"
                                  type="password"
                                  name="confirmPassword"
                                  value={formData.confirmPassword}
                                  onChange={handleChange}
                                />
                                {errors.confirmPassword && (
                                  <small className="text-danger">
                                    {errors.confirmPassword}
                                  </small>
                                )}
                              </div>
                              <button className="theme-btn my-3" type="submit">
                                <span className="far fa-key"></span> Change
                                Password
                              </button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <a href="#" id="scroll-top">
        <i className="far fa-arrow-up"></i>
      </a>
    </>
  );
};

export default ChangePassword;
