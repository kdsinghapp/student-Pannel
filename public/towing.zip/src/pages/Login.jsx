import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginTowingMan } from "../utils/authApi";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [popupMessage, setPopupMessage] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { email, password } = formData;

    setEmailError("");
    setPasswordError("");
    let hasError = false;

    if (!email) {
      setEmailError("Email is required.");
      hasError = true;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError("Invalid email format.");
      hasError = true;
    }

    if (!password) {
      setPasswordError("Password is required.");
      hasError = true;
    }

    if (hasError) return;

    setLoading(true);
    try {
      const response = await loginTowingMan(formData);

      if (
        response?.data?.adminVerification?.status === "Pending" ||
        response?.data?.adminVerification?.status === "Rejected"
      ) {
        setPopupMessage(
          `Your status is: ${response.data.adminVerification.status}`
        );
        setShowPopup(true);
      } else {
        navigate("/");
      }
    } catch (error) {
      console.error("Login failed:", error);
      setError(error.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("userToken");

    if (token) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div className="login-area mt-5 mb-5">
      <div className="container">
        <div className="col-md-5 mx-auto">
          <div className="login-form">
            <div className="login-header">
              <h3>Sign In</h3>
              <p>Sign in with your account</p>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Email Address</label>
                <input
                  className={`form-control ${emailError ? "is-invalid" : ""}`}
                  placeholder="Your Email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                {emailError && (
                  <small className="text-danger">{emailError}</small>
                )}
              </div>
              <div className="form-group">
                <label>Password</label>
                <input
                  className={`form-control ${
                    passwordError ? "is-invalid" : ""
                  }`}
                  placeholder="Your Password"
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                />
                {passwordError && (
                  <small className="text-danger">{passwordError}</small>
                )}
              </div>
              <div className="d-flex justify-content-between mb-4">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="remember"
                    type="checkbox"
                  />
                  <label className="form-check-label" htmlFor="remember">
                    Remember Me
                  </label>
                </div>
                <Link className="forgot-pass" to="/forgot-password">
                  Forgot Password?
                </Link>
              </div>
              <div className="d-flex align-items-center">
                <button
                  className="theme-btn btn btn-primary"
                  type="submit"
                  disabled={loading}
                >
                  {loading ? (
                    <span
                      className="spinner-border spinner-border-sm"
                      role="status"
                      aria-hidden="true"
                    ></span>
                  ) : (
                    "Sign In"
                  )}
                </button>
              </div>
            </form>

            {showPopup && (
              <div
                className="modal fade show"
                style={{
                  background: "rgba(0,0,0,0.5)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                tabIndex="-1"
              >
                <div className="modal-dialog" style={{ width: "30%" }}>
                  <div className="modal-content">
                    <div className="" style={{ position: "relative" }}>
                      <button
                        style={{
                          position: "absolute",
                          top: "10px",
                          right: "20px",
                        }}
                        type="button"
                        className="btn-close"
                        onClick={() => setShowPopup(false)}
                      ></button>
                    </div>
                    <div className="modal-body">
                      <p>{popupMessage}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div
              className="d-flex"
              style={{ alignItems: "center", justifyContent: "center" }}
            >
              <hr className="custom-line" />
              x
              <hr className="custom-line" />
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Link
                to="/signup"
                className="theme-btn btn btn-primary"
                style={{ border: "none" }}
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
