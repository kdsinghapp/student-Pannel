import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import BillingReport from "../components/BillingReport";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getTowingRequest } from "../utils/authApi";
import { useNavigate } from "react-router-dom";
import TalkClientRequest from "../components/TalkClientRequest";
// import img1 from "../../assets/img/notfounddata.png";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

const BillingDetails = () => {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});

  const [currentPage, setCurrentPage] = useState(1);
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);

  const handleOpenModal = (data) => {
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await getTowingRequest();
        setRequests(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      }
    };
    fetchRequests();
  }, [user]);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <>
      <main className="main">
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="table-responsive">
                        <table className="table text-nowrap">
                          <thead>
                            <tr>
                              <th>Car Info</th>
                              <th>Brand</th>
                              <th>Amount</th>
                              <th>Due date</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <BillingReport allRequests={allRequests} />
                          </tbody>
                        </table>
                      </div>
                      {totalPages > 1 && (
                        <div className="pagination-area">
                          <ul className="pagination">
                            <li
                              className={`page-item ${
                                currentPage === 1 ? "disabled" : ""
                              }`}
                            >
                              <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (currentPage > 1)
                                    handlePageChange(currentPage - 1);
                                }}
                                aria-label="Previous"
                              >
                                <i className="far fa-arrow-left" />
                              </a>
                            </li>

                            {Array.from(
                              { length: totalPages },
                              (_, i) => i + 1
                            ).map((pageNumber) => (
                              <li
                                key={pageNumber}
                                className={`page-item ${
                                  pageNumber === currentPage ? "active" : ""
                                }`}
                              >
                                <a
                                  className="page-link"
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handlePageChange(pageNumber);
                                  }}
                                >
                                  {pageNumber}
                                </a>
                              </li>
                            ))}

                            <li
                              className={`page-item ${
                                currentPage === totalPages ? "disabled" : ""
                              }`}
                            >
                              <a
                                className="page-link"
                                href="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (currentPage < totalPages)
                                    handlePageChange(currentPage + 1);
                                }}
                                aria-label="Next"
                              >
                                <i className="far fa-arrow-right" />
                              </a>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
};

export default BillingDetails;
