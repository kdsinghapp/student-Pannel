import React, { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import Swal from "sweetalert2";

const Sidebar = () => {
  const user = localStorage.getItem("userTowingMen");
  const userId = localStorage.getItem("userId");
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const fileInputRef = useRef(null);
  const [profileImage, setProfileImage] = useState(
    user?.profileImage ||
      "https://cdn-icons-png.flaticon.com/512/1995/1995470.png"
  );
  const [uploading, setUploading] = useState(false);
  const [towingData, setTowingData] = useState(null);
  const cleanUserId = userId.replace(/^"|"$/g, "");

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userToken");
    localStorage.removeItem("userTowingMen");
    navigate("/login");
  };

  const fetchMechanicDetails = async () => {
    try {
      const response = await axios.get(
        `http://193.203.161.2:8000/towing/get-towman/${cleanUserId}`
      );
      if (response.data.status) {
        setTowingData(response.data.data.image);
      } else {
        console.error("Mechanic not found");
      }
    } catch (error) {
      console.error("Error fetching mechanic details:", error);
    }
  };
  useEffect(() => {
    fetchMechanicDetails();
  }, [user?.id]);

  console.log("Response",towingData)

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to upload this image?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, upload it!",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    const formData = new FormData();
    formData.append("image", file);

    try {
      setUploading(true);

      const response = await axios.post(
        // `http://193.203.161.2:8000/mechanic/upload-image/${user.data.mechanicId}`,
        `http://193.203.161.2:8000/towing/upload-image/${cleanUserId}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      if (response.data.success) {
        const fullImagePath = `http://193.203.161.2:8000/image/${response.data.filePath.replace(
          /\\/g,
          "/"
        )}`;
        setProfileImage(fullImagePath);

        Swal.fire({
          title: "Uploaded!",
          text: response.data.message,
          icon: "success",
        });
        fetchMechanicDetails();
      } else {
        Swal.fire({
          title: "Failed!",
          text: "Failed to upload the image. Please try again.",
          icon: "error",
        });
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      Swal.fire({
        title: "Error!",
        text: "An error occurred while uploading the image.",
        icon: "error",
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="col-lg-3">
      <div className="user-profile-sidebar">
        <div className="user-profile-sidebar-top">
          <div className="user-profile-img">
            <img
              alt="Towing Service"
              src={`http://193.203.161.2:8000/images/${towingData}`}
              style={{ width: "100px", height: "95px" }}
            />
            <button
              className="profile-img-btn"
              type="button"
              onClick={() => fileInputRef.current.click()}
              style={{
                position: "absolute",
                bottom: "10px",
                right: "10px",
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                border: "none",
                color: "white",
                borderRadius: "50%",
                cursor: "pointer",
              }}
            >
              <i className="far fa-camera" />
            </button>
            <input
              className="profile-img-file"
              type="file"
              ref={fileInputRef}
              style={{ display: "none" }}
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
            />
          </div>
          <h5>Towing Service</h5>
          <p>
            <span className="text-primary">
              <strong>Active</strong>
            </span>
          </p>
        </div>
        <ul className="user-profile-sidebar-list">
          <li>
            <Link className={location.pathname === "/" ? "active" : ""} to="/">
              <i className="far fa-user"></i> Profile
            </Link>
          </li>
          <li>
            <Link
              className={location.pathname === "/all-requests" ? "active" : ""}
              to="/all-requests"
            >
              <i className="far fa-users"></i> All Requests
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/payment-request" ? "active" : ""
              }
              to="/payment-request"
            >
              <i class="fa-solid fa-money-bill"></i> Payment Pending
            </Link>
          </li>
          <li>
            <Link
              className={location.pathname === "/track-towings" ? "active" : ""}
              to="/track-towings"
            >
              <i class="fa-solid fa-shuffle"></i> Track Towings
            </Link>
          </li>
          <li>
            <Link
              className={location.pathname === "/billing" ? "active" : ""}
              to="/billing"
            >
              <i className="far fa-list"></i> Billing
            </Link>
          </li>
          <li>
            <Link
              className={location.pathname === "/sales-report" ? "active" : ""}
              to="/sales-report"
            >
              <i className="far fa-file"></i> Sales Report
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/change-password" ? "active" : ""
              }
              to="/change-password"
            >
              <i className="far fa-key"></i> Change Password
            </Link>
          </li>
          <li>
            <button
              className="btn btn-link text-danger"
              onClick={handleLogout}
              style={{ textDecoration: "none" }}
            >
              <i className="far fa-sign-out"></i> Logout
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
