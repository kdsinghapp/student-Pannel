import React from 'react'

const Navbar = () => {
  return (
    <div
    class="site-breadcrumb"
  >
    <div class="container">
      <h2 class="breadcrumb-title">Towing/Shipping - Manage account</h2>
      <ul class="breadcrumb-menu">
        <li>
          <a href="index.html">Home</a>
        </li>
        <li class="active">Change Password</li>
      </ul>
    </div>
  </div>
  )
}

export default Navbar