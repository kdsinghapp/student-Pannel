import React from "react";

const Loader = () => {
  return (
    <div class="preloader">
      <div class="loader-ripple">
        <div></div>
        <div></div>
      </div>
    </div>
  );
};

export default Loader;
