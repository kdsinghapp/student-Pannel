import React, { useState, useEffect } from "react";
import { getUserById, updateTowMan } from "../utils/authApi";
import axios from "axios";

const ProfileDetails = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    description: "",
  });

  const [loading, setLoading] = useState(false);
  const userId = localStorage.getItem("userId");

  const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  };

  const getUserProfile = async (id) => {
    setLoading(true);
    try {
      const res = await getUserById(id);
      const fullName = res.data.name || "";
      const nameParts = fullName.trim().split(" ");

      const firstName = capitalizeFirstLetter(nameParts[0] || "");
      const lastName = capitalizeFirstLetter(
        nameParts.slice(1).join(" ") || ""
      );

      setFormData({
        firstName: firstName,
        lastName: lastName,
        email: res.data.email || "",
        phone: res.data.phone || "",
        address: res.data.address || "Not Found",
        description: res.data.description || "Not Found",
      });
    } catch (error) {
      console.error("Error fetching user profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateUserProfile = async (formData) => {
    try {
      const response = await updateTowMan(formData);
    } catch (error) {}
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (Object.values(formData).some((field) => !field.trim())) {
      alert("All fields are required.");
      return;
    }

    updateUserProfile(formData);
  };

  useEffect(() => {
    if (userId) {
      getUserProfile(userId);
    }
  }, [userId]);

  return (
    <div className="user-profile-card">
      <h4 className="user-profile-card-title">Edit Profile</h4>
      <div className="user-profile-form">
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label>First Name</label>
                <input
                  className="form-control"
                  placeholder="First Name"
                  type="text"
                  name="firstName"
                  value={loading ? "Loading..." : formData.firstName}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label>Last Name</label>
                <input
                  className="form-control"
                  placeholder="Last Name"
                  type="text"
                  name="lastName"
                  value={loading ? "Loading..." : formData.lastName}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label>Email</label>
                <input
                  className="form-control"
                  placeholder="Email"
                  type="text"
                  name="email"
                  value={loading ? "Loading..." : formData.email}
                  onChange={handleChange}
                  disabled
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label>Phone</label>
                <input
                  className="form-control"
                  placeholder="Phone"
                  type="text"
                  name="phone"
                  value={loading ? "Loading..." : formData.phone}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>
            <div className="col-md-12">
              <div className="form-group">
                <label>Address</label>
                <input
                  className="form-control"
                  placeholder="Address"
                  type="text"
                  name="address"
                  value={loading ? "Loading..." : formData.address}
                  onChange={handleChange}
                  disabled={loading}
                />
              </div>
            </div>
            <div className="col-md-12">
              <div className="form-group">
                <label>Description</label>
                <textarea
                  name="description"
                  className="form-control"
                  placeholder="Description Here..."
                  type="text"
                  value={loading ? "Loading..." : formData.description}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>
          <button className="theme-btn my-3" type="submit" disabled={loading}>
            <span className="far fa-user"></span> Save Changes
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProfileDetails;
