import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem("userToken");
  const user = localStorage.getItem("userTowingMen");
  const userId = localStorage.getItem("userId");

  return token && user && userId ? children : <Navigate to="/login" />;
};

export default ProtectedRoute;
