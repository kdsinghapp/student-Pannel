import React from "react";

const PopUpModal = ({ message, onClose }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <button className="close-btn" onClick={onClose}>
          ✖
        </button>
        <h4>{message}</h4>
        <button className="signin-btn" onClick={onClose}>
          Sign In
        </button>
      </div>
    </div>
  );
};

export default PopUpModal;
