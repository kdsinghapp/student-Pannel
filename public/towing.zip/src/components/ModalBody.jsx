import React from "react";

const ModalBody = () => {
  return (
    <>
      <div class="modal" id="myModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Mercedes Benz Car</h4>
              <button
                class="btn-close"
                data-bs-dismiss="modal"
                type="button"
              ></button>
            </div>
            <div class="modal-body">
              <div class="row pb-4">
                <div class="col-lg-5">
                  <h5 class="mb-2">Price: $45,360</h5>
                  <div class="card mb-5" style="border:1px solid #eee">
                    <div class="card-body">
                      <p>
                        <strong>Dealer Name:</strong> John Doe
                      </p>
                      <p>
                        <strong>Address:</strong> 123A/21, Near old garden,
                        Indore
                      </p>
                      <p>
                        <strong>Phone:</strong> 7798797XXXXX
                      </p>
                    </div>
                  </div>
                  <a class="theme-btn" href="details.html">
                    Click For Full Details
                  </a>
                </div>
                <div class="col-lg-7">
                  <div class="carousel slide" data-bs-ride="carousel" id="demo">
                    <div class="carousel-indicators">
                      <button
                        class="active"
                        data-bs-slide-to="0"
                        data-bs-target="#demo"
                        type="button"
                      ></button>{" "}
                      <button
                        data-bs-slide-to="1"
                        data-bs-target="#demo"
                        type="button"
                      ></button>{" "}
                      <button
                        data-bs-slide-to="2"
                        data-bs-target="#demo"
                        type="button"
                      ></button>
                    </div>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/01.jpg"
                          style="width:100%"
                        />
                      </div>
                      <div class="carousel-item">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/02.jpg"
                          style="width:100%"
                        />
                      </div>
                      <div class="carousel-item">
                        <img
                          alt="car"
                          class="d-block"
                          src="../assets/img/car/03.jpg"
                          style="width:100%"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="#" id="scroll-top">
        <i class="far fa-arrow-up"></i>
      </a>
    </>
  );
};

export default ModalBody;
