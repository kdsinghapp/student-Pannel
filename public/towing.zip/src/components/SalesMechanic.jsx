import React, { useState } from "react";

const SalesMechanic = ({ allRequests }) => {
  const [showModal, setShowModal] = useState(false);
  const [selectedData, setSelectedData] = useState(null);

  const handleModalOpen = (data) => {
    setSelectedData(data);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedData(null);
  };

  return (
    <>
      {allRequests?.map(
        (data) =>
          data?.carId && (
            <tr key={data._id}>
              <td>{data?.user?.name}</td>
              <td>{data?.user?.email}</td>
              <td>{data?.user?.address}</td>
              <td>
                {data.carId.car_name?.split(" ").slice(0, 4).join(" ")}...
              </td>
              <td>${data.carId.car_price}</td>
              <td>${data?.amount}</td>
              <td>
                <span className="badge badge-success">
                  {data.paymentId !== "" ? "Received" : "Pending"}
                </span>
              </td>
              <td>
                <div className="btn-group">
                  <button
                    style={{ width: "100px" }}
                    type="button"
                    className="btn btn-primary dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Done
                  </button>
                  <ul className="dropdown-menu dropdown-menu-right">
                    <li>
                      <button className="dropdown-item" type="button">
                        All Inspections
                      </button>
                    </li>
                    <li>
                      <button className="dropdown-item" type="button">
                        Inspection at Shop
                      </button>
                    </li>
                  </ul>
                </div>
              </td>
              <td>
                {new Date(data?.date).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })}
              </td>
            </tr>
          )
      )}

      {showModal && (
        <div
          className="modal fade show"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(0, 0, 0, 0.5)",
          }}
          tabIndex="-1"
          aria-labelledby="modalLabel"
          aria-hidden="false"
        >
          <div className="modal-dialog modal-lg">
            <div className="modal-content" style={{ width: "700px" }}>
              <div
                className="modal-header"
                style={{
                  backgroundColor: "#0B5ED7",
                }}
              >
                <h5
                  className="modal-title"
                  id="modalLabel"
                  style={{ fontWeight: "bold" }}
                >
                  Car Details
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={handleModalClose}
                />
              </div>

              <div className="modal-body" style={{ padding: "10px 0px" }}>
                {selectedData && (
                  <div className="row">
                    <div className="col-md-4 mb-3">
                      <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0uuDxRucH9U651bytMA6GVMKIBzFMa-6P8XDw_RCk_n59Qu0RpTY1fi4C-4o3PW4IAhOb&s"
                        alt="Car Image"
                        style={{
                          width: "100%",
                          height: "100%",
                          borderRadius: "10px",
                          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                        }}
                      />
                    </div>

                    <div className="col-md-8">
                      <h6 style={{ fontWeight: "bold", marginBottom: "10px" }}>
                        Car Name:{" "}
                        <span style={{ fontWeight: "normal" }}>
                          {selectedData?.car?.car_name
                            .split(" ")
                            .slice(0, 7)
                            .join(" ")}
                        </span>
                      </h6>
                      <p>
                        <strong>Price:</strong> $
                        {selectedData?.car?.car_price || "N/A"}
                      </p>
                      <p>
                        <strong>Created At:</strong>{" "}
                        {new Date(selectedData?.createdAt).toLocaleDateString(
                          "en-US",
                          {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          }
                        )}
                      </p>
                      <p>
                        <strong>Location:</strong>{" "}
                        {selectedData?.locationType || "N/A"}
                      </p>
                      <p>
                        <strong>Request Status:</strong>{" "}
                        {selectedData?.status || "N/A"}
                      </p>
                      <p>
                        <strong>Payment Status:</strong>{" "}
                        {selectedData?.paymentId === ""
                          ? "Received"
                          : "Pending"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div
                className="modal-footer"
                style={{
                  borderTop: "1px solid #dee2e6",
                }}
              >
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleModalClose}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SalesMechanic;
