import React, { useEffect, useState } from "react";
import { findUserById } from "../utils/authApi";

const TalkClientRequest = ({ data }) => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUserData = async (data) => {
    const user = {
      userId: data.user,
    };
    try {
      const response = await findUserById(user);
      setUserData(response.data);
    } catch (error) {
      console.error("Error fetching user data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData(data);
  }, [data]);

  if (loading) {
    return <p>Loading user details...</p>;
  }

  if (!userData) {
    return <p>Unable to fetch user details.</p>;
  }
  return (
    <div className="form-container">
      <h3
        className="details"
        style={{ color: "black", borderBottom: "1px solid lightgrey" }}
      >
        Customer Details
      </h3>
      <div className="section mt-3">
        <div className="input-group">
          <label className="text-label" for="name" style={{ color: "#dc3545" }}>
            Name:-
          </label>
          <p>&nbsp;&nbsp;{userData.name || ""}</p>
        </div>
        <div className="input-group">
          <label
            className="text-label"
            for="email"
            style={{ color: "#dc3545" }}
          >
            Email:-
          </label>
          <p>&nbsp;&nbsp;{userData.email || ""}</p>
        </div>
        <div className="input-group">
          <label
            for="phone"
            className="text-label"
            style={{ color: "#dc3545" }}
          >
            Phone Number:-
          </label>
          <p>&nbsp;&nbsp;{userData.mobile_number || ""}</p>{" "}
        </div>
      </div>
    </div>
  );
};

export default TalkClientRequest;
