import React, { useState } from "react";
import Sidebar from "../components/Sidebar";

const TrackingStatusUpdate = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    vehicleType: "",
    trackingId: "",
    status: "In Transit",
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate form fields
    let newErrors = {};
    if (!formData.name) newErrors.name = "Name is required";
    if (!formData.email) newErrors.email = "Email is required";
    if (!formData.vehicleType)
      newErrors.vehicleType = "Vehicle type is required";
    if (!formData.trackingId) newErrors.trackingId = "Tracking ID is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      alert("Vehicle status updated successfully!");
      console.log("Form Data Submitted:", formData);
    }, 1500);
  };

  return (
    <main className="main">
      <div className="user-profile py-120">
        <div className="container">
          <div className="row">
            <Sidebar />
            <div className="col-lg-9">
              <div className="user-profile-wrapper">
                <div className="user-profile-card">
                  <div
                    className="d-flex w-100 user-profile-card-title"
                    style={{
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <h4>Update Vehicle Status:</h4>
                    <h5>Current Status: {formData.status}</h5>
                  </div>
                  <form onSubmit={handleSubmit}>
                    <div className="row">
                      <div className="col-md-6">
                        <div className="form-group">
                          <label>Driver Name</label>
                          <input
                            className={`form-control ${
                              errors.name ? "is-invalid" : ""
                            }`}
                            placeholder="Driver Name"
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                          />
                          {errors.name && (
                            <small className="text-danger">
                              {errors.name}
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-group">
                          <label>Email Address</label>
                          <input
                            className={`form-control ${
                              errors.email ? "is-invalid" : ""
                            }`}
                            placeholder="Your Email"
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                          />
                          {errors.email && (
                            <small className="text-danger">
                              {errors.email}
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-group">
                          <label>Vehicle Type</label>
                          <input
                            className={`form-control ${
                              errors.vehicleType ? "is-invalid" : ""
                            }`}
                            placeholder="Vehicle Type"
                            type="text"
                            name="vehicleType"
                            value={formData.vehicleType}
                            onChange={handleChange}
                          />
                          {errors.vehicleType && (
                            <small className="text-danger">
                              {errors.vehicleType}
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-group">
                          <label>Tracking ID</label>
                          <input
                            className={`form-control ${
                              errors.trackingId ? "is-invalid" : ""
                            }`}
                            placeholder="Tracking ID"
                            type="text"
                            name="trackingId"
                            value={formData.trackingId}
                            onChange={handleChange}
                          />
                          {errors.trackingId && (
                            <small className="text-danger">
                              {errors.trackingId}
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-group">
                          <label>Update Status</label>
                          <select
                            className={`form-control ${
                              errors.status ? "is-invalid" : ""
                            }`}
                            name="status"
                            value={formData.status}
                            onChange={handleChange}
                          >
                            <option value="pending">Pending</option>
                            <option value="in_transit">In Transit</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                          {errors.status && (
                            <small className="text-danger">
                              {errors.status}
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-12">
                        <button
                          className="theme-btn btn btn-primary"
                          type="submit"
                          disabled={loading}
                        >
                          {loading ? (
                            <span
                              className="spinner-border spinner-border-sm"
                              role="status"
                              aria-hidden="true"
                            ></span>
                          ) : (
                            "Update Status"
                          )}
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default TrackingStatusUpdate;