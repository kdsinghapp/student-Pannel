import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("userTowingMen");
    localStorage.removeItem("userId");

    navigate("/login");
  };

  return (
    <header className="header">
      <div className="header-top">
        <div className="container">
          <div className="header-top-wrapper">
            <div className="header-top-left">
              <div className="header-top-contact">
                <ul>
                  <li>
                    <a href="#">
                      <i className="far fa-envelopes"></i>{" "}
                      <span
                        className="__cf_email__"
                        data-cfemail="dab3b4bcb59abfa2bbb7aab6bff4b9b5b7"
                      >
                        test@mail.com
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:+21236547898">
                      <i className="far fa-phone-volume"></i> +XX XXXXXXXXXX
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="header-top-right">
              <div className="header-top-social">
                <select className="btn btn-primary">
                  <option selected>English</option>
                  <option>Arabic</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="main-navigation">
        <nav className="navbar navbar-expand-lg">
          <div className="container position-relative">
            <Link className="navbar-brand" to="/">
              <h3
                style={{
                  color: "#000",
                  textTransform: "uppercase",
                  fontWeight: "bold",
                }}
              >
                Sayarat
              </h3>
            </Link>
            <div className="mobile-menu-right">
              <div className="nav-right-account">
                <div className="dropdown">
                  <div aria-expanded="false" data-bs-toggle="dropdown">
                    <img
                      alt=""
                      src="https://foglesongtow.com/wp-content/uploads/2022/09/Roadside-Assistance-Companies-Chino-CA.jpeg"
                    />
                  </div>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li>
                      <Link className="dropdown-item" to="/">
                        <i className="far fa-home"></i> Manage Towing Account
                      </Link>
                    </li>

                    <li>
                      <button className="dropdown-item" onClick={handleLogout}>
                        <i className="far fa-sign-out"></i> Log Out
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
              <button
                aria-expanded="false"
                aria-label="Toggle navigation"
                className="navbar-toggler"
                data-bs-target="#main_nav"
                data-bs-toggle="collapse"
                type="button"
              >
                <span className="navbar-toggler-mobile-icon">
                  <i className="far fa-bars"></i>
                </span>
              </button>
            </div>
            <div className="collapse navbar-collapse" id="main_nav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/">
                    Home
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className="nav-link" to="/about-us">
                    About Us
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className="nav-link" to="/contact-us">
                    Contact Us
                  </Link>
                </li>
              </ul>
              <div className="nav-right">
                <div className="nav-right-account">
                  <div className="dropdown">
                    <div aria-expanded="false" data-bs-toggle="dropdown">
                      <img
                        alt=""
                        src="https://foglesongtow.com/wp-content/uploads/2022/09/Roadside-Assistance-Companies-Chino-CA.jpeg"
                        style={{ width: "50px", height: "50px" }}
                      />{" "}
                      <span>Towing Service</span>
                    </div>

                    <ul className="dropdown-menu dropdown-menu-end">
                      <li>
                        <Link className="dropdown-item" to="/towing">
                          <i className="far fa-home"></i> Manage Towing Account
                        </Link>
                      </li>

                      <li>
                        <button
                          className="dropdown-item"
                          onClick={handleLogout}
                        >
                          <i className="far fa-sign-out"></i> Log Out
                        </button>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
