Future pending work

add api 1 :- implementation of google map api for add geo area agter login.