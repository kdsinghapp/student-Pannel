import axios from "axios";

// const API_URL = "http://localhost:8000";
const API_URL = "http://193.203.161.2:8000";
const userExist = JSON.parse(localStorage.getItem("user"));

export const MachanicAvailability = async (data) => {
  try {
    const res = await axios.post(
      `${API_URL}/mechanic/availability/${userExist.mechanicId}`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    );
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const MachanicGeoArea = async (data) => {
  try {
    const res = await axios.post(
      `${API_URL}/mechanic/service-area/${userExist.mechanicId}`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    );
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const getAllRequests = async () => {
  console.log("Userexist", userExist.data.mechanicId);

  try {
    const res = await axios.get(`${API_URL}/mechanic/all-requests/${userExist.data.mechanicId}`,
      {
        headers: {
          "Content-Type": "application/json",
          // Authorization: `Bearer ${token}`,
        },
      }
    )
    console.log("Response", res.data);
    return res.data
  } catch (error) {
    console.error("Error fetching Requests:-", error);
    throw error;
  }
}

export const acceptRejectRequest = async (data) => {
  const allData = {
    mechanicId: data.mechanicId,
    action: data.action
  }
  console.log("Data", allData);

  try {
    const res = await axios.post(`${API_URL}/mechanic/request/${data.id}`, allData,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      })
    console.log("Response", res.data);
    return res.data
  } catch (error) {
    console.error("Error fetching Requests:-", error);
    throw error;
  }
}

export const getMechanicById = async (data) => {
  console.log("Data:-", data)
  try {
    const res = await axios.post(`${API_URL}/mechanic/${data}`,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    )
    return res.data
  } catch (error) {
    console.error("Error fetching Mechanic:-", error);
    throw error;
  }
}

export const findUserById = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/buyer/find-user`, data,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    )
    console.log("Response Data", res.data);
    return res.data
  } catch (error) {
    console.error("Error fetching User:-", error);
    throw error;
  }
}

export const createInspection = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/mechanic/addInspection/${data}`,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    )
    console.log("Response Data", res.data);
    return res.data
  } catch (error) {
    console.error("Error fetching User:-", error);
    throw error;
  }
}

export const getInspectionByCategory = async (data) => {
  try {
    const res = await axios.get(`${API_URL}/mechanic/${data.selectedType}/${data.inspection}`,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    )
    console.log("Response Data", res.data);
    return res.data
  } catch (error) {
    console.error("Error fetching User:-", error);
    throw error;
  }
}

export const editInspection = async (data) => {
  console.log("Data here:-", data.inspectionData);
  try {
    const res = await axios.put(`${API_URL}/${data.selectedType}/${data.inspection}`, data.inspectionData,
      {
        headers: {
          "Content-Type": "application/json",
          //   Authorization: `Bearer ${token}`,
        },
      }
    )
    return res.data
  } catch (error) {
    console.error("Error fetching User:-", error);
    throw error;
  }
}