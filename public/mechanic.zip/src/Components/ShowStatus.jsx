import React, { useEffect, useState } from "react";
// import gif from "../../assets/img/verified";
// import gif  from "../../assets/img/mechanic/user.gif"
import gif from "../../assets/img/mechanic/shield.gif"

const ShowStatus = ({ status }) => {
    const [data, setData] = useState("Pending");

    console.log("Status here", status);

    useEffect(() => {
        if (status?.adminVerification?.status === false) {
            setData("Admin Verification Pending");
        } else if (status?.isFullyVerified) {
            setData("Fully Verified");
        } else {
            setData("Pending");
        }
    }, [status]);

    return (
        <div>
            <div
                style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                }}
            >

                {status?.isFullyVerified && (
                    <img
                        width="150"
                        height="150"
                        src={gif}
                        alt="verification-gif"
                    />
                )}

                <button
                    className="btn"
                    style={{
                        backgroundColor: "green",
                        color: "white",
                        marginTop: "10px",
                    }}
                >
                    {data}
                </button>
            </div>
        </div>
    );
};

export default ShowStatus;
