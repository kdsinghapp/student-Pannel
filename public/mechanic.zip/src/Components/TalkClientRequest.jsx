import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { findUserById } from '../Utils/authApi';
import ".././form.css"

const TalkClientRequest = ({ data }) => {
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(true);

    console.log("Data", data.user);

    const fetchUserData = async (data) => {
        const user = {
            userId: data.user
        }
        try {
            const response = await findUserById(user);
            console.log("Result here", response.data);
            setUserData(response.data);
        } catch (error) {
            console.error("Error fetching user data:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUserData(data);
    }, [data]);

    if (loading) {
        return <p>Loading user details...</p>;
    }

    if (!userData) {
        return <p>Unable to fetch user details.</p>;
    }
    console.log("User Data Here:-", userData);
    return (
        <div class="form-container">
            <h3 className='details' style={{color:"white"}}>Customer Details</h3>
            <div class="section">
                <div class="input-group">
                    <label className='text-label' for="name">Name:-</label>
                    <p>&nbsp;&nbsp;{userData.name || ''}</p>
                </div>
                <div class="input-group">
                    <label for="email">Email:-</label>
                    <p>&nbsp;&nbsp;{userData.email || ''}</p>
                </div>
                <div class="input-group">
                    <label for="phone">Phone Number:-</label>
                    <p>&nbsp;&nbsp;{userData.mobile_number || ''}</p>                  </div>
            </div>
        </div>
    );
};

export default TalkClientRequest;
