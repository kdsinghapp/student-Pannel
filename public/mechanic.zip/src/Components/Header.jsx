import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
  return (
    <header className="header">
      <div className="header-top">
        <div className="container">
          <div className="header-top-wrapper">
            <div className="header-top-left">
              <div className="header-top-contact">
                <ul>
                  <li>
                    <a href="#">
                      <i className="far fa-envelopes" />{" "}
                      <span
                        className="__cf_email__"
                        data-cfemail="dab3b4bcb59abfa2bbb7aab6bff4b9b5b7"
                      >
                        test@mail.com
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:+21236547898">
                      <i className="far fa-phone-volume" /> +XX XXXXXXXXXX
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="header-top-right">
              <div className="header-top-social">
                <select className="btn btn-primary">
                  <option selected="">English</option>
                  <option>Arabic</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="main-navigation">
        <nav className="navbar navbar-expand-lg">
          <div className="container position-relative">
            <Link className="navbar-brand" href="/">
              <h3
                style={{
                  color: "#000",
                  textTransform: "uppercase",
                  fontWeight: "bold"
                }}
              >
                Sayarat
              </h3>
            </Link>
            <div className="mobile-menu-right">
              <div className="nav-right-account">
                <div className="dropdown">
                  <div aria-expanded="false" data-bs-toggle="dropdown">
                    <img
                      alt=""
                      src="https://cdn-icons-png.flaticon.com/512/1995/1995470.png"
                    />
                  </div>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li>
                      <Link className="dropdown-item" to="/">
                        <i className="far fa-home" /> Manage Account
                      </Link>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        <i className="far fa-sign-out" /> Log Out
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <button
                aria-expanded="false"
                aria-label="Toggle navigation"
                className="navbar-toggler"
                data-bs-target="#main_nav"
                data-bs-toggle="collapse"
                type="button"
              >
                <span className="navbar-toggler-mobile-icon">
                  <i className="far fa-bars" />
                </span>
              </button>
            </div>
            <div className="collapse navbar-collapse" id="main_nav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    About Us
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Added Car List
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Contact Us
                  </a>
                </li>
              </ul>
              <div className="nav-right">
                <div className="nav-right-account">
                  <div className="dropdown">
                    <div aria-expanded="false" data-bs-toggle="dropdown">
                      <img
                        alt=""
                        src="https://cdn-icons-png.flaticon.com/512/1995/1995470.png"
                        style={{ width: 50 }}
                      />{" "}
                      <span>Mechanic</span>
                    </div>
                    <ul className="dropdown-menu dropdown-menu-end">
                      <li>
                        <a className="dropdown-item" href="#">
                          <i className="far fa-home" /> Manage Account
                        </a>
                      </li>
                      <li>
                        <a className="dropdown-item" href="#">
                          <i className="far fa-sign-out" /> Log Out
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
  )
}

export default Header
