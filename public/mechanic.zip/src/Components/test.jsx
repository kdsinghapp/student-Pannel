import React from 'react';
import { useSelector } from 'react-redux';

const TalkClientRequest = ({ data }) => {
    const users = useSelector((state) => state.users); // Assuming users data is in Redux state
    const user = users.find((u) => u.id === data.user); // Find user by ID

    if (!user) {
        return <p>User not found.</p>;
    }

    return (
        <div>
            <h2>Client Details</h2>
            <div className='form-control'>
                <label>Name:</label>
                <input type="text" value={user.name || ''} readOnly />
            </div>
            <div className='form-control'>
                <label>Email:</label>
                <input type="email" value={user.email || ''} readOnly />
            </div>
            <div className='form-control'>
                <label>Contact:</label>
                <input type="number" value={user.contact || ''} readOnly />
            </div>
        </div>
    );
};

export default TalkClientRequest;
