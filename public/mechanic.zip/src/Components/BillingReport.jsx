import React, { useState } from "react";

const BillingReport = ({ allRequests }) => {
  const [showModal, setShowModal] = useState(false);
  const [selectedData, setSelectedData] = useState(null);

  const handleModalOpen = (data) => {
    setSelectedData(data);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedData(null);
  };

  console.log("All Requests", allRequests);

  return (
    <>
      {allRequests?.map((data) => (
        <tr key={data._id}>
          <td>
            <div className="table-list-info">
              <a href="#">
                <img alt="" src="../assets/img/car/01.jpg" />
                <div className="table-list-content">
                  <h6>
                    {data?.car?.car_name?.split(" ").slice(0, 4).join(" ")}...
                  </h6>
                  <span>
                    Car ID: #{data?.car?._id?.split("").slice(0, 8).join("")}...
                  </span>
                </div>
              </a>
            </div>
          </td>
          <td>{data?.car?.car_name?.split(" ").slice(0, 2).join(" ")}...</td>
          <td>${data?.car?.car_price}</td>
          <td>
            {new Date(data?.createdAt).toLocaleDateString("en-US", {
              year: "numeric",
              month: "short",
              day: "numeric",
            })}
          </td>
          <td>
            <span className="badge badge-success">
              {data.paymentId !== "" ? "Received" : "Pending"}
            </span>
          </td>
          <td>
            <a
              aria-label="Details"
              className="btn btn-outline-secondary btn-sm rounded-2"
              data-bs-toggle="tooltip"
              href="#"
              onClick={() => handleModalOpen(data)}
            >
              <i className="far fa-eye" />
            </a>
          </td>
        </tr>
      ))}

      {/* Modal */}
      {showModal && (
        <div
          className="modal fade show"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(0, 0, 0, 0.5)", // Adds a semi-transparent background
          }}
          tabIndex="-1"
          aria-labelledby="modalLabel"
          aria-hidden="false"
        >
          <div className="modal-dialog modal-lg">
            <div className="modal-content" style={{ width: "700px" }}>
              {/* Modal Header */}
              <div
                className="modal-header"
                style={{
                  backgroundColor: "#0B5ED7",
                  // borderBottom: "1px solid #dee2e6",
                }}
              >
                <h5
                  className="modal-title"
                  id="modalLabel"
                  style={{ fontWeight: "bold" }}
                >
                  Car Details
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={handleModalClose}
                />
              </div>

              <div className="modal-body" style={{ padding: "10px 0px" }}>
                {selectedData && (
                  <div className="row">
                    {/* Car Image */}
                    <div className="col-md-4 mb-3">
                      <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0uuDxRucH9U651bytMA6GVMKIBzFMa-6P8XDw_RCk_n59Qu0RpTY1fi4C-4o3PW4IAhOb&s"
                        alt="Car Image"
                        style={{
                          width: "100%",
                          height: "100%",
                          borderRadius: "10px",
                          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", // Adds subtle shadow
                        }}
                      />
                    </div>

                    {/* Car Details */}
                    <div className="col-md-8">
                      <h6 style={{ fontWeight: "bold", marginBottom: "10px" }}>
                        Car Name:{" "}
                        <span style={{ fontWeight: "normal" }}>
                          {selectedData?.car?.car_name
                            .split(" ")
                            .slice(0, 7)
                            .join(" ")}
                        </span>
                      </h6>
                      <p>
                        <strong>Price:</strong> $
                        {selectedData?.car?.car_price || "N/A"}
                      </p>
                      <p>
                        <strong>Created At:</strong>{" "}
                        {new Date(selectedData?.createdAt).toLocaleDateString(
                          "en-US",
                          {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          }
                        )}
                      </p>
                      <p>
                        <strong>Inspection At:</strong>{" "}
                        {selectedData?.locationType === "UserPlace" ? "Users Location" : "At Shop" || "N/A"}
                      </p>
                      <p>
                        <strong>Request Status:</strong>{" "}
                        {selectedData?.status || "N/A"}
                      </p>
                      <p>
                        <strong>Payment Status:</strong>{" "}
                        {selectedData?.paymentId === ""
                          ? "Received"
                          : "Pending"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div
                className="modal-footer"
                style={{
                  borderTop: "1px solid #dee2e6",
                }}
              >
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleModalClose}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BillingReport;
