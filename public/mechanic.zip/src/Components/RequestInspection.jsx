import React, { useMemo, useState } from "react";

const RequestInspection = ({
  handleInspection,
  handlePageChange,
  handleOpenModal,
  selectedLocation,
  setSelectedLocation,
  currentData,
  totalPages,
  img1,
}) => {
  const [filterType, setFilterType] = useState("All");

  const filteredData = useMemo(() => {
    return filterType === "All"
      ? currentData
      : currentData.filter((item) => item.locationType === filterType);
  }, [filterType, currentData]);
  

  console.log("Filtered Data", filteredData);

  return (
    <div className="user-profile-card">
      <div
        className="d-flex"
        style={{
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <h4 className="user-profile-card-title">All Inspection Vehicles</h4>
        <div className="btn-group">
          <button
            style={{ width: "200px" }}
            type="button"
            className="btn btn-warning dropdown-toggle"
            data-bs-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            {filterType === "All"
              ? "All Inspections"
              : filterType === "Shop"
              ? "Inspection at Shop"
              : "Inspection at UserPlace"}
          </button>
          <ul className="dropdown-menu dropdown-menu-right">
            <li>
              <button
                className="dropdown-item"
                type="button"
                onClick={() => setFilterType("All")}
              >
                All Inspections
              </button>
            </li>
            <li>
              <button
                className="dropdown-item"
                type="button"
                onClick={() => setFilterType("Shop")}
              >
                Inspection at Shop
              </button>
            </li>
            <li>
              <button
                className="dropdown-item"
                type="button"
                onClick={() => setFilterType("UserPlace")}
              >
                Inspection at UserPlace
              </button>
            </li>
          </ul>
        </div>
      </div>
      <div className="car-area list p-0">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-12">
              <div className="row">
                {filteredData.length ? (
                  filteredData.filter(
                    (allRequest) =>
                      allRequest.status === "Accepted" &&
                      allRequest.paymentId !== "" &&
                      allRequest.locationType !== ""
                  ).length ? (
                    filteredData
                      .filter(
                        (allRequest) =>
                          allRequest.status === "Accepted" &&
                          allRequest.paymentId !== ""
                      )
                      .map((allRequest) => (
                        <div
                          className="col-md-6 col-lg-12"
                          key={allRequest._id}
                        >
                          <div className="car-item">
                            <div className="col-md-3">
                              <div>
                                <img
                                  alt={allRequest.car?.model || "Car Image"}
                                  src={
                                    allRequest.car?.image ||
                                    "../assets/img/car/03.jpg"
                                  }
                                  style={{
                                    width: "100%",
                                    borderRadius: 10,
                                  }}
                                />
                              </div>
                            </div>
                            <div className="car-content sideborder col-md-6">
                              <h6>
                                <a className="me-3" href="#">
                                  {allRequest.car?.car_name || "Car Model"}
                                </a>
                              </h6>
                              <ul className="car-list">
                                <li>
                                  <span className="text-danger">
                                    <strong>Check Package Selected:</strong>
                                  </span>
                                </li>
                                <li>
                                  {allRequest.car?.inspectionPoints ||
                                    "No inspection points"}
                                </li>
                              </ul>
                              <div className="d-flex">
                                <h6>
                                  <strong className="text-primary">
                                    Car Price:
                                  </strong>{" "}
                                  ${allRequest?.car?.car_price || "N/A"}
                                  .00
                                </h6>
                                <h6>
                                  <strong className="text-primary">
                                    Service Cost:
                                  </strong>{" "}
                                  ${allRequest.amount || "N/A"}
                                  .00
                                </h6>
                              </div>
                            </div>
                            <div className="btnns col-md-3">
                              <div className="mb-2 mt-2">
                                <button
                                  className="btn btn-primary w-100"
                                  onClick={() => handleOpenModal(allRequest)}
                                >
                                  Talk to Client
                                </button>
                              </div>
                              <button
                                className="btn btn-default border w-100"
                                onClick={() => handleInspection(allRequest)}
                              >
                                Fill Inspection <br />
                                Results
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                  ) : (
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "60vh",
                      }}
                    >
                      <div>
                        <img src={img1} alt="No Data Found" />
                      </div>
                    </div>
                  )
                ) : (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      width: "100%",
                      height: "60vh",
                    }}
                  >
                    <div>
                      <img src={img1} alt="No Data Found" />
                    </div>
                  </div>
                )}
              </div>

              {totalPages > 1 && (
                <div className="pagination-area">
                  <ul className="pagination">
                    <li
                      className={`page-item ${
                        currentPage === 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        className="page-link"
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          if (currentPage > 1)
                            handlePageChange(currentPage - 1);
                        }}
                        aria-label="Previous"
                      >
                        <i className="far fa-arrow-left" />
                      </a>
                    </li>

                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                      (pageNumber) => (
                        <li
                          key={pageNumber}
                          className={`page-item ${
                            pageNumber === currentPage ? "active" : ""
                          }`}
                        >
                          <a
                            className="page-link"
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              handlePageChange(pageNumber);
                            }}
                          >
                            {pageNumber}
                          </a>
                        </li>
                      )
                    )}

                    <li
                      className={`page-item ${
                        currentPage === totalPages ? "disabled" : ""
                      }`}
                    >
                      <a
                        className="page-link"
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          if (currentPage < totalPages)
                            handlePageChange(currentPage + 1);
                        }}
                        aria-label="Next"
                      >
                        <i className="far fa-arrow-right" />
                      </a>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestInspection;
