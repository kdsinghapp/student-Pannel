import React, { useEffect, useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import Footer from './Footer';
import { useSelector } from 'react-redux';
import { getMechanicById } from '../Utils/authApi';
import { useLocation, useNavigate } from 'react-router-dom';

const FillInspectionResult = () => {
    const { user } = useSelector((state) => state.auth);
    const [allServices, setAllServices] = useState(null);
    const mechanic = user.data.mechanicId;
    const navigate = useNavigate()
    const location = useLocation();
    const { selectedRequest, inspectionData } = location.state || {};

    console.log("Inspection Data", inspectionData._id);
    console.log("Selected Request", selectedRequest);

    const fetchUserData = async (mechanic) => {
        try {
            const response = await getMechanicById(mechanic);
            setAllServices(response.mechanic);
        } catch (error) {
            console.error('Error in Fetching Requests:', error.message);
        }
    };

    const handleInspectionData = (data) => {
        navigate('/fill-inspection-result', {
            state: { selectedType: data, inspectionData: inspectionData },
        });
    };

    useEffect(() => {
        fetchUserData(mechanic);
    }, [mechanic]);

    return (
        <>
            <Header />
            <main className="main">
                <div
                    className="site-breadcrumb"
                    style={{ background: 'url(../assets/img/breadcrumb/01.jpg)' }}
                >
                    <div className="container">
                        <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
                        <ul className="breadcrumb-menu">
                            <li>
                                <a href="#">Home</a>
                            </li>
                            <li className="active">Vehicle needs inspection List</li>
                        </ul>
                    </div>
                </div>
                <div className="user-profile py-120">
                    <div className="container">
                        <div className="row">
                            <Sidebar />
                            <div className="col-lg-9">
                                <div className="user-profile-wrapper">
                                    <div className="row">
                                        <div className="col-lg-12">
                                            <h4 className="user-profile-card-title">
                                                Fill Inspection Result
                                            </h4>
                                            <table
                                                className="table table-striped mt-3"
                                                style={{ width: '100%' }}
                                            >
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Service Type</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {allServices?.inspection?.map((data, index) => (
                                                        <tr key={index}>
                                                            <td>{index + 1}</td>
                                                            <td>{data}</td>
                                                            <td>
                                                                <button className="btn btn-primary" onClick={() => handleInspectionData(data)}>
                                                                    Fill Details
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </>
    );
};

export default FillInspectionResult;
