import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { inspectionProfile } from "../store/features/auth/authSlice";

const MechanicProfile = ({ onClose, FirstLogin }) => {
  const { user, isLoading, isSuccess, isError } = useSelector(
    (state) => state.auth
  );
  console.log(user);
  const [profileData, setProfileData] = useState({
    vehicleType: "",
    amount: "",
    state: "",
    city: "",
    address: "",
    startTime: "",
    endTime: "",
    userId: user?.mechanicId || "",
  });
  const [error, setError] = useState("");

  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfileData({ ...profileData, [name]: value });
  };

  const handleSelectChange = (e) => {
    setProfileData({ ...profileData, vehicleType: e.target.value });
  };

  const validateForm = () => {
    const { vehicleType, amount, state, city, address, startTime, endTime } =
      profileData;
    if (
      !vehicleType ||
      !amount ||
      !state ||
      !city ||
      !address ||
      !startTime ||
      !endTime
    ) {
      setError("All fields are required.");
      return false;
    }
    setError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
  
    try {
      const formattedData = {
        vehicleDetails: [
          {
            vehicleType: profileData.vehicleType,
            inspectionCharge: profileData.amount,
          },
        ],
        availability: {
          startTime: profileData.startTime,
          endTime: profileData.endTime,
        },
        serviceArea: {
          city: profileData.city,
          state: profileData.state,
          address: profileData.address,
        },
      };
      dispatch(inspectionProfile({ ...formattedData, userId: user.mechanicId }));
  
      if (isSuccess) {
        dispatch(setFirstLoginStatus(false)); // Set FirstLogin to false after the first login is complete
        onClose();
      } else if (isError) {
        setError("Failed to submit profile. Please try again.");
      }
      console.log(user);
    } catch (error) {
      console.error("Error:", error);
    }
  };  

  return (
    <div className="modal1">
      <div className="modal-content1">
        <h3>Complete Your Profile</h3>
        {error && <p className="error">{error}</p>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Vehicle Type</label>
            <select
              name="vehicleType"
              value={profileData.vehicleType}
              onChange={handleSelectChange}
            >
              <option value="">Select Vehicle Type</option>
              <option value="sedan">Sedan</option>
              <option value="hatchback">Hatchback</option>
              <option value="suv">SUV</option>
              <option value="truck">Truck</option>
            </select>
          </div>

          <div className="form-group">
            <label>Amount</label>
            <input
              type="number"
              name="amount"
              value={profileData.amount}
              onChange={handleChange}
              placeholder="Enter the amount"
            />
          </div>

          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              name="address"
              value={profileData.address}
              onChange={handleChange}
              placeholder="Enter your address"
            />
          </div>

          <div className="form-group">
            <label>City</label>
            <input
              type="text"
              name="city"
              value={profileData.city}
              onChange={handleChange}
              placeholder="Enter your city"
            />
          </div>

          <div className="form-group">
            <label>State</label>
            <input
              type="text"
              name="state"
              value={profileData.state}
              onChange={handleChange}
              placeholder="Enter your state"
            />
          </div>

          <div className="form-group">
            <label>Start Time</label>
            <input
              type="time"
              name="startTime"
              value={profileData.startTime}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>End Time</label>
            <input
              type="time"
              name="endTime"
              value={profileData.endTime}
              onChange={handleChange}
            />
          </div>

          <button type="submit" disabled={isLoading}>
            {isLoading ? "Submitting..." : "Submit"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default MechanicProfile;
