import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { logoutUser } from "../store/features/auth/authSlice";
import axios from "axios";
import Swal from "sweetalert2";

const Sidebar = () => {
  const { user, isSuccess } = useSelector((state) => state.auth);
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const fileInputRef = useRef(null);
  const [profileImage, setProfileImage] = useState(
    user?.profileImage ||
    "https://cdn-icons-png.flaticon.com/512/1995/1995470.png"
  );
  const [uploading, setUploading] = useState(false);
  const [mechanicData, setMechanicData] = useState(null);

  // console.log("User here:-", user)

  const IMG_URL = "http://localhost:8000";

  const fetchMechanicDetails = async () => {
    try {
      if (user?.mechanicId) {
        const response = await axios.post(
          `http://193.203.161.2:8000/mechanic/${user.data.mechanicId}`
        );

        if (response.data.status) {
          setMechanicData(response.data.mechanic.image);
        } else {
          console.error("Mechanic not found");
        }
      }
    } catch (error) {
      console.error("Error fetching mechanic details:", error);
    }
  };
  useEffect(() => {
    fetchMechanicDetails();
  }, [user?.mechanicId]);

  useEffect(() => {
    if (!user && !isSuccess) {
      navigate("/login");
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    await dispatch(logoutUser());
    navigate("/login");
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to upload this image?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, upload it!",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    const formData = new FormData();
    formData.append("image", file);

    try {
      setUploading(true);

      const response = await axios.post(
        `http://193.203.161.2:8000/mechanic/upload-image/${user.mechanicId}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log(response.data.filePath);
      if (response.data.success) {
        const fullImagePath = `http://193.203.161.2:8000/${response.data.filePath.replace(
          /\\/g,
          "/"
        )}`;
        setProfileImage(fullImagePath);

        console.log("Image Path:", fullImagePath);

        Swal.fire({
          title: "Uploaded!",
          text: response.data.message,
          icon: "success",
        });
        fetchMechanicDetails();
      } else {
        Swal.fire({
          title: "Failed!",
          text: "Failed to upload the image. Please try again.",
          icon: "error",
        });
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      Swal.fire({
        title: "Error!",
        text: "An error occurred while uploading the image.",
        icon: "error",
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="col-lg-3">
      <div className="user-profile-sidebar">
        <div className="user-profile-sidebar-top">
          <div
            className="user-profile-img"
            style={{
              position: "relative",
              width: "130px",
              height: "130px",
              overflow: "hidden",
              borderRadius: "50%",
              border: "2px solid #ccc",
            }}
          >
            {/* Image preview */}
            <img
              alt="User Profile"
              src={
                IMG_URL + mechanicData ||
                "https://cdn-icons-png.flaticon.com/512/1995/1995470.png"
              }
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
              }}
            />{" "}
            <button
              className="profile-img-btn"
              type="button"
              onClick={() => fileInputRef.current.click()}
              style={{
                position: "absolute",
                bottom: "10px",
                right: "10px",
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                border: "none",
                color: "white",
                borderRadius: "50%",
                cursor: "pointer",
              }}
            >
              <i className="far fa-camera" />
            </button>
            <input
              className="profile-img-file"
              type="file"
              ref={fileInputRef}
              style={{ display: "none" }}
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
            />
          </div>
          <h5>{user ? user.name : "Guest"}</h5>
          <p>
            <span className="text-primary">
              <strong>{user ? "Active" : "Inactive"}</strong>
            </span>
          </p>
        </div>
        <ul className="user-profile-sidebar-list">
          <li>
            <Link
              className={location.pathname === "/" ? "active" : ""}
              to="/">
              <i className="far fa-user" /> My Profile
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/all-requests" ? "active" : ""
              }
              to="/all-requests"
            >
              <i className="far fa-users" /> All Requests
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/accepted-request" ? "active" : ""
              }
              to="/accepted-request"
            >
              <i class="fa-regular fa-ballot-check"></i> Accepted requests
            </Link>
          </li>
          <li>
            <Link
              className={location.pathname === "/sales-report" ? "active" : ""}
              to="/sales-report"
            >
              <i className="far fa-file" /> Sales Report
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/mechanic-billing" ? "active" : ""
              }
              to="/mechanic-billing"
            >
              <i className="far fa-list" /> Billing
            </Link>
          </li>
          <li>
            <Link
              className={
                location.pathname === "/change-password" ? "active" : ""
              }
              to="/change-password"
            >
              <i className="far fa-key" /> Change Password
            </Link>
          </li>
          <li>
            <Link onClick={handleLogout}>
              <i className="far fa-sign-out" /> Logout
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
