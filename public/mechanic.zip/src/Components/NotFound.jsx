import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
    return (
        <div className="the-width">
            <div className="">
                <div className="four04">
                    <h1>404</h1>
                    <div className="target-cont">
                        <div className="cover"></div>
                        <div className="marks"></div>
                    </div>
                </div>
                <h2>The page you requested was not found.</h2>
                <Link to={'/'} className="button-28" role="button" style={{ marginTop: "70px", color: "white", border: "1px solid #fff" }}>Go to Home</Link>
            </div>
        </div>
    );
}

export default NotFound;
