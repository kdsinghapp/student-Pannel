import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { authService } from "./authService";

const userExist = JSON.parse(localStorage.getItem("user"));

const initialState = {
  user: userExist ? userExist : null,
  isLoading: false,
  isSuccess: false,
  isError: false,
  message: "Something went wrong",
  FirstLogin: userExist ? userExist.FirstLogin : true,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setFirstLogin: (state, action) => {
      state.FirstLogin = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Log in user
      .addCase(loginUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isError = false;
        state.user = action.payload;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.isError = true;
        state.isSuccess = false;
        state.isLoading = false;
        state.user = null;
        state.message = action.payload;
      })

      // Log out user
      .addCase(logoutUser.fulfilled, (state) => {
        state.isError = false;
        state.isSuccess = false;
        state.isLoading = false;
        state.user = null;
        state.message = "";
      })

      // Change password
      .addCase(changePassword.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(changePassword.fulfilled, (state) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isError = false;
        state.message = "Password changed successfully!";
      })
      .addCase(changePassword.rejected, (state, action) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.isError = true;
        state.message = action.payload || "Failed to change password.";
      })

      // Update user profile
      .addCase(updateUserProfile.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(updateUserProfile.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isError = false;
        state.user = {
          ...state.user,
          ...action.payload,
        };
        state.message = "Profile updated successfully!";
      })
      .addCase(updateUserProfile.rejected, (state, action) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.isError = true;
        state.message = action.payload || "Failed to update profile.";
      })

      // Handle inspection profile
      .addCase(inspectionProfile.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(inspectionProfile.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isError = false;
        state.user = {
          ...state.user,
          inspectionDetails: action.payload,
        };
        state.message = "Inspection profile updated successfully!";
        if (state.FirstLogin) {
          state.FirstLogin = false;
        }
      })
      .addCase(inspectionProfile.rejected, (state, action) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.isError = true;
        state.message =
          action.payload || "Failed to update inspection profile.";
      });
  },
});

export default authSlice.reducer;

export const logoutUser = createAsyncThunk("LOGOUT/USER", async () => {
  localStorage.removeItem("user");
  console.log("user logout");
  return null;
});

export const loginUser = createAsyncThunk(
  "LOGIN/USER",
  async (formData, thunkAPI) => {
    try {
      const response = await authService.login(formData);
      if (response.FirstLogin) {
        thunkAPI.dispatch(setFirstLogin(false));
      }
      return response;
    } catch (error) {
      const message = error.response
        ? error.response.data.message
        : error.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const changePassword = createAsyncThunk(
  "CHANGEPASSWORD/USER",
  async (formData, thunkAPI) => {
    try {
      return await authService.passwordChange(formData);
    } catch (error) {
      const message = error.response
        ? error.response.data.message
        : error.message;
      return thunkAPI.rejectWithValue(message || "Failed to change password.");
    }
  }
);

export const updateUserProfile = createAsyncThunk(
  "UPDATEPROFILE/USER",
  async (formData, thunkAPI) => {
    try {
      return await authService.updateUserProfile(formData);
    } catch (error) {
      const message = error.response
        ? error.response.data.message
        : error.message;
      return thunkAPI.rejectWithValue(message || "Failed to update profile.");
    }
  }
);

export const inspectionProfile = createAsyncThunk(
  "INSPECTIONPROFILE/USER",
  async (profileData, thunkAPI) => {
    try {
      return await authService.addInspectionDetails(profileData);
    } catch (error) {
      const message = error.response
        ? error.response.data.message
        : error.message;
      return thunkAPI.rejectWithValue(message || "Failed Inspection.");
    }
  }
);
