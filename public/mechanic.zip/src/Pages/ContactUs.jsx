import React from "react";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import MechanicProfile from "../Components/MechanicProfile";

const ContactUs = () => {
  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">My Profile</li>
            </ul>
          </div>
        </div>
        <div className="user-profile">
          <div className="container">
            <div className="col-lg-12">
              <main className="main">
                <div
                  className="site-breadcrumb"
                  style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
                >
                  <div className="container">
                    <h2 className="breadcrumb-title">Contact Us</h2>
                    <ul className="breadcrumb-menu">
                      <li>
                        <a href="index.html">Home</a>
                      </li>
                      <li className="active">Contact Us</li>
                    </ul>
                  </div>
                </div>
                <div className="about-area py-120">
                  <div className="container">
                    <div className="row align-items-center">
                      <div className="col-lg-6">
                        <img
                          src="https://m.atcdn.co.uk/a/media/9803c68f3aa1439a93135846076a4660.jpg"
                          style={{ width: "100%" }}
                          alt=""
                        />
                      </div>
                      <div className="col-lg-6">
                        <div
                          className="about-right wow fadeInRight"
                          data-wow-delay=".25s"
                        >
                          <div className="site-heading mb-3">
                            <span className="site-title-tagline justify-content-start">
                              <i className="flaticon-drive" /> About Us
                            </span>
                            <h2 className="site-title">
                              World Largest <span>Car Dealer</span> Marketplace.
                            </h2>
                          </div>
                          <p style={{ textAlign: "justify" }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, quis
                            nostrud exercitation ullamco laboris nisi ut aliquip
                            ex ea commodo consequat. Duis aute irure dolor in
                            reprehenderit in voluptate velit esse cillum dolore
                            eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia
                            deserunt mollit anim id est laborum.
                          </p>
                          <p style={{ textAlign: "justify" }}>
                            Sed ut perspiciatis unde omnis iste natus error sit
                            voluptatem accusantium doloremque laudantium, totam
                            rem aperiam, eaque ipsa quae ab illo inventore
                            veritatis et quasi architecto beatae vitae dicta
                            sunt explicabo. Nemo enim ipsam voluptatem quia
                            voluptas sit aspernatur aut odit aut fugit.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="counter-area pt-30 pb-30">
                  <div className="container">
                    <div className="row">
                      <div className="col-lg-3 col-sm-6">
                        <div className="counter-box">
                          <div className="icon">
                            <i className="flaticon-car-rental" />
                          </div>
                          <div>
                            <span
                              className="counter"
                              data-count="+"
                              data-to={500}
                              data-speed={3000}
                            >
                              500
                            </span>
                            <h6 className="title">+ Available Cars </h6>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-3 col-sm-6">
                        <div className="counter-box">
                          <div className="icon">
                            <i className="flaticon-car-key" />
                          </div>
                          <div>
                            <span
                              className="counter"
                              data-count="+"
                              data-to={900}
                              data-speed={3000}
                            >
                              900
                            </span>
                            <h6 className="title">+ Happy Clients</h6>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-3 col-sm-6">
                        <div className="counter-box">
                          <div className="icon">
                            <i className="flaticon-screwdriver" />
                          </div>
                          <div>
                            <span
                              className="counter"
                              data-count="+"
                              data-to={1500}
                              data-speed={3000}
                            >
                              1500
                            </span>
                            <h6 className="title">+ Team Workers</h6>
                          </div>
                        </div>
                      </div>
                      <div className="col-lg-3 col-sm-6">
                        <div className="counter-box">
                          <div className="icon">
                            <i className="flaticon-review" />
                          </div>
                          <div>
                            <span
                              className="counter"
                              data-count="+"
                              data-to={30}
                              data-speed={3000}
                            >
                              30
                            </span>
                            <h6 className="title">+ Years Of Experience</h6>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="testimonial-area bg py-120">
                  <div className="container">
                    <div className="row">
                      <div className="col-lg-6 mx-auto">
                        <div className="site-heading text-center">
                          <span className="site-title-tagline">
                            <i className="flaticon-drive" /> Testimonials
                          </span>
                          <h2 className="site-title">
                            What Our Client <span>Say's</span>
                          </h2>
                          <div className="heading-divider" />
                        </div>
                      </div>
                    </div>
                    <div className="testimonial-slider owl-carousel owl-theme">
                      <div className="testimonial-single">
                        <div className="testimonial-content">
                          <div className="testimonial-author-img">
                            <img src="assets/img/testimonial/01.jpg" alt="" />
                          </div>
                          <div className="testimonial-author-info">
                            <h4>Sylvia H Green</h4>
                            <p>Customer</p>
                          </div>
                        </div>
                        <div className="testimonial-quote">
                          <span className="testimonial-quote-icon">
                            <i className="flaticon-quote" />
                          </span>
                          <p>
                            There are many variations of passages available but
                            the majority have suffered to the alteration in some
                            injected.
                          </p>
                        </div>
                        <div className="testimonial-rate">
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                        </div>
                      </div>
                      <div className="testimonial-single">
                        <div className="testimonial-content">
                          <div className="testimonial-author-img">
                            <img src="assets/img/testimonial/02.jpg" alt="" />
                          </div>
                          <div className="testimonial-author-info">
                            <h4>Gordo Novak</h4>
                            <p>Customer</p>
                          </div>
                        </div>
                        <div className="testimonial-quote">
                          <span className="testimonial-quote-icon">
                            <i className="flaticon-quote" />
                          </span>
                          <p>
                            There are many variations of passages available but
                            the majority have suffered to the alteration in some
                            injected.
                          </p>
                        </div>
                        <div className="testimonial-rate">
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                        </div>
                      </div>
                      <div className="testimonial-single">
                        <div className="testimonial-content">
                          <div className="testimonial-author-img">
                            <img src="assets/img/testimonial/03.jpg" alt="" />
                          </div>
                          <div className="testimonial-author-info">
                            <h4>Reid E Butt</h4>
                            <p>Customer</p>
                          </div>
                        </div>
                        <div className="testimonial-quote">
                          <span className="testimonial-quote-icon">
                            <i className="flaticon-quote" />
                          </span>
                          <p>
                            There are many variations of passages available but
                            the majority have suffered to the alteration in some
                            injected.
                          </p>
                        </div>
                        <div className="testimonial-rate">
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                        </div>
                      </div>
                      <div className="testimonial-single">
                        <div className="testimonial-content">
                          <div className="testimonial-author-img">
                            <img src="assets/img/testimonial/04.jpg" alt="" />
                          </div>
                          <div className="testimonial-author-info">
                            <h4>Parker Jimenez</h4>
                            <p>Customer</p>
                          </div>
                        </div>
                        <div className="testimonial-quote">
                          <span className="testimonial-quote-icon">
                            <i className="flaticon-quote" />
                          </span>
                          <p>
                            There are many variations of passages available but
                            the majority have suffered to the alteration in some
                            injected.
                          </p>
                        </div>
                        <div className="testimonial-rate">
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                        </div>
                      </div>
                      <div className="testimonial-single">
                        <div className="testimonial-content">
                          <div className="testimonial-author-img">
                            <img src="assets/img/testimonial/05.jpg" alt="" />
                          </div>
                          <div className="testimonial-author-info">
                            <h4>Heruli Nez</h4>
                            <p>Customer</p>
                          </div>
                        </div>
                        <div className="testimonial-quote">
                          <span className="testimonial-quote-icon">
                            <i className="flaticon-quote" />
                          </span>
                          <p>
                            There are many variations of passages available but
                            the majority have suffered to the alteration in some
                            injected.
                          </p>
                        </div>
                        <div className="testimonial-rate">
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                          <i className="fas fa-star" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="blog-area py-120">
                  <div className="container">
                    <div className="row">
                      <div className="col-lg-6 mx-auto">
                        <div className="site-heading text-center">
                          <span className="site-title-tagline">
                            <i className="flaticon-drive" /> Our Blog
                          </span>
                          <h2 className="site-title">
                            Latest News &amp; <span>Blog</span>
                          </h2>
                          <div className="heading-divider" />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6 col-lg-4">
                        <div
                          className="blog-item wow fadeInUp"
                          data-wow-delay=".25s"
                          style={{
                            visibility: "visible",
                            animationDelay: "0.25s",
                            animationName: "fadeInUp",
                          }}
                        >
                          <div className="blog-item-img">
                            <img alt="Thumb" src="assets/img/blog/01.jpg" />
                          </div>
                          <div className="blog-item-info">
                            <div className="blog-item-meta">
                              <ul>
                                <li>
                                  <a href="#">
                                    <i className="far fa-user-circle" /> By
                                    Alicia Davis
                                  </a>
                                </li>
                                <li>
                                  <a href="#">
                                    <i className="far fa-calendar-alt" />{" "}
                                    January 29, 2023
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <h4 className="blog-title">
                              <a href="#">
                                There are many variations of passage available.
                              </a>
                            </h4>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6 col-lg-4">
                        <div
                          className="blog-item wow fadeInUp"
                          data-wow-delay=".50s"
                          style={{
                            visibility: "visible",
                            animationDelay: "0.5s",
                            animationName: "fadeInUp",
                          }}
                        >
                          <div className="blog-item-img">
                            <img alt="Thumb" src="assets/img/blog/02.jpg" />
                          </div>
                          <div className="blog-item-info">
                            <div className="blog-item-meta">
                              <ul>
                                <li>
                                  <a href="#">
                                    <i className="far fa-user-circle" /> By
                                    Alicia Davis
                                  </a>
                                </li>
                                <li>
                                  <a href="#">
                                    <i className="far fa-calendar-alt" />{" "}
                                    January 29, 2023
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <h4 className="blog-title">
                              <a href="#">
                                There are many variations of passage available.
                              </a>
                            </h4>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6 col-lg-4">
                        <div
                          className="blog-item wow fadeInUp"
                          data-wow-delay=".75s"
                          style={{
                            visibility: "visible",
                            animationDelay: "0.75s",
                            animationName: "fadeInUp",
                          }}
                        >
                          <div className="blog-item-img">
                            <img alt="Thumb" src="assets/img/blog/03.jpg" />
                          </div>
                          <div className="blog-item-info">
                            <div className="blog-item-meta">
                              <ul>
                                <li>
                                  <a href="#">
                                    <i className="far fa-user-circle" /> By
                                    Alicia Davis
                                  </a>
                                </li>
                                <li>
                                  <a href="#">
                                    <i className="far fa-calendar-alt" />{" "}
                                    January 29, 2023
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <h4 className="blog-title">
                              <a href="#">
                                There are many variations of passage available.
                              </a>
                            </h4>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </main>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <a href="#" id="scroll-top">
        <i className="far fa-arrow-up" />
      </a>
    </>
  );
};

export default ContactUs;
