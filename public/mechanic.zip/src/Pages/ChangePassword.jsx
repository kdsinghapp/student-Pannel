import React, { useState, useEffect } from "react";
import Swal from "sweetalert2"; // Import SweetAlert2
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import { useDispatch, useSelector } from "react-redux";
import Footer from "../Components/Footer";
import { changePassword } from "../store/features/auth/authSlice";

export default function ChangePassword() {
  const [formData, setFormData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const { oldPassword, newPassword, confirmPassword } = formData;

  const { user } = useSelector((state) => state.auth);
  const { isLoading, isError, isSuccess, message } = useSelector(
    (state) => state.auth
  );
  const dispatch = useDispatch();

  // Update form data
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Prepare form data
  const payload = {
    mechanicId: user?.mechanicId, // Ensure mechanicId is available
    oldPassword,
    newPassword,
    confirmPassword,
  };

  // Handle form submission with SweetAlert confirmation
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation checks
    if (!oldPassword || !newPassword || !confirmPassword) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please fill in all fields!",
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      Swal.fire({
        icon: "error",
        title: "Password Mismatch",
        text: "New password and confirmation do not match.",
      });
      return;
    }

    // SweetAlert confirmation
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to change your password?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, change it!",
    });

    if (result.isConfirmed) {
      dispatch(changePassword(payload));
    }
  };

  // Show success or error messages based on the result of the changePassword action
  useEffect(() => {
    if (isSuccess) {
      setFormData({
        oldPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    }

    if (isError) {
      Swal.fire("Error", message, "error");
    }
  }, [isSuccess, isError, message]);

  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">My Profile</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Change Password
                        </h4>
                        <div className="col-lg-12">
                          <div className="user-profile-form">
                            <form onSubmit={handleSubmit}>
                              <div className="form-group">
                                <label>Old Password</label>
                                <input
                                  className="form-control"
                                  placeholder="Old Password"
                                  type="password"
                                  name="oldPassword"
                                  value={formData.oldPassword}
                                  onChange={handleInputChange}
                                />
                              </div>
                              <div className="form-group">
                                <label>New Password</label>
                                <input
                                  className="form-control"
                                  placeholder="New Password"
                                  type="password"
                                  name="newPassword"
                                  value={formData.newPassword}
                                  onChange={handleInputChange}
                                />
                              </div>
                              <div className="form-group">
                                <label>Re-Type Password</label>
                                <input
                                  className="form-control"
                                  placeholder="Re-Type Password"
                                  type="password"
                                  name="confirmPassword"
                                  value={formData.confirmPassword}
                                  onChange={handleInputChange}
                                />
                              </div>
                              <button className="theme-btn my-3" type="submit">
                                <span className="far fa-key" /> Change Password
                              </button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <a href="#" id="scroll-top">
        <i className="far fa-arrow-up" />
      </a>
    </>
  );
}
