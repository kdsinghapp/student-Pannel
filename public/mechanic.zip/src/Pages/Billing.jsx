import React from 'react'
import Header from '../Components/Header'
import Sidebar from '../Components/Sidebar'
import Footer from '../Components/Footer'

export default function Billing() {
  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">Billing</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="table-responsive">
                        <table className="table text-nowrap">
                          <thead>
                            <tr>
                              <th>Car Info</th>
                              <th>Brand</th>
                              <th>Amount</th>
                              <th>Due date</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/01.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/02.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/03.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/04.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/05.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <div className="table-list-info">
                                  <a href="#">
                                    <img alt="" src="../assets/img/car/06.jpg" />
                                    <div className="table-list-content">
                                      <h6>Mercedes Benz Car</h6>
                                      <span>Car ID: #123456</span>
                                    </div>
                                  </a>
                                </div>
                              </td>
                              <td>Ferrari</td>
                              <td>$50,650</td>
                              <td> May 08, 2024 </td>
                              <td>
                                <span className="badge badge-success">
                                  Received
                                </span>
                              </td>
                              <td>
                                <a
                                  aria-label="Details"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-eye" />
                                </a>{" "}
                                <a
                                  aria-label="Edit"
                                  className="btn btn-outline-secondary btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-pen" />
                                </a>{" "}
                                <a
                                  aria-label="Delete"
                                  className="btn btn-outline-danger btn-sm rounded-2"
                                  data-bs-toggle="tooltip"
                                  href="#"
                                >
                                  <i className="far fa-trash-can" />
                                </a>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="pagination-area">
                        <div aria-label="Page navigation example">
                          <ul className="pagination my-3">
                            <li className="page-item">
                              <a
                                aria-label="Previous"
                                className="page-link"
                                href="#"
                              >
                                <span aria-hidden="true">
                                  <i className="far fa-angle-double-left" />
                                </span>
                              </a>
                            </li>
                            <li className="page-item active">
                              <a className="page-link" href="#">
                                1
                              </a>
                            </li>
                            <li className="page-item">
                              <a className="page-link" href="#">
                                2
                              </a>
                            </li>
                            <li className="page-item">
                              <a className="page-link" href="#">
                                3
                              </a>
                            </li>
                            <li className="page-item">
                              <a aria-label="Next" className="page-link" href="#">
                                <span aria-hidden="true">
                                  <i className="far fa-angle-double-right" />
                                </span>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      {/* The Modal */}
      <div className="modal" id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">
              <h4 className="modal-title">Mercedes Benz Car</h4>
              <button className="btn-close" data-bs-dismiss="modal" type="button" />
            </div>
            {/* Modal body */}
            <div className="modal-body">
              <div className="row pb-4">
                <div className="col-lg-5">
                  <h5 className="mb-2">Price: $45,360</h5>
                  <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                    <div className="card-body">
                      <p>
                        <strong>Dealer Name:</strong> John Doe
                      </p>
                      <p>
                        <strong>Address:</strong> 123A/21, Near old garden, Indore
                      </p>
                      <p>
                        <strong>Phone:</strong> 7798797XXXXX
                      </p>
                    </div>
                  </div>
                  <a className="theme-btn" href="details.html">
                    Click For Full Details
                  </a>
                </div>
                <div className="col-lg-7">
                  {/* Carousel */}
                  <div className="carousel slide" data-bs-ride="carousel" id="demo">
                    {/* Indicators/dots */}
                    <div className="carousel-indicators">
                      <button
                        className="active"
                        data-bs-slide-to={0}
                        data-bs-target="#demo"
                        type="button"
                      />{" "}
                      <button
                        data-bs-slide-to={1}
                        data-bs-target="#demo"
                        type="button"
                      />{" "}
                      <button
                        data-bs-slide-to={2}
                        data-bs-target="#demo"
                        type="button"
                      />
                    </div>
                    {/* The slideshow/carousel */}
                    <div className="carousel-inner">
                      <div className="carousel-item active">
                        <img
                          alt="car"
                          className="d-block"
                          src="../assets/img/car/01.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div className="carousel-item">
                        <img
                          alt="car"
                          className="d-block"
                          src="../assets/img/car/02.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div className="carousel-item">
                        <img
                          alt="car"
                          className="d-block"
                          src="../assets/img/car/03.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="#" id="scroll-top">
        <i className="far fa-arrow-up" />
      </a>
    </>

  )
}
