import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import { useSelector, useDispatch } from "react-redux";
import { updateUserProfile } from "../store/features/auth/authSlice";
import { useNavigate } from "react-router-dom";
import MechanicProfile from "../Components/MechanicProfile";
import { getMechanicById } from "../Utils/authApi";

export default function Profile() {

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user, isLoading, isSuccess, isError, message } = useSelector(
    (state) => state.auth
  );

  const fetchMechanic = async (user) => {
    try {
      if (!user || !user.data.mechanicId) return;

      const mechanicId = user.data.mechanicId;
      const response = await getMechanicById(mechanicId);

      console.log("Response", response);

      if (response && response.mechanic) {
        setFormData({
          firstName: response.mechanic.firstName || "",
          lastName: response.mechanic.lastName || "",
          email: response.mechanic.email || "",
          contact: response.mechanic.contact || "",
          address: response.mechanic.address || "",
          userId: mechanicId,
        });
      }
    } catch (error) {
      console.error("Error in Fetching User:", error.message);
    }
  };
  useEffect(() => {

    fetchMechanic(user);
  }, [user]);


  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    contact: "",
    address: "",
    userId: user?.mechanicId || "",
  });

  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/login");
    } else if (user.data.isFirstLogin) {
      navigate('/check-status')
    }
    else {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        contact: user.contact || "",
        address: user.address || "",
      });

      // Work on it is pending 
      // if (user.isFirstLogin === false) {
      //   setShowModal(true);
      // }
    }
  }, [user, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to save the changes to your profile?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, save it!",
      cancelButtonText: "Cancel",
    });

    if (result.isConfirmed) {
      // Show loading alert
      Swal.fire({
        title: "Updating...",
        text: "Please wait while we save your changes.",
        allowOutsideClick: false,
        didOpen: () => {
          Swal.showLoading();
        },
      });

      formData.userId = user?.mechanicId;
      dispatch(updateUserProfile(formData)).then(() => {
        Swal.close();
      });
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  if (isLoading) {
    return (
      <div className="preloader">
        <div className="loader-ripple">
          <div></div>
          <div></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">My Profile</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Edit Profile
                        </h4>
                        <div className="user-profile-form">
                          <form onSubmit={handleSubmit}>
                            <div className="row">
                              <div className="col-md-6">
                                <div className="form-group">
                                  <label>First Name</label>
                                  <input
                                    className="form-control"
                                    placeholder="First Name"
                                    type="text"
                                    name="firstName"
                                    value={formData.firstName}
                                    onChange={handleInputChange}
                                  />
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <label>Last Name</label>
                                  <input
                                    className="form-control"
                                    placeholder="Last Name"
                                    type="text"
                                    name="lastName"
                                    value={formData.lastName}
                                    onChange={handleInputChange}
                                  />
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <label>Email</label>
                                  <input
                                    className="form-control"
                                    placeholder="Email"
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    disabled
                                  />
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div className="form-group">
                                  <label>Phone</label>
                                  <input
                                    className="form-control"
                                    placeholder="Contact"
                                    type="number"
                                    name="contact"
                                    value={formData.contact}
                                    onChange={handleInputChange}
                                  />
                                </div>
                              </div>
                              <div className="col-md-12">
                                <div className="form-group">
                                  <label>Address</label>
                                  <input
                                    className="form-control"
                                    placeholder="Address"
                                    type="text"
                                    name="address"
                                    value={formData.address}
                                    onChange={handleInputChange}
                                  />
                                </div>
                              </div>
                            </div>
                            <button className="theme-btn my-3" type="submit">
                              <span className="far fa-user" /> Save Changes
                            </button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <a href="#" id="scroll-top">
        <i className="far fa-arrow-up" />
      </a>

      {/* Conditionally show the modal */}
      {showModal && (
        <MechanicProfile
          onClose={handleCloseModal}
          FirstLogin={user.isFirstLogin}
        />
      )}
    </>
  );
}
