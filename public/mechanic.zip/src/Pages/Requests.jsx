import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import { useSelector } from "react-redux";
import { createInspection, getAllRequests } from "../Utils/authApi";
import { useNavigate } from "react-router-dom";
import TalkClientRequest from "../Components/TalkClientRequest";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
      if (e.target.classList.contains("modal-overlay")) {
          onClose();
      }
  };

  return (
      <div
          className="modal-overlay"
          onClick={handleOverlayClick}
          role="dialog"
          aria-modal="true"
      >
          <div className="modal-content">
              <button className="close-button" onClick={onClose} aria-label="Close">
                  &times;
              </button>
              {children}
          </div>
      </div>
  );
};

export default function Requests() {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});
  const navigate = useNavigate();

  const [currentPage, setCurrentPage] = useState(1);
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);

  const handleOpenModal = (data) => {
    console.log("Selected Request Data:", data);
    setSelectedRequest(data);
    setShowModal(true);
};

const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
};

  useEffect(() => {
    // Fetch all requests received by the mechanic
    const fetchRequests = async () => {
      try {
        const response = await getAllRequests();
        console.log("Fetched Requests:", response.data);
        setRequests(response.data || []);
        setRequests([...response.data, ...response.data]);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      }
    };
    fetchRequests();
  }, [user]);

  // Fetch inspection data by request ID
  const fetchServices = async (id) => {
    try {
      const response = await createInspection(id);
      console.log("Fetched Inspection Data:", response.inspection);
      return response.inspection;
    } catch (error) {
      console.error("Error in Fetching Inspection Data:", error.message);
      throw error;
    }
  };

  // Handle inspection creation and navigation
  const handleInspection = async (id) => {
    console.log("Initiating Inspection for Request ID:", id);
    try {
      const inspectionData = await fetchServices(id);
      console.log("Inspection Data before Navigation:", inspectionData);
      navigate("/inspections", {
        state: { selectedRequest: id, inspectionData },
      });
    } catch (error) {
      console.error("Error during inspection process:", error);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  console.log("All Requests:-",allRequests)

  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage Account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">Vehicle Needs Inspection List </li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Vehicle Needs Inspection List
                        </h4>
                        <div className="car-area list p-0">
                          <div className="container">
                            <div className="row justify-content-center">
                              <div className="col-lg-12">
                                <div className="row">
                                  {currentData.length ? (
                                    currentData
                                      .filter(
                                        (allRequest) =>
                                          allRequest.status === "Accepted"
                                      )
                                      .map((allRequest, index) => (
                                        <div
                                          className="col-md-6 col-lg-12"
                                          key={allRequest._id}
                                        >
                                          <div className="car-item">
                                            <div className="col-md-3">
                                              <div>
                                                <img
                                                  alt={
                                                    allRequest.car?.model ||
                                                    "Car Image"
                                                  }
                                                  src={
                                                    allRequest.car?.image ||
                                                    "../assets/img/car/03.jpg"
                                                  }
                                                  style={{
                                                    width: "100%",
                                                    borderRadius: 10,
                                                  }}
                                                />
                                              </div>
                                            </div>
                                            <div className="car-content sideborder col-md-6">
                                              <h6>
                                                <a className="me-3" href="#">
                                                  {allRequest.car?.model ||
                                                    "Car Model"}
                                                </a>
                                              </h6>
                                              <ul className="car-list">
                                                <li>
                                                  <span className="text-danger">
                                                    <strong>
                                                      Check Package Selected:
                                                    </strong>
                                                  </span>
                                                </li>
                                                <li>
                                                  {allRequest.car
                                                    ?.inspectionPoints ||
                                                    "No inspection points"}
                                                </li>
                                              </ul>
                                              <h6>
                                                <strong className="text-primary">
                                                  Inspection cost:
                                                </strong>{" "}
                                                ${allRequest.amount || "N/A"}
                                              </h6>
                                            </div>
                                            <div className="btnns col-md-3">
                                              <div className="mb-2 mt-2">
                                                <button
                                                  className="btn btn-primary w-100"
                                                  onClick={() => handleOpenModal(allRequest)}
                                                >
                                                  Talk to Client
                                                </button>
                                              </div>
                                              <div>
                                                <button
                                                  className="btn btn-default border w-100"
                                                  onClick={() =>
                                                    handleInspection(
                                                      allRequest._id
                                                    )
                                                  }
                                                >
                                                  Fill Inspection <br />
                                                  Results
                                                </button>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      ))
                                  ) : (
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        width: "100%",
                                        height: "60vh",
                                      }}
                                    >
                                      <div className="loader"></div>
                                    </div>
                                  )}
                                </div>

                                {totalPages > 1 && (
                                  <div className="pagination-area">
                                    <ul className="pagination">
                                      <li
                                        className={`page-item ${currentPage === 1 ? "disabled" : ""
                                          }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage > 1)
                                              handlePageChange(currentPage - 1);
                                          }}
                                          aria-label="Previous"
                                        >
                                          <i className="far fa-arrow-left" />
                                        </a>
                                      </li>

                                      {Array.from(
                                        { length: totalPages },
                                        (_, i) => i + 1
                                      ).map((pageNumber) => (
                                        <li
                                          key={pageNumber}
                                          className={`page-item ${pageNumber === currentPage
                                            ? "active"
                                            : ""
                                            }`}
                                        >
                                          <a
                                            className="page-link"
                                            href="#"
                                            onClick={(e) => {
                                              e.preventDefault();
                                              handlePageChange(pageNumber);
                                            }}
                                          >
                                            {pageNumber}
                                          </a>
                                        </li>
                                      ))}

                                      <li
                                        className={`page-item ${currentPage === totalPages
                                          ? "disabled"
                                          : ""
                                          }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage < totalPages)
                                              handlePageChange(currentPage + 1);
                                          }}
                                          aria-label="Next"
                                        >
                                          <i className="far fa-arrow-right" />
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
}
