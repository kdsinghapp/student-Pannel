import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import { useLocation } from "react-router-dom";
import { editInspection, getInspectionByCategory } from "../Utils/authApi";
import Swal from "sweetalert2";

// Function to convert strings to camelCase
const toCamelCase = (str) => {
  return str
    .toLowerCase()
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .split(" ")
    .map((word, index) =>
      index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)
    )
    .join("");
};

export default function InspectionResult() {
  const [formData, setFormData] = useState({});
  const [checkboxStates, setCheckboxStates] = useState([]);
  const location = useLocation();
  const { inspectionData } = location.state || {};
  const [detail, setDetail] = useState({});

  console.log("Inspection:-", inspectionData._id);

  const selectedType = location.state?.selectedType || "";
  const inspection = inspectionData?._id;

  const data = {
    inspection,
    selectedType: toCamelCase(selectedType),
  };

  const editService = async (data) => {
    try {
      const res = await editInspection(data);
      console.log("Inspection updated:", res);
    } catch (error) {
      console.error("Error in Edit Inspection:", error.message);
    }
  };

  const getCategory = async (data) => {
    try {
      const res = await getInspectionByCategory(data);
      console.log("Response here:-", res);
      setDetail(res);
      setFormData(res);

      const initialStates = [
        ...(res?.vehicleHistory || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.roadTest || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.vehicleInterior || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.vehicleExterior || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.underHood || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.underBody || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
        ...(res?.vehicleDiagnostics || []).map((data) => ({
          _id: data._id,
          type: data.type,
          status: data.status,
        })),
      ];

      setCheckboxStates(initialStates);
    } catch (error) {
      console.error("Error in get category:", error.message);
    }
  };

  // Handle checkbox changes
  const handleCheckboxChange = (id, status) => {
    const updatedStates = [...checkboxStates];

    const itemIndex = updatedStates.findIndex((item) => item._id === id);
    if (itemIndex !== -1) {
      updatedStates[itemIndex] = {
        ...updatedStates[itemIndex],
        status: updatedStates[itemIndex].status === status ? "" : status,
      };
    }

    setCheckboxStates(updatedStates);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
    const updatedInspectionData = checkboxStates.map((item) => ({
      type: item.type,
      status: item.status,
    }));
  
    const data = {
      inspection,
      selectedType: toCamelCase(selectedType),
      inspectionData: updatedInspectionData,
      formData,
    };
  
    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to submit the inspection data?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, submit it!",
    }).then((result) => {
      if (result.isConfirmed) {
        console.log("Data to be submitted:", data);
        editService(data);
        Swal.fire("Submitted!", "Your data has been submitted successfully.", "success");
      }
    });
  };
  

  useEffect(() => {
    getCategory(data);
  }, []);

  console.log("Details:-", detail);

  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">Fill Inspection Result</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          {selectedType}
                        </h4>
                        <form onSubmit={handleSubmit}>
                          {[...(formData?.vehicleHistory || []), ...(formData?.vehicleInterior || []), ...(formData?.roadTest || []), ...(formData?.vehicleExterior || []), ...(formData?.vehicleDiagnostics || []), ...(formData?.underHood || []), ...(formData?.underBody || [])].map(
                            (data) => (
                              <div
                                className="form-group d-flex"
                                style={{ alignItems: "center", justifyContent: "space-between" }}
                                key={data._id}  // Use _id for the key
                              >
                                <p style={{ fontSize: "15px", color: "black" }}>{data.type}</p>
                                <span
                                  className="d-flex"
                                  style={{
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    gap: "30px",
                                  }}
                                >
                                  <p className="d-flex" style={{ fontSize: "16px" }}>
                                    Repaired:-{" "}
                                    <input
                                      style={{ marginLeft: "5px", fontSize: "13px" }}
                                      type="checkbox"
                                      checked={checkboxStates.find((item) => item._id === data._id)?.status === "Repaired"}
                                      onChange={() =>
                                        handleCheckboxChange(data._id, "Repaired")
                                      }
                                    />
                                  </p>
                                  <p className="d-flex" style={{ fontSize: "16px" }}>
                                    Replaced:-{" "}
                                    <input
                                      style={{ marginLeft: "5px", fontSize: "13px" }}
                                      type="checkbox"
                                      checked={checkboxStates.find((item) => item._id === data._id)?.status === "Replaced"}
                                      onChange={() =>
                                        handleCheckboxChange(data._id, "Replaced")
                                      }
                                    />
                                  </p>
                                  <p className="d-flex" style={{ fontSize: "16px" }}>
                                    Passed:-{" "}
                                    <input
                                      style={{ marginLeft: "5px", fontSize: "13px" }}
                                      type="checkbox"
                                      checked={checkboxStates.find((item) => item._id === data._id)?.status === "Passed"}
                                      onChange={() =>
                                        handleCheckboxChange(data._id, "Passed")
                                      }
                                    />
                                  </p>
                                  <p className="d-flex" style={{ fontSize: "16px" }}>
                                    N/A:-{" "}
                                    <input
                                      style={{ marginLeft: "5px", fontSize: "13px" }}
                                      type="checkbox"
                                      checked={checkboxStates.find((item) => item._id === data._id)?.status === "N/A"}
                                      onChange={() =>
                                        handleCheckboxChange(data._id, "N/A")
                                      }
                                    />
                                  </p>
                                </span>
                              </div>
                            )
                          )}
                          <button className="btn btn-primary my-3 w-100">Submit</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
