import React, { useEffect, useState } from "react";
import Header from "../../Components/Header";

import { Stepper, Step } from "react-form-stepper";
import Availability from "./Availability";
import GeoArea from "./GeoArea";
import InspectionPricing from "./inspectionPricing";
import InspectionPoints from "./InspectionPoints";
import ShowStatus from "../../Components/showStatus";
import { useSelector } from "react-redux";
import { getMechanicById } from "../../Utils/authApi";
import Footer from "../../Components/Footer";

export default function CheckStatus() {
  const [activeStep, setActiveStep] = useState(0);
  const { user } = useSelector(state => state.auth)
  const [status, setStatus] = useState({})
  const [availability, setAvailablity] = useState({})
  console.log("First User:-", user);

  const handleNext = () => {
    if (activeStep < 4) {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep((prev) => prev - 1);
    }
  };

  const fetchUser = async (user) => {
    const mechanic = user?.data?.mechanicId

    try {
      const response = await getMechanicById(mechanic)
      console.log("Mechanic", response.mechanic)
      setStatus(response.mechanic)
    } catch (error) {
      console.error("Error in Fetching Mechanic:", error.message);
    }
  }

  useEffect(() => {
    fetchUser(user)
  }, [user])

  console.log("User Data here:-", user);
  console.log("User status here:-", status.isFullyVerified);

  return (
    <>
      <div style={{ background: "#bababa" }}>
        <Header />

        <div className="container w-50 my-4" style={{ background: "#fff", borderRadius: '16px' }}>
          <div style={{ padding: "20px" }}>
            <Stepper
              activeStep={activeStep}
              styleConfig={{
                activeBgColor: "#4caf50",
                completedBgColor: "#2196f3",
                size: "2em",
                circleFontSize: "1em",
              }}
            >
              <Step label="Step 1" />
              <Step label="Step 2" />
              <Step label="Step 3" />
              <Step label="Step 4" />
              <Step label="Step 5" />
            </Stepper>

            <div style={{ marginTop: "20px" }}>
              {/* {renderStepContent()} */}

              {activeStep === 0 && (
                <ShowStatus status={status} />
              )}
              {activeStep === 1 && (
                <Availability Next={handleNext} Back={handleBack} data={[]} getApi={[]} />
              )}
              {activeStep === 2 && (
                <GeoArea Next={handleNext} Back={handleBack} data={[]} getApi={[]} />
              )}
              {activeStep === 3 && (
                <InspectionPricing Next={handleNext} Back={handleBack} data={[]} getApi={[]} />
              )}
              {activeStep === 4 && (
                <InspectionPoints Next={handleNext} Back={handleBack} data={[]} getApi={[]} />
              )}

              {
                status?.isFullyVerified ? (
                  <div style={{ marginTop: "20px", width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <button onClick={handleBack} disabled={activeStep === 0} style={{ border: "none", backgroundColor: "none" }}>
                      <span class="left-arrow"></span>
                    </button>
                    <button
                      onClick={handleNext}
                      disabled={activeStep === 4 || !status?.isFullyVerified}
                      style={{ border: "none", backgroundColor: "none" }}
                    >
                      <span className="arrow"></span>
                    </button>
                  </div>
                ) : (
                  <>
                  </>
                )
              }
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
}
