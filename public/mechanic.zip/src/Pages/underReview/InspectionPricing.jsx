import React, { useState } from "react";

export default function InspectionPricing({ Next, Back, data, List }) {
  const [inspections, setInspections] = useState(List || []); // Current inspections
  const [newInspection, setNewInspection] = useState({
    vehicleType: "",
    price: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewInspection((prev) => ({ ...prev, [name]: value }));
  };

  const addInspection = (e) => {
    e.preventDefault();
    if (newInspection.vehicleType && newInspection.price) {
      setInspections((prev) => [...prev, newInspection]);
      setNewInspection({ vehicleType: "", price: "" }); // Reset form
    } else {
      alert("Please fill in both fields before adding.");
    }
  };

  const SubmitForm = async (e) => {
    e.preventDefault(); // Prevent default form submission

    const sendData = inspections; // Send all inspections data to the API

    try {
      const res = await callApi(sendData); // Replace with actual API call
      if (res.success) {
        alert("Inspections updated successfully.");
      } else {
        alert("Failed to update inspections. Please try again.");
      }
    } catch (error) {
      console.error("Error calling API:", error);
      alert("An error occurred. Please try again later.");
    }
  };

  return (
    <div>
      <h4>Add New Inspection</h4>
      <form onSubmit={addInspection}>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group">
              <label>Vehicle Type</label>
              <input
                className="form-control"
                placeholder="e.g., Sedan"
                type="text"
                name="vehicleType"
                value={newInspection.vehicleType}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>Price</label>
              <input
                className="form-control"
                placeholder="e.g., 120"
                type="number"
                name="price"
                value={newInspection.price}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>
        </div>
        <button className="theme-btn my-3" type="submit">
          Add Inspection
        </button>
      </form>
      {inspections.length > 0 ? (
        <div className="p-2">
          <table className="table table-striped mt-3">
            <thead>
              <tr>
                <th>#</th>
                <th>Vehicle Type</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              {inspections.map((item, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{item.vehicleType}</td>
                  <td>$ {item.price}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <></>
      )}
    </div>
  );
}

// Mock API call function
async function callApi(data) {
  console.log("Data sent to API:", data); // Log data for debugging
  return new Promise((resolve) =>
    setTimeout(() => resolve({ success: true }), 1000)
  );
}
