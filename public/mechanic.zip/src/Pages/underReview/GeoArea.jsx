import React, { useState } from "react";
import { MachanicGeoArea } from "../../Utils/authApi";

export default function GeoArea({ Next }) {
  const [formData, setFormData] = useState({
    address: "",
    radius: 5, // Default value for radius
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const SubmitForm = async (e) => {
    e.preventDefault(); // Prevent default form submission
    const sendData = {
      longitude: -73.935242, // Static longitude
      latitude: 40.73061,   // Static latitude
      radius: formData.radius,
      address: formData.address,
    };

    try {
      const res = await MachanicGeoArea(sendData);
      console.log(res);
      
      if (res.status) {
        Next(); 
      } else {
        alert("Failed to update geo area. Please try again.");
      }
    } catch (error) {
      console.error("Error calling API:", error);
      alert("An error occurred. Please try again later.");
    }
  };

  return (
    <form onSubmit={SubmitForm}>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <label>Address</label>
            <input
              className="form-control"
              placeholder="Enter Address"
              type="text"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <label>Radius (in km)</label>
            <select
              className="form-control"
              name="radius"
              value={formData.radius}
              onChange={handleInputChange}
              required
            >
              {Array.from({ length: 30 }, (_, i) => i + 1).map((value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <button className="theme-btn my-3" type="submit">
        <span className="far fa-user" /> Save Changes
      </button>
    </form>
  );
}

// Mock API call function
async function callApi(data) {
  console.log("Data sent to API:", data); // Log data for debugging
  return new Promise((resolve) =>
    setTimeout(() => resolve({ success: true }), 1000)
  );
}
