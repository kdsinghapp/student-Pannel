import React, { useState } from "react";
import { TimePicker } from "antd";
import dayjs from "dayjs";
import "antd/dist/reset.css"; // Import Ant Design styles

export default function Availability({ Next, Back, data, getApi }) {
  const [formData, setFormData] = useState({
    startTime: "",
    endTime: "",
  });

  const [logging, SetLoading] = useState(false);

  // Handle time selection
  const handleTimeChange = (time, timeString, fieldName) => {
    setFormData((prev) => ({ ...prev, [fieldName]: timeString }));
  };

  const availability = async (e) => {
    e.preventDefault();

    const sendData = {
      startTime: formData.startTime,
      endTime: formData.endTime,
    };

    try {
      SetLoading(true);
      const res = await MachanicAvailability(sendData);
      if (res.status) {
        Next();
      } else {
        alert("Failed to update availability. Please try again.");
      }
    } catch (error) {
      console.error("Error calling API:", error);
      alert("An error occurred. Please try again later.");
    } finally {
      SetLoading(false);
    }
  };

  return (
    <>
      <h3 style={{ backgroundColor: "rgb(33 150 243)", textAlign: "center", padding: "10px 0px",borderRadius:"15px",fontWeight:"bold",color:"#fff" }}>Add Availability</h3>
      <form onSubmit={availability}>
        <div className="row mt-2">
          <div className="col-md-6">
            <div className="form-group">
              <label>Start Time</label>
              <TimePicker
                className="form-control"
                format="HH:mm"
                value={formData.startTime ? dayjs(formData.startTime, "HH:mm") : null}
                onChange={(time, timeString) =>
                  handleTimeChange(time, timeString, "startTime")
                }
                placeholder="Select Start Time"
                required
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <label>End Time</label>
              <TimePicker
                className="form-control"
                format="HH:mm"
                value={formData.endTime ? dayjs(formData.endTime, "HH:mm") : null}
                onChange={(time, timeString) =>
                  handleTimeChange(time, timeString, "endTime")
                }
                placeholder="Select End Time"
                required
              />
            </div>
          </div>
        </div>
        <button style={{width:"160px",padding:"10px 0px",backgroundColor: "rgb(33 150 243)",}} className="theme-btn my-3" type="submit" disabled={logging}>
          <span className="far fa-user" />
          {logging ? "Saving..." : "Save Changes"}
        </button>
      </form>
    </>
  );
}

async function callApi(data) {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ success: true }), 1000)
  );
}
