import React from 'react'

export default function Status({Next, Back, data}) {
  return (
    <div>Status</div>
  )
}
