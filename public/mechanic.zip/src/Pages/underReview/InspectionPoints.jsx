import React, { useState, useMemo } from "react";
import Swal from "sweetalert2";

const TagInput = ({ values, onChange, autocompleteItems }) => {
  const [inputValue, setInputValue] = useState("");
  const [open, setOpen] = useState(false);

  // Filter autocompleteItems based on the current input value and already selected values
  const filteredItems = useMemo(() => {
    return autocompleteItems.filter(
      (item) =>
        item.program.toLowerCase().includes(inputValue.toLowerCase()) &&
        !values.includes(item.program)
    );
  }, [inputValue, autocompleteItems, values]);

  const handleAddTag = (e) => {
    if (
      e.key === "Enter" &&
      inputValue.trim() &&
      !values.includes(inputValue)
    ) {
      onChange([...values, inputValue.trim()]);
      setInputValue("");
      setOpen(false);
    }
  };

  const handleRemoveTag = (tag) => {
    onChange(values.filter((value) => value !== tag));
  };

  const handleFocus = () => {
    setOpen(true);
  };

  const handleInput = (item) => {
    onChange([...values, item.program]);
    setInputValue("");
    setOpen(false);
  };

  return (
    <div className="tag-input-container">
      <div
        className="tag-input"
        style={{
          width: "100%",
        }}
      >
        {values.map((tag, index) => (
          <span key={index} className="tag mt-2">
            {tag}
            <button
              type="button"
              onClick={() => handleRemoveTag(tag)}
              className="tag-remove-btn"
            >
              &times;
            </button>
          </span>
        ))}
      </div>
      <input
        type="text"
        className="form-control tag-input-field mt-3 p-2"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onKeyDown={handleAddTag}
        placeholder="Add a program"
        onFocus={handleFocus}
        style={{
          width: "100%",
        }}
      />
      {open && filteredItems.length > 0 && (
        <ul className="autocomplete-list">
          {filteredItems.map((item) => (
            <li
              key={item.srNum}
              onClick={() => handleInput(item)}
              className="autocomplete-item"
            >
              {item.program}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

const InspectionPoints = () => {
  const validOptions = useMemo(
    () => [
      { srNum: 1, program: "Vehicle History" },
      { srNum: 2, program: "Road Test" },
      { srNum: 3, program: "Vehicle Exterior" },
      { srNum: 4, program: "Vehicle Interior" },
      { srNum: 5, program: "Vehicle Diagnostics" },
      { srNum: 6, program: "Underhood" },
    ],
    []
  );

  const [selectedTags, setSelectedTags] = useState([]);

  const SubmitForm = async (e) => {
    e.preventDefault();
    console.log("Selected Tags:", selectedTags);
    Swal.fire("Success", "Form submitted successfully!", "success");
  };

  return (
    <form onSubmit={SubmitForm}>
      <div className="row">
        <label className="inspection-points" htmlFor="inspection-points">Select Inspection Points</label>
        <TagInput
          values={selectedTags}
          onChange={setSelectedTags}
          autocompleteItems={validOptions}
        />
      </div>
      <button className="theme-btn my-3" type="submit">
        <span className="far fa-user" /> Save Changes
      </button>
    </form>
  );
};

export default InspectionPoints;
