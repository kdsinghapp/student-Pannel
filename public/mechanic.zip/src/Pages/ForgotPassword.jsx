import React from 'react'

const ForgotPassword = () => {
    return (
        <div className="login-area mt-5 mb-5">
            <div className="container">
                <div className="col-md-5 mx-auto">
                    <div className="login-form">
                        <div className="login-header">
                            <h3>Forgot Password</h3>
                        </div>
                        <form onSubmit={handleSubmit}>
                            <h1>Forgot Password Section Here</h1>
                            {isAlertVisible && (
                                <div className="alert alert-dismissible alert-danger mt-3">
                                    <strong>{error}</strong>
                                </div>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ForgotPassword