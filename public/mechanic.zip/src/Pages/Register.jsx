import React from 'react'

const Register = () => {

    return (
        <main className="main">
            <div className="login-area mt-5 mb-5">
                <div className="container">
                    <div className="col-md-12 mx-auto">
                        <div className="login-form">
                            <div className="login-header">
                                <h3>Mechanic Registration</h3>
                                <p>Interested in becoming a mechanic inspector or wants to learn more?<br />
                                    Please call 1-800-555-5555 or complete the form below.</p>
                            </div>
                            <form action="#">
                                <div className="row">
                                    <div className="form-group col-lg-6">
                                        <label>Name</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Last Name</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Phone Number</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Email Address</label> <input className="form-control" placeholder="" type="email" />
                                    </div>
                                    <div className="form-group col-lg-12">
                                        <label>Company Name</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Address</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>City</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>State</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Zipcode</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-6">
                                        <label>Vehicle Type</label> <input className="form-control" placeholder="" type="text" />
                                    </div>
                                    <div className="form-group col-lg-12">
                                        <label>Anything else you want to tell us</label>
                                        <textarea className="form-control" placeholder="" row="20"></textarea>
                                    </div>
                                    <div className="form-group  col-lg-12">
                                        <input className="form-check-input" id="agree" type="checkbox" value="" /> <label className="form-check-label" >Accept <a href="#">Privacy</a> Agreement</label>
                                    </div>
                                    <div className="col-lg-12">
                                        <button className="theme-btn" type="submit" style={{ width: "auto" }}>Register As Mechanic</button>
                                        <div>
                                            <p>Already registered? <a href="mechaniclogin.html">Log In.</a></p>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}

export default Register