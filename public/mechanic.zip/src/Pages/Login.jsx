import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "../store/features/auth/authSlice";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isAlertVisible, setIsAlertVisible] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isLoading, isSuccess, isError, message, user, FirstLogin } = useSelector(
    (state) => state.auth
  );

  const { email, password } = formData;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setEmailError("");
    setPasswordError("");
    setError("");

    if (email.length === 0) {
      setEmailError("Please enter your email.");
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError("Please enter a valid email address.");
      return;
    }
    if (password.length === 0) {
      setPasswordError("Please enter your password.");
      return;
    }

    setLoading(true);
    dispatch(loginUser(formData));
  };

  useEffect(() => {
    if (isLoading) setLoading(true);
    else setLoading(false);

    if (user && isSuccess) {
      if (user.data.isFirstLogin) {
        navigate("/check-status");
      } else {
        navigate("/");
      }
    }
    if (isError) {
      setError(message);
      setIsAlertVisible(true);
    }
  }, [isLoading, isSuccess, isError, message, navigate, FirstLogin]);

  return (
    <div className="login-area mt-5 mb-5">
      <div className="container">
        <div className="col-md-5 mx-auto">
          <div className="login-form">
            <div className="login-header">
              <h3>Sign In</h3>
              <p>Sign in with your account</p>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Email Address</label>
                <input
                  className={`form-control ${emailError ? "is-invalid" : ""}`}
                  placeholder="Your Email"
                  type="email"
                  name="email"
                  value={email}
                  onChange={handleChange}
                />
                {emailError && (
                  <small className="text-danger">{emailError}</small>
                )}
              </div>
              <div className="form-group">
                <label>Password</label>
                <input
                  className={`form-control ${passwordError ? "is-invalid" : ""}`}
                  placeholder="Your Password"
                  type="password"
                  name="password"
                  value={password}
                  onChange={handleChange}
                />
                {passwordError && (
                  <small className="text-danger">{passwordError}</small>
                )}
              </div>
              <div className="d-flex justify-content-between mb-4">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="remember"
                    type="checkbox"
                  />
                  <label className="form-check-label" htmlFor="remember">
                    Remember Me
                  </label>
                </div>
                <Link className="forgot-pass" to="/forgot-password">
                  Forgot Password?
                </Link>
              </div>
              <div className="d-flex align-items-center">
                <button className="theme-btn" type="submit" disabled={loading}>
                  {loading ? (
                    <span
                      className="spinner-border spinner-border-sm"
                      role="status"
                      aria-hidden="true"
                    ></span>
                  ) : (
                    <i className="far fa-sign-in me-2"></i>
                  )}
                  {loading ? " Signing In..." : "Sign In"}
                </button>
              </div>
              {isAlertVisible && (
                <div className="alert alert-dismissible alert-danger mt-3">
                  <strong>{error}</strong>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
