import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import { useSelector } from "react-redux";
import {
  checkInspectionCreatedAlreadyExists,
  createInspection,
  getAllRequests,
  getPaymentPendingRequest,
} from "../Utils/authApi";
import { useNavigate } from "react-router-dom";
import TalkClientRequest from "../Components/TalkClientRequest";
import img1 from "../../assets/img/notfounddata.png";

const Modal = ({ show, onClose, children }) => {
  if (!show) return null;

  const handleOverlayClick = (e) => {
    if (e.target.classList.contains("modal-overlay")) {
      onClose();
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
    >
      <div className="modal-content">
        <button className="close-button" onClick={onClose} aria-label="Close">
          &times;
        </button>
        {children}
      </div>
    </div>
  );
};

export default function PaymentPending() {
  const { user } = useSelector((state) => state.auth);
  const [allRequests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState({});
  const navigate = useNavigate();

  console.log("User", user);

  const [currentPage, setCurrentPage] = useState(1);
  const dataPerPage = 5;
  const indexOfLastItem = currentPage * dataPerPage;
  const indexOfFirstItem = indexOfLastItem - dataPerPage;
  const currentData = allRequests.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(allRequests.length / dataPerPage);

  const handleOpenModal = (data) => {
    console.log("Selected Request Data:", data);
    setSelectedRequest(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedRequest(null);
  };

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await getAllRequests();
        console.log("Fetched Requests:", response.data);
        setRequests(response.data || []);
      } catch (error) {
        console.error("Error in Fetching Requests:", error.message);
      }
    };
    fetchRequests();
  }, [user]);

  // Fetch inspection data by request ID
  const fetchServices = async (allRequest) => {
    try {
      const response = await createInspection(allRequest._id);
      console.log("Fetched Inspection Data:", response);
      // if(response.inspection.request)
      navigate("/inspections", { state: { inspectionData: allRequest } });
      return response.inspection;
    } catch (error) {
      console.error("Error in Fetching Inspection Data:", error.message);
      if (error) {
        navigate("/inspections", { state: { inspectionData: allRequest } });
      }
      throw error;
    }
  };

  const checkInspectionCreatedAlready = async (allRequest) => {
    const data = {
      requestId: allRequest._id,
      userId: allRequest.user,
      carId: allRequest.car?._id,
      mechanicId: allRequest.mechanic,
    };
    console.log("Data here:-", data);
    try {
      const res = await checkInspectionCreatedAlreadyExists(data);
      console.log("Response", res);
      return res;
    } catch (error) {
      console.error("Error in Checking Inspection Exists:", error);
    }
  };

  // Handle inspection creation and navigation
  const handleInspection = async (allRequest) => {
    console.log("Initiating Inspection for Request ID:", allRequest._id);

    try {
      // Check if inspection already exists
      const inspectionExist = await checkInspectionCreatedAlready(allRequest);

      if (inspectionExist?.message === "Inspection found") {
        console.log("Inspection already exists. Navigating to /inspections.");
        navigate("/inspections", { state: { inspectionData: allRequest } });
        return; // Prevent further execution if inspection exists
      }

      // If inspection does not exist, create a new inspection
      const inspectionData = await fetchServices(allRequest);
      console.log("Inspection Data before Navigation:", inspectionData);
    } catch (error) {
      console.error("Error during inspection process:", error);
    }
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  console.log("Handle Requests",allRequests);
  

  return (
    <>
      <Header />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(../assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Mechanic - Manage Account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="#">Home</a>
              </li>
              <li className="active">Vehicle Inspection Payment Pending </li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <Sidebar />
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Vehicle Needs Inspection Payment Pending:
                        </h4>
                        <div className="car-area list p-0">
                          <div className="container">
                            <div className="row justify-content-center">
                              <div className="col-lg-12">
                                <div className="row">
                                  {currentData.length ? (
                                    currentData.filter(
                                      (allRequest) =>
                                        allRequest?.paymentId === ""
                                    ).length ? (
                                      currentData
                                        .filter(
                                          (allRequest) =>
                                            allRequest.paymentId === ""
                                        )
                                        .map((allRequest, index) => (
                                          <div
                                            className="col-md-6 col-lg-12"
                                            key={allRequest._id}
                                          >
                                            <div className="car-item">
                                              <div className="col-md-3">
                                                <div>
                                                  <img
                                                    alt={
                                                      allRequest.car?.model ||
                                                      "Car Image"
                                                    }
                                                    src={
                                                      allRequest.car?.image ||
                                                      "../assets/img/car/03.jpg"
                                                    }
                                                    style={{
                                                      width: "100%",
                                                      borderRadius: 10,
                                                    }}
                                                  />
                                                </div>
                                              </div>
                                              <div className="car-content sideborder col-md-6">
                                                <h6>
                                                  <a className="me-3" href="#">
                                                    {allRequest.car?.car_name ||
                                                      "Car Model"}
                                                  </a>
                                                </h6>
                                                <ul className="car-list">
                                                  <li>
                                                    <span className="text-danger">
                                                      <strong>
                                                        Check Package Selected:
                                                      </strong>
                                                    </span>
                                                  </li>
                                                  <li>
                                                    {allRequest.car
                                                      ?.inspectionPoints ||
                                                      "No inspection points"}
                                                  </li>
                                                </ul>
                                                <div className="d-flex">
                                                  <h6>
                                                    <strong className="text-primary">
                                                      Car Price:
                                                    </strong>{" "}
                                                    $
                                                    {allRequest?.car
                                                      ?.car_price || "N/A"}
                                                    .00
                                                  </h6>
                                                  <h6>
                                                    <strong className="text-primary">
                                                      Service Cost:
                                                    </strong>{" "}
                                                    $
                                                    {allRequest.amount || "N/A"}
                                                    .00
                                                  </h6>
                                                </div>
                                              </div>
                                              <div className="btnns col-md-3">
                                                <div className="mb-2 mt-2">
                                                  <button className="btn btn-danger w-100">
                                                    Payment Pending
                                                  </button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        ))
                                    ) : (
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "center",
                                          width: "100%",
                                          height: "60vh",
                                        }}
                                      >
                                        <div>
                                          <img src={img1} alt="No Data Found" />
                                        </div>
                                      </div>
                                    )
                                  ) : (
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        width: "100%",
                                        height: "60vh",
                                      }}
                                    >
                                      <div>
                                        <img src={img1} alt="No Data Found" />
                                      </div>
                                    </div>
                                  )}
                                </div>
                                {totalPages > 1 && (
                                  <div className="pagination-area">
                                    <ul className="pagination">
                                      <li
                                        className={`page-item ${
                                          currentPage === 1 ? "disabled" : ""
                                        }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage > 1)
                                              handlePageChange(currentPage - 1);
                                          }}
                                          aria-label="Previous"
                                        >
                                          <i className="far fa-arrow-left" />
                                        </a>
                                      </li>

                                      {Array.from(
                                        { length: totalPages },
                                        (_, i) => i + 1
                                      ).map((pageNumber) => (
                                        <li
                                          key={pageNumber}
                                          className={`page-item ${
                                            pageNumber === currentPage
                                              ? "active"
                                              : ""
                                          }`}
                                        >
                                          <a
                                            className="page-link"
                                            href="#"
                                            onClick={(e) => {
                                              e.preventDefault();
                                              handlePageChange(pageNumber);
                                            }}
                                          >
                                            {pageNumber}
                                          </a>
                                        </li>
                                      ))}

                                      <li
                                        className={`page-item ${
                                          currentPage === totalPages
                                            ? "disabled"
                                            : ""
                                        }`}
                                      >
                                        <a
                                          className="page-link"
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            if (currentPage < totalPages)
                                              handlePageChange(currentPage + 1);
                                          }}
                                          aria-label="Next"
                                        >
                                          <i className="far fa-arrow-right" />
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Modal show={showModal} onClose={handleCloseModal}>
        <TalkClientRequest data={selectedRequest} />
      </Modal>
    </>
  );
}
