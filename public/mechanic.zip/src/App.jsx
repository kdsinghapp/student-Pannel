import "./App.css";
import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./Components/ProtectedRoute";
import PublicRoute from "./Components/PublicRoute";
import SalesReport from "./Pages/SalesReport";

// Lazy-loaded components for code-splitting
const Profile = lazy(() => import("./Pages/Profile"));
const Billing = lazy(() => import("./Pages/Billing"));
const ChangePassword = lazy(() => import("./Pages/ChangePassword"));
const InspectionResult = lazy(() => import("./Pages/InspectionResult"));
const Requests = lazy(() => import("./Pages/Requests"));
const AllRequests = lazy(() => import("./Pages/AllRequests"));
const Login = lazy(() => import("./Pages/Login"));
const Register = lazy(() => import("./Pages/Register"));
const CheckStatus = lazy(() => import("./Pages/underReview/CheckStatus"));
const FillInspectionResult = lazy(() => import("./Components/FillInspectionResult"));
const NotFound = lazy(() => import("./Components/NotFound"));

function App() {

  return (
    <Router  >
      {/* <Router basename="/mechanical/" > */}
      <Suspense fallback={
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "100%", height: "100vh" }}>
          <div class="loader"></div>
        </div>
      }>
        <Routes>
          <Route
            path="/login"
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            }
          />
          <Route
            path="/register"
            element={
              <PublicRoute>
                <Register />
              </PublicRoute>
            }
          />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/mechanic-billing"
            element={
              <ProtectedRoute>
                <Billing />
              </ProtectedRoute>
            }
          />
          <Route
            path="/change-password"
            element={
              <ProtectedRoute>
                <ChangePassword />
              </ProtectedRoute>
            }
          />
          <Route
            path="/sales-report"
            element={
              <ProtectedRoute>
                <SalesReport />
              </ProtectedRoute>
            }
          />
          <Route
            path="/accepted-request"
            element={
              <ProtectedRoute>
                <Requests />
              </ProtectedRoute>
            }
          />
          <Route
            path="/all-requests"
            element={
              <ProtectedRoute>
                <AllRequests />
              </ProtectedRoute>
            }
          />
          <Route
            path="/check-status"
            element={
              <ProtectedRoute>
                <CheckStatus />
              </ProtectedRoute>
            }
          />
          <Route
            path="/inspections"
            element={
              <ProtectedRoute>
                <FillInspectionResult />
              </ProtectedRoute>
            }
          />
          <Route
            path="/fill-inspection-result"
            element={
              <ProtectedRoute>
                <InspectionResult />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </Router>
  );
}

export default App;
