const express = require("express");
const app = express();
require("dotenv").config();
const bodyParser = require("body-parser");
const cors = require("cors");
const { connectDB } = require("./db/db");
const path = require("path");
const { swaggerUi, specs } = require("./swaggerConfig");

app.use(
  cors({
    origin: "*",
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    credentials: true,
  })
);
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use("/images", express.static("images"));
app.use("/testimage", express.static(path.join(__dirname, "testimage")));

// const PORT = 3000
const PORT = process.env.PORT || 7000;

// connect for database
connectDB();

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(specs));
app.use("/dealer", require("./Routes/dealerRoutes"));
app.use("/buyer", require("./Routes/buyerRoutes"));
app.use("/car-makers", require("./Routes/carMakers"));
app.use("/admin", require("./Routes/Admin/adminRouters"));
app.use("/chat", require("./Routes/chatRouter"));
app.use("/mechanic", require("./Routes/mechanic/authRoutes"));
app.use("/towing", require("./Routes/towing/towingRoutes"));
// app.use("/testing", require("./Routes/payment"));

// Machenicl Check Routes by anand <= search for mechanic related routes
/**
 all folling modules are in inside /buyer/purchase this
 // Machenicl Check Routes
 // Delivery Details
 // cleaning Details
 */

app.get("/", (req, res) => {
  res.send("Welcome to the server");
});

app.listen(PORT, () => {
  console.log(`app is running on ${PORT}`);
});

/*
105987
24   5395  = 129480   (23493)
36   3939  = 141804   (35817) 12324

# work in api Implement related to stape add car flow in dealer dashbord
- add api for add car details 
- chagnes in api related on add car details
- Implement api for get at step 2
- Implement api for get at step 3
- changes in api for add images.
- Made changes in design for add image page as needed in api. 
- by tommorow full flow of add car will be completed as want. with all 6 step. 

# flow for add car is completed
- create api for add auction.
- implement api for auction.
- implemnt api for check status of auction and redirect on pages.
- create api for final upload car and publish.
- implemnt api for final upload car and publish and avalable for buy.
- added conditional routing in all 6 pages

{
  status: true,
  message: "success",
  data : cars,
}

{
  status: false,
  message: "failed or ( specific message )",
}
*/
