const axios = require("axios");
const express = require("express");
const router = express.Router();
const { v4: uuidv4 } = require("uuid"); // For unique IDs

// Retrieve Geidea configuration from environment variables
const GEIDEA_BASE_URL = process.env.GEIDEA_API_BASE_URL;
const GEIDEA_PUBLIC_KEY = process.env.GEIDEA_PUBLIC_KEY;
const GEIDEA_API_PASSWORD = process.env.GEIDEA_API_PASSWORD;
const GEIDEA_CALLBACK_URL =
  process.env.GEIDEA_CALLBACK_URL || "http://salousi.com/";

// Check if required environment variables are set
if (!GEIDEA_BASE_URL || !GEIDEA_PUBLIC_KEY || !GEIDEA_API_PASSWORD) {
  console.error(
    "Geidea API credentials are missing. Please set GEIDEA_API_BASE_URL, GEIDEA_PUBLIC_KEY, and GEIDEA_API_PASSWORD."
  );
  process.exit(1); // Exit if essential variables are missing
}

// Create a new payment
router.post("/create-payment", async (req, res) => {
  try {
    // Destructure the incoming request body
    const { amount, currency, customerEmail } = req.body;

    // Validate the required fields
    if (!amount || !currency || !customerEmail) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Generate a unique order ID for the transaction
    const orderId = `order_${uuidv4()}`;

    // Prepare the data to send to Geidea's API
    const paymentData = {
      amount,
      currency,
      callbackUrl: GEIDEA_CALLBACK_URL,
      customerEmail,
      orderId,
    };

    // Make a POST request to Geidea API to initiate the payment
    const response = await axios.post(
      // `${GEIDEA_BASE_URL}/payment-intent/api/v1/direct/eInvoice`,
      `https://api.ksamerchant.geidea.net/payment-intent/api/v2/direct/session`,
      paymentData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `ApiKey ${GEIDEA_PUBLIC_KEY}:${GEIDEA_API_PASSWORD}`,
        },
      }
    );

    // Log success for debugging and auditing
    console.log(`Payment created successfully for order ${orderId}`);

    // Send the successful response back to the client
    res.status(200).json(response.data);
  } catch (error) {
    // Log the error for debugging purposes
    console.error(
      "Payment creation error:",
      error.response?.data || error.message
    );

    // Check if the error is from the Geidea API and provide detailed error message
    const errorMessage =
      error.response?.data ||
      "An unexpected error occurred during payment creation.";

    // Send a detailed error message to the client
    res.status(500).json({
      error: errorMessage,
    });
  }
});

module.exports = router;
