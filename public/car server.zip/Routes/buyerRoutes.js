const express = require("express");
const router = express.Router();
const user = require("./userRoutes");
const car = require("./carRoute");
const favorite = require("./favoritesRoute");
const bids = require("./bidRoute");
const offer = require("./OfferRoute");
const purchase = require("./purchaseUserRoute");
const { authenticateuser } = require("../Middleware/userMiddleware");
const {
  getMechanicsByLocationAndVehicleType,
} = require("../Controller/Mechanic/locationMechanic");
const {
  createRequestToMechanic,
  findUserById,
  checkRequest,
  checkExistingRequest,
  createRequestToTowMan,
} = require("../Controller/userAuth");

router.post("/find-user", findUserById);
router.use("/user", user);
router.use("/car", car);
router.use("/favorites", favorite);
router.use("/bid", bids);
router.use("/offer", offer);
router.use("/purchase", purchase);

// Get Mechanic by Location anad Vehicle Type
router.post(
  "/find-mechanics",
  authenticateuser,
  getMechanicsByLocationAndVehicleType
);

// Send Request to Mechanic from User
router.post("/request-mechanic", authenticateuser, createRequestToMechanic);
router.post("/request-towman", authenticateuser, createRequestToTowMan);

router.post("/", checkRequest);

router.post("/check-request", checkExistingRequest);

module.exports = router;
