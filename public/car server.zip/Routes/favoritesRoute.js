const express = require("express");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { setFavorite, myFavorites } = require("../Controller/favorite");
const router = express.Router();


// Add to favorites
router.post('/setfavorite',authenticateuser, setFavorite );

// Get my favorites
router.get('/my-favorites',authenticateuser, myFavorites );


module.exports = router;
