const express = require("express");
const { dealerMiddleware } = require("../../Middleware/dealerMiddleware");
const { getDealerOffer, getOffersForDealerAndCar, changeOfferStatus } = require("../../Controller/dealer/offerDealerController");
const router = express.Router();




router.get("/get",dealerMiddleware, getDealerOffer);
router.get("/get/:carId",dealerMiddleware, getOffersForDealerAndCar);
router.post("/statusUpdate",dealerMiddleware, changeOfferStatus);


// router.get("/get",dealerMiddleware, getDealerOffer);





module.exports = router;