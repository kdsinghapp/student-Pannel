const express = require("express");
const { dealerMiddleware } = require("../../Middleware/dealerMiddleware");
const { AddCar, choosePlan, NewAddedCar, addPhotos, getCarStatus, updateAuctionStatus, UploadCar } = require("../../Controller/car");
const { upload } = require("../../Middleware/imageMiddlewere");
const { getDealerCars,  changeCarStatus, updateCar, viewDealerCar } = require("../../Controller/dealer/carDealerController");
const router = express.Router();

const uploadFields = upload.fields([
  { name: 'image', maxCount: 1 }, 
  { name: 'gallery', maxCount: 10 } 
]);

const uploadFieldsPlan = upload.fields([
  { name: 'image', maxCount: 1 }, 
  { name: 'gallery', maxCount: 50 } 
]);

router.post("/add",(req, res, next) => {
  console.log('Request files:', req.files);
  console.log('Request body:', req.body);
  next();
}, uploadFields,dealerMiddleware, AddCar);

router.get("/get",dealerMiddleware, getDealerCars);
router.get("/get/:carId",dealerMiddleware, viewDealerCar);

router.put("/update/:carId", (req, res, next) => {
  console.log('Request files:', req.files);
  console.log('Request body:', req.body);
  next();
}, uploadFields, dealerMiddleware, updateCar);

router.post('/changeCarStatus' ,dealerMiddleware, changeCarStatus)

// new flow for purchase plan and add car
router.post("/buy-plan",dealerMiddleware, choosePlan);
router.post("/add-car-details/:carId",dealerMiddleware, NewAddedCar);

router.post('/upload-car-images/:carId', uploadFieldsPlan, addPhotos)
router.get('/get-buy-status/:carId',dealerMiddleware, getCarStatus)
router.post('/updateStatus/:carId', dealerMiddleware, updateAuctionStatus)
router.post('/UploadCar/:carId', dealerMiddleware, UploadCar)

/**

"car_name":"M8"
"car_price":"120000"
"car_maker_id":"66b5bedd27429849a33e9dca"
"car_model_id":"66b5bf9327429849a33e9dd2"
"car_city_id":"66b60b7b65a2f8ea72e057a3"
"car_class":"a-class"
"car_model_year":"2018"
"car_reginal_specification":""
"car_kilometers":"14000"
"car_engine_capacity":""
"car_cylinder":"4"
"car_transmission":"Automatic"
"car_body_color":"red"
"car_fuel_type":"Petrol"
"car_door":"5"
"car_rim_sizes":"34"
"car_type":"sport"
"car_condition":"Best"
"car_under_warranty":"NO"
"car_extra_features":"heating seets"
"car_rent_price":"2000"
"car_interior_color":"white"
"car_additional_details":"water proof"
"car_seat":"4"
"car_drive_type":""
"car_service_history":""
"car_horse_power":"500"
"car_regional_specs":""
"car_address":""
"ground_clearance":"250 mm"
"tank_capacity":"40"
"torque":320 "nm"
"boot_space":"65 L"
"airbag":"6"
"alloy_wheels":"yes"
"car_user_id":""
"car_admin_id":""
"car_plates_codes_id":""
"car_plate_design_id":""
"car_plate_source_id":""
"car_advertisement_id":""
"car_review_count":"",

 */





module.exports = router;