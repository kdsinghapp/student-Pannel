const express = require("express");
const { dealerMiddleware } = require("../../Middleware/dealerMiddleware");
const { getDealerBid, getBidsForDealerAndCar, changeBidStatus } = require("../../Controller/dealer/bidsDealerController");
const router = express.Router();




router.get("/get",dealerMiddleware, getDealerBid);
router.get("/get/:carId",dealerMiddleware, getBidsForDealerAndCar);
router.post("/statusUpdate",dealerMiddleware, changeBidStatus);


// router.get("/get",dealerMiddleware, getDealerOffer);





module.exports = router;