const express = require("express");
const { dealerMiddleware } = require("../../Middleware/dealerMiddleware");
const {  getOffersForDealerAndCar, changeOfferStatus } = require("../../Controller/dealer/offerDealerController");
const { getDealerPurchase, dealerListSoldCar, dealerMarkAsSoldOffline, dealerUnderSoldCar, listMechanicsByDealer, verifyMechenicalProof, UploadMechenicalReport } = require("../../Controller/dealer/purchaseDealerController");
const { upload } = require("../../Middleware/imageMiddlewere");
const router = express.Router();

const uploadFields = upload.fields([
    { name: 'image', maxCount: 1 }, 
  ])


router.get("/get",dealerMiddleware, getDealerPurchase);

// under payment ( added in sold list )
router.get("/get-under-sold",dealerMiddleware, dealerListSoldCar);
router.get("/get-under-sold/:soldId",dealerMiddleware, dealerUnderSoldCar);
router.post("/mark-sold",dealerMiddleware, dealerMarkAsSoldOffline);

router.get('/machenical-list' ,listMechanicsByDealer)  
router.post('/machenical-pay-accepted',dealerMiddleware ,verifyMechenicalProof)  
router.post('/machenical-Upload-report',uploadFields,dealerMiddleware ,UploadMechenicalReport) 


// router.get("/get/:carId",dealerMiddleware, getOffersForDealerAndCar);
// router.post("/statusUpdate",dealerMiddleware, changeOfferStatus);


// router.get("/get",dealerMiddleware, getDealerOffer);


module.exports = router;