const express = require("express");
const { createDealer, updateDealer, loginDealer, getDealer } = require("../../Controller/dealerAuth");
const { dealerMiddleware } = require("../../Middleware/dealerMiddleware");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("Welcome to the user");
});

router.post('/create' , createDealer )
router.post('/login' , loginDealer )
router.get('/getdealer' ,dealerMiddleware, getDealer )
router.put('/update' ,dealerMiddleware, updateDealer )

// router.post("/create", createUser);


module.exports = router;