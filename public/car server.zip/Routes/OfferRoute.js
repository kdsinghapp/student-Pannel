const express = require("express");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { addOffer, offersByCar, myOffer , removeOffer, editOffer } = require("../Controller/offers");
const router = express.Router();

router.post('/',authenticateuser, addOffer );
router.get('/history/:carId', offersByCar);
router.get('/myoffers',authenticateuser, myOffer);
router.post('/cancel-offer',authenticateuser, removeOffer);
router.post('/edit-offer',authenticateuser, editOffer);
  


module.exports = router;
