const express = require("express");
const router = express.Router();
const {
  createUser,
  loginUser,
  getUser,
  logout,
  updateUser,
  logoutAll,
  changePassword,
} = require("../Controller/userAuth");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { upload } = require("../Middleware/imageMiddlewere");
const {
  getMechanicsByLocationAndVehicleType,
} = require("../Controller/Mechanic/locationMechanic");

router.get("/", (req, res) => {
  res.send("Welcome to the user");
});

router.post("/create", createUser);
router.post("/login", loginUser);
router.get("/getuser", authenticateuser, getUser);
router.get("/logout", authenticateuser, logout);
router.put(
  "/update",
  authenticateuser,
  upload.single("profile_image"),
  updateUser
);
router.post("/logout-all", authenticateuser, logoutAll);
router.post("/change-password", authenticateuser, changePassword);

router.post(
  "/find-mechanics",
  authenticateuser,
  getMechanicsByLocationAndVehicleType
);

module.exports = router;
