const express = require("express");
const router = express.Router();
const { authenticateuser } = require("../Middleware/userMiddleware");
const { upload } = require("../Middleware/imageMiddlewere");
const { sendMessage, allChatRooms, allChatRoomsDealer,sendMessageByDealer, getMessagesDealer, getMessagesUser } = require("../Controller/chat");
const { dealerMiddleware } = require("../Middleware/dealerMiddleware");

router.get("/", (req, res) => {
  res.send("Welcome to the chat section!");
});

// all route related to user
router.post("/send",authenticateuser, sendMessage);
router.get("/user-messages/:dealerId",authenticateuser, getMessagesUser);
router.get("/user/rooms",authenticateuser, allChatRooms);

// all route related to DEALER
router.get("/dealer/rooms",dealerMiddleware, allChatRoomsDealer);
router.get("/messages/:chatRoomId",dealerMiddleware, getMessagesDealer);
router.post("/send-by-dealer",dealerMiddleware, sendMessageByDealer);




/**
 
user name anand
66e7e09ce640d2fc3868e1d1

testnew2@gmail.com
66d1665bec243136daf4d744
 
 */


module.exports = router;
