const express = require("express");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { PurchaseImmediateUser, getPurchaseUser, proseedBuyUser, userBuyList, SoldCarByUser, trackPurchase, addMacheniclCheck, UploadMechenicalPayProof, addDeliveryDetails, addCleaningDetails, cancelPurchase, payment, ProofUpload, trackOnePurchase, listMechanicsByDealer, verifyMechenicalProof } = require("../Controller/dealer/purchaseDealerController");
const { upload } = require("../Middleware/imageMiddlewere");
const { dealerMiddleware } = require("../Middleware/dealerMiddleware");
const router = express.Router();

const uploadFields = upload.fields([
    { name: 'image', maxCount: 1 }, 
  ]);

router.post('/buy',authenticateuser ,PurchaseImmediateUser) // this is for imidiate add in purchase list
router.get('/getpurchase',authenticateuser ,getPurchaseUser) // this is for purchase list
router.post('/proseed-buy',authenticateuser ,proseedBuyUser) // this is for choose purchase offline / online

router.get('/my-buying-list',authenticateuser ,userBuyList) // this is for get status of buyed after slection of mode of purchase
router.get('/my-buys',authenticateuser ,SoldCarByUser) // this is list for complete sold car and payment is confirmed from both sides

router.get('/trackPurchase',authenticateuser ,trackPurchase) // this is list for complete sold car and payment is confirmed from both sides
router.get('/track-one-purchase',authenticateuser ,trackOnePurchase) // one car 

// Machenicl Check Routes
// New Check > ... >Uploaded > Accepted
router.post('/add-machenicl-check',authenticateuser ,addMacheniclCheck) // 1 -> 2 "New Check" this is list for complete sold car and payment is confirmed from both sides
// 2 -> 3 when pay payment
router.post('/add-machenical-pay-proof/:userId',uploadFields ,UploadMechenicalPayProof) // 3 -> 4 this is list for complete sold car and payment is confirmed from both sides
// router.post('/machenical-pay-accepted',dealerMiddleware ,verifyMechenicalProof) //added in dealer list 4 -> 5 when review payment and work stared and get 
// router.post('/machenical-list',dealerMiddleware ,listMechanicsByDealer)  // added in dealer list


// Delivery Details
router.post('/add-delivery-detals',authenticateuser ,addDeliveryDetails)

// cleaning Details
router.post('/add-cleaning-detals',authenticateuser ,addCleaningDetails)

// cancel
router.post('/cancel-purchase',authenticateuser ,cancelPurchase)

// for payment
router.post('/pay',authenticateuser ,payment)
router.post('/payment-proof',uploadFields,authenticateuser ,ProofUpload)


module.exports = router;
