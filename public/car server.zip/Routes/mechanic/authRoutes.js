const express = require("express");
const {
  applyMechanic,
  verifyMechanicEmail,
  loginMechanic,
  changePasswordMechanic,
  logoutMechanic,
  checkBlacklist,
  registerMechanic,
  updateServiceDetails,
  findMechanicByEmail,
  setAvailability,
  updateAvailability,
  setGeolocation,
  addInspectionPrice,
  createInspectionTasks,
  updateInspectionTasks,
  getInspectionTasks,
  deleteInspectionTasks,
  getRequestsForMechanic,
  acceptAndRejectRequest,
  checkInspectionCreated,
  getRequestPaymentPending,
} = require("../../Controller/Mechanic/mechanicController");
const {
  updateMechanicProfile,
  findMechanic,
  getAllMechanics,
} = require("../../Controller/Mechanic/profileController");
const Mechanic = require("../../Models/mechanic/authSchema");
const multer = require("multer");
const router = express.Router();
var fs = require("fs-extra");
const Mechanical = require("../../Models/carSchema/mechanicModel");
const {
  addInspection,
  getCategoryById,
  editCategoryById,
  getInspectionById,
  getAllInspectionById,
} = require("../../Controller/Mechanic/inspectionController");

// Mechanic application
router.post("/apply-mechanic", applyMechanic);

// Mechanic email verification
router.get("/verify-mechanic/:token", verifyMechanicEmail);

// Mechaanic Register
router.get("/register-mechanic", registerMechanic);

// Mechanic login
router.post("/login-mechanic", loginMechanic);

// Mechanic Change Password
router.post("/change-password", changePasswordMechanic);

// Mechanic Log Out
router.post("/logout-mechanic", checkBlacklist, logoutMechanic);

// Update Mechanic Profile
router.put("/update-profile/:mechanicId", updateMechanicProfile);

// for single image path
const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    // var path = `./image`;
    var path = `./testimage`;
    fs.mkdirsSync(path);
    callback(null, path);
  },
  filename: function (req, file, callback) {
    var ext = file.originalname.substring(file.originalname.lastIndexOf("."));
    return callback(null, file.fieldname + "-" + Date.now() + ext);
  },
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 20 * 1048576,
  },
  fileFilter: (req, file, callback) => {
    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "image/gif"];
    if (!validTypes.includes(file.mimetype)) {
      return callback(
        new Error("Only JPEG, PNG, and GIF files are allowed"),
        false
      );
    }
    callback(null, true);
  },
});

router.post("/upload-image/:id", async (req, res) => {
  upload.single("image")(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err.message });
    }

    if (!req.file) {
      return res
        .status(400)
        .json({ success: false, message: "No file uploaded" });
    }

    try {
      const mechanicalId = req.params.id;

      const updateData = {
        image: `/testimage/${req.file.filename}`,
      };

      const updatedMechanical = await Mechanic.findByIdAndUpdate(
        mechanicalId,
        updateData,
        { new: true }
      );

      if (!updatedMechanical) {
        return res
          .status(404)
          .json({ success: false, message: "Mechanical not found" });
      }

      res.json({
        success: true,
        message: "File uploaded and Mechanical updated successfully",
        filePath: req.file.path.replace(/\\/g, "/"),
        updatedMechanical,
      });
    } catch (error) {
      console.error("Error updating Mechanical:", error);
      res.status(500).json({
        success: false,
        message: "An error occurred while updating the Mechanical record.",
        error: error.message,
      });
    }
  });
});

router.post("/check-inspection-available", checkInspectionCreated);

// Find Mechanic by id
router.post("/:mechanicId", findMechanic);

// Find Mechanic by email
router.get("/email/:email", findMechanicByEmail);

// Get All Mechanic
router.get("/all-mechanics", getAllMechanics);

// Verify Payment from Mechanic
// router.post("/payment/:id/verify", verifyPayment);

// Fill Mechanic Details
router.post("/service-details/:id", updateServiceDetails);

router.post("/availability/:id", setAvailability);

// Update availability
router.put("/update-availability/:id", updateAvailability);

// Create Geo Location
router.post("/service-area/:id", setGeolocation);

// Inspection Prive and Vehicle Type
router.put("/inspection-price/:id", addInspectionPrice);

// Add Inspection Tasks
router.post("/inspection-task/:id", createInspectionTasks);

// Update inspection tasks
router.put("/update-inspection-task/:id", updateInspectionTasks);

// Get Inspection by Id
router.get("/get-inspection/:id", getInspectionTasks);

// Delete Inspection by Id
router.delete("/delete-inspection/:id", deleteInspectionTasks);

// Get User Requests from Mechanic Side
router.get("/all-requests/:id", getRequestsForMechanic);

// Accept and Reject User Request
router.post("/request/:id", acceptAndRejectRequest);

// Inspection Section
router.post("/addInspection/:requestId", addInspection);

// Get a specific category by inspection ID
router.get("/:category/:id", getCategoryById);

// Edit a specific category by inspection ID
router.put("/:category/:id", editCategoryById);

// Get inspection by ID
router.get("/:id", getInspectionById);

// Get inspection by ID
router.post("/inspections/:carId", getAllInspectionById);

// Get inspection whose payment is pending
router.get("/inspection/:paymentId", getRequestPaymentPending);

module.exports = router;
