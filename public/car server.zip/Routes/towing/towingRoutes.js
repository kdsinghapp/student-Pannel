const express = require("express");
const {
  registerTowMan,
  loginTowMan,
  getRequestByTowingMan,
  changePassword,
  getTowManDetails,
  updateTowManDetails,
  acceptAndRejectRequest,
  getRequestById,
  updateTrackingStatus,
} = require("../../Controller/Towing/towingController");
const {
  authenticateTowingToken,
} = require("../../Middleware/towingMiddleware");
const multer = require("multer");
const TowMan = require("../../Models/towing/TowManSchema");
const router = express.Router();
var fs = require("fs-extra");

// for single image path
const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    // var path = `./image`;
    var path = `./testimage`;
    fs.mkdirsSync(path);
    callback(null, path);
  },
  filename: function (req, file, callback) {
    var ext = file.originalname.substring(file.originalname.lastIndexOf("."));
    return callback(null, file.fieldname + "-" + Date.now() + ext);
  },
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 20 * 1048576,
  },
  fileFilter: (req, file, callback) => {
    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "image/gif"];
    if (!validTypes.includes(file.mimetype)) {
      return callback(
        new Error("Only JPEG, PNG, and GIF files are allowed"),
        false
      );
    }
    callback(null, true);
  },
});

router.post("/upload-image/:id", async (req, res) => {
  upload.single("image")(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err.message });
    }

    if (!req.file) {
      return res
        .status(400)
        .json({ success: false, message: "No file uploaded" });
    }

    try {
      const towingId = req.params.id;
      console.log(towingId)

      const updateData = {
        image: `/${req.file.filename}`,
      };

      const updatedTowing = await TowMan.findByIdAndUpdate(
        towingId,
        updateData,
        { new: true }
      );

      if (!updatedTowing) {
        return res
          .status(404)
          .json({ success: false, message: "Towman not found" });
      }

      res.json({
        success: true,
        message: "File uploaded and Towman updated successfully",
        filePath: req.file.path.replace(/\\/g, "/"),
        updatedTowing,
      });
    } catch (error) {
      console.error("Error updating Mechanical:", error);
      res.status(500).json({
        success: false,
        message: "An error occurred while updating the Towman record.",
        error: error.message,
      });
    }
  });

});

// Register Towman
router.post("/register", registerTowMan);

// Login Towman
router.post("/login", loginTowMan);

// Change Password of Tow man
router.post("/change-password/:id", changePassword);

// Get Single TowMan by Id
router.get("/get-towman/:id", getTowManDetails);

// Update TowMan by Id
router.post("/update-towman/:id", authenticateTowingToken, updateTowManDetails);

// Accept Request of TowMan
router.post("/request/:id", acceptAndRejectRequest);

// Get all requests received to towing man
router.post("/all-requests/:towingId", getRequestByTowingMan);

// Get request by id received to towing man
router.post("/get-requests/:towingId", getRequestById);

// Update request received to towing man
router.put("/update-requests/:towingId", updateTrackingStatus);

module.exports = router;
