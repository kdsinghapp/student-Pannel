const express = require("express");
const router = express.Router();

const dealerAuth = require("./dealer/dealerAuth");
const carForDealer = require("./dealer/carForDealer");
const bidDealerRoute = require("./dealer/bidDealerRoute");
const offerDealerRoute = require("./dealer/offerDealerRoute");
const purchaseDealerRoute = require("./dealer/purchaseDealerRoute");
const { dealerMiddleware } = require("../Middleware/dealerMiddleware");
const {
  getDashboard,
  getMechanicsData,
  getTowmanData,
} = require("../Controller/dealer/carDealerController");
const { adminApprove, adminApproveTowman } = require("../Controller/userAuth");

router.get("/", (req, res) => {
  res.send("Welcome to the dealer");
});

// router.post('/create-dealer' , createDealer )
// router.put('/update-dealer/:id' , updateDealer )

router.use("/auth", dealerAuth);
router.use("/car", carForDealer);
router.use("/bids", bidDealerRoute);
router.use("/offers", offerDealerRoute);
router.use("/purchase", purchaseDealerRoute);

router.get("/dashboard", dealerMiddleware, getDashboard);

// GET all mechanics
router.get("/mechanics", dealerMiddleware, getMechanicsData);

// GET all mechanics
router.get("/towman", dealerMiddleware, getTowmanData);

// Admin Verification API for Mechanic
router.put("/mechanic/:id", dealerMiddleware, adminApprove);

// Admin Verification API for Mechanic
router.put("/towman/:id", dealerMiddleware, adminApproveTowman);

// router.use("/favorites", favorite);
// router.use("/bid", bids);
// router.use("/offer", offer);

module.exports = router;
