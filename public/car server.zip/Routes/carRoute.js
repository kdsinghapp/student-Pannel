const express = require("express");
const {
  AddCar,
  getCars,
  filterCars,
  viewCar,
  detailCarView,
  filtersCar,
  predictCarValue,
  addNewCarAdvertisement,
  getAllCarAdvertisement,
  getAdvertisedCarById,
} = require("../Controller/car");
const { upload } = require("../Middleware/imageMiddlewere");
const {
  addComment,
  commentReply,
  userComments,
} = require("../Controller/Comment");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { dealerMiddleware } = require("../Middleware/dealerMiddleware");
const {
  PurchaseImmediateUser,
  getPurchaseUser,
} = require("../Controller/dealer/purchaseDealerController");
const router = express.Router();

const uploadFields = upload.fields([
  { name: "image", maxCount: 1 },
  { name: "gallery", maxCount: 10 },
]);

router.get("/", (req, res) => {
  res.send("Welcome to the car");
});

router.post(
  "/add",
  (req, res, next) => {
    console.log("Request files:", req.files);
    console.log("Request body:", req.body);
    next();
  },
  uploadFields,
  dealerMiddleware,
  AddCar
);

router.get("/get", getCars);
router.post("/filterCars", filterCars);
router.post("/filtersCar", filtersCar);
router.get("/view-car/:carId", viewCar);
router.get("/detail-car-view/:carId", detailCarView);

// Comment on car //
router.post("/add-comment", authenticateuser, addComment);
router.post("/add-reply/:commentId", authenticateuser, commentReply);
router.get("/user-comments", authenticateuser, userComments);

router.post("/buy", authenticateuser, PurchaseImmediateUser);
router.get("/getpurchase", authenticateuser, getPurchaseUser);
router.post("/proseed-buy", authenticateuser, getPurchaseUser);

router.post("/predict-car-value", authenticateuser, predictCarValue);

router.post("/add-car-advertisement/:userId",  addNewCarAdvertisement);
router.post("/car-advertisement", getAllCarAdvertisement);
router.post(
  "/car-addvertisement-by-id",
  authenticateuser,
  getAdvertisedCarById
);

module.exports = router;
