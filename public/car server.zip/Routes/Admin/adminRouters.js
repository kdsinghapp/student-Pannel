const express = require("express");
const { addCityDetail, getCitys } = require("../../Controller/admin/admin");
const router = express.Router();

router.post("/add-city", addCityDetail);
router.get("/get-citys", getCitys);


module.exports = router;