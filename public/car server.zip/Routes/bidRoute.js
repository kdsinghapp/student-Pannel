const express = require("express");
const { authenticateuser } = require("../Middleware/userMiddleware");
const { addBid, bidsByCar, mybids, removeBids } = require("../Controller/bids");
const router = express.Router();

router.post('/',authenticateuser, addBid );
router.get('/history/:carId', bidsByCar);
router.get('/mybids',authenticateuser, mybids);
router.post('/cancel-bid',authenticateuser, removeBids);
  


module.exports = router;
