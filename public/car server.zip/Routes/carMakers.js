const express = require("express");
const { addCarModel, addCarMaker, getCarMaker, getCarModel } = require("../Controller/carMakers");
const router = express.Router();

router.post("/add-maker", addCarMaker);
router.post("/add-model", addCarModel);

router.get("/get-maker", getCarMaker);
router.get("/get-model", getCarModel);

module.exports = router;
