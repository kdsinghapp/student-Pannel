const jwt = require('jsonwebtoken');
const Dealer = require('../Models/dealerModel');

// Middleware to authenticate the token
const dealerMiddleware = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ status: false, message: 'Token not provided' });
  }

  try {
    const decoded = jwt.verify(token, 'your_jwt_secret');
    const dealer = await Dealer.findById(decoded.dealerId);

    if (!dealer) {
      return res.status(401).json({ status: false, message: 'dealer not found' });
    }

    if (!dealer.token.includes(token)) {
      return res.status(401).json({ status: false, message: 'Token is not valid' });
    }

    req.user = dealer;
    next();
  } catch (error) {
    return res.status(403).json({ status: false, message: 'Token verification failed' });
  }
};


module.exports = {dealerMiddleware};

// .json({status:false, message: 'Token not provided' });