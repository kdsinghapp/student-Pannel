const jwt = require("jsonwebtoken");
const Towing = require("../Models/towing/TowManSchema");

// Middleware to authenticate the token for towing
const authenticateTowingToken = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ status: false, message: "Token not provided" });
  }

  try {
    // Verify the token
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || "your_towing_jwt_secret"
    );

    // Check if the towing request exists
    const towingRequest = await Towing.findById(decoded.towingId);
    if (!towingRequest) {
      return res
        .status(404)
        .json({ status: false, message: "Towing request not found" });
    }

    // Attach the towing request to the request object
    req.towingRequest = towingRequest;
    next();
  } catch (error) {
    console.error("Token verification failed:", error.message);
    return res
      .status(403)
      .json({ status: false, message: "Invalid token", error: error.message });
  }
};

module.exports = { authenticateTowingToken };
