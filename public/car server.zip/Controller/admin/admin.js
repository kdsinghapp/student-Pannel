const city = require("../../Models/admin/cityModel");

const addCityDetail = async (req, res) => {
    try {
        
        const {
            city_name,
            state_id,
            country_id,
        } = req.body;
        if (!city_name) {
            return res.status(404).send({ error: 'city_name not found' });
          }
        
      // Create a new car make document
      const newCity = new city({
        city_name,
        state_id,
        country_id,
      });
  
      // Save the document to the database
      const savedCity = await newCity.save();
      res.status(201).json(savedCity);
    } catch (error) {
      if (error.code === 11000) {
        console.log(req.body);
        res.status(400).json({ error: "somthing went wrong" });
      } else {
        res.status(500).json({ error: "Failed to add city" });
      }
    }
  };
const getCitys = async (req, res) => {
    try {
      // Save the document to the database
      const savedCity = await city.find({});
      res.status(201).json({
        status: true,
        message: "success",
        data : savedCity,
      });
    } catch (error) {
        res.status(500).json({ error: "Failed to get city" });
    }
  };

module.exports = { addCityDetail,getCitys }