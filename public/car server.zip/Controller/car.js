const Car = require("../Models/carSchema/carModel");
const Comment = require("../Models/carSchema/commentModel");
const Favorite = require("../Models/carSchema/favorite");
const Dealer = require("../Models/dealerModel");
const CarListing = require("../Models/carSchema/carValue");
const fs = require("fs");

const AddCar = async (req, res) => {
  const requiredFields = ["car_name", "car_price"]; // Add required fields here

  // Check for missing required fields
  for (const field of requiredFields) {
    if (!req.body[field]) {
      return res.status(400).json({ error: `${field} is required` });
    }
  }
  const dealerId = req.user._id;

  try {
    const car = new Car({
      ...req.body,
      dealer: dealerId,
      image: req.files["image"] ? req.files["image"][0].filename : null,
      gallery: req.files["gallery"]
        ? req.files["gallery"].map((file) => file.filename)
        : [],
    });

    const savedCar = await car.save();
    // res.status(201).json(savedCar);
    res.status(201).json({
      status: true,
      message: "successfully added car",
      data: savedCar,
    });
  } catch (error) {
    // Handle errors
    res.status(400).json({ error: error.message });
  }
};

const getCars = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const userId = req.query.userId || "";
    const skip = (page - 1) * limit;
    const sortOption = req.query.data;

    let favoriteCarIds = [];

    // If userId is provided, fetch the user's favorite cars
    if (userId) {
      const favoriteCars = await Favorite.find({ userId }).select("carId");
      favoriteCarIds = favoriteCars.map((favorite) =>
        favorite.carId.toString()
      );
    }

    // Define the sorting options
    let sort = { _id: -1 };
    if (sortOption === "latest") {
      sort = { _id: -1 };
    } else if (sortOption === "lowPrice") {
      sort = { car_price: 1 };
    } else if (sortOption === "highPrice") {
      sort = { car_price: -1 };
    } else if (sortOption === "featured") {
      // Add your logic for featured sorting
    }

    const allCar = await Car.find({ car_status: "ACTIVE" })
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .select(
        "car_name car_class car_price car_model_year car_fuel_type car_kilometers car_transmission image car_condition gallery dealer car_address"
      )
      .populate({ path: "dealer", select: "number name" });

    const carsWithFavorites = allCar.map((car) => {
      return {
        ...car.toObject(),
        isFavorite: userId
          ? favoriteCarIds.includes(car._id.toString())
          : false,
      };
    });

    // Respond with the car data including pagination
    res.status(200).json({
      status: true,
      message: "success",
      data: carsWithFavorites,
      pagination: {
        page,
        limit,
        totalResults: await Car.countDocuments({ car_status: "ACTIVE" }),
        totalPages: Math.ceil(
          (await Car.countDocuments({ car_status: "ACTIVE" })) / limit
        ),
      },
    });
  } catch (error) {
    res.status(500).json({ status: false, error: error.message });
  }
};

const filterCars = async (req, res) => {
  try {
    const { car_maker_id, car_model_id, minPrice, maxPrice, car_city_id } =
      req.body;

    // Building the filter criteria
    let filterCriteria = { car_status: "ACTIVE" };

    if (car_maker_id) {
      filterCriteria.car_maker_id = car_maker_id;
    }

    if (car_model_id) {
      filterCriteria.car_model_id = car_model_id;
    }
    if (car_city_id) {
      filterCriteria.car_city_id = car_city_id;
    }

    if (minPrice || maxPrice) {
      filterCriteria.car_price = {};
      if (minPrice) {
        filterCriteria.car_price.$gte = parseInt(minPrice);
      }
      if (maxPrice) {
        filterCriteria.car_price.$lte = parseInt(maxPrice);
      }
    }

    // Query the database with the filter criteria
    const cars = await Car.find(filterCriteria).populate({
      path: "dealer",
      select: "number name",
    });

    res.status(200).json({
      status: true,
      message: "success",
      data: cars,
    });
  } catch (error) {
    res.status(500).json({ status: true, error: error.message });
  }
};

const filtersCar = async (req, res) => {
  try {
    const {
      car_condition,
      minPrice,
      maxPrice,
      minYear,
      maxYear,
      car_city_id,
      car_maker_id,
      car_type,
      fuelType,
      engine_size,
      kilometers,
      transmission,
      minSeat,
      maxSeat,
    } = req.body;

    let filterCriteria = { car_status: "ACTIVE" };

    // Price filtering
    if (minPrice || maxPrice) {
      filterCriteria.car_price = {};
      if (minPrice) {
        filterCriteria.car_price.$gte = parseInt(minPrice, 10);
      }
      if (maxPrice) {
        filterCriteria.car_price.$lte = parseInt(maxPrice, 10);
      }
    }

    // Year range filtering
    if (minYear || maxYear) {
      filterCriteria.car_model_year = {};
      if (minYear) {
        filterCriteria.car_model_year.$gte = parseInt(minYear, 10);
      }
      if (maxYear) {
        filterCriteria.car_model_year.$lte = parseInt(maxYear, 10);
      }
    }

    // New filters for body type, fuel, engine size, etc.
    if (car_type) {
      filterCriteria.car_car_type = car_type;
    }

    if (fuelType) {
      filterCriteria.car_fuel_type = fuelType;
    }

    if (engine_size) {
      filterCriteria.car_engine_capacity = engine_size;
    }

    if (kilometers) {
      filterCriteria.car_kilometers = { $lte: kilometers };
    }

    if (transmission) {
      filterCriteria.car_transmission = transmission;
    }

    // Seat filtering (minSeat and maxSeat)
    if (minSeat || maxSeat) {
      filterCriteria.car_seat = {};
      if (minSeat) {
        filterCriteria.car_seat.$gte = parseInt(minSeat, 10);
      }
      if (maxSeat) {
        filterCriteria.car_seat.$lte = parseInt(maxSeat, 10);
      }
    }

    // Existing filters
    if (car_maker_id) {
      filterCriteria.car_maker_id = car_maker_id;
    }

    if (car_city_id) {
      filterCriteria["car_city_id.$oid"] = car_city_id;
    }

    if (car_condition) {
      filterCriteria.car_condition = car_condition;
    }

    console.log("Constructed Filter Criteria:", filterCriteria);

    const cars = await Car.find(filterCriteria);

    // Respond with filtered car data
    res.status(200).json({
      status: true,
      message: "success",
      data: cars,
    });
  } catch (error) {
    console.error("Error fetching cars:", error);
    res.status(500).json({
      status: false,
      message: "An error occurred while fetching cars.",
      error: error.message,
    });
  }
};

const viewCar = async (req, res) => {
  try {
    const { carId } = req.params;

    // Find the car by ID
    const car = await Car.findById(carId);

    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    res.status(200).json(car);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve car" });
  }
};

// const detailCarView = async (req, res) => {
//   try {
//     const { carId } = req.params;

//     // Find the car by ID
//     const car = await Car.findById(carId);

//     if (!car) {
//       return res.status(404).json({ error: 'Car not found' });
//     }

//     const comments = await Comment.find({ carId })
//     .populate('userId', 'name first_name last_name profile_image')
//     .populate('replies.userId', 'name first_name last_name')
//     .sort({ createdAt: -1 });

//     // res.status(200).json(car);
//     res.status(200).json({
//       status: true,
//       message: "success",
//       car : car,
//       comments : comments,
//     }
//     );
//   } catch (error) {
//     res.status(500).json({
//       status: false,
//       message: "Failed to retrieve car",
//     });
//   }
// };

const detailCarView = async (req, res) => {
  try {
    const { carId } = req.params;
    const { addView } = req.query;
    const userId = req.query.userId || "";

    if (addView) {
      const car = await Car.findByIdAndUpdate(
        carId,
        { $inc: { car_views: 1 } },
        { new: true }
      );
    }

    const car = await Car.findById(carId);
    const favoriteCars = await Favorite.find({ userId, carId }).select("carId");

    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    // Retrieve comments associated with the car
    const comments = await Comment.find({ carId })
      .populate("userId", "name first_name last_name profile_image")
      .populate("replies.userId", "name first_name last_name")
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: true,
      message: "success",
      car: car,
      comments: comments,
      isFavorite: favoriteCars.length > 0,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "Failed to retrieve car",
    });
  }
};

/** ------------------ new mathod plans of car sell and purchase plan */

const plans = {
  free: { carImageLimit: 1, duration: 2 }, // 2 weeks
  standard: { carImageLimit: 4, duration: 4 }, // 4 weeks
  enhanced: { carImageLimit: 20, duration: 8 }, // 8 weeks
  deluxe: { carImageLimit: 40, duration: 52 }, // 52 weeks
};

// POST: Add Car Photos API
const choosePlan = async (req, res) => {
  const { planType } = req.body;
  const dealerId = req.user._id;

  if (!plans[planType]) {
    return res.status(400).json({ error: "Invalid plan selected" });
  }

  // Calculate expiry date based on the selected plan
  const selectedPlan = plans[planType];
  const adExpiryDate = new Date();
  adExpiryDate.setDate(adExpiryDate.getDate() + selectedPlan.duration * 7); // weeks to days

  console.log("api run =======>2", planType);
  try {
    const newCar = new Car({
      car_advertisement_id: `ad-${Date.now()}`,
      planType,
      dealer: dealerId,
      carImageLimit: selectedPlan.carImageLimit,
      adExpiryDate,
      car_status: "PLAN", // Status is empty at this stage
    });

    console.log("api run =======>newCar", newCar);
    const savedata = await newCar.save();
    console.log("api run =======>savedata", savedata);

    res.status(201).json({
      status: true,
      message: "success",
      car: newCar,
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to select plan", error });
  }
};

const NewAddedCar = async (req, res) => {
  const { carId } = req.params;
  const dealerId = req.user._id;

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId });
    if (!car) {
      return res
        .status(404)
        .json({ error: "Car not found or dealer does not own this car" });
    }
    Object.assign(car, req.body);
    car.car_status = "DETAILS";
    const updatedCar = await car.save();
    res.status(200).json({
      status: true,
      message: "Car details updated successfully",
      data: updatedCar,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const addPhotos = async (req, res) => {
  const { carId } = req.params;
  const files = req.files; // files is an object with 'image' and 'gallery' arrays

  try {
    const car = await Car.findById(carId);
    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    const imageLimit = car.carImageLimit;
    const currentGalleryCount = car.gallery ? car.gallery.length : 0;

    // Prepare filenames to add
    const newGalleryImages = files.gallery
      ? files.gallery.map((file) => file.filename)
      : [];

    // Check if adding new gallery images exceeds the limit
    if (currentGalleryCount + newGalleryImages.length > imageLimit) {
      // If limit exceeded, delete the uploaded images from the server
      if (files.image && files.image.length > 0) {
        fs.unlinkSync(files.image[0].path); // Remove the main image if uploaded
      }

      newGalleryImages.forEach((file) => {
        fs.unlinkSync(`images/${file}`); // Remove all uploaded gallery images
      });

      return res.status(400).json({
        error: `You can only upload ${imageLimit} images in This plan`,
      });
    }

    // Add new image if car has no image yet
    if (!car.image && files.image && files.image.length > 0) {
      car.image = files.image[0].filename;
    }

    // Add new gallery images to the car's gallery
    car.gallery = [...car.gallery, ...newGalleryImages];

    car.car_status = "IMAGES"; // Update the status
    await car.save();

    res.status(200).json({ message: "Images uploaded successfully", car });
  } catch (error) {
    console.error("Error while uploading images:", error);
    res.status(500).json({ error: "Failed to upload images" });
  }
};

/**
New by chat gpt


const addPhotos = async (req, res) => {
  const { carId } = req.params;
  const files = req.files; // files contain 'image' and 'gallery' arrays

  try {
    const car = await Car.findById(carId);
    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    const imageLimit = car.carImageLimit;
    const currentGalleryCount = car.gallery ? car.gallery.length : 0;

    // Get new gallery images from request
    const newGalleryImages = files.gallery ? files.gallery.map(file => file.filename) : [];

    // Check if new images exceed the allowed limit
    if (currentGalleryCount + newGalleryImages.length > imageLimit) {
      // If image limit exceeded, remove uploaded images
      if (files.image && files.image.length > 0) {
        fs.unlinkSync(files.image[0].path); // Remove main image if uploaded
      }

      newGalleryImages.forEach((filename) => {
        fs.unlinkSync(`images/${filename}`); // Remove uploaded gallery images
      });

      return res.status(400).json({
        error: `You can only upload ${imageLimit} images in the gallery`,
      });
    }

    // Add the main image if the car doesn't have one
    if (!car.image && files.image && files.image.length > 0) {
      car.image = files.image[0].filename;
    }

    // Update the gallery with new images
    car.gallery = [...car.gallery, ...newGalleryImages];
    car.status = "images added"; // Update the car's status

    await car.save();

    return res.status(200).json({
      message: "Images uploaded successfully",
      car,
    });
  } catch (error) {
    console.error("Error while uploading images:", error);
    return res.status(500).json({ error: "Failed to upload images" });
  }
};



 */

const getCarStatus = async (req, res) => {
  const { carId } = req.params;

  try {
    const car = await Car.findById(carId);
    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    const { image, gallery } = car;

    return res.status(200).json({
      status: true,
      message: "Images retrieved successfully",
      data: { image, gallery },
      car,
    });
  } catch (error) {
    console.error("Error fetching car images:", error);
    return res.status(500).json({ error: "Failed to retrieve images" });
  }
};

const updateAuctionStatus = async (req, res) => {
  const { carId } = req.params;
  const dealerId = req.user._id;
  const { auctionIt } = req.body; // expects auctionIt as true or false

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId });
    if (!car) {
      return res
        .status(404)
        .json({ error: "Car not found or dealer does not own this car" });
    }
    car.auctionIt = auctionIt;
    car.car_status = "AUCTION";
    const updatedCar = await car.save();
    res.status(200).json({
      status: true,
      message: "Auction status updated successfully",
      data: updatedCar,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const UploadCar = async (req, res) => {
  const { carId } = req.params;
  const dealerId = req.user._id;

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId });
    if (!car) {
      return res
        .status(404)
        .json({ error: "Car not found or dealer does not own this car" });
    }
    car.car_status = "ACTIVE";
    const updatedCar = await car.save();
    res.status(200).json({
      status: true,
      message: "Auction status updated successfully",
      data: updatedCar,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const carBasePrices = {
  "Toyota Corolla": 20000,
  "Honda Civic": 22000,
  "Ford Focus": 18000,
  "BMW 3 Series": 35000,
};

// Function to determine a default price if the car is not listed
const getDefaultBasePrice = (make) => {
  const luxuryBrands = ["BMW", "Mercedes", "Audi", "Lexus"];
  const midRangeBrands = ["Toyota", "Honda", "Ford", "Hyundai"];

  if (luxuryBrands.includes(make)) return 30000; // Higher starting price for luxury cars
  if (midRangeBrands.includes(make)) return 20000; // Mid-range price
  return 15000; // Default price for other brands
};

const styleFactors = {
  "AWD/4WD": 1.1,
  Commercial: 0.8,
  Convertible: 1.2,
  Coupe: 1.05,
  Hatchback: 0.95,
  "Hybrid/Electric": 1.15,
  Luxury: 1.3,
  Sedan: 1.0,
  "SUV/Crossover": 1.2,
  Truck: 1.1,
  "Van/Minivan": 0.9,
  Wagon: 0.9,
};

const predictCarValue = async (req, res) => {
  try {
    const {
      location,
      condition,
      color,
      accidentHistory,
      rentalCar,
      previousOwners,
      years,
      make,
      model,
      mileage,
      style,
    } = req.body;

    // Check if car make & model exists, otherwise assign a default value
    let basePrice =
      carBasePrices[`${make} ${model}`] || getDefaultBasePrice(make);

    // Depreciation based on years
    for (let i = 0; i < years; i++) {
      basePrice -= basePrice * 0.15; // 15% depreciation per year
    }

    // Mileage factor
    if (mileage > 100000) basePrice -= basePrice * 0.2;
    else if (mileage > 50000) basePrice -= basePrice * 0.1;

    // Condition factor
    const conditionFactors = { Excellent: 1, Good: 0.9, Fair: 0.8, Poor: 0.7 };
    basePrice *= conditionFactors[condition] || 1;

    // Accident history (reduces value by 15%)
    if (accidentHistory === "Yes") basePrice -= basePrice * 0.15;

    // Rental car usage (reduces value by 10%)
    if (rentalCar === "Yes") basePrice -= basePrice * 0.1;

    // Previous owners (each owner reduces value by 5%)
    basePrice -= previousOwners * 0.05 * basePrice;

    // Color impact (Red & unique colors tend to have better resale)
    if (color === "Red") basePrice *= 1.05;
    else if (["Yellow", "Green", "Purple"].includes(color)) basePrice *= 0.95;

    // Location impact (Example: higher demand areas)
    if (location === "California") basePrice *= 1.1;
    else if (location === "Rural Area") basePrice *= 0.9;

    // Apply car style multiplier
    basePrice *= styleFactors[style] || 1;

    // Ensure minimum price
    const estimatedValue = Math.max(basePrice, 1000).toFixed(2);

    res.json({ estimatedValue: `$${estimatedValue}` });
  } catch (error) {
    res
      .status(500)
      .json({ error: "Internal Server Error", details: error.message });
  }
};

// Car Advertisement and Party to sell
const addNewCarAdvertisement = async (req, res) => {
  try {
    const { 
      carDetails, 
      predictedValue, 
      sellingOption, 
      advertisement, 
      mainBannerImage, 
      extraImages 
    } = req.body;

    const { userId } = req.params;

    const newListing = new CarListing({
      carDetails,
      predictedValue,
      sellingOption,
      advertisement,
      mainBannerImage,  
      extraImages,    
      userId
    });

    await newListing.save();

    const populatedListing = await CarListing.findById(newListing._id).populate({
      path: "userId",
      select: "name email phone" 
    });

    res.status(201).json({ 
      status: true, 
      message: "Car listing added", 
      data: populatedListing 
    });
  } catch (error) {
    res.status(500).json({ 
      status: false, 
      message: "Server error", 
      error: error.message 
    });
  }
};

const getAllCarAdvertisement = async (req, res) => {
  try {
    // const userId = req.user._id;
    const listings = await CarListing.find();

    res
      .status(200)
      .json({ status: true, message: "Car listings fetched", data: listings });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Server error", error: error.message });
  }
};

const getAdvertisedCarById = async (req, res) => {
  try {
    const { id } = req.params;
    const listing = await CarListing.findById(id);

    if (!listing) {
      return res
        .status(404)
        .json({ status: false, message: "Car listing not found" });
    }

    res
      .status(200)
      .json({ status: true, message: "Car listing fetched", data: listing });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Server error", error: error.message });
  }
};

module.exports = {
  AddCar,
  predictCarValue,
  getCars,
  filterCars,
  filtersCar,
  viewCar,
  detailCarView,
  choosePlan,
  NewAddedCar,
  addPhotos,
  getCarStatus,
  updateAuctionStatus,
  UploadCar,
  addNewCarAdvertisement,
  getAllCarAdvertisement,
  getAdvertisedCarById,
};

///////////// NOTE //////////////////////////////////////////////
/*
# chagne in name and not creting seprate table
car_class
car_model_year
car_reginal_specification
car_engine_capacity
car_cylinder
car_transmission
car_body_color
car_fuel_type
car_door
car_rim_sizes
car_type
car_condition
car_under_warranty
car_interior_color
car_seat
car_extra_feature
car_drive_type


# must create
car_maker_id

# shood add
Ground Clearance
Fuel Tank Capacity68 Litres
Transmission TypeAutomatic
Max Torque420Nm
Boot Space314 Litres
Max Power300bhp
Airbag
Alloy Wheels




car_name:xc 60
car_class:E-class
car_price:40000
car_maker_id:
car_model_id:
car_model_year:2018
car_reginal_specification:
car_kilometers:34000
car_engine_capacity:
car_cylinder:4
car_transmission:Automatic
car_body_color:red
car_fuel_type:LPG
car_door:5
car_deleted_at:
car_rim_sizes:34
car_type:retro car
car_condition:Good
car_under_warranty:5 months
car_extra_features:heating seets
car_rent_price:3000
car_interior_color:white
car_additional_details:water proof
car_seat:4
car_extra_feature:
car_drive_type:
car_service_history:
car_horse_power:500
car_regional_specs:
car_address:
ground_clearance:250 mm
tank_capacity:40
torque:320 nm
boot_space:65 L
airbag:6
alloy_wheels:yes
car_user_id:"", // use ?
car_admin_id:"", // use ?
car_city_id:"", // see after
car_plates_codes_id:"", // see after
car_plate_design_id:"", // see after
car_plate_source_id:"", // see after
//car_advertisement_id:"",
//car_status:"", // use ?
//car_review_count:"", 

*/
