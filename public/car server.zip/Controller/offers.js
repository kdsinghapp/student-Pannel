const Offer = require("../Models/carSchema/offerModel");
const Car = require("../Models/carSchema/carModel");

const addOffer = async (req, res) => {
  const { amount, carId } = req.body;
  const userId = req.user._id;

  try {
    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ message: "Car not found" });

    if (car?.car_status !== "ACTIVE") {
      return res.status(403).json({
        status: false,
        message: "Car is already sold, please check another car",
      });
    }

    const existingOffer = await Offer.findOne({ user: userId, car: carId });
    if (existingOffer) {
      return res.status(400).json({
        status: false,
        message: "You have already made an offer for this car.",
      });
    }

    // Check if the Offer is higher than the 10% price
    if (amount <= car.car_price * 0.1) {
      return res.status(400).json({
        status: false,
        message: "Your offered ammout is too low",
      });
    }

    // Create a new Offer
    const offer = new Offer({
      user: userId,
      car: carId,
      amount,
      status: "New offer"
    });
    await offer.save();

    res.status(200).json({
      status: true,
      message: "Offer placed successfully",
      data: offer,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};

const offersByCar = async (req, res) => {
  const { carId } = req.params;

  try {
    const offer = await Offer.find({ car: carId })
      .populate("user", "name email")
      .sort({ date: -1 });
    res.status(200).json({
      status: true,
      message: "success",
      data: offer,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const myOffer = async (req, res) => {
  const userId = req.user._id;

  try {
    const offer = await Offer.aggregate([
      { $match: { user: userId } },
      
      // Sort offer by car and date in descending order
      { $sort: { car: 1, date: -1 } },

      // Group by car and keep only the latest offer
      {
        $group: {
          _id: "$car",
          offer: { $first: "$$ROOT" } // Take the first (latest) offer for each car
        }
      },

      // Replace root to simplify the data structure
      { $replaceRoot: { newRoot: "$offer" } },

      // Populate the user information
      {
        $lookup: {
          from: "users", // The name of the user collection
          localField: "user",
          foreignField: "_id",
          as: "user"
        }
      },

      // Unwind the user array
      { $unwind: "$user" },
      {
        $lookup: {
          from: "cars",
          localField: "car",
          foreignField: "_id",
          as: "car"
        }
      },

      { $unwind: "$car" },

      {
        $project: {
          _id: 1,
          car: {
            _id: 1,
            carModel: 1,
            currentPrice: 1, // Add this field to include the current price
            car_status: 1,
            car_name: 1,
            car_price: 1,
            car_interior_color: 1,
            car_transmission: 1,
            car_door: 1,
            car_engine_capacity: 1,
            Mileage: 1,
            image: 1,
            Exterior: 1,
          },
          amount: 1,
          date: 1,
          status: 1,
          "user.name": 1,
          "user.email": 1
        }
      },

      { $sort: { date: -1 } }
    ]);

    res.status(200).json({
      status: true,
      message: "Success",
      data: offer,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
const removeOffer = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id;

  try {
    // Find the car to ensure it exists
    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ message: "Car not found" });

    // Delete all offer by the user for the given car
    const result = await Offer.deleteMany({ user: userId, car: carId });

    if (result.deletedCount === 0) {
      return res.status(404).json({
        status: false,
        message: "No offer found for this car by the user",
      });
    }

    res.status(200).json({
      status: true,
      message: `Offer removed successfully`,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};

const editOffer = async (req, res) => {
  const { offerId, amount } = req.body;
  const userId = req.user._id;

  try {
    const offer = await Offer.findOne({ _id: offerId, user: userId });
    if (!offer) {
      return res.status(404).json({
        status: false,
        message: "Offer not found or you are not authorized to edit this offer.",
      });
    }

    if (offer.status !== "New offer") {
      return res.status(400).json({
        status: false,
        message: "Only offers with status 'New offer' can be edited.",
      });
    }

    const car = await Car.findById(offer.car);
    if (amount <= car.car_price * 0.1) {
      return res.status(400).json({
        status: false,
        message: "Your new offered amount is too low.",
      });
    }

    offer.amount = amount;
    await offer.save();

    res.status(200).json({
      status: true,
      message: "Offer updated successfully.",
      data: offer,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};


module.exports = { addOffer, offersByCar, myOffer , removeOffer, editOffer  };
