const { get_current_date } = require("../assets/utils");
const Dealer = require("../Models/dealerModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const getDealer = (req, res) => {
  try {
    const sendUser = {
      _id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      password: req.user.password,
      number: req.user.number,
      country: req.user.country,
      city: req.user.city,
      lat: req.user.lat,
      long: req.user.long,
    };
    res
      .status(200)
      .json({ status: true, message: "Successful", dealer: sendUser });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const createDealer = async (req, res) => {
  const { name, email, password, number, country, city, lat, long } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      status: false,
      message: "Email and password are required",
      error,
    });
  }

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    const dealer = new Dealer({
      name,
      email,
      password: hashedPassword,
      number,
      country,
      city,
      lat,
      long,
    });
    await dealer.save();
    res
      .status(201)
      .json({ status: true, message: "Successful", dealer: dealer });
  } catch (error) {
    // Handle duplicate email error specifically
    if (error.code === 11000) {
      return res
        .status(400)
        .json({ status: false, message: "Email already exists", error });
    }
    res
      .status(400)
      .json({ status: false, message: "Internal server error", error });
  }
};

const loginDealer = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if the user exists
    const dealer = await Dealer.findOne({ email });
    if (!dealer) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, dealer.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    // Generate a JWT token
    const token = jwt.sign({ dealerId: dealer._id }, "your_jwt_secret", {
      expiresIn: "90d",
    });

    // Store the token in the dealer's token array ( without removing old tokens)
    // dealer.token = dealer.token || [];
    // dealer.token.push(token);
    // await dealer.save();

    // Store the token in the dealer's token ( with removing old tokens)
    dealer.token = [token];
    await dealer.save();

    const sendDealer = {
      _id: dealer._id,
      email: dealer.email,
      name: dealer.name,
      number: dealer.number,
      country: dealer.country,
      city: dealer.city,
      lat: dealer.lat,
      long: dealer.long,
    };

    res.status(200).json({
      status: true,
      message: "Login successful",
      dealer: sendDealer,
      token,
    });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const updateDealer = async (req, res) => {
  const { name, email, password, number, country, city, lat, long } = req.body;
  const updates = {
    name,
    email,
    password,
    number,
    country,
    city,
    lat,
    long,
    updated_date: get_current_date(),
  };
  const id = req.user._id;
  try {
    const dealer = await Dealer.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    });

    if (!dealer) {
      return res
        .status(404)
        .json({ status: false, message: "Dealer not found", error });
    }

    res.json(dealer);
  } catch (error) {
    // Handle duplicate email error specifically
    if (error.code === 11000) {
      return res
        .status(400)
        .json({ status: false, message: "Email already exists", error });
    }
    res
      .status(400)
      .json({ status: false, message: "Internal server error", error });
  }
};



module.exports = {
  createDealer,
  getDealer,
  loginDealer,
  updateDealer,
};
