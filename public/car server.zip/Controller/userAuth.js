const User = require("../Models/userModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const Mechanical = require("../Models/carSchema/mechanicModel");
const Mechanic = require("../Models/mechanic/authSchema");
const Request = require("../Models/mechanic/requestSchema");
const TowingRequest = require("../Models/towing/towingModels");
const Inspection = require("../Models/mechanic/inspectionSchema");
const TowManSchema = require("../Models/towing/TowManSchema");

const getUser = (req, res) => {
  try {
    const sendUser = {
      _id: req.user._id,
      email: req.user.email,
      created_at: req.user.created_at,
      first_name: req.user.first_name,
      last_name: req.user.last_name,
      mobile_number: req.user.mobile_number,
      country_code: req.user.country_code,
      address: req.user.address,
      profile_image: req.user.profile_image,
    };
    res
      .status(200)
      .json({ status: true, message: "Successful", user: sendUser });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const createUser = async (req, res) => {
  try {
    const { email, password, name, mobile_number, country_code, address } =
      req.body;

    // Check if the email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res
        .status(400)
        .json({ status: false, message: "Email already exists" });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = new User({
      email,
      password: hashedPassword,
      name,
      mobile_number,
      country_code,
      address,
    });

    // Save the user to the database
    await newUser.save();

    const sendUser = {
      _id: newUser._id,
      email: newUser.email,
      created_at: newUser.created_at,
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      mobile_number: newUser.mobile_number,
      country_code: newUser.country_code,
      address: newUser.address,
    };
    res.status(201).json({
      status: true,
      message: "User created successfully",
      user: sendUser,
    });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if the user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    // Generate a JWT token
    const token = jwt.sign({ userId: user._id }, "your_jwt_secret", {
      expiresIn: "90d",
    });

    // Store the token in the user's token array
    user.token = user.token || [];
    user.token.push(token);
    await user.save();

    const sendUser = {
      _id: user._id,
      email: user.email,
      created_at: user.created_at,
      first_name: user.first_name,
      last_name: user.last_name,
      mobile_number: user.mobile_number,
      country_code: user.country_code,
      address: user.address,
    };

    res.status(200).json({
      status: true,
      message: "Login successful",
      user: sendUser,
      token,
    });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const logout = async (req, res) => {
  try {
    const token = req.headers["authorization"].split(" ")[1];

    // Remove the token from the user's token array
    req.user.token = req.user.token.filter((userToken) => userToken !== token);

    await req.user.save();

    res.status(200).json({ status: true, message: "Logout successful" });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const updateUser = async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      mobile_number,
      country_code,
      address,
      password,
    } = req.body;

    // Find the user by ID
    const user = req.user;

    // Update user fields
    if (first_name) user.first_name = first_name;
    if (last_name) user.last_name = last_name;
    if (mobile_number) user.mobile_number = mobile_number;
    if (country_code) user.country_code = country_code;
    if (address) user.address = address;
    if (password) user.password = await bcrypt.hash(password, 10);

    // Update profile image if uploaded
    if (req.file) {
      // Delete old profile image if it exists
      if (user.profile_image) {
        const oldImagePath = path.join(__dirname, "..", user.profile_image); // Construct the correct path
        fs.unlink(oldImagePath, (err) => {
          if (err && err.code !== "ENOENT") {
            console.log("Failed to delete old profile image:", err);
          }
        });
      }

      // Update to new profile image
      user.profile_image = `images/${req.file.filename}`; // Use relative path
    }
    await user.save();

    res
      .status(200)
      .json({ status: true, message: "User updated successfully", user });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const logoutAll = async (req, res) => {
  try {
    const user = req.user;

    // Clear all tokens
    user.token = [];

    await user.save();

    res.status(200).json({
      status: true,
      message: "Logged out from all devices successfully",
    });
  } catch (error) {
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const changePassword = async (req, res) => {
  try {
    const { current_password, new_password, confirm_password } = req.body;
    const userId = req.user._id; // Assuming req.user is populated via authentication middleware

    // Check if all fields are provided
    if (!current_password || !new_password || !confirm_password) {
      return res.status(400).json({
        status: false,
        message: "All fields (current, new, confirm password) are required",
      });
    }

    // Check if new and confirm passwords match
    if (new_password !== confirm_password) {
      return res.status(400).json({
        status: false,
        message: "New password and confirm password do not match",
      });
    }

    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        status: false,
        message: "User not found",
      });
    }

    // Compare current password with stored password
    const isMatch = await bcrypt.compare(current_password, user.password);
    if (!isMatch) {
      return res.status(400).json({
        status: false,
        message: "Current password is incorrect",
      });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(new_password, 10);

    // Update the password in the database
    user.password = hashedPassword;
    await user.save();

    res.status(200).json({
      status: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "Server error",
      error,
    });
  }
};

// Send Request for Mechanic from User to Mechanic
const createRequestToMechanic = async (req, res) => {
  try {
    const { userId, mechanicId, carId, amount } = req.body;

    // Validate required fields
    if (!userId || !mechanicId || !carId || !amount) {
      return res
        .status(400)
        .json({ status: false, message: "Missing required fields" });
    }

    // Check if a similar request already exists
    const existingRequest = await Request.findOne({
      user: userId,
      mechanic: mechanicId,
      car: carId,
    });
    if (existingRequest) {
      return res.status(409).json({
        status: false,
        message: "Request already sent to this mechanic for this car",
        request: existingRequest,
      });
    }

    // Create a new request document
    const newRequest = new Request({
      user: userId,
      mechanic: mechanicId,
      car: carId,
      amount,
    });

    // Save the request to the database
    await newRequest.save();

    res.status(201).json({
      status: true,
      message: "Inspection request sent successfully",
      request: newRequest,
    });
  } catch (error) {
    console.error("Error creating inspection request:", error);
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const findUserById = async (req, res) => {
  const { userId } = req.body;

  try {
    if (!userId) {
      return res
        .status(400)
        .json({ status: false, message: "User ID is required" });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ status: false, message: "User not found" });
    }

    res.status(200).json({ status: true, message: "User found", data: user });
  } catch (error) {
    console.error("Error finding User:", error);
    res
      .status(500)
      .json({ status: false, message: "Server error", error: error.message });
  }
};

const checkRequest = async (req, res) => {
  const { userId, carId } = req.body;

  // Ensure both userId and carId are provided
  if (!userId || !carId) {
    return res
      .status(400)
      .json({ message: "User ID and Car ID are required." });
  }

  try {
    // Find if there's a request that matches the userId and carId
    const existingRequest = await Request.findOne({ userId, carId });

    if (existingRequest) {
      return res.status(200).json({
        message: "Request already sent for this car.",
        requestSent: true,
      });
    } else {
      return res
        .status(200)
        .json({ message: "No request found.", requestSent: false });
    }
  } catch (error) {
    console.error("Error checking request:", error);
    return res.status(500).json({ message: "Server error" });
  }
};

const checkExistingRequest = async (req, res) => {
  try {
    const { userId, carId } = req.body;

    // Validate input
    if (!userId || !carId) {
      return res.status(400).json({
        status: false,
        message: "Missing required parameters: userId or carId",
      });
    }

    // Check for an active request
    const existingRequest = await Request.findOne({
      user: userId,
      car: carId,
    });

    let inspection = null;

    if (existingRequest) {
      // Find the related inspection for the user or car
      inspection = await Inspection.findOne({
        $or: [{ user: userId }, { car: carId }],
      });

      return res.status(200).json({
        status: true,
        message: "Request already exists",
        request: existingRequest,
        inspection, // Add inspection details if found
      });
    }

    res.status(200).json({
      status: false,
      message: "No existing request found",
    });
  } catch (error) {
    console.error("Error checking existing request:", error);
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

const adminApprove = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminVerificationStatus, verifiedBy } = req.body;

    // Validate adminVerificationStatus field
    if (typeof adminVerificationStatus !== "string") {
      return res.status(400).json({
        success: false,
        message: "Invalid admin verification status. Must be true or false.",
      });
    }

    // Find mechanic by ID
    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ success: false, message: "Mechanic not found." });
    }

    // Update adminVerification object and status
    mechanic.adminVerification.status = adminVerificationStatus;
    mechanic.adminVerification.verifiedBy = verifiedBy;
    mechanic.status =
      adminVerificationStatus === "Accepted" ? "Fully Verified" : "Pending";

    console.log("Mechanic before saving:", mechanic);

    await mechanic.save().catch((error) => {
      console.error("Mongoose Validation Error:", error);
      res.status(400).json({ success: false, message: "Validation failed." });
    });

    return res.status(200).json({
      success: true,
      message: `Mechanic admin verification status updated to ${adminVerificationStatus}.`,
      mechanic: mechanic,
    });
  } catch (error) {
    console.error("Error updating admin verification:", error);
    return res.status(500).json({ success: false, message: "Server error." });
  }
};

const adminApproveTowman = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminVerificationStatus, verifiedBy } = req.body;

    // Validate adminVerificationStatus field
    if (
      typeof adminVerificationStatus !== "string" ||
      !["Accepted", "Rejected"].includes(adminVerificationStatus)
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Invalid admin verification status. Must be 'Accepted' or 'Rejected'.",
      });
    }

    // Find TowMan by ID
    const towman = await TowManSchema.findById(id);
    if (!towman) {
      return res
        .status(404)
        .json({ success: false, message: "Towman not found." });
    }

    // Update adminVerification object and status
    towman.adminVerification.status = adminVerificationStatus;
    towman.adminVerification.verifiedBy = verifiedBy;
    towman.status =
      adminVerificationStatus === "Accepted" ? "Fully Verified" : "Pending";

    console.log("TowMan before saving:", towman);

    await towman.save();

    return res.status(200).json({
      success: true,
      message: `Towman admin verification status updated to ${adminVerificationStatus}.`,
      towman: towman,
    });
  } catch (error) {
    console.error("Error updating admin verification:", error);
    return res.status(500).json({ success: false, message: "Server error." });
  }
};

const createRequestToTowMan = async (req, res) => {
  try {
    const {
      userId,
      towManId,
      carId,
      pickupLocation,
      destination,
      carDetails,
      status,
      pickupTime,
      dispatchDetails,
      tracking,
      isCompleted,
      paymentId,
      amount,
    } = req.body;

    if (!userId || !towManId || !carId || !amount) {
      return res
        .status(400)
        .json({ status: false, message: "Missing required fields" });
    }

    console.log("User Id =====>>>>>>", userId);
    console.log("Tow Man Id =====>>>>>>", towManId);
    console.log("Car Id =====>>>>>>", carId);
    console.log("Amount =====>>>>>>", amount);

    const existingRequest = await TowingRequest.findOne({
      user: userId,
      towman: towManId,
      carId: carId,
    });

    if (existingRequest) {
      return res.status(409).json({
        status: false,
        message: "Request already sent to this towman for this car",
        request: existingRequest,
      });
    }

    const newRequest = new TowingRequest({
      user: userId,
      towman: towManId,
      carId: carId,
      pickupLocation: pickupLocation || "",
      destination: destination || "",
      carDetails: carDetails || null,
      status: status || "Pending",
      pickupTime: pickupTime || null,
      dispatchDetails: dispatchDetails || null,
      tracking: tracking || [],
      isCompleted: isCompleted || false,
      paymentId: paymentId || "bhvcbfdjfdvbhjvbfhyvfgbvyuhb54586",
      amount: amount,
      date: new Date(),
    });

    console.log("New Request =====>>>>>>", newRequest);
    await newRequest.save();

    res.status(201).json({
      status: true,
      message: "Tow request sent successfully",
      request: newRequest,
    });
  } catch (error) {
    console.error("Error creating tow request:", error);
    res.status(500).json({ status: false, message: "Server error", error });
  }
};

module.exports = {
  createRequestToMechanic,
  createUser,
  changePassword,
  loginUser,
  getUser,
  logout,
  updateUser,
  logoutAll,
  findUserById,
  checkRequest,
  checkExistingRequest,
  adminApprove,
  createRequestToTowMan,
  adminApproveTowman,
};
