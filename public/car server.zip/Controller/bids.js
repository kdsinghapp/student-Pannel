const Bid = require("../Models/carSchema/bidsModel");
const Car = require("../Models/carSchema/carModel");

const addBid = async (req, res) => {
  const { amount, carId } = req.body;
  const userId = req.user._id;

  try {
    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ message: "Car not found" });

    if (car?.car_status !== "ACTIVE") {
      return res.status(403).json({
        status: false,
        message: "Car is already sold, please check another car",
      });
    }

    // Check if the bid is higher than the current price
    if (amount <= car.car_price * 0.1 || amount <= car.currentPrice) {
      return res.status(400).json({
        status: false,
        message: "Your bidding ammout is too low",
      });
    }

    // Create a new bid
    const bid = new Bid({
      user: userId,
      car: carId,
      amount,
      status: "New Bid"
    });
    await bid.save();

    // Update the car's current price
    car.currentPrice = amount;
    await car.save();

    res.status(200).json({
      status: true,
      message: "Bid placed successfully",
      data: bid,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};

const bidsByCar = async (req, res) => {
  const { carId } = req.params;

  try {
    const bids = await Bid.find({ car: carId })
      .populate("user", "name email")
      .sort({ date: -1 });
    res.status(200).json({
      status: true,
      message: "success",
      data: bids,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const mybids = async (req, res) => {
  const userId = req.user._id;

  try {
    const bids = await Bid.aggregate([
      { $match: { user: userId } },
      
      { $sort: { car: 1, date: -1 } },
      {
        $group: {
          _id: "$car",
          bid: { $first: "$$ROOT" } 
        }
      },
      { $replaceRoot: { newRoot: "$bid" } },
      {
        $lookup: {
          from: "users", 
          localField: "user",
          foreignField: "_id",
          as: "user"
        }
      },
      { $unwind: "$user" },
      {
        $lookup: {
          from: "cars",
          localField: "car",
          foreignField: "_id",
          as: "car"
        }
      },
      { $unwind: "$car" },
      {
        $project: {
          _id: 1,
          car: {
            _id: 1,
            carModel: 1,
            currentPrice: 1,
            car_status: 1,
            car_name: 1,
            car_price: 1,
            car_interior_color: 1,
            car_transmission: 1,
            car_door: 1,
            car_engine_capacity: 1,
            Mileage: 1,
            image: 1,
            Exterior: 1,
          },
          amount: 1,
          date: 1,
          status: 1,
          "user.name": 1,
          "user.email": 1
        }
      },

      { $sort: { date: -1 } }
    ]);

    res.status(200).json({
      status: true,
      message: "Success",
      data: bids,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
const removeBids = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id;

  try {
    const car = await Car.findById(carId);
    if (!car) return res.status(404).json({ message: "Car not found" });

    const result = await Bid.deleteMany({ user: userId, car: carId });

    if (result.deletedCount === 0) {
      return res.status(404).json({
        status: false,
        message: "No bids found for this car by the user",
      });
    }

    const highestRemainingBid = await Bid.findOne({ car: carId })
      .sort({ amount: -1 }) 
      .exec();
    if (highestRemainingBid) {
      car.currentPrice = highestRemainingBid.amount;
    } else {
      car.currentPrice = car.initialPrice; 
    }
    await car.save();

    res.status(200).json({
      status: true,
      message: `${result.deletedCount} bid removed successfully`,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};



module.exports = { addBid, bidsByCar, mybids, removeBids  };


