const Car = require("../Models/carSchema/carModel");
const User = require("../Models/userModel");
const Comment = require("../Models/carSchema/commentModel");

const addComment = async (req, res) => {
  try {
    const userId = req.user._id
    const {carId, text ,type } = req.body;

    if (!text || text == "") {
      return res.status(404).json({
        status: false,
        message: "text not found",
      });
    }
    // Validate product and user
    const product = await Car.findById(carId);
    if (!product) {
      return res.status(404).json({
        status: false,
        message: "car not found",
      });
    }

    const comment = new Comment({
      carId : carId,
      userId,
      text,
      type
    });

    await comment.save();
    res.status(201).json({
      status: true,
      message: "Comment added successfully",
      data : comment,
    });
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "Server error",
    });
  }
};


const commentReply = async (req, res) => {
  try {
      const userId = req.user._id
      const { commentId } = req.params;
      const { text, type } = req.body;

      if (!text || text == "") {
        return res.status(404).json({
          status: false,
          message: "text not found",
        });
      }

      const comment = await Comment.findById(commentId);
      if (!comment) {
          return res.status(404).json({
            status: false,
            message: "Comment not found",
          });
      }

      // Check if the user has already replied
      const existingReplyIndex = comment.replies.findIndex(
          reply => reply.userId.toString() === userId.toString()
      );

      if (existingReplyIndex !== -1) {
        console.log('found', existingReplyIndex  )
          // If reply exists, update the existing reply
          comment.replies[existingReplyIndex].text = text;
          // comment.replies[existingReplyIndex].createdAt = Date.now(); // Optional: Update the timestamp
      } else {
          // If no existing reply, add a new one
          const reply = {
              userId,
              text,
              createdAt: Date.now()
          };
          comment.replies.push(reply);
      }

      await comment.save();

      res.status(201).json({ message: 'Reply added/updated successfully', comment });
  } catch (error) {
      res.status(500).json({
        status: false,
        message: "Server error",
      });
  }
}

const userComments = async (req, res) => {
  try {
    const userId = req.user._id

      // Find all comments made by the given userId
      const comments = await Comment.find({ userId })
          .populate('carId', 'car_status car_status car_status car_status') 
          .populate('replies.userId', 'name')
          .sort({ _id: -1 }); 

      if (!comments.length) {
          return res.status(404).json({
            status: false,
            message: "No comments found for this user",
          });
      }

      res.status(200).json({
        status: true,
        message: "success",
        data : comments,
      });
  } catch (error) {
      res.status(500).json({
        status: false,
        message: "Server error",
        error
      });
  }
}



module.exports = { addComment , commentReply, userComments };
