const Mechanic = require("../../Models/mechanic/authSchema");

exports.updateMechanicProfile = async (req, res) => {
  const { mechanicId } = req.params;
  const { firstName, lastName, email, contact, address, description } = req.body;

  try {
    // Validate input
    if (!firstName || !lastName || !email || !contact || !address || !description) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Find the mechanic by ID
    const mechanic = await Mechanic.findById(mechanicId);
    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found" });
    }

    // Update fields
    mechanic.firstName = firstName || mechanic.firstName;
    mechanic.lastName = lastName || mechanic.lastName;
    mechanic.email = email || mechanic.email;
    mechanic.contact = contact || mechanic.contact;
    mechanic.address = address || mechanic.address;
    mechanic.description = description || mechanic.description;

    // Save updated mechanic profile
    await mechanic.save();

    res.status(200).json({ message: "Profile updated successfully", mechanic });
  } catch (error) {
    console.error("Error updating profile:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.findMechanic = async (req, res) => {
  const { mechanicId } = req.params;

  try {
    const mechanic = await Mechanic.findById(mechanicId);

    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found" });
    }

    // Step 2: Return the mechanic's data
    res.status(200).json({
      status: true,
      message: "success",
      mechanic: mechanic,
    });
  } catch (error) {
    console.error("Error finding mechanic:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.getAllMechanics = async (req, res) => {
  try {
    const mechanics = await Mechanic.find();

    if (!mechanics || mechanics.length === 0) {
      return res.status(404).json({ message: "No mechanics found" });
    }

    res.status(200).json({ mechanics });
  } catch (error) {
    console.error("Error fetching all mechanics:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
