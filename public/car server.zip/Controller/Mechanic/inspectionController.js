const Request = require("../../Models/mechanic/requestSchema");
const Inspection = require("../../Models/mechanic/inspectionSchema");

// Add Inspection for a Request
exports.addInspection = async (req, res) => {
  try {
    const { requestId } = req.params;

    const request = await Request.findById(requestId)
      .populate("user")
      .populate("mechanic")
      .populate("car");
    if (!request || !request.user || !request.mechanic || !request.car) {
      return res
        .status(404)
        .json({ message: "Request or associated data not found." });
    }

    // If not, create a new inspection
    const { user, mechanic, car } = await Request.findById(requestId);
    if (!user || !mechanic || !car) {
      return res.status(404).json({ message: "Request not found." });
    }

    const preloadTypes = (allowedTypes) => {
      return allowedTypes.map((type) => ({
        type,
        status: "N/A",
      }));
    };

    const newInspection = new Inspection({
      user,
      mechanic,
      car,
      requests: requestId,
      vehicleHistory: preloadTypes(
        Inspection.schema.path("vehicleHistory.type").enumValues
      ),
      roadTest: preloadTypes(
        Inspection.schema.path("roadTest.type").enumValues
      ),
      vehicleExterior: preloadTypes(
        Inspection.schema.path("vehicleExterior.type").enumValues
      ),
      vehicleInterior: preloadTypes(
        Inspection.schema.path("vehicleInterior.type").enumValues
      ),
      vehicleDiagnostics: preloadTypes(
        Inspection.schema.path("vehicleDiagnostics.type").enumValues
      ),
      underHood: preloadTypes(
        Inspection.schema.path("underHood.type").enumValues
      ),
      underBody: preloadTypes(
        Inspection.schema.path("underBody.type").enumValues
      ),
    });

    const savedInspection = await newInspection.save();

    res.status(201).json({
      message: "Inspection created successfully",
      inspection: savedInspection,
    });
  } catch (error) {
    console.error("Error Adding inspection:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Generic function to get any category by ID
exports.getCategoryById = async (req, res) => {
  try {
    const { id, category } = req.params;

    const validCategories = [
      "vehicleHistory",
      "roadTest",
      "vehicleExterior",
      "vehicleInterior",
      "vehicleDiagnostics",
      "underHood",
      "underBody",
    ];
    if (!validCategories.includes(category)) {
      return res.status(400).json({ message: "Invalid category" });
    }

    const inspection = await Inspection.findById(id);
    if (!inspection) {
      return res.status(404).json({ message: "Inspection not found" });
    }

    res.status(200).json({
      message: `${category} retrieved successfully`,
      [category]: inspection[category],
    });
  } catch (error) {
    console.error(`Error fetching ${req.params.category}:`, error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Generic function to update any category by ID
exports.editCategoryById = async (req, res) => {
  try {
    const { id, category } = req.params;
    const updatedData = req.body;

    const validCategories = [
      "vehicleHistory",
      "roadTest",
      "vehicleExterior",
      "vehicleInterior",
      "vehicleDiagnostics",
      "underHood",
      "underBody",
    ];
    if (!validCategories.includes(category)) {
      return res.status(400).json({ message: "Invalid category" });
    }

    if (!updatedData || !Array.isArray(updatedData)) {
      return res.status(400).json({ message: "Invalid data format" });
    }

    const inspection = await Inspection.findById(id);
    if (!inspection) {
      return res.status(404).json({ message: "Inspection not found" });
    }

    inspection[category] = updatedData;
    const updatedInspection = await inspection.save();

    res.status(200).json({
      message: `${category} updated successfully`,
      [category]: updatedInspection[category],
    });
  } catch (error) {
    console.error(`Error updating ${req.params.category}:`, error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get Inspection By Id
exports.getInspectionById = async (req, res) => {
  const { id } = req.params;

  console.log("Received ID:", id);

  // Validate ObjectId
  if (!mongoose.isValidObjectId(id)) {
    return res.status(400).json({ message: "Invalid Inspection ID" });
  }

  try {
    const inspection = await Inspection.findById(id);

    if (!inspection) {
      return res.status(404).json({ message: "Inspection not found" });
    }

    res.status(200).json({
      message: "Inspection retrieved successfully",
      inspection,
    });
  } catch (error) {
    console.error("Error fetching inspection:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};


exports.getAllInspectionById = async (req, res) => {
  const { carId } = req.params;
  console.log(carId);
  try {
    const car = carId;
    const inspection = await Inspection.findOne({ car });
    if (!inspection) {
      return res.status(404).json({ message: "Inspection not found" });
    }
    console.log("Inspection", inspection);
    res.status(200).json(inspection);
  } catch (error) {
    console.error("Error fetching inspection by car:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
