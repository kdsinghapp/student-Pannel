const Mechanic = require("../../Models/mechanic/authSchema");

/**
 * Get Mechanics by Location and Vehicle Type
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getMechanicsByLocationAndVehicleType = async (req, res) => {
  try {
    const { city, latitude, longitude, vehicleType } = req.body;

    // Validate input
    if (!vehicleType || (!city && (!latitude || !longitude))) {
      return res.status(400).json({
        message: "vehicleType and either city or latitude/longitude are required.",
      });
    }

    // Query for mechanics by city (case-insensitive) or proximity (if latitude and longitude are provided)
    const query = {
      $and: [
        {
          $or: [
            city ? { city: { $regex: new RegExp(city, "i") } } : null, // Case-insensitive city match
            latitude && longitude
              ? {
                  $expr: {
                    $lte: [
                      {
                        $sqrt: {
                          $add: [
                            { $pow: [{ $subtract: ["$latitude", latitude] }, 2] },
                            { $pow: [{ $subtract: ["$longitude", longitude] }, 2] },
                          ],
                        },
                      },
                      "$serviceRadius",
                    ],
                  },
                }
              : null,
          ].filter(Boolean),
        },
        { "prices.vehicleType": vehicleType }, // Match vehicle type in prices array
      ],
    };

    // Find mechanics
    const mechanics = await Mechanic.find(query);

    // Check if mechanics were found
    if (!mechanics || mechanics.length === 0) {
      return res.status(404).json({
        message: "No mechanics found for the given location and vehicle type.",
      });
    }

    // Respond with found mechanics
    return res.status(200).json({
      message: "Mechanics found successfully.",
      data: mechanics,
    });
  } catch (error) {
    console.error("Error fetching mechanics:", error);
    return res.status(500).json({
      message: "An error occurred while fetching mechanics.",
      error: error.message,
    });
  }
};

module.exports = {
  getMechanicsByLocationAndVehicleType,
};
