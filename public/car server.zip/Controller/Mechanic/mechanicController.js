const User = require("../../Models/userModel");
const Mechanic = require("../../Models/mechanic/authSchema");
const Requests = require("../../Models/mechanic/requestSchema");
const MechanicService = require("../../Models/mechanic/mechanicServiceSchema");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const Inspection = require("../../Models/mechanic/inspectionSchema");
require("dotenv").config();

const blacklist = [];

// Helper function to send verification email
const sendVerificationEmail = async (mechanic) => {
  const token = jwt.sign({ mechanicId: mechanic._id }, process.env.JWT_SECRET, {
    expiresIn: "1h",
  });
  const clientUrl = process.env.CLIENT_URL;

  if (!clientUrl) {
    throw new Error("CLIENT_URL is not defined in the environment variables");
  }

  const url = `${clientUrl}/verify-mechanic/${token}`;

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  try {
    await transporter.sendMail({
      from: `"Mechanic Application" <${process.env.EMAIL_USER}>`,
      to: mechanic.email,
      subject: "Verify your email to become a mechanic",
      html: `
                <html>
                    <body style="font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; padding: 20px;">
                        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); max-width: 600px; margin: auto;">
                            <h2>Welcome to Mechanic Application</h2>
                            <p>Click the button below to verify your email and complete the application process.</p>
                            <a href="${url}" style="background-color: #007BFF; color: white; padding: 14px 30px; text-decoration: none; border-radius: 5px; font-size: 16px; display: inline-block;">Verify Email</a>
                        </div>
                    </body>
                </html>
            `,
    });
    console.log(`Verification email sent to: ${mechanic.email}`);
  } catch (error) {
    console.error("Error sending email:", error);
    mechanic.verificationToken = null;
    await mechanic.save();
    throw new Error("Failed to send verification email");
  }
  return token;
};

exports.applyMechanic = async (req, res) => {
  const {
    userId,
    firstName,
    lastName,
    email,
    zipcode,
    address,
    companyName,
    contact,
    description,
    state,
    city,
    geoAddress,
    location,
    prices,
  } = req.body;

  try {
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ message: "Invalid User ID format." });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const existingMechanic = await Mechanic.findOne({ userId });
    if (existingMechanic) {
      return res
        .status(400)
        .json({ message: "You already have a mechanic account." });
    }

    if (!user.password) {
      return res
        .status(400)
        .json({ message: "User does not have a password set." });
    }

    console.log("User's hashed password:", user.password);

    const mechanic = new Mechanic({
      userId: user._id,
      firstName,
      lastName,
      email,
      zipcode,
      address,
      companyName,
      contact,
      description,
      state,
      city,
      geoAddress,
      location: {
        type: "Point",
        coordinates: location,
      },
      prices,
      password: user.password,
    });

    await mechanic.save();

    const token = await sendVerificationEmail(mechanic);
    mechanic.verificationToken = token;
    await mechanic.save();

    res.status(201).json({
      message:
        "Mechanic application submitted. Please check your email to verify your account.",
      mechanic,
    });
  } catch (error) {
    console.error("Error in applyMechanic:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Mechanic Application (applyMechanic)
exports.applyMechanic = async (req, res) => {
  const {
    userId,
    firstName,
    lastName,
    email,
    zipcode,
    address,
    companyName,
    contact,
    description,
    state,
    city,
  } = req.body;

  try {
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ message: "Invalid User ID format." });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const existingMechanic = await Mechanic.findOne({ userId });
    if (existingMechanic) {
      return res
        .status(400)
        .json({ message: "You already have a mechanic account." });
    }

    if (!user.password) {
      return res
        .status(400)
        .json({ message: "User does not have a password set." });
    }

    console.log("User's hashed password:", user.password);

    const mechanic = new Mechanic({
      userId: user._id,
      firstName,
      lastName,
      email,
      zipcode,
      address,
      companyName,
      contact,
      description,
      state,
      city,
      password: user.password,
    });

    await mechanic.save();

    const token = await sendVerificationEmail(mechanic);
    mechanic.verificationToken = token;
    await mechanic.save();

    res.status(201).json({
      message:
        "Mechanic application submitted. Please check your email to verify your account.",
    });
  } catch (error) {
    console.error("Error in applyMechanic:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Mechanic Registration (registerMechanic)
exports.registerMechanic = async (req, res) => {
  const {
    firstName,
    lastName,
    phoneNumber,
    email,
    companyName,
    address,
    city,
    state,
    zipcode,
    additionalInfo,
    password,
  } = req.body;

  try {
    if (
      !firstName ||
      !lastName ||
      !phoneNumber ||
      !email ||
      !companyName ||
      !address ||
      !city ||
      !state ||
      !zipcode ||
      !password
    ) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const existingMechanic = await Mechanic.findOne({ email });
    if (existingMechanic) {
      return res
        .status(400)
        .json({ message: "A mechanic with this email already exists." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const mechanic = new Mechanic({
      firstName,
      lastName,
      phoneNumber,
      email,
      companyName,
      address,
      city,
      state,
      zipcode,
      additionalInfo,
      password: hashedPassword,
    });

    await mechanic.save();
    const token = await sendVerificationEmail(mechanic);
    mechanic.verificationToken = token;
    await mechanic.save();

    res.status(201).json({
      message:
        "Mechanic account created. Please check your email to verify your account.",
    });
  } catch (error) {
    console.error("Error in registerMechanic:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Mechanic Email Verification (verifyMechanicEmail)
exports.verifyMechanicEmail = async (req, res) => {
  const { token } = req.params;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const mechanic = await Mechanic.findById(decoded.mechanicId);

    if (!mechanic) {
      return res
        .status(400)
        .json({ message: "Invalid token: Mechanic not found" });
    }

    if (mechanic.isEmailVerified) {
      return res.status(400).json({ message: "Email already verified" });
    }

    mechanic.isEmailVerified = true;
    mechanic.emailVerificationToken = null;
    await mechanic.save();

    res.json({
      message: "Email verified successfully. Waiting for admin approval.",
    });
  } catch (error) {
    console.error("Error in verifyMechanicEmail:", error);
    res.status(500).json({ message: "Token expired or invalid" });
  }
};

// Mechanic Login
exports.loginMechanic = async (req, res) => {
  const { email, password } = req.body;

  try {
    const mechanic = await Mechanic.findOne({ email });
    if (!mechanic) {
      console.log("Mechanic not found:", email);
      return res
        .status(404)
        .json({ success: false, message: "Mechanic not found" });
    }

    if (!mechanic.password) {
      console.log("Password not set for mechanic:", email);
      return res
        .status(400)
        .json({ success: false, message: "No password set for this user" });
    }

    if (!mechanic.isEmailVerified) {
      console.log("Email not verified for mechanic:", email);
      return res.status(403).json({
        success: false,
        message: "Please verify your email before logging in",
      });
    }

    if (!mechanic.adminVerification.status) {
      console.log("Admin approval pending for mechanic:", email);
      return res.status(403).json({
        success: false,
        message: "Your account is pending admin approval",
      });
    }

    const isMatch = await bcrypt.compare(password, mechanic.password);
    if (!isMatch) {
      console.log("Invalid credentials for mechanic:", email);
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { mechanicId: mechanic._id, email: mechanic.email },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    const isFirstLogin = mechanic.isFirstLogin;

    if (isFirstLogin) {
      mechanic.isFirstLogin = false;
      await mechanic.save();
    }

    console.log("Login successful for mechanic:", email);

    res.status(200).json({
      success: true,
      message: "Login successful",
      data: { token, mechanicId: mechanic._id, isFirstLogin },
    });
  } catch (error) {
    console.error("Error during mechanic login:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

// Mechanic Change Password (changePasswordMechanic)
exports.changePasswordMechanic = async (req, res) => {
  const { mechanicId, oldPassword, newPassword, confirmPassword } = req.body;

  try {
    if (newPassword !== confirmPassword) {
      return res
        .status(400)
        .json({ message: "New password and confirm password do not match" });
    }

    const mechanic = await Mechanic.findById(mechanicId);
    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found" });
    }

    const isMatch = await bcrypt.compare(oldPassword, mechanic.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Incorrect old password" });
    }

    mechanic.password = await bcrypt.hash(newPassword, 10);
    await mechanic.save();

    res.status(200).json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("Error changing password:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Logout Mechanic (logoutMechanic)
exports.logoutMechanic = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(400).json({ message: "Token not provided" });
  }

  try {
    jwt.verify(token, process.env.JWT_SECRET);
    blacklist.push(token);

    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    console.error("Error in logout:", error);
    res.status(400).json({ message: "Invalid token" });
  }
};

// Middleware to check if token is blacklisted (checkBlacklist)
exports.checkBlacklist = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (blacklist.includes(token)) {
    return res.status(401).json({ message: "Token has been invalidated" });
  }
  next();
};

// Admin Approval of Mechanic (approveMechanic)
exports.approveMechanic = async (req, res) => {
  const { mechanicId } = req.params;
  const adminId = req.admin._id;

  try {
    const mechanic = await Mechanic.findById(mechanicId);

    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found" });
    }

    if (!mechanic.isEmailVerified) {
      return res.status(400).json({
        message: "Mechanic's email is not verified. Please verify email first.",
      });
    }

    if (mechanic.adminVerification.status) {
      return res.status(400).json({
        message: "Mechanic is already approved by admin.",
      });
    }

    mechanic.adminVerification.status = true;
    mechanic.adminVerification.verifiedBy = adminId;

    await mechanic.save();
    console.log(
      `Admin ${adminId} approved mechanic ${mechanicId} successfully.`
    );

    res.status(200).json({
      message: "Mechanic approved successfully by admin.",
      mechanic,
    });
  } catch (error) {
    console.error("Error in approveMechanic:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.updateServiceDetails = async (req, res) => {
  try {
    const mechanicId = req.params.id;
    const { vehicleDetails, availability, serviceArea } = req.body;

    let serviceDetails = await MechanicService.findOne({ mechanicId });

    if (serviceDetails) {
      serviceDetails.vehicleDetails = vehicleDetails;
      serviceDetails.availability = availability;
      serviceDetails.serviceArea = serviceArea;
      await serviceDetails.save();
    } else {
      serviceDetails = new MechanicService({
        mechanicId,
        vehicleDetails,
        availability,
        serviceArea,
      });
      await serviceDetails.save();
    }

    const mechanic = await Mechanic.findById(mechanicId);
    if (mechanic) {
      mechanic.isFirstLogin = false;
      mechanic.status = "active";
      await mechanic.save();
    }

    res.status(200).json({
      message: "Service details and status updated successfully.",
      serviceDetails,
      mechanic: {
        firstLogin: mechanic?.isFirstLogin,
        status: mechanic?.status,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update service details or status.",
      error: error.message,
    });
  }
};

exports.findMechanicByEmail = async (req, res) => {
  try {
    const email = req.params.email;

    const mechanic = await Mechanic.findOne({ email });

    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found." });
    }

    res
      .status(200)
      .json({ status: "success", message: "Get email", data: mechanic });
  } catch (error) {
    res.status(500).json({
      message: "Error finding mechanic by email.",
      error: error.message,
    });
  }
};

// Set availability of Mechanic
exports.setAvailability = async (req, res) => {
  const { id } = req.params;
  const { startTime, endTime } = req.body;

  try {
    if (!startTime || !endTime) {
      return res.status(400).json({
        status: false,
        message: "Both startTime and endTime are required.",
      });
    }

    const today = new Date();
    const startTimeDate = new Date(
      `${today.toISOString().split("T")[0]}T${startTime}`
    );
    const endTimeDate = new Date(
      `${today.toISOString().split("T")[0]}T${endTime}`
    );

    if (isNaN(startTimeDate.getTime()) || isNaN(endTimeDate.getTime())) {
      return res.status(400).json({
        status: false,
        message: "Invalid time format. Use HH:mm:ss format.",
      });
    }

    if (endTimeDate <= startTimeDate) {
      return res.status(400).json({
        status: false,
        message: "endTime must be after startTime.",
      });
    }

    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ status: false, message: "Mechanic not found." });
    }

    mechanic.startTime = startTimeDate;
    mechanic.endTime = endTimeDate;

    await mechanic.save();

    res.status(200).json({
      status: true,
      message: "Availability set successfully.",
      availability: {
        startTime: mechanic.startTime,
        endTime: mechanic.endTime,
      },
    });
  } catch (error) {
    console.error("Error setting availability:", error);
    res.status(500).json({
      status: false,
      message: "Failed to set availability.",
    });
  }
};

// Update Availibility of Mechanic
exports.updateAvailability = async (req, res) => {
  const { id } = req.params;
  const { startTime, endTime } = req.body;

  try {
    if (!startTime || !endTime) {
      return res
        .status(400)
        .json({ message: "Both startTime and endTime are required." });
    }

    const updatedMechanic = await Mechanic.findByIdAndUpdate(
      id,
      {
        startTime: new Date(startTime),
        endTime: new Date(endTime),
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!updatedMechanic) {
      return res.status(404).json({ message: "Mechanic not found." });
    }

    res.status(200).json({
      status: "success",
      message: "Availability updated successfully.",
      availability: {
        startTime: updatedMechanic.startTime,
        endTime: updatedMechanic.endTime,
      },
    });
  } catch (error) {
    console.error("Error updating availability:", error);
    res.status(500).json({
      message: "Failed to update availability.",
      error: error.message,
    });
  }
};

// Set Geo Location
exports.setGeolocation = async (req, res) => {
  const { id } = req.params;
  const { longitude, latitude, radius, serviceAddress } = req.body;

  try {
    if (!longitude || !latitude) {
      return res
        .status(400)
        .json({ message: "Both longitude and latitude are required." });
    }

    if (
      longitude < -180 ||
      longitude > 180 ||
      latitude < -90 ||
      latitude > 90
    ) {
      return res
        .status(400)
        .json({ message: "Invalid longitude or latitude range." });
    }

    if (radius && radius <= 0) {
      return res
        .status(400)
        .json({ message: "Radius must be a positive number." });
    }

    if (serviceAddress && serviceAddress.trim() === "") {
      return res
        .status(400)
        .json({ message: "Service address cannot be empty." });
    }

    const updatedMechanic = await Mechanic.findByIdAndUpdate(
      id,
      {
        longitude,
        latitude,
        ...(radius && { serviceRadius: radius }),
        ...(serviceAddress && { serviceAddress }),
      },
      { new: true, runValidators: true }
    );

    if (!updatedMechanic) {
      return res.status(404).json({ message: "Mechanic not found." });
    }

    res.status(200).json({
      status: true,
      message: "Geolocation and service address updated successfully.",
      geolocation: {
        longitude: updatedMechanic.longitude,
        latitude: updatedMechanic.latitude,
        serviceRadius: updatedMechanic.serviceRadius,
        serviceAddress: updatedMechanic.serviceAddress,
      },
    });
  } catch (error) {
    console.error("Error updating geolocation:", error);
    res.status(500).json({
      message: "Failed to update geolocation.",
      error: error.message,
    });
  }
};

// Add Inspection price and vehicle Type
exports.addInspectionPrice = async (req, res) => {
  const { id } = req.params; // Mechanic ID
  const { vehicleType, price } = req.body;

  try {
    if (!vehicleType || typeof price !== "number" || price <= 0) {
      return res.status(400).json({
        message: "Valid vehicleType and positive price are required.",
      });
    }

    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res.status(404).json({ message: "Mechanic not found." });
    }

    const existingPriceIndex = mechanic.prices.findIndex(
      (item) => item.vehicleType.toLowerCase() === vehicleType.toLowerCase()
    );

    if (existingPriceIndex > -1) {
      mechanic.prices[existingPriceIndex].price = price;
    } else {
      mechanic.prices.push({ vehicleType, price });
    }
    await mechanic.save();
    res.status(200).json({
      status: true,
      message: "Inspection price added/updated successfully.",
      prices: mechanic.prices,
    });
  } catch (error) {
    console.error("Error adding inspection price:", error);
    res.status(500).json({
      status: false,
      message: "Failed to add inspection price.",
      error: error.message,
    });
  }
};

// Create Inspection Task
exports.createInspectionTasks = async (req, res) => {
  const { id } = req.params;
  const { inspectionTasks } = req.body;

  try {
    if (!Array.isArray(inspectionTasks) || inspectionTasks.length === 0) {
      return res.status(400).json({
        status: false,
        message: "Inspection tasks must be a non-empty array.",
      });
    }

    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ status: false, message: "Mechanic not found." });
    }

    if (!Array.isArray(mechanic.inspection)) {
      mechanic.inspection = [];
    }

    const existingTasks = mechanic.inspection;
    const newTasks = inspectionTasks.filter(
      (task) => !existingTasks.includes(task)
    );

    if (newTasks.length === 0) {
      return res.status(400).json({
        status: false,
        message: "All provided inspection tasks already exist.",
      });
    }

    mechanic.inspection.push(...newTasks);

    await mechanic.save();

    res.status(201).json({
      status: true,
      message: "Inspection tasks added successfully.",
      inspection: mechanic.inspection,
    });
  } catch (error) {
    console.error("Error creating inspection tasks:", error);
    res.status(500).json({
      status: false,
      message: "Failed to Create Vehicle Inspection.",
      error: error.message,
    });
  }
};

// Update Inspection Tasks
exports.updateInspectionTasks = async (req, res) => {
  const { id } = req.params;
  const { inspectionTasks } = req.body;

  try {
    if (!Array.isArray(inspectionTasks) || inspectionTasks.length === 0) {
      return res.status(400).json({
        status: false,
        message: "Inspection tasks must be a non-empty array.",
      });
    }

    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ status: false, message: "Mechanic not found." });
    }

    mechanic.inspection = inspectionTasks;

    await mechanic.save();

    res.status(200).json({
      status: true,
      message: "Inspection tasks updated successfully.",
      inspection: mechanic.inspection,
    });
  } catch (error) {
    console.error("Cannot Update Inspection Tasks:", error);
    res.status(500).json({
      status: false,
      message: "Failed to Update Vehicle Inspection",
      error: error.message,
    });
  }
};

// Get Inspection Tasks
exports.getInspectionTasks = async (req, res) => {
  const { id } = req.params;

  try {
    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ status: false, message: "Mechanic not found." });
    }

    res.status(200).json({
      status: true,
      message: "Inspection tasks fetched successfully.",
      inspection: mechanic.inspection,
    });
  } catch (error) {
    console.error("Error fetching inspection tasks:", error);
    res.status(500).json({
      status: false,
      message: "Failed to fetch inspection tasks.",
      error: error.message,
    });
  }
};

// Delete Inspection Tasks
exports.deleteInspectionTasks = async (req, res) => {
  const { id } = req.params;
  const { tasksToDelete } = req.body;

  try {
    const mechanic = await Mechanic.findById(id);
    if (!mechanic) {
      return res
        .status(404)
        .json({ status: false, message: "Mechanic not found." });
    }

    if (!Array.isArray(mechanic.inspection)) {
      mechanic.inspection = [];
    }

    if (
      !tasksToDelete ||
      !Array.isArray(tasksToDelete) ||
      tasksToDelete.length === 0
    ) {
      mechanic.inspection = [];
    } else {
      mechanic.inspection = mechanic.inspection.filter(
        (task) => !tasksToDelete.includes(task)
      );
    }

    await mechanic.save();

    res.status(200).json({
      status: true,
      message: "Inspection tasks deleted successfully.",
      inspection: mechanic.inspection,
    });
  } catch (error) {
    console.error("Error deleting inspection tasks:", error);
    res.status(500).json({
      status: false,
      message: "Failed to delete inspection tasks.",
      error: error.message,
    });
  }
};

// Fetch All Requests
exports.getRequestsForMechanic = async (req, res) => {
  try {
    const { id: mechanicId } = req.params;
    console.log("Mechanic ID:", mechanicId);

    const allRequests = await Requests.find({ mechanic: mechanicId })
      .populate({
        path: "car",
        select: "car_name image car_price",
      })
      .populate({
        path: "user",
        select: "name email phone address ",
      });

    console.log("All Requests", allRequests);
    res.status(200).json({
      status: true,
      message: "Successfully fetched requests",
      data: allRequests,
    });
  } catch (error) {
    console.error("Error retrieving mechanic requests:", error);
    res.status(500).json({
      status: false,
      message: "Server error",
      error,
    });
  }
};

// Accept and Reject Request
exports.acceptAndRejectRequest = async (req, res) => {
  try {
    const { id: requestId } = req.params;
    const { mechanicId, action } = req.body;

    if (!["Accepted", "Rejected"].includes(action)) {
      return res.status(400).json({
        status: false,
        message: "Invalid action. Use 'Accepted' or 'Rejected'.",
      });
    }

    const mechanic = await Mechanic.findById(mechanicId);
    if (!mechanic) {
      return res.status(404).json({
        status: false,
        message: "Mechanic not found.",
      });
    }

    const request = await Requests.findById(requestId);
    if (!request) {
      return res.status(404).json({
        status: false,
        message: "Request not found.",
      });
    }

    if (request.mechanic.toString() !== mechanicId) {
      return res.status(403).json({
        status: false,
        message: "Mechanic is not authorized to update this request.",
      });
    }

    request.status = action;
    await request.save();

    res.status(200).json({
      status: true,
      message: `Request has been ${action.toLowerCase()} successfully.`,
      request,
    });
  } catch (error) {
    console.error("Error accepting/rejecting request:", error);
    res.status(500).json({
      status: false,
      message: "Server error",
      error,
    });
  }
};

exports.checkInspectionCreated = async (req, res) => {
  const { userId, carId, mechanicId, requestId } = req.body;

  try {
    if (!userId || !carId || !mechanicId || !requestId) {
      return res.status(400).json({
        status: false,
        message:
          "Missing required fields (userId, carId, mechanicId, requestId)",
      });
    }

    const inspection = await Inspection.findOne({
      user: userId,
      car: carId,
      mechanic: mechanicId,
      requests: requestId,
    }).populate("user mechanic car requests");

    if (!inspection) {
      return res.status(404).json({
        status: false,
        message: "Inspection not found with the provided details",
      });
    }

    res.status(200).json({
      status: true,
      message: "Inspection found",
      data: inspection,
    });
  } catch (error) {
    console.error("Error while checking inspection:", error);
    res.status(500).json({
      status: false,
      message: "Server error occurred",
      error: error.message,
    });
  }
};

exports.getRequestPaymentPending = async (req, res) => {
  const { carId, mechanicId, userId } = req.query;

  if (!carId || !mechanicId || !userId) {
    return res
      .status(400)
      .json({ error: "carId, mechanicId, and userId are required." });
  }

  try {
    const request = await Request.findOne({
      car: carId,
      mechanic: mechanicId,
      user: userId,
    });

    if (!request) {
      return res.status(404).json({ error: "Request not found." });
    }

    res.json({ paymentId: request.paymentId });
  } catch (error) {
    console.error("Error finding request:", error);
    res.status(500).json({ error: "Internal server error." });
  }
};
