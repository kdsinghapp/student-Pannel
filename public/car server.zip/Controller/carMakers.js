const CarMaker = require("../Models/carSchema/carMakerModel");
const CarModel = require("../Models/carSchema/carModelsVersions");

// Controller function to add a new car make
const addCarModel = async (req, res) => {
  try {
    const {
      car_model_id,
      car_model_name,
      car_model_ar_name,
      car_maker_id,
      maker_id,
      car_model_admin_status,
    } = req.body;

    // Create a new car make document
    const newCarMake = new CarModel({
      car_model_id,
      car_model_name,
      car_model_ar_name,
      car_maker_id,
      maker_id,
      car_model_admin_status,
    });

    // Save the document to the database
    const savedCarMake = await newCarMake.save();
    res.status(201).json(savedCarMake);
  } catch (error) {
    if (error.code === 11000) {
      // Handle unique constraint error for car_model_id
      console.log(req.body);
      res.status(400).json({ error: "car_model_id must be unique" });
    } else {
      res.status(500).json({ error: "Failed to add car make" });
    }
  }
};

const getCarModel = async (req, res) => {
  try {
    const {car_maker_id} = req.query ;
    const condition = {}
    if (car_maker_id) {
      // return res.status(404).send({ error: 'car_maker_id not found' });
      condition.car_maker_id = car_maker_id
    }
    const newCarMake = await CarModel.find(condition);

    res.status(201).json({
      status: true,
      message: "success",
      data : newCarMake,
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to get" });
  }
};

const addCarMaker = async (req, res) => {
  try {
    const {
      car_maker_id,
      car_maker_sub_category_id,
      car_maker_name,
      car_maker_deleted_at,
      car_maker_admin_status,
    } = req.body;

    // Create a new car maker document
    const newCarMaker = new CarMaker({
      car_maker_id,
      car_maker_sub_category_id,
      car_maker_name,
      car_maker_deleted_at,
      car_maker_admin_status,
    });

    // Save the document to the database
    const savedCarMaker = await newCarMaker.save();
    res.status(201).json(savedCarMaker);
  } catch (error) {
    if (error.code === 11000) {
      // Handle unique constraint error for car_maker_id
      res.status(400).json({ error: "car_maker_id must be unique" });
    } else {
      res.status(500).json({ error: "Failed to add car maker" });
    }
  }
};

const getCarMaker = async (req, res) => {
  try {
    

    // Create a new car maker document
    const newCarMaker = await CarMaker.find({});

    res.status(201).json({
      status: true,
      message: "success",
      data : newCarMaker,
    });
  } catch (error) {
    if (error.code === 11000) {
      // Handle unique constraint error for car_maker_id
      res.status(400).json({ error: "car_maker_id must be unique" });
    } else {
      res.status(500).json({ error: "Failed to add car maker" });
    }
  }
};

module.exports = { addCarModel, addCarMaker,getCarMaker, getCarModel };
