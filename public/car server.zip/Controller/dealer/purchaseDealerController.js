const Purchase = require("../../Models/carSchema/Purchase");
const Bid = require("../../Models/carSchema/bidsModel");
const Car = require("../../Models/carSchema/carModel");
const Cleaning = require("../../Models/carSchema/cleaningModel");
const Delivery = require("../../Models/carSchema/deliveryModel");
const Mechanical = require("../../Models/carSchema/mechanicModel");
const Offer = require("../../Models/carSchema/offerModel");
const SoldCar = require("../../Models/carSchema/soldCarModel");
const Mechanic = require("../../Models/mechanic/authSchema")

const getDealerPurchase = async (req, res) => {
  const dealerId = req.user._id;

  // Pagination parameters
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 100;
  const skip = (page - 1) * limit;

  try {

    const purchase = await Purchase.find({ dealer: dealerId })
      .populate("car")
      .populate("user", "_id email name")
      .skip(skip)
      .limit(limit);

    const totalPurchase = await Purchase.countDocuments({ dealer: dealerId });
    const totalPages = Math.ceil(totalPurchase / limit);

    return res.json({
      status: true,
      message: "Success",
      data: purchase,
      pagination: {
        totalItems: totalPurchase,
        totalPages: totalPages,
        currentPage: page,
        itemsPerPage: limit,
      },
    });
  } catch (error) {
    console.error("Error fetching dealer's cars in Purchase:", error);
    return res.json({
      status: false,
      message: "failed",
    });
  }
};

const getOffersForDealerAndCar = async (req, res) => {
  const dealerId = req.user._id;
  const carId = req.params.carId;

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId }).select(
      "_id"
    );
    if (!car) {
      return res.status(404).json({
        status: false,
        message: "Car not found or does not belong to the dealer",
      });
    }

    const offers = await Offer.find({ car: carId })
      .populate("car")
      .populate(
        "user",
        "name email profile_image mobile_number last_name first_name"
      )
      .select("car amount status date _id");

    return res.json({
      status: true,
      message: "success",
      data: offers,
    });
  } catch (error) {
    console.error("Error fetching offers for the dealer's car:", error);
    return res.status(500).json({
      status: false,
      message: "failed",
    });
  }
};

const changeOfferStatus = async (req, res) => {
  const { status, offerId } = req.body; // status:- Rejected or Accepted
  const dealerId = req.user._id;

  try {
    const offer = await Offer.findOne({ _id: offerId });
    if (!offer) {
      return res
        .status(404)
        .json({ status: false, message: "Offer not found." });
    }

    if (status === "Rejected") {
      offer.status = status;
      await offer.save();
      return res.status(200).json({
        status: true,
        message: "Offer rejected successfully.",
        data: offer,
      });
    }

    if (status === "Accepted") {
      const carData = await Car.findOne({ _id: offer?.car });
      if (!carData) {
        return res
          .status(404)
          .json({ status: false, message: "Car not found." });
      }

      if (carData?.car_status !== "ACTIVE") {
        return res.status(403).json({
          status: false,
          message: "Car is already sold, please check buying or sold list..",
        });
      }

      offer.status = status;
      await offer.save();

      const updatedCarStatus = await Car.findByIdAndUpdate(
        offer?.car,
        { $set: { car_status: "BUYING" } },
        { new: true }
      );

      await Bid.updateMany(
        { car: offer?.car}, // Exclude the current accepted bid
        { $set: { status: "Canceled Automatically" } }
      );
    
      await Offer.updateMany(
        { car: offer?.car, _id: { $ne: offer?._id }  },
        { $set: { status: "Canceled Automatically" } }
      );

      
      const newPurchase = new Purchase({
        user: offer?.user,
        dealer: dealerId,
        car: offer?.car,
        bidId: "", 
        offerId: offer?._id || "", 
        amount: offer?.amount,
        status: "Offer Accepted",
      });

      await newPurchase.save();

      return res.status(200).json({
        status: true,
        message: "Offer accepted successfully.",
        data: { offer, updatedCarStatus, newPurchase },
      });
    }

    return res.status(400).json({
      status: false,
      message: "Invalid offer status.",
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const PurchaseImmediateUser = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id;

  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const carData = await Car.findOne({ _id: carId, car_status: "ACTIVE" }).session(session);
    if (!carData) {
      throw new Error("Car not available for purchase.");
    }

    const updatedCarStatus = await Car.findByIdAndUpdate(
      carId,
      { $set: { car_status: "BUYING" } },
      { new: true, session }
    );

    await Bid.updateMany(
      { car: carId },
      { $set: { status: "Canceled Automatically" } },
      { session }
    );

    await Offer.updateMany(
      { car: carId },
      { $set: { status: "Canceled Automatically" } },
      { session }
    );

    const newPurchase = new Purchase({
      user: userId,
      dealer: carData.dealer,
      car: carId,
      amount: carData.car_price,
      status: "Price Accepted",
    });

    await newPurchase.save({ session });

    await session.commitTransaction();
    session.endSession();

    return res.status(200).json({
      status: true,
      message: "Car purchased successfully at the current price.",
      data: { updatedCarStatus, newPurchase },
    });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();

    console.error("Error purchasing car:", error);
    return res.status(500).json({
      status: false,
      message: "Transaction failed.",
      error: error.message,
    });
  }
};

const getPurchaseUser = async (req, res) => {
  const userId = req.user._id;

  try {   
      const purchase = await Purchase.find({user:userId})
      .populate("car")
      .populate("dealer","number email name")
      .sort({_id: -1});
      

      return res.status(200).json({
        status: true,
        message: "get purchase Car list.",
        data: purchase,
      });

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const proseedBuyUser = async (req, res) => {
  const { carId, status, note } = req.body; // status :-  Offline 
  const userId = req.user._id;
  try {   
    
    const soldCheck = await SoldCar.findOne({car:carId})
    
    if (soldCheck) {
      return res
      .status(404)
      .json({ status: false, message: "This car is already Sold" ,data: soldCheck?.status});
    }
    
    const purchase = await Purchase.findOne({user:userId , car:carId})
    
    if (!purchase) {
      return res
      .status(404)
      .json({ status: false, message: "Your Purchase is not avalable content Seller" });
    }
    if (status === 'Offline') {
    
      const updatedPurchaseStatus = await Purchase.findByIdAndUpdate(
        purchase._id,
        { $set: { status: "Buy Offline" } },
        { new: true }
      );

      console.log("purchase", purchase);
      console.log("purchase?.dealer", purchase?.dealer);
      

      const newSoldCar = new SoldCar({
        user: userId,
        dealer: purchase?.dealer,
        car: carId,
        purchaseId: purchase._id,
        amount: purchase.amount,
        note,
        status: "Offline purchase",
      });

      await newSoldCar.save();

      return res.status(200).json({
        status: true,
        message: "Car successfully added in offline list wait for dealer contect you.",
        data: newSoldCar,
      });
    }else if(status === 'Online') {
     
      const updatedPurchaseStatus = await Purchase.findByIdAndUpdate(
        purchase._id,
        { $set: { status: "Buy Online" } },
        { new: true }
      );
  
      const newSoldCar = new SoldCar({
        user: userId,
        dealer: purchase?.dealer,
        car: carId,
        purchaseId: purchase._id,
        amount: purchase.amount,
        note,
        status: "Online purchase",
      });

      await newSoldCar.save();

      return res.status(200).json({
        status: true,
        message: "Car successfully added in Online list wait for dealer contect you.",
        data: newSoldCar,
      });
    }
    
    return res.status(400).json({
      status: false,
      message: "status not valid.",
    });

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};
const addMacheniclCheck = async (req, res) => {
  const { carId, SoldCarId, mechanicCheckNote, amount , isSkip } = req.body;
  const userId = req.user._id;
  // New Check => fee paid => proof uploaded => work started => view report
  try {   

    const mechanicalExist = await Mechanical.findOne({ car: carId });
    if (mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "This car is already in machanical Check." });
    }
    
    
    const carData = await Car.findOne({ _id: carId });
    console.log("carData" , carData);
    
    if (!carData) {
      return res
        .status(404)
        .json({ status: false, message: "Car not found." });
    }
    
    
    const soldCheck = await SoldCar.findById(SoldCarId)
    if (!soldCheck) {
      return res
      .status(404)
      .json({ status: false, message: "Something went worng car is not avalable"});
    }

    if (soldCheck.status != "Online purchase") {
      return res
        .status(404)
        .json({ status: false, message: "Car not found in Online purchase." });
    }

    if (isSkip) {
      const updatedSoldCar = await SoldCar.findByIdAndUpdate(
        soldCheck._id,
        { $set: {  mechanicskip:true } },
        { new: true }
      );

      return res.status(201).json({
        status: true,
        message: "Skip successfully.",
      });
    }
    const newdMacheniclChec = new Mechanical({
      user: userId,
      car: carId,
      soldId: soldCheck._id,
      note: mechanicCheckNote,
      amount: amount,
      status: "New Check",
    });

    const mechenicData = await newdMacheniclChec.save();
    
    const updatedSoldCar = await SoldCar.findByIdAndUpdate(
      soldCheck._id,
      { $set: { machenical: mechenicData?._id } },
      { new: true }
    );

    return res.status(200).json({
      status: true,
      message: "Car successfully added mechenicData.",
      data: updatedSoldCar,
      data2: newdMacheniclChec,
    });
   

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const UploadMechenicalPayProof = async (req, res) => {
  const userId = req.params.id;
  const { mechanicId } = req.body;
  try {
    const mechanicalExist = await Mechanic.findById(mechanicId);
    if (!mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "machanical Check not found." });
    }

    if (req.files['image']) {
      // old delete prosess
      // if (car.image) {
      //   const oldImagePath = path.join(__dirname, '../../images/', car.image);
      //   fs.unlink(oldImagePath, (err) => {
      //     if (err) console.log('Failed to delete old image:', err);
      //   });
      // } 
      image = req.files['image'][0].filename;
      console.log("image=====>" , image);

      const updatedSoldCar = await Mechanic.findByIdAndUpdate(
        mechanicId,
        { $set: {status: "Uploaded", proofimg: image } },
        { new: true }
      );

      return res.status(200).json({
        status: true,
        message: "successfully added Proof.",
        data: updatedSoldCar,
      });
      
    }else{
      return res
      .status(404)
      .json({ status: false, message: "Image not provided" });
    }
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}
const verifyMechenicalProof = async (req, res) => {
  const { MechenicalId } = req.body;
  const userId = req.user._id;
  try {
    const mechanicalExist = await Mechanical.findById(MechenicalId);
    if (!mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "machanical Check not found." });
    }
    if (mechanicalExist.status != "Uploaded") {
      return res
        .status(404)
        .json({ status: false, message: "User not uploaded payment proof" });
    }
   
    const updatedSoldCar = await Mechanical.findByIdAndUpdate(
      MechenicalId,
      { $set: {status: "Accepted" } },
      { new: true }
    );

    return res.status(200).json({
      status: true,
      message: "successfully added Proof.",
      data: updatedSoldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const listMechanicsByDealer = async (req, res) => {
  // const { dealerId } = req.user._id;

  try {
    // Step 1: Find all cars that belong to the dealer
    const cars = await SoldCar.find({});
    
    if (!cars || cars.length === 0) {
      return res.status(404).json({ 
        status: false, 
        message: "No cars found for this dealer." 
      });
    }

    // Step 2: Extract car IDs from the cars array
    const carIds = cars.map(car => car.car);

    // Step 3: Find all mechanics related to those car IDs
    const mechanics = await Mechanical.find({ car: { $in: carIds } })
    .populate("user", "name email")
    .populate("car")
    .sort({_id: -1});
    ;

    if (!mechanics || mechanics.length === 0) {
      return res.status(404).json({ 
        status: false, 
        message: "No mechanics found for these cars." ,
      });
    }

    // Step 4: Return the list of mechanics
    return res.status(200).json({
      status: true,
      message: "Mechanics related to dealer found successfully.",
      data: mechanics
    });

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const UploadMechenicalReport = async (req, res) => {
  const userId = req.user._id;
  const { MechenicalId , note} = req.body;
  try {
    const mechanicalExist = await Mechanical.findById(MechenicalId);
    if (!mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "machanical Check not found." });
    }
    if (mechanicalExist.reportImg) {
      return res
        .status(404)
        .json({ status: false, message: "Report update only ones." });
    }

    if (req.files['image']) {
      // old delete prosess
      // if (car.image) {
      //   const oldImagePath = path.join(__dirname, '../../images/', car.image);
      //   fs.unlink(oldImagePath, (err) => {
      //     if (err) console.log('Failed to delete old image:', err);
      //   });
      // } 
      image = req.files['image'][0].filename;
      console.log("image=====>" , image);

      const updatedSoldCar = await Mechanical.findByIdAndUpdate(
        MechenicalId,
        { $set: {status: "Report", reportImg: image, reportText: note } },
        { new: true }
      );

      return res.status(200).json({
        status: true,
        message: "successfully added Proof.",
        data: updatedSoldCar,
      });
      
    }else{
      return res
      .status(404)
      .json({ status: false, message: "Image not provided" });
    }
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const addDeliveryDetails = async (req, res) => {
  const { carId, SoldCarId, DeliveryNote, amount, address, lat, long, pincode,isSkip } = req.body;
  const userId = req.user._id;
  try {   

    const mechanicalExist = await Delivery.findOne({ car: carId });
    if (mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "This car already has Delivery address." });
    }
    
    
    const carData = await Car.findOne({ _id: carId });
    
    if (!carData) {
      return res
        .status(404)
        .json({ status: false, message: "Car not found." });
    }
    
    
    const soldCheck = await SoldCar.findById(SoldCarId)
    if (!soldCheck) {
      return res
      .status(404)
      .json({ status: false, message: "Something went worng car is not avalable"});
    }

    if (soldCheck.status != "Online purchase") {
      return res
        .status(404)
        .json({ status: false, message: "Car not found in Online purchase." });
    }

    if (isSkip) {
      const updatedSoldCar = await SoldCar.findByIdAndUpdate(
        soldCheck._id,
        { $set: {  deliveryskip : true } },
        { new: true }
      );

      return res.status(201).json({
        status: true,
        message: "Skip successfully.",
      });
    }
    const newDeliveryAddress = new Delivery({
      user: userId,
      car: carId,
      soldId: soldCheck._id,
      note: DeliveryNote,
      amount: amount,
      address, 
      lat, 
      long, 
      pincode,
      status: "new",
    });

    const deliveryData = await newDeliveryAddress.save();
    
    const updatedSoldCar = await SoldCar.findByIdAndUpdate(
      soldCheck._id,
      { $set: { delivery: deliveryData?._id , deliveryskip : false } },
      { new: true }
    );

    return res.status(200).json({
      status: true,
      message: "Car successfully added Delivery Data.",
      data: updatedSoldCar,
      data2: newDeliveryAddress,
    });
   

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const addCleaningDetails = async (req, res) => {
  const { carId, SoldCarId, CleaningNote, amount, isSkip } = req.body;
  const userId = req.user._id;
  try {   

    const mechanicalExist = await Cleaning.findOne({ car: carId });
    if (mechanicalExist) {
      return res
        .status(404)
        .json({ status: false, message: "This car already has Cleaning." });
    }
    
    
    const carData = await Car.findOne({ _id: carId });
    
    if (!carData) {
      return res
        .status(404)
        .json({ status: false, message: "Car not found." });
    }
    
    
    const soldCheck = await SoldCar.findById(SoldCarId)
    if (!soldCheck) {
      return res
      .status(404)
      .json({ status: false, message: "Something went worng car is not avalable"});
    }

    if (soldCheck.status != "Online purchase") {
      return res
        .status(404)
        .json({ status: false, message: "Car not found in Online purchase." });
    }

    if (isSkip) {
      const updatedSoldCar = await SoldCar.findByIdAndUpdate(
        soldCheck._id,
        { $set: {  cleaningskip : true } },
        { new: true }
      );

      return res.status(201).json({
        status: true,
        message: "Skip successfully.",
      });
    }
    const newCleaningAddress = new Cleaning({
      user: userId,
      car: carId,
      soldId: soldCheck._id,
      note: CleaningNote,
      amount: amount,
      status: "new",
    });

    const deliveryData = await newCleaningAddress.save();
    
    const updatedSoldCar = await SoldCar.findByIdAndUpdate(
      soldCheck._id,
      { $set: { cleaning: deliveryData?._id } },
      { new: true }
    );

    return res.status(200).json({
      status: true,
      message: "Car successfully added Cleaning Data.",
      data: updatedSoldCar,
      data2: newCleaningAddress,
    });
   

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const proseedBuyUserOnline = async (req, res) => {
  const { status, carId, note, mechanicCheck, delivery, addCheaning } = req.body;
  const userId = req.user._id;
  try {   
    if (status === 'Online') {
      
      const soldCheck = await SoldCar.findOne({car:carId})

      if (soldCheck) {
        return res
          .status(404)
          .json({ status: false, message: "This car is already Sold" ,data: soldCheck?.status});
      }

      const purchase = await Purchase.findOne({user:userId , car:carId})

      if (!purchase) {
        return res
          .status(404)
          .json({ status: false, message: "Your Purchase is not avalable content Seller" });
      }

      const updatedPurchaseStatus = await Purchase.findByIdAndUpdate(
        purchase._id,
        { $set: { status: "Buy Ofline" } },
        { new: true }
      );

      if (mechanicCheck) {
        console.log("enter in mechanicCheck =======>");
        
        const mechanic = new SoldCar({
          user: userId,
          dealer: purchase?.dealer,
          car: carId,
          purchaseId: purchase._id,
          cost:1000,
          status: "New", // ammount paid // report genrated
          note:"",
        });
  
        // await mechanic.save();
      }
      if (delivery) {
        console.log("enter in delivery =======>");

        const mechanic = new SoldCar({
          user: userId,
          dealer: purchase?.dealer,
          car: carId,
          purchaseId: purchase._id,
          address:'',
          note:'',
          cost:150,
        });
  
        // await mechanic.save();
      }
      if (addCheaning) {
        console.log("enter in addCheaning =======>");
      }
      
      const newSoldCar = new SoldCar({
        user: userId,
        dealer: purchase?.dealer,
        car: carId,
        purchaseId: purchase._id,
        amount: purchase.amount,
        note,
        status: "Online purchase",

        // mechanicId
        // deliveryId
        // cheaningId
      });

      await newSoldCar.save();

      return res.status(200).json({
        status: true,
        message: "Car successfully added in online list wait for dealer contect you.",
        data: newSoldCar,
      });
    }

    // not started this api
    if (status === 'Online') {
     
      return res.status(400).json({
        status: false,
        message: "not started part.",
      });
    }
    
    return res.status(400).json({
      status: false,
      message: "status not valid.",
    });

  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const userBuyList = async (req, res) => {
  const userId = req.user._id;
  try {
    const soldCar = await SoldCar.find({user:userId})
      .populate("car")
      .populate("dealer","number email name")
      .populate("machenical")
      .populate("delivery")
      .populate("cleaning")
      .sort({_id: -1});

    console.log("soldCar", soldCar);
    

    return res.status(200).json({
      status: true,
      message: "Car Buy list",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const dealerListSoldCar = async (req, res) => {
  const dealerId = req.user._id;
  try {
    const soldCar = await SoldCar.find({dealer:dealerId})
    .populate("user", "name email")
    .populate("car")
    .populate("dealer","number email name")
    .populate("machenical")
    .populate("delivery")
    .populate("cleaning")
    .sort({_id: -1});

    return res.status(200).json({
      status: true,
      message: "Car successfully added in offline list wait for dealer contect you.",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const dealerUnderSoldCar = async (req, res) => {
  const soldId = req.params.soldId;
  try {
    const soldCar = await SoldCar.findById(soldId)
    .populate("user", "name email")
    .populate("car")
    .populate("dealer","number email name")
    .populate("machenical")
    .populate("delivery")
    .populate("cleaning")
    .sort({_id: -1});

    return res.status(200).json({
      status: true,
      message: "Car successfully added in offline list wait for dealer contect you.",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const dealerMarkAsSoldOffline = async (req, res) => {
  const { status, carId } = req.body;
  const dealerId = req.user._id;
  try {
    const soldCar = await SoldCar.findOne({dealer:dealerId, car:carId})
      .populate("car")
      .populate("dealer","number email name");
    
    if (!soldCar) {
      return res
        .status(404)
        .json({ status: false, message: "This car is not avalable to mark as sold" });
    }

    if (soldCar?.status == "SOLD") {
      return res
        .status(400)
        .json({ status: false, message: `You already maked this car as ${soldCar?.status}` });
    }

    const updatedPurchaseStatus = await SoldCar.findByIdAndUpdate(
      soldCar._id,
      { $set: { status: "SOLD" } },
      { new: true }
    ); 

    return res.status(200).json({
      status: true,
      message: "Car Is Sold",
      data: updatedPurchaseStatus,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const SoldCarByUser = async (req, res) => {
  const userId = req.user._id;
 
  try {
    const soldCar = await SoldCar.find({user:userId, status: "SOLD"})
      .populate("car")
      .populate("dealer","number email name");
    
    if (!soldCar) {
      return res
        .status(404)
        .json({ status: false, message: "cars are not avalable" });
    }

    return res.status(200).json({
      status: true,
      message: "Car Is Sold",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const trackPurchase = async (req, res) => {
  const userId = req.user._id;
  try {
    const soldCar = await SoldCar.find({user:userId})
    if (!soldCar) {
      return res
        .status(404)
        .json({ status: false, message: "cars are not avalable" });
    }

    return res.status(200).json({
      status: true,
      message: "Get under Sold car",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const trackOnePurchase = async (req, res) => {
  const userId = req.user._id;
  try {
    const soldCar = await SoldCar.find({user:userId})
      .populate("car")
      .populate("dealer","number email name")
      .populate("machenical")
      .populate("delivery")
      .populate("cleaning")
      .sort({_id: -1});

    if (!soldCar) {
      return res
        .status(404)
        .json({ status: false, message: "cars are not avalable" });
    }

    return res.status(200).json({
      status: true,
      message: "Get under Sold car",
      data: soldCar,
    });
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
}

const cancelPurchase = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id; 

  try {
    
    const purchaseRecord = await Purchase.findOne({ user: userId, car: carId });

    if (!purchaseRecord) {
      return res.status(404).json({
        status: false,
        message: "Purchase record not found for this car.",
      });
    }

    const soldCar = await SoldCar.findOne({ user: userId, car: carId });

    if (!soldCar) {
      return res.status(404).json({
        status: false,
        message: "Sold car record not found for this car.",
      });
    }

    const machanicalRecord = await Mechanical.findById(soldCar.machenical);

    if (!machanicalRecord) {
      return res.status(404).json({
        status: false,
        message: "can not cancel without machenical check",
      });
    }

    if (machanicalRecord.status != "checking done") {
      return res.status(404).json({
        status: false,
        message: "Mechanical check is under progress please wait for few more time.",
      });
    }

    // Update the status to 'user canceled' or your preferred status
    purchaseRecord.status = 'user canceled';
    soldCar.status = 'user canceled';

    // Save the updated records
    await purchaseRecord.save();
    await soldCar.save();

    return res.status(200).json({
      status: true,
      message: "Purchase canceled successfully.",
      data: {
        purchase: purchaseRecord,
        soldCar,
        // machanicalRecord,
      },
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const payment = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id; 

  try {
    
    const purchaseRecord = await Purchase.findOne({ user: userId, car: carId });

    if (!purchaseRecord) {
      return res.status(404).json({
        status: false,
        message: "Purchase record not found for this car.",
      });
    }

    const soldCar = await SoldCar.findOne({ user: userId, car: carId });

    if (!soldCar) {
      return res.status(404).json({
        status: false,
        message: "Sold car record not found for this car.",
      });
    }

    

    soldCar.status = 'Paid';

    // Save the updated records
    const newsoldCar = await soldCar.save();

    return res.status(200).json({
      status: true,
      message: "payment successfully.",
      data: {
        soldCar:newsoldCar,
      },
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

const ProofUpload = async (req, res) => {
  const { carId } = req.body;
  const userId = req.user._id; 

  try {
    
    const purchaseRecord = await Purchase.findOne({ user: userId, car: carId });

    if (!purchaseRecord) {
      return res.status(404).json({
        status: false,
        message: "Purchase record not found for this car.",
      });
    }

    const soldCar = await SoldCar.findOne({ user: userId, car: carId });

    if (!soldCar) {
      return res.status(404).json({
        status: false,
        message: "Sold car record not found for this car.",
      });
    }

    // paymentProof

    if (req.files['image']) {
      // old delete prosess
      // if (car.image) {
      //   const oldImagePath = path.join(__dirname, '../../images/', car.image);
      //   fs.unlink(oldImagePath, (err) => {
      //     if (err) console.log('Failed to delete old image:', err);
      //   });
      // } 
      image = req.files['image'][0].filename;
      console.log("image=====>" , image);

      const updatedSoldCar = await SoldCar.findByIdAndUpdate(
        soldCar._id,
        { $set: {status: "Uploaded", paymentProof: image } },
        { new: true }
      );

      return res.status(200).json({
        status: true,
        message: "successfully added Proof.",
        data: updatedSoldCar,
      });
      
    }else{
      return res
      .status(404)
      .json({ status: false, message: "Image not provided" });
    }
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};






/** 

**/
module.exports = {
  getDealerPurchase,
  getOffersForDealerAndCar,
  changeOfferStatus,

  PurchaseImmediateUser,
  getPurchaseUser,
  proseedBuyUser,
  userBuyList,
  SoldCarByUser,


  dealerListSoldCar,
  dealerUnderSoldCar,
  dealerMarkAsSoldOffline,

  trackPurchase,
  trackOnePurchase,

  addMacheniclCheck,
  UploadMechenicalPayProof,
  verifyMechenicalProof,
  listMechanicsByDealer,
  UploadMechenicalReport,

  addDeliveryDetails,
  addCleaningDetails,

  cancelPurchase,
  payment,
  ProofUpload,
};
