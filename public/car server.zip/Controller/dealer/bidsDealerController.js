const Bid = require("../../Models/carSchema/bidsModel");
const Car = require("../../Models/carSchema/carModel");
const Offer = require("../../Models/carSchema/offerModel");
const Purchase = require("../../Models/carSchema/Purchase");

const getDealerBid = async (req, res) => {
  const dealerId = req.user._id;

  // Pagination parameters
  const page = parseInt(req.query.page) || 1; 
  const limit = parseInt(req.query.limit) || 100; 
  const skip = (page - 1) * limit;

  try {
    const cars = await Car.find({ dealer: dealerId }).select('_id');
    const carIds = cars.map(car => car._id);

    const bids = await Bid.find({ car: { $in: carIds } })
      .populate('car') 
      .select('car amount status date _id')
      .sort({ _id: -1 })
      .skip(skip)
      .limit(limit);

    // Step 3: Prepare the response data
    const data = bids.map(bid => ({
      car: bid.car,
      amount: bid.amount,
      status: bid.status,
      date: bid.date,
      _id: bid._id,
    }));

    // Step 4: Calculate total Bids count for pagination
    const totalBids = await Bid.countDocuments({ car: { $in: carIds } });
    const totalPages = Math.ceil(totalBids / limit);

    // Step 5: Send the response with the bids and pagination info
    return res.json({
      status: true,
      message: "success",
      data: data,
      pagination: {
        totalItems: totalBids,
        totalPages: totalPages,
        currentPage: page,
        itemsPerPage: limit,
      },
    });
  } catch (error) {
    console.error("Error fetching dealer's cars in Bids:", error);
    return res.json({
      status: false,
      message: "failed",
    });
  }
};

const getBidsForDealerAndCar = async (req, res) => {
  const dealerId = req.user._id;
  const carId = req.params.carId;

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId }).select('_id');
    if (!car) {
      return res.status(404).json({
        status: false,
        message: "Car not found or does not belong to the dealer",
      });
    }

    const bids = await Bid.find({ car: carId })
      .populate('car')
      .populate('user', 'name email profile_image mobile_number last_name first_name')
      .select('car amount status date user');

    return res.json({
      status: true,
      message: "success",
      data: bids,
    });
  } catch (error) {
    console.error("Error fetching bids for the dealer's car:", error);
    return res.status(500).json({
      status: false,
      message: "failed",
    });
  }
};

// const changeBidStatus = async (req, res) => {
//  const { status ,  bidId } = req.body; // status:-  Rejected
//   const dealerId = req.user._id;

//   try {
//     const bid = await Bid.findOne({ _id: bidId });
//     console.log("dealerId" , dealerId);
    

//     if (!bid) {
//       return res.status(403).json({ message: "Bid not found." });
//     }
//     bid.status = status;
//     await bid.save();

//     return res.status(200).json({ message: "Bid status updated successfully.", bid });
//   } catch (error) {
//     return res.status(500).json({ message: "Server error.", error });
//   }
// }

const changeBidStatus = async (req, res) => {
  const { status, bidId } = req.body; // status:- Rejected or Accepted
  const dealerId = req.user._id;

  try {
    const bid = await Bid.findOne({ _id: bidId });
    console.log();
    
    if (!bid) {
      return res
        .status(404)
        .json({ status: false, message: "bid not found." });
    }

    if (status === "Rejected") {
      bid.status = status;
      await bid.save();
      return res.status(200).json({
        status: true,
        message: "Bid rejected successfully.",
        data: bid,
      });
    }

    if (status === "Accepted") {
      const carData = await Car.findOne({ _id: bid?.car });
      if (!carData) {
        return res
          .status(404)
          .json({ status: false, message: "Car not found." });
      }

      if (carData?.car_status !== "ACTIVE") {
        return res.status(403).json({
          status: false,
          message: "Car is already sold, please check buying or sold list.",
        });
      }

      bid.status = status;
      await bid.save();

      const updatedCarStatus = await Car.findByIdAndUpdate(
        bid?.car,
        { $set: { car_status: "BUYING" } },
        { new: true }
      );

      await Bid.updateMany(
        { car: bid?.car, _id: { $ne: bid?._id } }, // Exclude the current accepted bid
        { $set: { status: "Canceled Automatically" } }
      );
    
      await Offer.updateMany(
        { car: bid?.car },
        { $set: { status: "Canceled Automatically" } }
      );

      
      const newPurchase = new Purchase({
        user: bid?.user,
        dealer: dealerId,
        car: bid?.car,
        bidId: bid?._id || "", 
        amount: bid?.amount,
        status: "bid Accepted",
      });

      await newPurchase.save();

      return res.status(200).json({
        status: true,
        message: "Bid accepted successfully.",
        data: { bid, updatedCarStatus, newPurchase },
      });
    }

    return res.status(400).json({
      status: false,
      message: "Invalid bid status.",
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};



module.exports = {getDealerBid, getBidsForDealerAndCar, changeBidStatus}