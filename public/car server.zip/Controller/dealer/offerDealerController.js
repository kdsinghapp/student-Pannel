const Purchase = require("../../Models/carSchema/Purchase");
const Bid = require("../../Models/carSchema/bidsModel");
const Car = require("../../Models/carSchema/carModel");
const Offer = require("../../Models/carSchema/offerModel");

const getDealerOffer = async (req, res) => {
  const dealerId = req.user._id;

  // Pagination parameters
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 100;
  const skip = (page - 1) * limit;

  try {
    // Step 1: Find all cars associated with the dealer
    const cars = await Car.find({ dealer: dealerId }).select("_id");
    const carIds = cars.map((car) => car._id);

    // Step 2: Find all offers related to these cars with pagination
    const offers = await Offer.find({ car: { $in: carIds } })
      .populate("car")
      .select("car amount status date")
      .sort({ _id: -1 })
      .skip(skip)
      .limit(limit);

    // Step 3: Prepare the response data
    const data = offers.map((offer) => ({
      car: offer.car,
      amount: offer.amount,
      status: offer.status,
      date: offer.date,
      _id: offer._id,
    }));

    // Step 4: Calculate total offers count for pagination
    const totalOffers = await Offer.countDocuments({ car: { $in: carIds } });
    const totalPages = Math.ceil(totalOffers / limit);

    // Step 5: Send the response with the offers and pagination info
    return res.json({
      status: true,
      message: "success",
      data: data,
      pagination: {
        totalItems: totalOffers,
        totalPages: totalPages,
        currentPage: page,
        itemsPerPage: limit,
      },
    });
  } catch (error) {
    console.error("Error fetching dealer's cars in offers:", error);
    return res.json({
      status: false,
      message: "failed",
    });
  }
};

const getOffersForDealerAndCar = async (req, res) => {
  const dealerId = req.user._id;
  const carId = req.params.carId;

  try {
    const car = await Car.findOne({ _id: carId, dealer: dealerId }).select(
      "_id"
    );
    if (!car) {
      return res.status(404).json({
        status: false,
        message: "Car not found or does not belong to the dealer",
      });
    }

    const offers = await Offer.find({ car: carId })
      .populate("car")
      .populate(
        "user",
        "name email profile_image mobile_number last_name first_name"
      )
      .select("car amount status date _id");

    return res.json({
      status: true,
      message: "success",
      data: offers,
    });
  } catch (error) {
    console.error("Error fetching offers for the dealer's car:", error);
    return res.status(500).json({
      status: false,
      message: "failed",
    });
  }
};

const changeOfferStatus = async (req, res) => {
  const { status, offerId } = req.body; // status:- Rejected or Accepted
  const dealerId = req.user._id;

  try {
    const offer = await Offer.findOne({ _id: offerId });
    if (!offer) {
      return res
        .status(404)
        .json({ status: false, message: "Offer not found." });
    }

    if (status === "Rejected") {
      offer.status = status;
      await offer.save();
      return res.status(200).json({
        status: true,
        message: "Offer rejected successfully.",
        data: offer,
      });
    }

    if (status === "Accepted") {
      const carData = await Car.findOne({ _id: offer?.car });
      if (!carData) {
        return res
          .status(404)
          .json({ status: false, message: "Car not found." });
      }

      if (carData?.car_status !== "ACTIVE") {
        return res.status(403).json({
          status: false,
          message: "Car is already sold, please check buying or sold list..",
        });
      }

      offer.status = status;
      await offer.save();

      const updatedCarStatus = await Car.findByIdAndUpdate(
        offer?.car,
        { $set: { car_status: "BUYING" } },
        { new: true }
      );

      await Bid.updateMany(
        { car: offer?.car}, // Exclude the current accepted bid
        { $set: { status: "Canceled Automatically" } }
      );
    
      await Offer.updateMany(
        { car: offer?.car, _id: { $ne: offer?._id }  },
        { $set: { status: "Canceled Automatically" } }
      );

      
      const newPurchase = new Purchase({
        user: offer?.user,
        dealer: dealerId,
        car: offer?.car,
        offerId: offer?._id || "", 
        amount: offer?.amount,
        status: "Offer Accepted",
      });

      await newPurchase.save();

      return res.status(200).json({
        status: true,
        message: "Offer accepted successfully.",
        data: { offer, updatedCarStatus, newPurchase },
      });
    }

    return res.status(400).json({
      status: false,
      message: "Invalid offer status.",
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "Server error.",
      error: error.message,
    });
  }
};

module.exports = {
  getDealerOffer,
  getOffersForDealerAndCar,
  changeOfferStatus,
};
