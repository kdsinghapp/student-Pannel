const fs = require("fs");
const path = require("path");

const Bid = require("../../Models/carSchema/bidsModel");
const Car = require("../../Models/carSchema/carModel");
const Offer = require("../../Models/carSchema/offerModel");
const Mechanic = require("../../Models/mechanic/authSchema");
const TowMan = require("../../Models/towing/TowManSchema");

const getDealerCars = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const userId = req.query.userId || "";
    const skip = (page - 1) * limit;
    const sortOption = req.query.data;

    const dealerId = req.user._id;

    // Define the sorting options
    let sort = { _id: -1 };
    if (sortOption === "latest") {
      sort = { _id: -1 };
    } else if (sortOption === "lowPrice") {
      sort = { car_price: 1 };
    } else if (sortOption === "highPrice") {
      sort = { car_price: -1 };
    } else if (sortOption === "featured") {
    }

    // Fetch cars with pagination, sorting, and selection
    const allCar = await Car.find({ dealer: dealerId })
      .sort(sort)
      .skip(skip)
      .limit(limit)
      // .select("car_name car_class car_price car_model_year car_fuel_type car_kilometers car_transmission image car_condition gallery dealer car_address")
      .populate({ path: "dealer", select: "number name" });

    // Respond with the car data including pagination
    res.status(200).json({
      status: true,
      message: "success",
      data: allCar,
      pagination: {
        page,
        limit,
        //   totalResults: await Car.countDocuments(),
        //   totalPages: Math.ceil((await Car.countDocuments()) / limit),
      },
    });
  } catch (error) {
    res.status(500).json({ status: false, error: error.message });
  }
};

const viewDealerCar = async (req, res) => {
  const { carId } = req.params;
  try {
    const dealerId = req.user._id;
    const allCar = await Car.findById(carId).populate({
      path: "dealer",
      select: "number name",
    });

    res.status(200).json({
      status: true,
      message: "success",
      data: allCar,
    });
  } catch (error) {
    res.status(500).json({ status: false, error: error.message });
  }
};

const updateCar = async (req, res) => {
  const { carId } = req.params;
  const dealerId = req.user._id;

  try {
    const car = await Car.findById(carId);

    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    if (car.dealer.toString() !== dealerId.toString()) {
      return res
        .status(403)
        .json({ error: "You do not have permission to update this car" });
    }

    for (const key in req.body) {
      car[key] = req.body[key];
    }

    if (req.files["image"]) {
      if (car.image) {
        const oldImagePath = path.join(__dirname, "../../images/", car.image);
        fs.unlink(oldImagePath, (err) => {
          if (err) console.log("Failed to delete old image:", err);
        });
      }
      car.image = req.files["image"][0].filename;
    }

    if (req.files["gallery"]) {
      if (car.gallery && car.gallery.length > 0) {
        car.gallery.forEach((oldGalleryImage) => {
          const oldGalleryImagePath = path.join(
            __dirname,
            "../../images/",
            oldGalleryImage
          );
          fs.unlink(oldGalleryImagePath, (err) => {
            if (err) console.log("Failed to delete old gallery image:", err);
          });
        });
      }
      car.gallery = req.files["gallery"].map((file) => file.filename);
    }

    const updatedCar = await car.save();
    res.status(200).json(updatedCar);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getDashboard = async (req, res) => {
  const dealerId = req.user._id;

  try {
    const carCount = await Car.countDocuments({
      dealer: dealerId,
      car_status: "ACTIVE",
    });
    const carDeletedCount = await Car.countDocuments({
      dealer: dealerId,
      car_status: "INACTIVE",
    });
    const offerCount = await Offer.countDocuments({
      car: {
        $in: await Car.find({ dealer: dealerId, car_status: "ACTIVE" }).select(
          "_id"
        ),
      },
    });
    const bidCount = await Bid.countDocuments({
      car: {
        $in: await Car.find({ dealer: dealerId, car_status: "ACTIVE" }).select(
          "_id"
        ),
      },
    });
    const mechanicalCount = await Mechanic.countDocuments({
      "adminVerification.status": { $in: [false, "Accepted"] },
    });
    const towmanCount = await TowMan.countDocuments({
      "adminVerification.status": { $in: [true, "Accepted"] },
    });

    return res.json({
      status: true,
      message: "Dashboard data fetched successfully",
      data: {
        carCount,
        offerCount,
        bidCount,
        carDeletedCount,
        mechanicalCount,
        towmanCount,
      },
    });
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    return res.status(500).json({
      status: false,
      message: "Failed to fetch dashboard data",
    });
  }
};

const changeCarStatus = async (req, res) => {
  const { status, CarId } = req.body;
  const dealerId = req.user._id;

  if (!status || !["ACTIVE", "INACTIVE"].includes(status)) {
    return res.status(400).json({ error: "Invalid or missing status" });
  }

  try {
    const car = await Car.findById(CarId);

    if (!car) {
      return res.status(404).json({ error: "Car not found" });
    }

    if (car.dealer.toString() !== dealerId.toString()) {
      return res.status(403).json({
        error: "You do not have permission to change the status of this car",
      });
    }

    car.car_status = status;
    const updatedCar = await car.save();

    res.status(200).json(updatedCar);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getMechanicsData = async (req, res) => {
  try {
    const mechanics = await Mechanic.find({});
    console.log("Mechanics", mechanics);
    return res.json({
      status: true,
      message: "Dashboard data fetched successfully",
      data: {
        mechanics,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "An error occurred while fetching mechanics.",
      error: error.message,
    });
  }
};

const getTowmanData = async (req, res) => {
  try {
    const towman = await TowMan.find({});
    console.log("Towman", towman);
    return res.json({
      status: true,
      message: "Dashboard data fetched successfully",
      data: {
        towman,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "An error occurred while fetching mechanics.",
      error: error.message,
    });
  }
};

module.exports = {
  getDealerCars,
  getDashboard,
  changeCarStatus,
  updateCar,
  viewDealerCar,
  getMechanicsData,
  getTowmanData,
};
