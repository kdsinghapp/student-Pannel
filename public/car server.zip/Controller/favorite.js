const Favorite = require("../Models/carSchema/favorite");

const setFavorite = async (req, res) => {
  const { carId, action } = req.body; 
  const userId = req.user._id

  try {
    if (action === "add") {
      // Check if the favorite already exists
      const existingFavorite = await Favorite.findOne({ userId, carId });
      if (existingFavorite) {
        return res.status(200).json({
          status: false,
          message: "Already in favorites",
        });
      }

      // Add to favorites
      const favorite = new Favorite({ userId, carId });
      await favorite.save();
      return res.status(201).json({
        status: true,
        message: "Added to favorites",
        data: favorite,
      });
    } else if (action === "remove") {
      // Remove from favorites
      const result = await Favorite.findOneAndDelete({ userId, carId });
      if (result) {
        return res.status(200).json({
          status: true,
          message: "Removed from favorites",
          data: result,
        });
      } else {
        return res.status(204).json({
          status: false,
          message: "Favorite not found",
        });
      }
    } else {
      return res.status(204).json({
        status: false,
        message: "Invalid action",
      });
    }
  } catch (error) {
    res.status(500).json({
      status: false,
      message: "Operation failed",
      error: error.message,
    });
  }
};


const myFavorites = async (req, res) => {
    const userId = req.user._id;
  
    try {
      const favorites = await Favorite.find({ userId }).populate('carId');
      
      if (favorites.length > 0) {
        res.status(200).json({
          status: true,
          message: 'Favorites retrieved successfully',
          data: favorites
        });
      } else {
        res.status(200).json({
          status: true,
          message: 'No favorites found',
          data: []
        });
      }
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Failed to retrieve favorites',
        error: error.message
      });
    }
  }

module.exports = { setFavorite, myFavorites };
