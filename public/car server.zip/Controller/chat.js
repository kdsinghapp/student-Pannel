const ChatRoom = require("../Models/chatRoomModel");
const Dealer = require("../Models/dealerModel");
const Message = require("../Models/messageModel");

const sendMessage = async (req, res) => {
    try {
        const {  dealerId, message } = req.body;
        console.log("userId" ,11111111111);
        const userId = req.user._id
        console.log("userId" ,req.user);
        

        // Find or create a chat room
        let chatRoom = await ChatRoom.findOne({ userId, dealerId });

        if (!chatRoom) {
            chatRoom = new ChatRoom({ userId, dealerId });
            await chatRoom.save();
        }

        // Create a new message with `seen: false`
        const newMessage = new Message({
            chatRoomId: chatRoom._id,
            senderId: userId,  // since user initiates chat, user is the sender here
            message,
            seen: false  // Mark message as unseen
        });

        await newMessage.save();

        // Add the message to the chat room
        chatRoom.messages.push(newMessage._id);
        chatRoom.updatedAt = Date.now();
        await chatRoom.save();

        return res.status(201).json({ success: true, message: 'Message sent successfully', chatRoom , addedMessage:newMessage });
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
}

const sendMessageByDealer = async (req, res) => {
    try {
        const { userId, message } = req.body;
        const dealerId = req.user._id

        // Find the existing chat room between the user and dealer
        const chatRoom = await ChatRoom.findOne({ userId, dealerId });

        if (!chatRoom) {
            return res.status(404).json({ success: false, message: 'Chat room not found' });
        }

        // Create a new message with `seen: false` (unseen by the user)
        const newMessage = new Message({
            chatRoomId: chatRoom._id,
            senderId: dealerId,  // Dealer is the sender in this case
            message,
            seen: false  // Mark message as unseen for the user
        });

        await newMessage.save();

        // Add the message to the chat room and update the `updatedAt` timestamp
        chatRoom.messages.push(newMessage._id);
        chatRoom.updatedAt = Date.now();
        await chatRoom.save();

        return res.status(201).json({ success: true, message: 'Message sent successfully', chatRoom , addedMessage:newMessage});
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};



// Get Messages in a Room
const getMessages = async (req, res) => {
    try {
        const { chatRoomId } = req.params;
        const { userId, dealerId } = req.body;  

        const messages = await Message.find({ chatRoomId }).sort({ createdAt: 1 });

        if (userId) {
            await Message.updateMany(
                { chatRoomId, senderId: { $ne: userId }, seen: false }, 
                { $set: { seen: true } }
            );
        } else if (dealerId) {
             const readMessage = await Message.updateMany(
                { chatRoomId, senderId: { $ne: dealerId }, seen: false }, 
                { $set: { seen: true } },
                { new: true }
            );
            
        }

        const unseenMessagesCount = userId
            ? await Message.countDocuments({ chatRoomId, senderId: { $ne: userId }, seen: false })
            : await Message.countDocuments({ chatRoomId, senderId: { $ne: dealerId }, seen: false });

        return res.status(200).json({ success: true, messages, unseenMessagesCount });
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};

// only for user
const getMessagesUser = async (req, res) => {
    try {
        const { dealerId } = req.params;  
        const userId = req.user._id; 
        

        let room = await ChatRoom.findOne({ userId, dealerId });

        const dealerExists = await Dealer.findById(dealerId);

        if (!room) {
        if (!dealerExists) {
            return res.status(404).json({ success: false, message: "Dealer not found" });
        }

            room = new ChatRoom({
                userId,
                dealerId,
                messages: []
            });
            await room.save();
        }

        const chatRoomId = room._id;

        const messages = await Message.find({ chatRoomId }).sort({ createdAt: 1 });

        await Message.updateMany(
            { chatRoomId, senderId: { $ne: userId }, seen: false },
            { $set: { seen: true } }
        );

        const unseenMessagesCount = await Message.countDocuments({
            chatRoomId,
            senderId: { $ne: userId },
            seen: false
        });

        return res.status(200).json({ success: true, messages, unseenMessagesCount , yourId:userId , user : dealerExists});
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};



// only for dealer
const getMessagesDealer = async (req, res) => {
    try {
        const { chatRoomId } = req.params;
        const dealerId  = req.user._id

        const chatRoom = await ChatRoom.findById(chatRoomId)
        .populate('userId' , "last_name first_name email name profile_image")
        ;


        const messages = await Message.find({ chatRoomId }).sort({ createdAt: 1 });

             const readMessage = await Message.updateMany(
                { chatRoomId, senderId: { $ne: dealerId }, seen: false },  
                { $set: { seen: true } },
                { new: true }
            );

        const unseenMessagesCount =  await Message.countDocuments({ chatRoomId, senderId: { $ne: dealerId }, seen: false });

        return res.status(200).json({ success: true, messages, unseenMessagesCount , yourId : dealerId , user : chatRoom?.userId});
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};


const allChatRooms = async (req, res) => {
    try {
        const userId = req.user._id

        const chatRooms = await ChatRoom.find({ userId }).populate('dealerId').sort({ updatedAt: -1 });

        const chatRoomsWithUnreadCount = await Promise.all(
            chatRooms.map(async (room) => {
                const unseenMessagesCount = await Message.countDocuments({
                    chatRoomId: room._id,
                    senderId: { $ne: userId },
                    seen: false
                });

                return { ...room.toObject(), unseenMessagesCount };
            })
        );

        return res.status(200).json({ success: true, chatRooms: chatRoomsWithUnreadCount  });
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};
const allChatRoomsDealer = async (req, res) => {
    try {
        const dealerId  = req.user._id
        console.log(dealerId);
        

        // Retrieve all chat rooms where the dealer is a participant
        const chatRooms = await ChatRoom.find({ dealerId }).populate('userId').sort({ updatedAt: -1 });

        // For each chat room, calculate the count of unseen user messages for the dealer
        const chatRoomsWithUnreadCount = await Promise.all(
            chatRooms.map(async (room) => {
                const unseenMessagesCount = await Message.countDocuments({
                    chatRoomId: room._id,
                    senderId: { $ne: dealerId },  // Messages from the user
                    seen: false
                });
                return { ...room.toObject(), unseenMessagesCount };
            })
        );

        return res.status(200).json({ success: true, chatRooms: chatRoomsWithUnreadCount });
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
};

module.exports = {
    sendMessage,
    sendMessageByDealer,
    getMessages,
    allChatRooms,
    allChatRoomsDealer,
    getMessagesDealer,

    getMessagesUser,
};
