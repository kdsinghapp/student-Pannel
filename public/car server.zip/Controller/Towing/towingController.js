const TowMan = require("../../Models/towing/TowManSchema");
const Towing = require("../../Models/towing/towingModels");
// const TowingRequest = require("../../Models/towing/towingModels")
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const createTowingToken = (towingId) => {
  return jwt.sign(
    { towingId },
    process.env.JWT_SECRET || "your_towing_jwt_secret",
    { expiresIn: "1h" }
  );
};

const registerTowMan = async (req, res) => {
  const {
    name,
    email,
    password,
    phone,
    vehicleType,
    drivingLicense,
    mainServiceLocation,
    address,
  } = req.body;

  try {
    const existingTowMan = await TowMan.findOne({
      $or: [{ email }, { phone }, { drivingLicense }],
    });

    if (existingTowMan) {
      let message = "Already registered:";
      if (existingTowMan.email === email) message += " Email";
      if (existingTowMan.phone === phone) message += " Phone";
      if (existingTowMan.drivingLicense === drivingLicense)
        message += " Driving License";
      return res.status(400).json({ status: false, message });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newTowMan = new TowMan({
      name,
      email,
      password: hashedPassword,
      phone,
      vehicleType,
      drivingLicense,
      mainServiceLocation,
      address: "",
      description: "",
    });

    const savedTowMan = await newTowMan.save();

    res.status(201).json({
      status: true,
      message: "Tow man registered successfully",
      data: savedTowMan,
    });
  } catch (error) {
    console.error("Failed to register tow man", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const loginTowMan = async (req, res) => {
  const { email, password } = req.body;
  try {
    const towMan = await TowMan.findOne({ email });
    if (!towMan) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, towMan.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid email or password" });
    }

    const token = createTowingToken(towMan._id);

    res.status(200).json({
      status: true,
      message: "Login successful",
      data: {
        id: towMan._id,
        name: towMan.name,
        email: towMan.email,
        phone: towMan.phone,
        vehicleType: towMan.vehicleType,
        drivingLicense: towMan.drivingLicense,
        mainServiceLocation: towMan.mainServiceLocation,
        adminVerification: towMan.adminVerification,
        address: towMan.address,
        description: towMan.description,
      },
      token,
    });
  } catch (error) {
    console.error("Login failed", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const logoutTowMan = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res
        .status(400)
        .json({ status: false, message: "Token not provided" });
    }

    const decoded = jwt.decode(token);
    const expiration = decoded.exp * 1000 - Date.now();

    if (expiration > 0) {
      await redisClient.set(token, "invalid", "PX", expiration);
    }

    res.status(200).json({ status: true, message: "Logout successful" });
  } catch (error) {
    console.error("Logout failed", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getRequestByTowingMan = async (req, res) => {
  const { id } = req.params;

  try {
    const towingRequests = await Towing.find({ towingManId: id })
      .populate({
        path: "carId",
        select: "car_name image car_price",
      })
      .populate({
        path: "user",
        select: "name email phone address",
      })
      .select("+carDetails"); // Ensure carDetails is included in response

    if (!towingRequests || towingRequests.length === 0) {
      return res.status(404).json({
        status: false,
        message: "No towing requests found for this TowMan",
      });
    }

    res.status(200).json({
      status: true,
      message: "Towing requests fetched successfully",
      data: towingRequests,
    });
  } catch (error) {
    console.error("Cannot get requests", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getRequestById = async (req, res) => {
  const { towingId } = req.params;
  console.log("towingId", towingId);

  try {
    const towingRequest = await Towing.findById(towingId)
      .populate({
        path: "carId",
        select: "car_name image car_price",
      })
      .populate({
        path: "user",
        select: "name email phone address",
      })
      .select("+carDetails");

    if (!towingRequest) {
      return res.status(404).json({
        status: false,
        message: "Towing request not found",
      });
    }

    res.status(200).json({
      status: true,
      message: "Towing request fetched successfully",
      data: towingRequest,
    });
  } catch (error) {
    console.error("Cannot get request", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const changePassword = async (req, res) => {
  const { oldPassword, newPassword, confirmPassword } = req.body;
  const { id } = req.params;

  try {
    if (!oldPassword || !newPassword || !confirmPassword) {
      return res
        .status(400)
        .json({ status: false, message: "All fields are required" });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        status: false,
        message: "New password and confirm password do not match",
      });
    }

    const towMan = await TowMan.findById(id);
    if (!towMan) {
      return res.status(404).json({ status: false, message: "User not found" });
    }

    const isMatch = await bcrypt.compare(oldPassword, towMan.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Old password is incorrect" });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    towMan.password = hashedNewPassword;
    await towMan.save();

    res.status(200).json({
      status: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    console.error("Error changing password", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const getTowManDetails = async (req, res) => {
  const { id } = req.params;

  try {
    const towMan = await TowMan.findById(id);

    if (!towMan) {
      return res.status(404).json({
        status: false,
        message: "TowMan not found",
      });
    }
    console.log("Tow man here", towMan);

    res.status(200).json({
      status: true,
      message: "TowMan details fetched successfully",
      data: towMan,
    });
  } catch (error) {
    console.error("Error fetching TowMan details", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const updateTowManDetails = async (req, res) => {
  const { id } = req.params;
  const { name, contact, address, description } = req.body;

  try {
    // Find the TowMan by ID
    const towMan = await TowMan.findById(id);

    if (!towMan) {
      return res.status(404).json({
        status: false,
        message: "TowMan not found",
      });
    }

    // Update the TowMan details if provided
    if (name) towMan.name = name;
    if (contact) towMan.contact = contact;
    if (address) towMan.address = address;
    if (description) towMan.description = description;

    // Save the updated details
    await towMan.save();

    res.status(200).json({
      status: true,
      message: "TowMan details updated successfully",
      data: towMan,
    });
  } catch (error) {
    console.error("Error updating TowMan details:", error);
    res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

const acceptAndRejectRequest = async (req, res) => {
  try {
    const { id: requestId } = req.params;
    const { towmanId, action } = req.body;

    if (!["Accepted", "Rejected"].includes(action)) {
      return res.status(400).json({
        status: false,
        message: "Invalid action. Use 'Accepted' or 'Rejected'.",
      });
    }

    const towman = await TowMan.findById(towmanId);
    if (!towman) {
      return res.status(404).json({
        status: false,
        message: "Towman not found.",
      });
    }
    console.log("Towman", towmanId);
    console.log("Towman", towman);

    const request = await Towing.findById(requestId);
    if (!request) {
      return res.status(404).json({
        status: false,
        message: "Request not found.",
      });
    }

    request.status = action;
    await request.save();

    res.status(200).json({
      status: true,
      message: `Request has been ${action.toLowerCase()} successfully.`,
      request,
    });
  } catch (error) {
    console.error("Error accepting/rejecting request:", error);
    res.status(500).json({
      status: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const updateTrackingStatus = async (req, res) => {
  const {
    driverName,
    phone,
    drivingLicense,
    reachingTime,
    updateStatus,
    pickupStatus,
    pickupConfirmed,
    status,
  } = req.body;

  try {
    console.log("🔹 Incoming Request Body:", req.body);
    console.log("🔹 Updating Towing ID:", req.params.towingId);

    const updatedTracking = await Towing.findByIdAndUpdate(
      req.params.towingId,
      {
        $set: {
          "dispatchDetails.driverName": driverName,
          "dispatchDetails.phone": phone,
          "dispatchDetails.drivingLicense": drivingLicense,
          "dispatchDetails.reachingTime": reachingTime,
          "dispatchDetails.updateStatus": updateStatus,
          "dispatchDetails.pickupStatus": pickupStatus,
          pickupConfirmed: pickupConfirmed,
          status: status,
          updatedAt: new Date(),
        },
      },
      { new: true, runValidators: true }
    );

    console.log("🔹 Updated Document:", updatedTracking);

    if (!updatedTracking) {
      return res.status(404).json({ error: "Tracking ID not found" });
    }

    res.status(200).json({
      success: true,
      message: "Tracking details updated successfully",
      data: updatedTracking,
    });
  } catch (error) {
    console.error("❌ Error updating:", error);
    res.status(500).json({ error: "Failed to update tracking details" });
  }
};

module.exports = {
  registerTowMan,
  loginTowMan,
  getRequestByTowingMan,
  logoutTowMan,
  changePassword,
  getTowManDetails,
  updateTowManDetails,
  acceptAndRejectRequest,
  updateTrackingStatus,
  getRequestById,
};
