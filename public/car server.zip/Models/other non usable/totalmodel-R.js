about_us
`id`
`text_en`
`text_en_backup`
`text_ar_backup`
`text_ar`

admins
`id`
`name`
`email`
`email_verified_at`
`password`
`remember_token`
`created_at`
`updated_at`
`deleted_at`
`profile_image`

cache
`key`
`owner`
`expiration`

cars
`car_id`
`car_advertisement_id`
`car_name`
`car_class_id`
`car_user_id`
`car_admin_id`
`car_review_count`
`car_price`
`car_maker_id`
`car_model_id`
`car_model_year_id`
`car_reginal_specification_id`
`car_kilometers`
`car_engine_capacity_id`
`car_cylinder_id`
`car_transmission_id`
`car_body_color_id`
`car_fuel_type_id`
`car_door_id`
`car_city_id`
`car_created_at`
`car_updated_at`
`car_deleted_at`
`car_admin_status`
`car_plates_codes_id`
`car_plate_design_id`
`car_plate_source_id`
`car_rim_sizes_id`
`car_type_id`
`car_condition_id`
`car_under_warranty_id`
`car_extra_features`
`car_rent_price`
`car_interior_color_id`
`car_additional_details`
`car_seat_id`
`car_extra_feature_id`
`car_drive_type_id`
`car_service_history_id`
`car_horse_power_id`
`car_regional_specs_id`
`car_address`
`car_views`

cars_body_colors
`car_body_color_id`
`car_body_color_name`
`car_body_color_created_at`
`car_body_color_updated_at`
`car_body_color_deleted_at`
`car_body_color_admin_status`

cars_cities
`car_city_id`
`car_city_name`
`car_city_created_at`
`car_city_updated_at`
`car_city_deleted_at`
`car_city_admin_status`

cars_classes
`car_class_id`
`car_class_name`
`car_class_created_at`
`car_class_updated_at`
`car_class_deleted_at`
`car_class_admin_status`

cars_conditions
`car_condition_id`
`car_condition_name`
`car_condition_created_at`
`car_condition_updated_at`
`car_condition_deleted_at`
`car_condition_admin_status`

cars_cylinders
`car_cylinder_id`
`car_cylinder_count`
`car_cylinder_created_at`
`car_cylinder_updated_at`
`car_cylinder_deleted_at`
`car_cylinder_admin_status`

cars_doors
`car_door_id`
`car_door_count`
`car_door_created_at`
`car_door_updated_at`
`car_door_deleted_at`
`car_door_admin_status`

cars_drives_types
`car_drive_type_id`
`car_drive_type_name`
`car_drive_type_created_at`
`car_drive_type_updated_at`
`car_drive_type_deleted_at`
`car_drive_type_admin_status`

cars_engine_capacities
`car_engine_capacity_id`
`car_engine_capacity_value`
`car_engine_capacity_created_at`
`car_engine_capacity_updated_at`
`car_engine_capacity_deleted_at`
`car_engine_capacity_admin_status`

cars_extra_features
`car_extra_feature_id`
`car_extra_feature_sub_id`
`car_extra_feature_name`
`car_extra_feature_created_at`
`car_extra_feature_updated_at`
`car_extra_feature_deleted_at`
`car_extra_feature_admin_status`

cars_fuel_types
`car_fuel_type_id`
`car_fuel_type_name`
`car_fuel_type_created_at`
`car_fuel_type_updated_at`
`car_fuel_type_deleted_at`
`car_fuel_type_admin_status`

cars_horses_powers
`car_horse_power_id`
`car_horse_power_name`
`car_horse_power_created_at`
`car_horse_power_updated_at`
`car_horse_power_deleted_at`
`car_horse_power_admin_status`

cars_images
`car_image_id`
`car_image_car_id`
`car_image_created_at`
`car_image_updated_at`
`car_image_deleted_at`
`car_image_admin_status`
`car_image_name`

cars_interior_colors
`car_interior_color_id`
`car_interior_color_name`
`car_interior_color_created_at`
`car_interior_color_updated_at`
`car_interior_color_deleted_at`
`car_interior_color_admin_status`

cars_makers   ( big )
`car_maker_id`
`car_maker_sub_category_id`
`car_maker_name`
`car_maker_created_at`
`car_maker_updated_at`
`car_maker_deleted_at`
`car_maker_admin_status`

cars_models ( big )
`car_model_id`
`car_model_name`
`car_model_ar_name`
`car_model_car_maker_id`
`car_model_created_at`
`car_model_updated_at`
`car_model_deleted_at`
`car_model_admin_status`

cars_regional_specs
`car_regional_specs_id`
`car_regional_specs_name`
`car_regional_specs_created_at`
`car_regional_specs_updated_at`
`car_regional_specs_deleted_at`
`car_regional_specs_admin_status`

cars_rim_sizes
`car_rim_size_id`
`car_rim_size_name`
`car_rim_size_created_at`
`car_rim_size_updated_at`
`car_rim_size_deleted_at`
`car_rim_size_admin_status`

cars_seats
`car_seat_id`
`car_seat_name`
`car_seat_created_at`
`car_seat_updated_at`
`car_seat_deleted_at`
`car_seat_admin_status`

cars_services_histories
`car_service_history_id`
`car_service_history_name`
`car_service_history_created_at`
`car_service_history_updated_at`
`car_service_history_deleted_at`
`car_service_history_admin_status`

cars_transmissions
`car_type_id`
`car_type_name`
`car_type_created_at`
`car_type_updated_at`
`car_type_deleted_at`
`car_type_admin_status`
`car_type_image_name`

cars_under_warranties
`car_under_warranty_id`
`car_under_warranty_name`
`car_under_warranty_created_at`
`car_under_warranty_updated_at`
`car_under_warranty_deleted_at`
`car_under_warranty_admin_status`

cars_years
`car_year_id`
`car_year_name`
`car_year_created_at`
`car_year_updated_at`
`car_year_deleted_at`
`car_year_admin_status`

car_additional_details
`car_year_id`
`car_year_name`
`car_year_created_at`
`car_year_updated_at`
`car_year_deleted_at`
`car_year_admin_status`