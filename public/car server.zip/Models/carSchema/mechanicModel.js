const mongoose = require("mongoose");

const mechanicalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  soldId: { type: mongoose.Schema.Types.ObjectId, ref: "soldCar" },
  note: { type: String },
  amount: { type: Number, required: true },
  status: { type: String },
  date: { type: Date, default: Date.now },
  proofimg: { type: String },
  reportImg: { type: String },
  reportText: { type: String },
}, {
  timestamps: true
});

const Mechanical = mongoose.model("mechanical", mechanicalSchema);
module.exports = Mechanical;
