const mongoose = require("mongoose");

const  deliverySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  soldId: { type: mongoose.Schema.Types.ObjectId, ref: "soldCar" },
  note: { type: String },
  amount: { type: Number },
  address: { type: String },
  lat: { type: String },
  long: { type: String },
  pincode: { type: String },
  status: { type: String },
  date: { type: Date, default: Date.now },
},{
  timestamps:true
});

const Delivery = mongoose.model("delivery", deliverySchema);
module.exports = Delivery;
