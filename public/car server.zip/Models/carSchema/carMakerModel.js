const mongoose = require('mongoose');
const { get_current_date } = require('../../assets/utils');

const carMakerSchema = new mongoose.Schema({
  car_maker_id: {
    type: Number,
    required: true,
    unique: true
  },
  car_maker_sub_category_id: {
    type: Number,
  },
  car_maker_name: {
    type: String,
  },
  car_maker_created_at: {
    type: Date,
    default: () => new Date()
  },
  car_maker_updated_at: {
    type: Date,
    default: () => new Date()
  },
  car_maker_deleted_at: {
    type: Date,
  },
  car_maker_admin_status: {
    type: String,
    enum: ['ACTIVE', 'INACTIVE'],
    default: 'ACTIVE'
  }
});

// Creating a model from the schema
const CarMaker = mongoose.model('CarMaker', carMakerSchema);

module.exports = CarMaker;