const mongoose = require("mongoose");

const purchaseSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  dealer: { type: mongoose.Schema.Types.ObjectId, ref: "Dealer", required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  bidId: { type: mongoose.Schema.Types.ObjectId, ref: "Bid" },
  OfferId: { type: mongoose.Schema.Types.ObjectId, ref: "offer" },
  amount: { type: Number, required: true },
  status: { type: String },
  date: { type: Date, default: Date.now },
},{
  timestamps:true
});

const Purchase = mongoose.model("purchase", purchaseSchema);
module.exports = Purchase;
