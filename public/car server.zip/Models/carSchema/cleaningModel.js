const mongoose = require("mongoose");

const  cleaningSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  soldId: { type: mongoose.Schema.Types.ObjectId, ref: "soldCar" },
  note: { type: String },
  amount: { type: Number },
  status: { type: String },
  date: { type: Date, default: Date.now },
},{
  timestamps:true
});


const Cleaning = mongoose.model("cleaning", cleaningSchema);
module.exports = Cleaning;
