const mongoose = require('mongoose');
const { get_current_date } = require('../../assets/utils');
const Schema = mongoose.Schema;

const commentSchema = new Schema({
    carId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Car',
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    text: {
        type: String,
        required: true
    },
    type: {
        type: String,
        default: "Random User"
    },
    replies: [
        {
            userId: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
                required: true
            },
            text: {
                type: String,
                required: true
            },
            createdAt: {
                type: String,
                default: get_current_date()
            },
            type: {
                type: String,
                default: "Random User"
            },
        }
    ],
    createdAt: {
        type: String,
        default: get_current_date()
    }
});

module.exports = mongoose.model('Comment', commentSchema);
