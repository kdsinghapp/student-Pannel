const mongoose = require('mongoose');

const carModelSchema = new mongoose.Schema({
  car_model_id: {
    type: Number,
    required: true,
    // unique: true,
  },
  car_model_name: {
    type: String,
  },
  car_model_ar_name: {
    type: String,
  },
  car_maker_id: {
    type: mongoose.Schema.ObjectId,
    ref: 'CarMaker'
  },
  maker_id: {
    type: Number,
  },
  car_model_created_at: {
    type: Date,
    default: Date.now,
  },
  car_model_updated_at: {
    type: Date,
    default: Date.now,
  },
  car_model_deleted_at: {
    type: Date,
  },
  car_model_admin_status: {
    type: String,
    enum: ['ACTIVE', 'INACTIVE'],
    default: 'ACTIVE',
  },
});

const CarModel = mongoose.model('CarModel', carModelSchema);

module.exports = CarModel;
