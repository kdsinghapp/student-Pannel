const mongoose = require("mongoose");
const { get_current_date } = require("../../assets/utils");

const carSchema = new mongoose.Schema({
  car_advertisement_id: {
    type: String,
  },
  car_name: {
    type: String,
    trim: true
  },
  car_class: {
    type: String,
  },
  car_user_id: {
    type: String,
  },
  car_admin_id: {
    type: String,
  },
  car_review_count: {
    type: Number,
  },
  car_price: {
    type: Number,
  },
  car_maker_id: {
    type: String,
  },
  car_model_id: {
    type: String,
  },
  car_model_year: {
    type: Number,
  },
  car_reginal_specification: {
    type: String,
  },
  car_kilometers: {
    type: Number,
    trim: true
  },
  car_engine_capacity: {
    type: String,
  },
  car_cylinder: {
    type: Number,
  },
  car_transmission: {
    type: String,
  },
  car_body_color: {
    type: String,
  },
  car_fuel_type: {
    type: String,
  },
  car_door: {
    type: Number,
  },
  car_city_id: {
    type: mongoose.Schema.ObjectId,
    ref: 'city',
  },
  created_at: {
    type: String,
    default: get_current_date()
  },
  updated_at: {
    type: String,
    default: get_current_date()
  },
  car_deleted_at: {
    type: String,
  },
  car_status: {
    type: String,
    enum: ['PLAN','DETAILS','IMAGES',"AUCTION", 'ACTIVE', 'INACTIVE', 'DELETED', 'BUYING', 'SOLD'],
  },
  car_plates_codes_id: {
    type: Number,
  },
  car_plate_design_id: {
    type: Number,
  },
  car_plate_source_id: {
    type: Number,
  },
  car_rim_sizes: {
    type: String,
  },
  car_type: {
    type: String,
  },
  car_condition: {
    type: String,
  },
  car_under_warranty: {
    type: String,
  },
  car_extra_features: {
    type: String,
    trim: true
  },
  car_rent_price: {
    type: Number,
  },
  car_interior_color: {
    type: String,
  },
  car_additional_details: {
    type: String,
    trim: true
  },
  car_seat: {
    type: String,
  },
  car_drive_type: {
    type: String,
  },
  car_service_history: {
    type: String,
  },
  car_horse_power_id: {
    type: Number,
  },
  car_regional_specs: {
    type: String,
  },
  car_address: {
    type: String,
    trim: true
  },
  car_views: {
    type: Number,
    default: 0
  },
  ground_clearance: {
    type: String,
  },
  tank_capacity: {
    type: String,
  },
  torque: {
    type: String,
  },
  boot_space: {
    type: String,
  },
  airbag: {
    type: Number,
  },
  alloy_wheels: {
    type: String,
  },
  image: {
    type: String,
  },
  gallery: {
    type: Array,
  },
  dealer: {
    type: mongoose.Schema.ObjectId,
    ref: 'Dealer',
  },
  currentPrice: {  // this is current bidding price for car
    type: Number,
    default: 0
  },
  // newly added 
  Exterior: {
    type: String,
  },
  interior: {
    type: String,
  },
  Mileage: {
    type: String,
  },
  auctionIt: {
    type: Boolean,
    default: false
  },
  planType: String,   // e.g., 'standard'
  carImageLimit: Number,
  adExpiryDate: Date,
  
});

const Car = mongoose.model("Car", carSchema);

module.exports = Car;
