const mongoose = require("mongoose");

const soldCarSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  dealer: { type: mongoose.Schema.Types.ObjectId, ref: "Dealer", required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  purchaseId: { type: mongoose.Schema.Types.ObjectId, ref: "purchase" },
  amount: { type: Number, required: true },
  status: { type: String },
  note: { type: String },
  mechanicskip: { type: Boolean },
  machenical: { type: mongoose.Schema.Types.ObjectId, ref: "mechanical" },
  deliveryskip: { type: Boolean },
  delivery: { type: mongoose.Schema.Types.ObjectId, ref: "delivery" },
  cleaningskip: { type: Boolean },
  cleaning: { type: mongoose.Schema.Types.ObjectId, ref: "cleaning" },
  paymentProof: { type: String },
  date: { type: Date, default: Date.now },
},{
  timestamps:true
});

const SoldCar = mongoose.model("soldCar", soldCarSchema);
module.exports = SoldCar;
