const mongoose = require("mongoose");

const carValue = new mongoose.Schema({
  carDetails: {
    make: String,
    model: String,
    year: Number,
    mileage: Number,
    condition: String,
    location: String,
  },
  predictedValue: {
    amount: Number,
    currency: String,
  },
  sellingOption: {
    type: String,
    enum: ["Private Party", "Dealer", "International"],
    default: "Private Party",
  },
  advertisement: {
    status: { type: String, default: "Pending" },
    platform: String,
    createdAt: { type: Date, default: Date.now },
  },
  mainBannerImage: {
    type: String, 
    required: true,
  },
  extraImages: [
    {
      type: String,
    },
  ],
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User" 
  }
});

carValue.pre(/^find/, function (next) {
  this.populate({
    path: "userId",
    select: "name email phone",
  });
  next();
});

module.exports = mongoose.model("CarListing", carValue);
