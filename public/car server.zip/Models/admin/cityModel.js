const mongoose = require('mongoose');

const cityModelSchema = new mongoose.Schema({
  city_name: {
    type: String,
  },
  state_id: {
    type: String,
  },
  country_id: {
    type: String,
  },
  car_model_created_at: {
    type: Date,
    default: Date.now,
  },
  car_model_updated_at: {
    type: Date,
    default: Date.now,
  },
  city_admin_status: {
    type: String,
    enum: ['ACTIVE', 'INACTIVE'],
    default: 'ACTIVE',
  },
});

const city = mongoose.model('city', cityModelSchema);

module.exports = city;
