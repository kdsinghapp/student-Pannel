const mongoose = require('mongoose');
const { Schema } = mongoose;

const chatRoomSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    dealerId: { type: Schema.Types.ObjectId, ref: 'Dealer', required: true },
    messages: [{ type: Schema.Types.ObjectId, ref: 'Message' }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const ChatRoom = mongoose.model('ChatRoom', chatRoomSchema);
module.exports = ChatRoom
