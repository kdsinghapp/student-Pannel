const mongoose = require('mongoose');
const { get_current_date } = require('../assets/utils');
const Schema = mongoose.Schema;

const dealerSchema = new Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  token:{
    type: Array,
  },
  number: {
    type: String,
  },
  country: {
    type: String,
  },
  city: {
    type: String,
  },
  lat: {
    type: Number,
  },
  long: {
    type: Number,
  },
  created_date: {
    type: String,
    default: get_current_date()
  },
  updated_date: {
    type: String,
    default: get_current_date()
  },
  plan: {
    type: String,
    enum: ['free', 'standard', 'enhanced', 'deluxe'],
    required: true,
    default: 'free',
  },
  planExpiry: {
    type: Date,
  }


});

const Dealer = mongoose.model('Dealer', dealerSchema);

module.exports = Dealer;
