const mongoose = require("mongoose");

// For Vehicle History
const allowedTypesVehicleHistory = [
  "VIN Inspection",
  "Service Recalls (OASIS) Performed",
  "Vehicle History Report Obtained",
  "Scheduled Maintenance Performed",
  "Vehicle Emissions Sticker (Applicable States)",
];

const vehicleHistorySchema = new mongoose.Schema({
  type: {
    type: String,
    enum: allowedTypesVehicleHistory,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

// For Road Test
const roadTestTypes = [
  "Engine Starts Properly",
  "Engine Idles Properly",
  "Remote Start System Operation",
  "Engine Accelerates and Cruises Properly/Smoothly",
  "Engine Noise Normal(Cold/Hot & High/Low Speeds)",
  "Auto/Manual Transmission/Transaxle Operation – Cold and Hot Shift Quality",
  "Auto/Manual Transmission/Transaxle Noise Normal – Cold and Hot",
  "Shift Interlock Operates Properly",
  "Drive Axle/Transfer Case Operation Noise Normal",
  "Clutch Operates Properly",
  "Steers Normally (Response, Centering, Free Play)",
  "Body and Suspension Squeaks and Rattles",
  "Struts/Shocks Operate Properly",
  "Brakes/ABS Operate Properly",
  "Cruise Control",
  "Gauges Operate Properly",
  "Driver Select/Memory Profile Systems",
  "No Abnormal Wind Noise",
];

// Subdocument schema for each road test entry
const roadTestSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: roadTestTypes,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

// For Vehicle Exterior
const vehicleExteriorTypes = [
  "No Evidence of Flood Damage",
  "No Evidence of Fire Damage",
  "No Evidence of Major Damage",
  "No Evidence of Hall Damage",
  "Body Panel Inspection",
  "Bumper/Fascia Inspection",
  "Doors Inspection/Alignment",
  "Hood Inspection/Alignment",
  "Deckltd Inspection/Alignment",
  "Tailgate Inspection/Alignment",
  "Roof Inspection",
  "Hood Release Mechanisms Operate Properly",
  "Hood Hinges, Prop Rod/Gas Struts Operate Properly",
  "Door Hinges Operate Properly",
  "Trunk/Tailgate Hinges/Gas Struts Operate Properly",
  "Power Liftgate Operation",
  "Grille Inspection",
  "Trim Inspection",
  "Roof Rack Inspection",
  "Deployable Running Boards",
  "Windshield Glass Inspection",
  "Side Glass Inspection",
  "Rear Window/Tailgate Glass Inspection",
  "Wiper Blade Replacement",
  "Outside Mirror Inspection",
  "Outside Folding Mirror Inspection",
  "Front-End Exterior Lights",
  "Back-End Exterior Lights",
  "Side Exterior Lights",
  "Hazard Lights",
  "Auto On/Off Lighting",
  "Trailer Lamp Connector Operation",
];

// Subdocument schema for each `vehicleExterior` entry
const vehicleExteriorSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: vehicleExteriorTypes,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

const allowedTypesVehicleInterior = [
  "Seats Condition",
  "Seat Adjustments",
  "Seat Heating/Ventilation",
  "Interior Trim Condition",
  "Headliner Condition",
  "Carpet Condition",
  "Dashboard Condition",
  "Door Panel Condition",
  "Instrument Cluster Functionality",
  "Glovebox Condition",
  "Center Console Functionality",
  "Sunroof/Moonroof Operation",
  "Steering Wheel Condition",
  "Steering Wheel Adjustment",
  "Horn Functionality",
  "Air Conditioning Operation",
  "Heater Operation",
  "Defroster Operation",
  "Audio System Functionality",
  "Speakers Condition",
  "Infotainment Screen Functionality",
  "Backup Camera Display",
  "Interior Lighting Operation",
  "Power Windows Operation",
  "Door Locks Operation",
  "Child Safety Locks",
  "Interior Mirrors Adjustment",
];

const vehicleInteriorSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: allowedTypesVehicleInterior,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

// Vehicle Diagnostics System
const allowedTypesVehicleDiagnostics = ["Perform Self-Test for all CMDTCs"];

const vehicleDiagnosticsSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: allowedTypesVehicleDiagnostics,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

// Vehicle Underhood
const allowedTypesUnderHood = [
  "Engine Oil/Filter Change",
  "Chassis Lube",
  "Coolant",
  "Brake Fluid",
  "Automatic Transaxle/Transmission Fluid",
  "Transfer Case Fluid",
  "Drive Axle Fluid",
  "Power Steering Fluid",
  "Manual Transaxle/Transmission Hydraulic Clutch Fluid",
  "Washer Fluid",
  "Air Conditioning System Charge",
  "Fluid Leaks",
  "Hoses, Lines and Fittings",
  "Belts",
  "Wiring",
  "Oil in Air Cleaner Housing",
  "Water, Sludge or Engine Coolant in Oil",
  "Oil Pressure",
  "Relative Cylinder Compression Test/Power Balance Readings (check if necessary)",
  "Timing Belt",
  "Engine Mounts",
  "Inspect Turbocharger Air Cooler",
  "Radiator",
  "Pressure-Test Radiator Cap and Radiator",
  "Cooling Fans, Clutches and Motors",
  "Water Pump",
  "Coolant Recovery Tank",
  "Cabin Air Filter",
  "Fuel Pump Noise Normal",
  "Fuel Pump Pressure",
  "Fuel Filter",
  "Engine Air Filter",
  "Starter Operation",
  "Ignition System",
  "Battery",
  "Alternator Output",
  "Diesel Glow Plug System",
  "Hybrid Cooling System",
  "Switchable Powertrain Mount",
  "Hybrid Entertainment and Information Display",
  "110 V Power Outlet",
];

const underHoodSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: allowedTypesUnderHood,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

// Under Body
const allowedTypesUnderBody = [
  "Frame Damage",
  "Fuel Supply System",
  "Exhaust System Condition",
  "Emissions Control Test",
  "Automatic Transmission/Transaxle",
  "Manual Transmission/Transaxle, Differential and Transfer Case",
  "4*4 Hub Operation",
  "Universal Joints, CV Joints and CV Joint Boots",
  "Transmission Mounts (not cracked, broken or oil-soaked)",
  "Differential/Drive Axle",
  "Tires Match and Are Correct Size",
  "Wheels Match and Are Correct Size",
  "Tire Tread Depth – Front Tires (L/R)",
  "Tire Tread Depth – Rear Tires (L/R)",
  "Normal Tire Wear",
  "Tire Pressure – Front Tires (L/R)",
  "Tire Pressure – Rear Tires (L/R)",
  "Tire Pressure Monitoring System",
  "Wheels",
  "Wheel Covers and Center Caps",
  "Rack-and-Pinion, Linkage and Boots",
  "Control Arms, Bushings and Ball Joints",
  "Tie Rods and Idler Arm",
  "Sway Bars, Links and Bushings",
  "Springs",
  "Struts and Shocks",
  "Wheel Alignment (check if necessary)",
  "Power Steering Pump",
  "Calipers and Wheel Cylinders",
  "Brake Pads and Shoes – Front Brakes (L/R)",
  "Brake Pads and Shoes – Rear Brakes (L/R)",
  "Rotors and Drums",
  "Brake Lines, Hoses and Fittings",
  "Parking Brake",
  "Master Cylinder and Booster",
  "Owner’s Guide",
  "Keys and Remote Controls",
  "Universal Transmitter (garage door opener)",
  "Full Fuel Level",
];

const underBodySchema = new mongoose.Schema({
  type: {
    type: String,
    enum: allowedTypesUnderBody,
    required: true,
  },
  status: {
    type: String,
    enum: ["Passed", "Repaired", "Replaced", "N/A"],
    default: "",
    required: true,
  },
});

const inspectionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: false,
  },
  mechanic: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Mechanic",
    required: false,
  },
  car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  requests: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Requests",
    required: false,
  },
  vehicleHistory: {
    type: [vehicleHistorySchema],
    default: [],
  },
  roadTest: {
    type: [roadTestSchema],
    default: [],
  },
  vehicleExterior: {
    type: [vehicleExteriorSchema],
    default: [],
  },
  vehicleInterior: {
    type: [vehicleInteriorSchema],
    default: [],
  },
  vehicleDiagnostics: {
    type: [vehicleDiagnosticsSchema],
    default: [],
  },
  underHood: {
    type: [underHoodSchema],
    default: [],
  },
  underBody: {
    type: [underBodySchema],
    default: [],
  },
});

module.exports = mongoose.model("Inspection", inspectionSchema);
