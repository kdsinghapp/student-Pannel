const mongoose = require("mongoose");

const mechanicSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    firstName: { type: String, required: false },
    lastName: { type: String, required: false },
    contact: { type: String, required: false },
    email: { type: String, required: false, unique: true },
    address: { type: String, required: false },
    city: { type: String, required: false },
    state: { type: String, required: false },
    zipcode: { type: String, required: false },
    description: { type: String },
    companyName: { type: String, required: false },
    password: { type: String },
    emailVerificationToken: { type: String },
    adminVerification: {
      status: {
        type: String,
        enum: ["Pending", "Accepted", "Rejected"],
        default: "Pending",
      },
      verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    },
    image: { type: String },
    isEmailVerified: { type: Boolean, default: false },
    status: { type: String, default: "Pending" },
    startTime: { type: Date, required: false },
    endTime: { type: Date, required: false },
    geoAddress: { type: String, required: false },
    longitude: { type: Number, required: false },
    latitude: { type: Number, required: false },
    serviceRadius: { type: Number, default: 30 },
    isAvailable: { type: Boolean, default: true },
    ratings: { type: Number, default: 0, min: 0, max: 5 },
    reviewCount: { type: Number, default: 0 },
    vehicleTypes: [{ type: String }],
    prices: [
      {
        vehicleType: { type: String, required: false },
        price: { type: Number, required: false },
      },
    ],
    inspection: [{ type: String }],
    serviceAddress: { type: String, required: false },
    requestCount: { type: Number, default: 0 },
    isFirstLogin: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Index for geolocation
mechanicSchema.index({ longitude: 1, latitude: 1 });

// Pre-save hook to update status field based on verification
mechanicSchema.pre("save", function (next) {
  if (this.isEmailVerified && this.adminVerification.status === "Accepted") {
    this.status = "Fully Verified";
  } else if (
    this.isEmailVerified ||
    this.adminVerification.status === "Accepted"
  ) {
    this.status = "Partially Verified";
  } else {
    this.status = "Pending";
  }
  next();
});

module.exports = mongoose.model("Mechanic", mechanicSchema);
