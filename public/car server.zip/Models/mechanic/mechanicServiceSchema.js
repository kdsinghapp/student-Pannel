const mongoose = require("mongoose");

const MechanicServiceSchema = new mongoose.Schema(
  {
    mechanicId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Mechanic",
      required: true,
    },
    vehicleDetails: [
      {
        vehicleType: { type: String, required: true },
        inspectionCharge: { type: Number, required: true },
      },
    ],
    availability: {
      startTime: { type: String, required: true },
      endTime: { type: String, required: true },
    },
    serviceArea: {
      city: { type: String, required: true },
      state: { type: String, required: true },
      address: { type: String, required: true },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("MechanicService", MechanicServiceSchema);
