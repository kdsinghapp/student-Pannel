const mongoose = require("mongoose");

const requestSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    car: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
    mechanic: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Mechanic",
      required: true,
    },
    amount: { type: Number, required: true },
    status: {
      type: String,
      enum: ["Pending", "Accepted", "Rejected"],
      default: "Pending",
    },
    reportText: { type: String },
    locationType: {
      type: String,
      enum: ["Shop", "UserPlace"],
      required: true,
    },
    date: { type: Date, default: Date.now },
    paymentId: { type: String, required: true, default: "cdnjiuvchiufdvbiu" }, // Passed by default payment id for testing purpose
  },
  { timestamps: true }
);

module.exports = mongoose.model("Requests", requestSchema);
