const mongoose = require("mongoose");

const TowManSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, required: false },
    description: { type: String, required: false },
    vehicleTypes: [{ type: String, required: true }],
    drivingLicense: { type: String, required: true },
    mainServiceLocation: { type: String, required: true },
    adminVerification: {
      status: {
        type: String,
        enum: ["Pending", "Accepted", "Rejected"],
        default: "Pending",
      },
      verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    },
    image: { type: String },
    startTime: { type: Date, required: false },
    endTime: { type: Date, required: false },
    geoAddress: { type: String, required: false },
    longitude: { type: Number, required: false },
    latitude: { type: Number, required: false },
    serviceRadius: { type: Number, default: 30 },
    isAvailable: { type: Boolean, default: true },
    ratings: { type: Number, default: 0, min: 0, max: 5 },
    reviewCount: { type: Number, default: 0 },
    prices: [
      {
        vehicleType: { type: String, required: false },
        price: { type: Number, required: false },
      },
    ],
    image: { type: String },
    serviceAddress: { type: String, required: false },
    requestCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("TowMan", TowManSchema);
