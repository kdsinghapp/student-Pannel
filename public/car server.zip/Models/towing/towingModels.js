const mongoose = require("mongoose");

const TrackingSchema = new mongoose.Schema({
  time: { type: Date, required: true, default: Date.now },
  location: { type: String, required: true },
  status: {
    type: String,
    enum: ["Pending", "In Transit", "Delivered", "Cancelled"],
    default: "Pending",
  },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
  notes: { type: String },
});

const DispatchDetailsSchema = new mongoose.Schema({
  driverName: { type: String, default: "" },
  phone: { type: String, default: "" },
  drivingLicense: { type: String, default: "" },
  truck: { type: String },
  reachingTime: { type: String, default: "" },
  updateStatus: { type: String, default: "" },
  pickupStatus: { type: String, default: "" },
});

const CarDetailsSchema = new mongoose.Schema({
  type: { type: String, required: true },
  size: { type: String, required: true },
});

const TowingRequestSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  carId: { type: mongoose.Schema.Types.ObjectId, ref: "Car", required: true },
  towman: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TowMan",
    required: true,
  },
  pickupLocation: { type: String, required: false },
  destination: { type: String, required: false },
  carDetails: {
    type: CarDetailsSchema,
    required: false,
    default: null,
  },
  status: {
    type: String,
    required: false,
    enum: ["Pending", "Accepted", "Rejected"],
    default: "Pending",
  },
  pickupTime: { type: Date, required: false },
  dispatchDetails: {
    type: DispatchDetailsSchema,
    required: false,
    default: null,
  },
  trackingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Tracking",
    required: false,
  },
  tracking: {
    type: [TrackingSchema],
    required: false,
    default: [],
  },
  amount: { type: Number, required: true },
  isCompleted: { type: Boolean, required: true, default: false },
  paymentId: {
    type: String,
    required: false,
    default: "bhvcbfdjfdvbhjvbfhyvfgbvyuhb54586",
  },
  paymentStatus: {
    type: String,
    enum: ["Pending", "Completed", "Failed"],
    default: "Pending",
  },
  pickupConfirmed: { type: Boolean, required: false, default: false },
  dispatchedAt: { type: Date, required: false },
  completedAt: { type: Date, required: false },
  date: { type: Date, default: Date.now },
});

module.exports = mongoose.model("TowingRequest", TowingRequestSchema);
