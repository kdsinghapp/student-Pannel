"use client";
import { getChatList } from "@/utils/chatApi";
import Link from "next/link";
import React, { useEffect, useState } from "react";
const dummyImage =
  "https://static.vecteezy.com/system/resources/thumbnails/020/911/732/small/profile-icon-avatar-icon-user-icon-person-icon-free-png.png";

function ChatList() {
  const [data, setData] = useState([]);
  const [image, setImage] = useState(null); // To store the image
  const [textReport, setTextReport] = useState(""); // To store the text report

  const getData = async () => {
    try {
      const res = await getChatList();
      console.log("setData", res.chatRooms);
      setData(res.chatRooms);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getData();

    const intervalId = setInterval(() => {
      getData();
    }, 5000);

    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, []);

  return (
    <div className="car-area list p-0">
      <div className="container">
        <div className="row justify-content-center">
        <div className="col">
              <div className="card p-3">
                <div className="container mt-3">
                  <div className="card">
                    <ul className="list-group list-group-flush">
                     
                      {data.map((chat) => (
                        <Link key={chat._id} href={`/chat/${chat?.dealerId?._id}`}>
                         <li
                          className="list-group-item d-flex justify-content-between align-items-center"
                        >
                          <div className="d-flex align-items-center">
                            <img
                              src={ chat.dealerId.profile_image ? ImageUrl() + chat.dealerId.profile_image : dummyImage}
                              alt="Profile"
                              className="rounded-circle me-3"
                              style={{ width: "25px", height: "25px" }}
                            />
                            <div className="mx-3">
                              <h6
                                className="mb-0"
                                style={{ fontWeight: "bold" }}
                              >
                                {chat?.dealerId?.name || chat?.dealerId?.first_name + " " + chat?.dealerId?.last_name}
                              </h6>
                              <small className="text-muted">
                                {chat?.lastMessage}
                              </small>
                            </div>
                          </div>
                            <span className="badge bg-primary rounded-pill text-white">
                              {chat?.unseenMessagesCount}
                            </span>
                         </li>
                        </Link>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          {/* <div className="col-lg-12">
            <div className="row">
              <div className="col-md-6 col-lg-12">
                <div className="car-item">
                  <div className="col-md-3">
                    <div className="col-md-12 col-lg-12 mb-2">
                      <h6>
                        <a href="#" className="me-3">
                          All chats with dealears
                        </a>{" "}
                      </h6>
                    </div>
                    <div className="">
                      <img
                        alt=""
                        src="assets/img/car/01.jpg"
                        style={{
                          width: "100%",
                          borderRadius: 10,
                        }}
                      />
                    </div>
                  </div>
                  <div className="car-content sideborder col-md-6">
                    <div className="car-top">
                      <p>
                        <a href="#">
                          <i className="fa fa-camera" /> Gallery
                        </a>
                      </p>
                    </div>
                    <ul className="car-list">
                      <li>Exterior: Velvet Red Pearlcoat</li>
                      <li>Interior: Linen/Black W/Leather W/</li>
                      <li>Trans.: 6 Speed Automatic</li>
                      <li>Doors: Four Door Sedan</li>
                      <li>Engine: 6 Cylinder</li>
                      <li>Mileage: 18,251</li>
                    </ul>
                  </div>
                  <div className="btnns col-md-3">
                    <div>
                      <p className="car-price f-14">
                        <span className="text-primary">Price:</span> $45,620
                      </p>
                      <p className="car-price f-14">
                        <span className="text-warning">Your price: </span>
                        $32,500
                      </p>
                    </div>
                    <div className="mb-2 mt-2">
                      <a className="btn btn-danger w-100" href="#">
                        Cancel buy
                      </a>
                    </div>
                    <div>
                      <a className="btn btn-primary w-100" href="#">
                        Buy At Full Price
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-12">
                <div className="car-item">
                  <div className="col-md-3">
                    <div className="col-md-12 col-lg-12 mb-2">
                      <h6>
                        <a href="#" className="me-3">
                          New 2018 Chrysler 400 C{" "}
                        </a>{" "}
                      </h6>
                    </div>
                    <div className="">
                      <img
                        alt=""
                        src="assets/img/car/02.jpg"
                        style={{
                          width: "100%",
                          borderRadius: 10,
                        }}
                      />
                    </div>
                  </div>
                  <div className="car-content sideborder col-md-6">
                    <div className="car-top">
                      <p>
                        <a href="#">
                          <i className="fa fa-camera" /> Gallery
                        </a>
                      </p>
                    </div>
                    <ul className="car-list">
                      <li>Exterior: Velvet Red Pearlcoat</li>
                      <li>Interior: Linen/Black W/Leather W/</li>
                      <li>Trans.: 6 Speed Automatic</li>
                      <li>Doors: Four Door Sedan</li>
                      <li>Engine: 6 Cylinder</li>
                      <li>Mileage: 18,251</li>
                    </ul>
                  </div>
                  <div className="btnns col-md-3">
                    <div>
                      <p className="car-price f-14">
                        Your buying was <br />
                        <span className="text-danger">
                          Canceled Automatically <span />
                        </span>
                      </p>
                      <p className="car-price f-14">Car was sold or removed</p>
                    </div>
                    <div className="mb-2 mt-2">
                      <p className="car-price f-14">
                        Price: <br />
                        <span className="text-primary">
                          $12150<span>.</span>
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-12">
                <div className="car-item">
                  <div className="col-md-3">
                    <div className="col-md-12 col-lg-12 mb-2">
                      <h6>
                        <a href="#" className="me-3">
                          New 2018 Chrysler 400 C{" "}
                        </a>{" "}
                      </h6>
                    </div>
                    <div className="">
                      <img
                        alt=""
                        src="assets/img/car/03.jpg"
                        style={{
                          width: "100%",
                          borderRadius: 10,
                        }}
                      />
                    </div>
                  </div>
                  <div className="car-content sideborder col-md-6">
                    <div className="car-top">
                      <p>
                        <a href="#">
                          <i className="fa fa-camera" /> Gallery
                        </a>
                      </p>
                    </div>
                    <ul className="car-list">
                      <li>Exterior: Velvet Red Pearlcoat</li>
                      <li>Interior: Linen/Black W/Leather W/</li>
                      <li>Trans.: 6 Speed Automatic</li>
                      <li>Doors: Four Door Sedan</li>
                      <li>Engine: 6 Cylinder</li>
                      <li>Mileage: 18,251</li>
                    </ul>
                  </div>
                  <div className="btnns col-md-3">
                    <div>
                      <p className="car-price f-14">
                        Your buying was <br />
                        <span className="text-danger">
                          not accepted <span />
                        </span>
                      </p>
                      <p className="car-price f-14">Car was sold or removed</p>
                    </div>
                    <div className="mb-2 mt-2">
                      <p className="car-price f-14">
                        Current buy price:{" "}
                        <span className="text-primary">
                          $12100<span>.</span>
                        </span>
                      </p>
                    </div>
                    <div>
                      <a className="btn btn-primary w-100" href="#">
                        Adjust buy price{" "}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-12">
                <div className="car-item">
                  <div className="col-md-3">
                    <div className="col-md-12 col-lg-12 mb-2">
                      <h6>
                        <a href="#" className="me-3">
                          New 2018 Chrysler 400 C{" "}
                        </a>{" "}
                      </h6>
                    </div>
                    <div className="">
                      <img
                        alt=""
                        src="assets/img/car/03.jpg"
                        style={{
                          width: "100%",
                          borderRadius: 10,
                        }}
                      />
                    </div>
                  </div>
                  <div className="car-content sideborder col-md-6">
                    <div className="car-top">
                      <p>
                        <a href="#">
                          <i className="fa fa-camera" /> Gallery
                        </a>
                      </p>
                    </div>
                    <ul className="car-list">
                      <li>Exterior: Velvet Red Pearlcoat</li>
                      <li>Interior: Linen/Black W/Leather W/</li>
                      <li>Trans.: 6 Speed Automatic</li>
                      <li>Doors: Four Door Sedan</li>
                      <li>Engine: 6 Cylinder</li>
                      <li>Mileage: 18,251</li>
                    </ul>
                  </div>
                  <div className="btnns col-md-3">
                    <div>
                      <p className="car-price f-14">
                        Your buying was <br />
                        <span style={{ color: "green" }}>
                          {" "}
                          accepted <span />
                        </span>
                      </p>
                      <p className="car-price f-14">Car was sold or removed</p>
                    </div>
                    <div className="mb-2 mt-2">
                      <p className="car-price f-14">
                        Current buying price:{" "}
                        <span className="text-primary">
                          $12100<span>.</span>
                        </span>
                      </p>
                    </div>
                    <div>
                      <a className="btn btn-primary w-100" href="#">
                        {" "}
                        Buy{" "}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="pagination-area">
              <div aria-label="Page navigation example">
                <ul className="pagination">
                  <li className="page-item">
                    <a aria-label="Previous" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-left" />
                      </span>
                    </a>
                  </li>
                  <li className="page-item active">
                    <a className="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li className="page-item">
                    <a aria-label="Next" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-right" />
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
}

export default ChatList;
