"use client";
import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useRouter } from "next/navigation";
import { login } from "@/store/features/userSlice";
import { useDispatch } from "react-redux";

const SignIn = () => {

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const user = localStorage.getItem("user");
      setIsLoggedIn(!!user);
    }
  }, []);

 
  
  const dispatch = useDispatch();
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const { email, password } = formData;

    if (!email || !password) {
      toast.error("All fields are required");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;    

    dispatch(login(formData))
      .unwrap()
      .then((response) => {
        toast.success(response.message);
        // router.push("/");
        router.push("/")
        // window.location.reload()
      })
      .catch((error) => {
        toast.error(error.message || error);
      });
  };

  useEffect(() => {
    isLoggedIn ? router.push("/") :''
  }, []);

  return (
    <form onSubmit={handleSubmit} action="myaccount" method="post">
      <div className="form-group">
        <label>Email Address</label>{" "}
        <input
          className="form-control"
          placeholder="Your Email"
          type="email"
          name="email"
          value={formData?.email}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label>Password</label>{" "}
        <input
          className="form-control"
          placeholder="Your Password"
          type="password"
          name="password"
          value={formData?.password}
          onChange={handleChange}
        />
      </div>
      <div className="d-flex justify-content-between mb-4">
        <div className="form-check">
          <input
            className="form-check-input"
            id="remember"
            type="checkbox"
            defaultValue=""
          />{" "}
          <label className="form-check-label" htmlFor="remember">
            Remember Me
          </label>
        </div>
        <a className="forgot-pass" href="forgot-password">
          Forgot Password?
        </a>
      </div>
      <div className="d-flex align-items-center">
        <button className="theme-btn" type="submit">
          <i className="far fa-sign-in" /> Sign In
        </button>
      </div>
      <ToastContainer />
    </form>
  );
};

export default SignIn;