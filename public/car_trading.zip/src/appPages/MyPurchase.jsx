"use client";
import OfferPageCount from "@/components/common/OfferPageCount";
import PurchasePageCount from "@/components/common/PurshasePageCount";
import { cancelBid, getMyPurchase, ImageUrl } from "@/utils/carApi";
import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const MyPurchase = () => {

  const [list, setList] = useState();
  const getData = async () => {
    try {
      const res = await getMyPurchase();
      setList(res?.data);
      console.log(res?.data);      
    } catch (error) {
      console.log(error);      
      
    }
    
  };
  useEffect(() => {
    getData();
  }, []);


  return (
    <div className="col-lg-12">
      <div className="row">
        {list?.map((item) => (
          <PurchasePageCount key={item} item={item} getData={getData} />
        ))}

        {/* <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a className="me-3" href="#">
                    Mercedes Benz Car
                  </a>
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/05.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  <span className="text-primary">Price:</span> $45,620
                </p>
                <p className="car-price f-14">
                  <span className="text-warning">Your Offer:</span> $32,500
                </p>
              </div>
              <div className="mb-2 mt-2">
                <a className="btn btn-danger w-100" href="#">
                  Cancel Offer
                </a>
              </div>
              <div>
                <a className="btn btn-primary w-100" href="#">
                  Buy At Full Price
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a className="me-3" href="#">
                    New 2018 Chrysler 400 C
                  </a>
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/06.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  Your Offer was
                  <br />
                  <span className="text-danger">Canceled Automatically </span>
                </p>
                <p className="car-price f-14">
                  <span>Car was sold or removed</span>
                </p>
              </div>
              <div className="mb-2 mt-2">
                <span className="text-danger" />
                <p className="car-price f-14">
                  Price:
                  <span className="text-primary">$12150.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <span className="text-danger" />
          <div className="car-item">
            <span className="text-danger" />
            <div className="col-md-3">
              <span className="text-danger" />
              <div className="col-md-12 col-lg-12 mb-2">
                <span className="text-danger" />
                <h6>
                  <span className="text-danger">
                    <a className="me-3" href="#">
                      Mercedes Benz Suv 1000cc
                    </a>
                  </span>
                </h6>
                <span className="text-danger" />
              </div>
              <div className="">
                <span className="text-danger">
                  <img
                    alt=""
                    src="assets/img/car/07.jpg"
                    style={{
                      width: "100%",
                      borderRadius: 10,
                    }}
                  />
                </span>
              </div>
              <span className="text-danger" />
            </div>
            <div className="car-content sideborder col-md-6">
              <span className="text-danger" />
              <div className="car-top">
                <span className="text-danger" />
                <p>
                  <span className="text-danger">
                    <a href="#">
                      <i className="fa fa-camera" /> Gallery
                    </a>
                  </span>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  <span>
                    Your Offer was
                    <br />
                    <span className="text-danger">
                      not accepted <span />
                    </span>
                  </span>
                </p>
              </div>
              <div className="mb-2 mt-2">
                <p className="car-price f-14">
                  <span>
                    Current Offer:{" "}
                    <span className="text-primary">
                      $12100<span>.</span>
                    </span>
                  </span>
                </p>
              </div>
              <div>
                <span className="text-danger">
                  <a className="btn btn-primary w-100" href="#">
                    Adjust Offer
                  </a>
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <span className="text-danger" />
          <div className="car-item">
            <span className="text-danger" />
            <div className="col-md-3">
              <span className="text-danger" />
              <div className="col-md-12 col-lg-12 mb-2">
                <span className="text-danger" />
                <h6>
                  <span className="text-danger">
                    <a className="me-3" href="#">
                      BMW Sports Car
                    </a>
                  </span>
                </h6>
                <span className="text-danger" />
              </div>
              <div className="">
                <span className="text-danger">
                  <img
                    alt=""
                    src="assets/img/car/08.jpg"
                    style={{
                      width: "100%",
                      borderRadius: 10,
                    }}
                  />
                </span>
              </div>
              <span className="text-danger" />
            </div>
            <div className="car-content sideborder col-md-6">
              <span className="text-danger" />
              <div className="car-top">
                <span className="text-danger" />
                <p>
                  <span className="text-danger">
                    <a href="#">
                      <i className="fa fa-camera" /> Gallery
                    </a>
                  </span>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <span className="text-danger" />
              <div>
                <span className="text-danger" />
                <p className="car-price f-14">
                  <span>
                    Your Offer was
                    <span style={{ color: "green" }}>accepted </span>
                  </span>
                </p>
              </div>
              <div className="mb-2 mt-2">
                <span className="text-danger" />
                <p className="car-price f-14">
                  <span>
                    Current Offer: <span className="text-primary">$12100</span>
                  </span>
                </p>
              </div>
              <div>
                <span className="text-danger">
                  <a className="btn btn-primary w-100" href="#">
                    Buy
                  </a>
                </span>
              </div>
              <span className="text-danger" />
            </div>
          </div>
        </div> */}
      </div>
      <div className="pagination-area">
        <span className="text-danger" />
        <div aria-label="Page navigation example">
          <span className="text-danger" />
          <ul className="pagination">
            <li className="page-item">
              <span className="text-danger">
                <a aria-label="Previous" className="page-link" href="#">
                  <span aria-hidden="true">
                    <i className="far fa-arrow-left" />
                  </span>
                </a>
              </span>
            </li>
            <li style={{ listStyle: "none" }} />
            <li className="page-item active">
              <a className="page-link" href="#">
                1
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                2
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                3
              </a>
            </li>
            <li className="page-item">
              <a aria-label="Next" className="page-link" href="#">
                <span aria-hidden="true">
                  <i className="far fa-arrow-right" />
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <ToastContainer />
    </div>
  );
};

export default MyPurchase;
