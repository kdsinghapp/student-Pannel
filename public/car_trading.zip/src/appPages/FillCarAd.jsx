"use client";

import Link from "next/link";
import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { useRouter } from "next/navigation";
import { createaddlatestCar } from "@/utils/carApi";

const FillCarAd = () => {
  const router = useRouter();
  const [formData, setFormData] = useState({
    carDetails: {
      make: "",
      model: "",
      year: "",
      mileage: "",
      condition: "",
      location: "",
    },
    predictedValue: {
      amount: "",
      currency: "USD",
    },
    sellingOption: "Private Party",
    advertisement: {
      platform: "Testing",
    },
    mainBannerImage: "",
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        const savedData = localStorage.getItem("carAdvertisementData");
        const parsedData = savedData ? JSON.parse(savedData) : null;

        if (!parsedData) {
          console.warn(
            "No valid car advertisement data found in localStorage."
          );
          return;
        }

        console.log("Stored Car Advertisement Data:", parsedData);

        let predictedAmount = "";
        const predictionResult = localStorage.getItem("predictionResult");

        if (predictionResult) {
          predictedAmount = predictionResult.replace(/[^\d.]/g, "") || "0";
        }

        setFormData({
          carDetails: {
            make: parsedData.make || "NA",
            model: parsedData.model || "NA",
            year: parsedData.years || "NA",
            mileage: parsedData.mileage || "NA",
            condition: parsedData.condition || "NA",
            location: parsedData.location || "NA",
          },
          predictedValue: {
            amount: predictedAmount || "0",
            currency: "USD",
          },
          sellingOption: {
            type: "Private Party",
          },
          advertisement: {
            platform: "",
          },
        });
      } catch (error) {
        console.error("Error accessing or parsing localStorage:", error);
        localStorage.removeItem("carAdvertisementData");
      }
    }
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const nameParts = name.split(".");

    setFormData((prevData) => {
      if (nameParts.length === 2) {
        return {
          ...prevData,
          [nameParts[0]]: {
            ...prevData[nameParts[0]],
            [nameParts[1]]: value,
          },
        };
      }

      return {
        ...prevData,
        [name]: value,
      };
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData((prevData) => ({
        ...prevData,
        mainBannerImage: file,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Confirm submission
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to submit this car advertisement?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, submit it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true,
      customClass: {
        confirmButton: "btn btn-success mx-2",
        cancelButton: "btn btn-danger mx-2",
      },
    });

    if (result.isConfirmed) {
      try {
        const dataToSubmit = new FormData();

        dataToSubmit.append("make", formData.carDetails.make || "NA");
        dataToSubmit.append("model", formData.carDetails.model || "NA");
        dataToSubmit.append("year", formData.carDetails.year || "NA");
        dataToSubmit.append("mileage", formData.carDetails.mileage || "NA");
        dataToSubmit.append("condition", formData.carDetails.condition || "NA");
        dataToSubmit.append("location", formData.carDetails.location || "NA");
        dataToSubmit.append(
          "predictedValue.amount",
          formData.predictedValue.amount
        );
        dataToSubmit.append(
          "predictedValue.currency",
          formData.predictedValue.currency
        );
        dataToSubmit.append("sellingOption", formData.sellingOption);
        dataToSubmit.append(
          "advertisement.platform",
          formData.advertisement.platform
        );

        if (formData.mainBannerImage) {
          dataToSubmit.append("mainBannerImage", formData.mainBannerImage);
        }

        const res = await createaddlatestCar(dataToSubmit);

        console.log("Res", res);

        await Swal.fire(
          "Submitted!",
          "Your car advertisement has been saved.",
          "success"
        );

        router.push("/");
      } catch (error) {
        console.error("Error submitting car advertisement:", error);
        Swal.fire("Error", "Something went wrong. Try again!", "error");
      }
    } else {
      Swal.fire(
        "Cancelled",
        "Your car advertisement was not submitted",
        "error"
      );
    }
  };

  return (
    <>
      <link rel="stylesheet" href="/flexslider/flexslider.css" />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Car Details Advertisement</h2>
            <ul className="breadcrumb-menu">
              <li>
                <Link href="/">Home</Link>
              </li>
              <li className="active">Car Details Advertisement</li>
            </ul>
          </div>
        </div>
        <div className="car-item-single bg">
          <div className="container">
            <div className="car-single-wrapper">
              <div className="row">
                <div className="col-lg-12">
                  <div className="car-single-details">
                    <form onSubmit={handleSubmit}>
                      <div className="car-single-widget">
                        <h4 className="mb-1">Car Details</h4>
                        <div className="row">
                          <div className="col-md-12 mt-3 mb-4">
                            <div className="form-group">
                              <label className="form-label fw-bold mb-2">
                                Car Image
                              </label>
                              <div className="file-upload-wrapper">
                                <input
                                  type="file"
                                  className="form-control file-upload-input"
                                  name="carDetails.image"
                                  onChange={handleImageChange}
                                  accept="image/*"
                                  id="carImageUpload"
                                />
                                <label
                                  htmlFor="carImageUpload"
                                  className="file-upload-label"
                                >
                                  <div className="file-upload-design">
                                    <i className="fas fa-cloud-upload-alt me-2"></i>
                                    <span>Choose Image</span>
                                    <p className="small text-muted mt-2 mb-0">
                                      PNG, JPG, JPEG (Max. 5MB)
                                    </p>
                                  </div>
                                </label>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Make</label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter car make (e.g., Toyota)"
                                name="carDetails.make"
                                value={formData.carDetails.make || "NA"}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Model</label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter car model (e.g., Camry)"
                                name="carDetails.model"
                                value={formData.carDetails.model}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Year</label>
                              <input
                                type="number"
                                className="form-control"
                                placeholder="Enter manufacturing year"
                                name="carDetails.year"
                                value={formData.carDetails.year}
                                onChange={handleInputChange}
                                max={new Date().getFullYear() + 1}
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Mileage</label>
                              <div className="input-group">
                                <input
                                  type="number"
                                  className="form-control"
                                  placeholder="Enter mileage"
                                  name="carDetails.mileage"
                                  value={formData.carDetails.mileage}
                                  onChange={handleInputChange}
                                  min="0"
                                  required
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Condition</label>
                              <input
                                type="text"
                                className="form-control"
                                name="carDetails.condition"
                                value={formData.carDetails.condition}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Location</label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter location (city, state)"
                                name="carDetails.location"
                                value={formData.carDetails.location}
                                onChange={handleInputChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Selling Price</label>
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <span className="input-group-text">$</span>
                                </div>
                                <input
                                  type="number"
                                  className="form-control"
                                  placeholder="Enter selling price"
                                  name="carDetails.sellingPrice"
                                  value={formData.predictedValue.amount}
                                  onChange={handleInputChange}
                                  min="0"
                                  step="0.01"
                                  required
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Selling Option</label>
                              <select
                                className="form-control"
                                name="sellingOption.type"
                                value={formData.sellingOption.sellingOption}
                                onChange={handleInputChange}
                                required
                              >
                                <option value="Private Party">
                                  Private Party
                                </option>
                                <option value="Dealer">Dealer</option>
                                <option value="International">
                                  International
                                </option>
                              </select>
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Description</label>
                              <textarea
                                className="form-control"
                                placeholder="Enter a brief description of the car"
                                name="carDetails.description"
                                value={formData.carDetails.description}
                                onChange={handleInputChange}
                                rows="3"
                                required
                              />
                            </div>
                          </div>
                          <div className="col-md-6 mt-2">
                            <div className="form-group">
                              <label>Features</label>
                              <textarea
                                className="form-control"
                                placeholder="Enter any special features"
                                name="carDetails.features"
                                value={formData.carDetails.features}
                                onChange={handleInputChange}
                                rows="3"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="car-single-widget">
                        <div className="form-group">
                          <button type="submit" className="btn btn-primary">
                            Submit Car Details
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default FillCarAd;
