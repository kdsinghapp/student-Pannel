"use client";
import { favorites, getFavorites } from "@/utils/carApi";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { toast , ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Favourites = () => {
    const [favouriteList , serfavouriteList] = useState([])
  const getFavouritesList = async () => {
    try {
      const res = await getFavorites();
      serfavouriteList(res?.data);
    } catch (erro) {
      console.log(erro);
    }
  };

  useEffect(() => {
    getFavouritesList();
  }, []);

  const handleSave = async (carId, action) => {
    const data = {
      carId: carId,
      action: action // 'add' or 'remove'
    };
  
    try {
        console.log(carId , action);
        
        const res = await favorites(data);
        console.log(res);
      
      if (res.status) {
        toast.success(res.message);
        getFavouritesList();
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error("An error occurred while processing your request.");
    }
  };

  return (
    <div className="col-lg-12">
      <div className="row">
       {
        favouriteList?.map((item) => (
         <div key={item?._id} className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    {item?.carId?.car_name}
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src={`http://193.203.161.2:8000/images/${item?.carId?.image}`}
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              {/* <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div> */}
              <ul className="car-list">
                <li>Exterior: {item?.carId?.car_body_color}</li>
                <li>Interior: {item?.carId?.car_interior_color}</li>
                <li>Trans.: {item?.carId?.car_transmission}</li>
                <li>Doors: {item?.carId?.car_door}</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  <span className="text-primary">Price:</span> ${item?.carId?.car_price}
                </p>
              </div>
              <div className="mb-2 mt-2">
                <button onClick={() => handleSave(item?.carId?._id , "remove")} className="btn btn-danger w-100">
                  Remove favourite
                </button>
              </div>
              <div className="mb-2 mt-2">
                <Link className="btn btn-primary w-100" href={`/detail/${item?.carId?._id}`} >
                  View car
                </Link>
              </div>
            </div>
          </div>
        </div>
        ))
       }
        
        {/* <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    Mercedes Benz Car
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/01.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  <span className="text-primary">Price:</span> $45,620
                </p>
              </div>
              <div className="mb-2 mt-2">
                <a className="btn btn-danger w-100" href="#">
                  Remove favourite
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    Mercedes Benz Car
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/01.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  <span className="text-primary">Price:</span> $45,620
                </p>
              </div>
              <div className="mb-2 mt-2">
                <a className="btn btn-danger w-100" href="#">
                  Remove favourite
                </a>
              </div>
            </div>
          </div>
        </div> */}
      </div>
      <div className="pagination-area">
        <div aria-label="Page navigation example">
          <ul className="pagination">
            <li className="page-item">
              <a aria-label="Previous" className="page-link" href="#">
                <span aria-hidden="true">
                  <i className="far fa-arrow-left" />
                </span>
              </a>
            </li>
            <li className="page-item active">
              <a className="page-link" href="#">
                1
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                2
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                3
              </a>
            </li>
            <li className="page-item">
              <a aria-label="Next" className="page-link" href="#">
                <span aria-hidden="true">
                  <i className="far fa-arrow-right" />
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <ToastContainer />    
    </div>
  );
};

export default Favourites;
