"use client";
import { getMechanic } from "@/store/features/userSlice";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const MechanicRegister = () => {
  const { user } = useSelector((state) => state.userData);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    contact: "",
    email: "",
    companyName: "",
    address: "",
    city: "",
    state: "",
    zipcode: "",
    description: "",
    agree: false,
    userId: user.user?._id || "",
  });
  const [errors, setErrors] = useState({});
  const dispatch = useDispatch();
  const [isRegistered, setIsRegistered] = useState(false);
  const [loading, setLoading] = useState(true); // Track if registration check is in progress

  const {
    firstName,
    lastName,
    contact,
    email,
    companyName,
    address,
    city,
    state,
    zipcode,
    description,
    agree,
    userId,
  } = formData;

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const validate = () => {
    const newErrors = {};
    if (!firstName.trim()) newErrors.firstName = "First Name is required";
    if (!lastName.trim()) newErrors.lastName = "Last Name is required";
    if (!contact.trim() || !/^\d{10}$/.test(contact))
      newErrors.contact = "Enter a valid 10-digit phone number";
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email))
      newErrors.email = "Enter a valid email address";
    if (!companyName.trim()) newErrors.companyName = "Company Name is required";
    if (!address.trim()) newErrors.address = "Address is required";
    if (!city.trim()) newErrors.city = "City is required";
    if (!state.trim()) newErrors.state = "State is required";
    if (!zipcode.trim() || !/^\d{5,6}$/.test(zipcode))
      newErrors.zipcode = "Enter a valid ZIP code";
    if (!agree) newErrors.agree = "You must accept the Privacy Agreement";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    formData.userId = user.user?._id;
    if (validate()) {
      dispatch(getMechanic(formData))
        .then(() => {
          setFormData({
            firstName: "",
            lastName: "",
            contact: "",
            email: "",
            companyName: "",
            address: "",
            city: "",
            state: "",
            zipcode: "",
            description: "",
            agree: false,
          });
          toast.success("Successfully applied for Mechanic!");
          setErrors({});
        })
        .catch((error) => {
          console.error("Registration failed:", error);
          toast.error("Already applied for Mechanic!");
        });
    }
  };

  useEffect(() => {
    // Check if user email is available
    if (user?.user?.email) {
      console.log("User email found:", user.user.email); // Log the user's email

      // Set loading to true before starting the API call
      setLoading(true);

      // Wait for 10 seconds before making the API request
      const timer = setTimeout(() => {
        // Fetch the email from the API
        axios
          .get(`http://localhost:8000/mechanic/email/${user.user.email}`)
          .then((response) => {
            console.log("API response:", response); // Log the API response
            // Check if the email from the API matches the user's email
            if (response.data.data.email === user?.user?.email) {
              console.log("Mechanic found, user is already registered."); // Log if mechanic is found
              setIsRegistered(true); // If emails match, set isRegistered to true
            } else {
              console.log("Mechanic not found, user can register."); // Log if mechanic is not found
              setIsRegistered(false); // If no match, allow registration
            }
            setLoading(false); // Set loading to false once check is complete
          })
          .catch((error) => {
            console.error("Error checking mechanic registration:", error); // Log any errors
            setLoading(false); // Set loading to false even in case of error
          });
      }, 1000); // 10 seconds delay (10000 milliseconds)

      // Clear the timeout if the component is unmounted or the email changes before 10 seconds
      return () => clearTimeout(timer);
    } else {
      console.log("User email not found.");
      setLoading(false); // Set loading to false if no email is found
    }
  }, [user?.user?.email]); // Run this ef

  useEffect(() => {
    if (user?.user) {
      setFormData({
        firstName: user.user?.first_name,
        lastName: user.user?.last_name,
        email: user.user?.email,
        userId: user.user?._id,
        contact: user.user?.mobile_number,
        address: user.user?.address,
      });
    }
  }, [user]);

  return (
    <>
      {loading ? (
        <div
          style={{
            height: "50vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="loader"></div>
        </div>
      ) : isRegistered ? (
        <div className="alert alert-info">
          <h4>You have already applied as a mechanic!</h4>
        </div>
      ) : (
        <>
          <div className="login-header">
            <h3>Mechanic Registration</h3>
            <p>
              Interested in becoming a mechanic inspector or wants to learn
              more?
              <br />
              Please call 1-800-555-5555 or complete the form below.
            </p>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="row">
              <div className="form-group col-lg-6">
                <label>First Name</label>
                <input
                  name="firstName"
                  className={`form-control ${
                    errors.firstName ? "is-invalid" : ""
                  }`}
                  type="text"
                  value={firstName}
                  onChange={handleInputChange}
                />
                {errors.firstName && (
                  <p className="error-text">{errors.firstName}</p>
                )}
              </div>
              <div className="form-group col-lg-6">
                <label>Last Name</label>
                <input
                  name="lastName"
                  className={`form-control ${
                    errors.lastName ? "is-invalid" : ""
                  }`}
                  type="text"
                  value={lastName}
                  onChange={handleInputChange}
                />
                {errors.lastName && (
                  <p className="error-text">{errors.lastName}</p>
                )}
              </div>
              <div className="form-group col-lg-6">
                <label>Phone Number</label>
                <input
                  name="contact"
                  className={`form-control ${
                    errors.contact ? "is-invalid" : ""
                  }`}
                  type="text"
                  value={contact}
                  onChange={handleInputChange}
                />
                {errors.contact && (
                  <p className="error-text">{errors.contact}</p>
                )}
              </div>
              <div className="form-group col-lg-6">
                <label>Email Address</label>
                <input
                  name="email"
                  className={`form-control ${errors.email ? "is-invalid" : ""}`}
                  type="email"
                  disabled
                  value={email}
                  onChange={handleInputChange}
                />
                {errors.email && <p className="error-text">{errors.email}</p>}
              </div>
              <div className="form-group col-lg-12">
                <label>Company Name</label>
                <input
                  name="companyName"
                  className={`form-control ${
                    errors.companyName ? "is-invalid" : ""
                  }`}
                  type="text"
                  value={companyName}
                  onChange={handleInputChange}
                />
                {errors.companyName && (
                  <p className="error-text">{errors.companyName}</p>
                )}
              </div>
              <div className="form-group col-lg-6">
                <label>Address</label>
                <input
                  className={`form-control ${
                    errors.address ? "is-invalid" : ""
                  }`}
                  name="address"
                  type="text"
                  value={address}
                  onChange={handleInputChange}
                />
                {errors.address && (
                  <p className="error-text">{errors.address}</p>
                )}
              </div>
              <div className="form-group col-lg-6">
                <label>City</label>
                <input
                  className={`form-control ${errors.city ? "is-invalid" : ""}`}
                  name="city"
                  type="text"
                  value={city}
                  onChange={handleInputChange}
                />
                {errors.city && <p className="error-text">{errors.city}</p>}
              </div>
              <div className="form-group col-lg-6">
                <label>State</label>
                <input
                  className={`form-control ${errors.state ? "is-invalid" : ""}`}
                  name="state"
                  type="text"
                  value={state}
                  onChange={handleInputChange}
                />
                {errors.state && <p className="error-text">{errors.state}</p>}
              </div>
              <div className="form-group col-lg-6">
                <label>Zipcode</label>
                <input
                  className={`form-control ${
                    errors.zipcode ? "is-invalid" : ""
                  }`}
                  name="zipcode"
                  type="text"
                  value={zipcode}
                  onChange={handleInputChange}
                />
                {errors.zipcode && (
                  <p className="error-text">{errors.zipcode}</p>
                )}
              </div>
              <div className="form-group col-lg-12">
                <label>Anything else you want to tell us</label>
                <textarea
                  className={`form-control ${
                    errors.description ? "is-invalid" : ""
                  }`}
                  name="description"
                  value={description}
                  onChange={handleInputChange}
                ></textarea>
              </div>
              <div className="form-check col-lg-12">
                <input
                  type="checkbox"
                  name="agree"
                  checked={agree}
                  onChange={handleInputChange}
                />
                <label> I agree to the Privacy Agreement</label>
                {errors.agree && <p className="error-text">{errors.agree}</p>}
              </div>
              <div className="col-lg-12">
                <button className="btn btn-primary" type="submit">
                  Submit
                </button>
              </div>
            </div>
          </form>
        </>
      )}
      <ToastContainer />
    </>
  );
};

export default MechanicRegister;
