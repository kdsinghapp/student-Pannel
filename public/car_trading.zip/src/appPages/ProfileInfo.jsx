"use client";

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { findUser, updateUserApi } from "@/utils/authApi";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Info = () => {
  const dispatch = useDispatch();
  const userData = useSelector((store) => store.userData);
  const [user, setUser] = useState({
    first_name: "",
    last_name: "",
    email: "",
    mobile_number: "",
    address: "",
  });

  useEffect(() => {
    console.log("userData", userData);
    if (userData?.user?.user) {
      setUser(userData.user.user);
    }
  }, [userData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  //   update user
  const updateUser = async () => {
    try {
      const formData = new FormData();

      formData.append("email", user.email);
      formData.append("first_name", user.first_name);
      formData.append("last_name", user.last_name);
      formData.append("mobile_number", user.mobile_number);
      formData.append("country_code", user.country_code || "+91");
      formData.append("address", user.address);

      // Append the profile image if it exists
      // if (profileImageFile) {
      //     formData.append('profile_image', profileImageFile);
      // }

      // Make the API call
      const response = await updateUserApi(formData);
      if (response.status === true) {
        toast.success(response.message);
      } else {
        toast.error(response.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  const fetchUser = async (user) => {
    console.log("user", user._id);
    try {
      const response = await findUser(user)
      console.log("Response here",response.data);
      const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
      const firstName = response.data.name.split(" ").map(capitalize)
      setUser({
        first_name: firstName[0],
        last_name:firstName[1]
      })
    } catch (error) {
      console.log("No user found",error);
    }
  }

  useEffect(() => {
    fetchUser(user)
  }, [user])

  return (
    <>
      <div className="user-profile-card">
        <h4 className="user-profile-card-title">Profile Info</h4>
        <div className="user-profile-form">
          <form action="#">
            <div className="row">
              <div className="col-md-6">
                <div className="form-group">
                  <label>First Name</label>
                  <input
                    className="form-control"
                    placeholder="First Name"
                    type="text"
                    name="first_name"
                    value={user.first_name}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label>Last Name</label>
                  <input
                    className="form-control"
                    placeholder="Last Name"
                    type="text"
                    name="last_name"
                    value={user.last_name}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label>Email</label>
                  <input
                    className="form-control"
                    placeholder="Email"
                    type="text"
                    name="email"
                    disabled
                    value={user.email}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label>Phone</label>
                  <input
                    className="form-control"
                    placeholder="+91"
                    type="text"
                    name="mobile_number"
                    value={user.mobile_number}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-group">
                  <label>Address</label>
                  <input
                    className="form-control"
                    placeholder="Address"
                    type="text"
                    name="address"
                    value={user.address}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
            <button
              className="theme-btn my-3"
              type="button"
              onClick={updateUser}
            >
              <span className="far fa-user" /> Save Changes
            </button>
            <ToastContainer />
          </form>
        </div>
      </div>
    </>
  );
};

export default Info;
