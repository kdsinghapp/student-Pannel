"use client";

import React from 'react';
import { useSelector } from 'react-redux';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Ensure Bootstrap CSS is imported

const Compare = () => {
  const compareCar1 = useSelector((state) => state.compare.car1);
  const compareCar2 = useSelector((state) => state.compare.car2);
  const compareCar3 = useSelector((state) => state.compare.car3);

  // Filter only the cars that exist
  const carsToCompare = [compareCar1, compareCar2, compareCar3].filter((car) => car);

  return (
    <div className="container mt-4">
      <div className="row">
        {carsToCompare.length > 0 ? (
          carsToCompare.map((car, index) => (
            <div className="col-12 col-sm-6 col-md-4 mb-4" key={index}>
              <div className="card">
                <img
                  src={`http://193.203.161.2:8000/images/${car.image}`}
                  alt={car.car_name}
                  className="card-img-top"
                  style={{ height: '150px', objectFit: 'cover' }}
                />
                <div className="card-body">
                  <h5 className="card-title">{car.car_name}</h5>
                  <ul className="list-group">
                    <li className="list-group-item">Car Price: ${car.car_price}</li>
                    <li className="list-group-item">Car Class: {car.car_class}</li>
                    <li className="list-group-item">Model Year: {car.car_model_year}</li>
                    <li className="list-group-item">Regional Specification: {car.car_reginal_specification}</li>
                    <li className="list-group-item">Kilometers: {car.car_kilometers} km</li>
                    <li className="list-group-item">Engine Capacity: {car.car_engine_capacity}</li>
                    <li className="list-group-item">Cylinders: {car.car_cylinder}</li>
                    <li className="list-group-item">Transmission: {car.car_transmission}</li>
                    <li className="list-group-item">Body Color: {car.car_body_color}</li>
                    <li className="list-group-item">Fuel Type: {car.car_fuel_type}</li>
                    <li className="list-group-item">Doors: {car.car_door}</li>

                    <li className="list-group-item">Car Status: {car.car_status}</li>
                    <li className="list-group-item">Rim Sizes: {car.car_rim_sizes}</li>
                    <li className="list-group-item">Car Type: {car.car_type}</li>
                    <li className="list-group-item">Car Condition: {car.car_condition}</li>
                    <li className="list-group-item">Under Warranty: {car.car_under_warranty}</li>
                    <li className="list-group-item">Extra Features: {car.car_extra_features}</li>
                    <li className="list-group-item">Rent Price: ${car.car_rent_price}</li>
                    <li className="list-group-item">Interior Color: {car.car_interior_color}</li>
                    <li className="list-group-item">Additional Details: {car.car_additional_details}</li>
                    <li className="list-group-item">Seats: {car.car_seat}</li>
                    <li className="list-group-item">Drive Type: {car.car_drive_type}</li>
                    <li className="list-group-item">Service History: {car.car_service_history}</li>
                    <li className="list-group-item">Regional Specs: {car.car_regional_specs}</li>
                    <li className="list-group-item">Address: {car.car_address}</li>
                    <li className="list-group-item">Ground Clearance: {car.ground_clearance}</li>
                    <li className="list-group-item">Tank Capacity: {car.tank_capacity}</li>
                    <li className="list-group-item">Torque: {car.torque}</li>
                    <li className="list-group-item">Boot Space: {car.boot_space}</li>
                    <li className="list-group-item">Alloy Wheels: {car.alloy_wheels}</li>


                    <li className="list-group-item">Current Price: ${car.currentPrice}</li>
                    <li className="list-group-item">Exterior: {car.Exterior}</li>
                    <li className="list-group-item">Interior: {car.interior}</li>
                    <li className="list-group-item">Mileage: {car.Mileage}</li>
                  </ul>

                </div>
              </div>
            </div>
          ))
        ) : (
          <p>No cars selected for comparison. Please select up to three cars to compare.</p>
        )}
      </div>
    </div>
  );
}

export default Compare;
