"use client";
import CarBigCard from "@/components/common/CarBigCard";
import { getLetestCar } from "@/store/features/carSlice";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Dropdown as CDropdown, DropdownToggle as CDropdownToggle, DropdownMenu as CDropdownMenu, DropdownItem as CDropdownItem } from 'reactstrap';
import { ToastContainer } from "react-toastify";

const RecentlyAddedCars = () => {
  const dispatch = useDispatch();
  const [cars, setCars] = useState([]);
  const [sortOption, setSortOption] = useState(""); // State for sorting option
  const carData = useSelector((store) => store.carData);

  const getCarFn = async () => {
    dispatch(getLetestCar(sortOption));
  };

  useEffect(() => {
    getCarFn(); 
  }, [sortOption]);

  useEffect(() => {
    setCars(carData?.car);
  }, [carData]);

  // Dropdown states
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedSort, setSelectedSort] = useState('Sort By Default');

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleSortChange = (value, label) => {
    setSelectedSort(label); // Update selected sort label
    console.log('Selected Sort:', value);
    setSortOption(value); // Update the sort option state
  };

  return (
    <div className="car-area list bg py-120">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-11">
            <div className="col-md-12">
              <div className="car-sort">
                <h6>Showing 1-10 of 50 Results</h6>
                <div className="col-md-3 car-sort-box">
                  <div className="form-group">
                    <label>Sort By</label>
                    <CDropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
                      <CDropdownToggle
                        style={{
                          backgroundColor: 'white',
                          borderColor: '#ced4da',
                          color: '#757F95',
                          width: '100%',
                          borderRadius: '10px',
                          height: '55px',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          padding: '0 1rem',
                        }}
                        caret
                      >
                        {selectedSort}
                      </CDropdownToggle>
                      <CDropdownMenu
                        style={{
                          width: '100%',
                          maxHeight: '200px',
                          overflowY: 'scroll',
                        }}
                      >
                        <CDropdownItem onClick={() => handleSortChange('', 'Sort By Default')}>
                          Sort By Default
                        </CDropdownItem>
                        <CDropdownItem onClick={() => handleSortChange('featured', 'Sort By Featured')}>
                          Sort By Featured
                        </CDropdownItem>
                        <CDropdownItem onClick={() => handleSortChange('latest', 'Sort By Latest')}>
                          Sort By Latest
                        </CDropdownItem>
                        <CDropdownItem onClick={() => handleSortChange('lowPrice', 'Sort By Low Price')}>
                          Sort By Low Price
                        </CDropdownItem>
                        <CDropdownItem onClick={() => handleSortChange('highPrice', 'Sort By High Price')}>
                          Sort By High Price
                        </CDropdownItem>
                      </CDropdownMenu>
                    </CDropdown>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              {cars?.map((item) => (
                <CarBigCard key={item._id} item={item} />
              ))}
            </div>
            <div className="pagination-area">
              <div aria-label="Page navigation example">
                <ul className="pagination">
                  <li className="page-item">
                    <a aria-label="Previous" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-left" />
                      </span>
                    </a>
                  </li>
                  <li className="page-item active">
                    <a className="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li className="page-item">
                    <a aria-label="Next" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-right" />
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer/>
    </div>
  );
};

export default RecentlyAddedCars;
