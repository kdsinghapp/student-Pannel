"use client";
import { useState, useEffect, useRef } from "react";
import FlexSlider from "@/components/common/FlexSlider";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { SiGodotengine } from "react-icons/si";
import { BiCylinder, BiLogoFacebook, BiLogoLinkedin, BiLogoWhatsapp } from "react-icons/bi";
import Icon from "@mdi/react";
import { IoPricetagOutline } from "react-icons/io5";
import { FaGears } from "react-icons/fa6";
import { GiGearStickPattern, GiCarDoor, GiCartwheel } from "react-icons/gi";
import { FaCarSide } from "react-icons/fa";
import {
  mdiAirbag,
  mdiTire,
  mdiCardAccountDetailsStar,
  mdiMapMarkerOutline,
  mdiInvertColors,
  mdiGauge,
  mdiFormatSize,
  mdiSeat,
  mdiHistory,
  mdiStorageTankOutline,
} from "@mdi/js";
import {
  AddBid,
  AddOffer,
  favorites,
  getCar,
  purchaseNow,
} from "@/utils/carApi";
import Comment from "@/components/common/Comment";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { getLetestCar } from "@/store/features/carSlice";

import { useDispatch, useSelector } from "react-redux";
import {
  addCompareItem1,
  addCompareItem2,
  addCompareItem3,
  removeCompareItem,
} from "../store/features/compareSlice";

// import AfroStyles from "./afroStyles";

const Detail = ({ carId }) => {
  const [nav1, setNav1] = useState(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slider1, setSlider1] = useState(null);
  const [gallery, setGallery] = useState([]);
  const [car, setCar] = useState("");
  const [comments, setComments] = useState([]);
  const [isFavorite, setisFavorite] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const userData = useSelector((store) => store?.userData);
  const [cars, setCars] = useState([]);
  const [sortOption, setSortOption] = useState("latest");
  const carData = useSelector((store) => store.carData);

  const getCarFn = async () => {
    dispatch(getLetestCar(sortOption));
  };

  useEffect(() => {
    getCarFn();
  }, [sortOption]);

  useEffect(() => {
    setCars(carData?.car);
  }, [carData]);

  useEffect(() => {
    // console.log("userData?.user?.user", userData?.user);
    if (userData?.user) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [userData]);

  // Slider settings
  const settings = {
    lazyLoad: "ondemand",
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: false,
    asNavFor: nav1,
    ref: (slider) => setSlider1(slider),
    beforeChange: (oldIndex, newIndex) => setCurrentSlide(newIndex),
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  useEffect(() => {
    setNav1(slider1);
  }, [slider1]);

  const Cars = async (addView) => {
    try {
      const data = {
        car_id: carId,
        addView: addView,
      };

      const res = await getCar(data);
      setCar(res?.car);
      setGallery(res?.car?.gallery);
      setComments(res?.comments);
      setisFavorite(res?.isFavorite);
    } catch (erro) {
      console.log(erro);
    }
  };

  const hasMounted = useRef(false);

  useEffect(() => {
    if (!hasMounted.current) {
      Cars(true);
      // console.log("This is useEffect running only once");
      hasMounted.current = true; // Set to true after the first run
    }
  }, []);

  const handleSave = async (action) => {
    if (!isLoggedIn) {
      toast.error("Please Login.");
      return;
    }
    const data = {
      carId: carId,
      action: action,
    };

    try {
      const res = await favorites(data);

      if (res.status) {
        toast.success(res.message);
        Cars()
      } else {
        toast.error(res.message);
        Cars()
      }
    } catch (error) {
      toast.error("An error occurred while processing your request.");
    }
  };

  // bid
  const [bidAmount, setBidAmount] = useState("");
  const [offerAmount, setOfferAmount] = useState("");

  const handleBid = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) {
      toast.error("Please Login.");
      return;
    }

    const data = {
      amount: bidAmount,
      carId: carId,
    };
    try {
      const res = await AddBid(data);
      console.log(res);
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }

    // Handle the response as needed
  };
  const handleOffer = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) {
      toast.error("Please Login.");
      return;
    }

    const data = {
      amount: offerAmount,
      carId: carId,
    };
    try {
      const res = await AddOffer(data);
      console.log(res);
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }

    // Handle the response as needed
  };
  const handlePurchaseNow = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) {
      toast.error("Please Login.");
      return;
    }

    const data = {
      carId: carId,
    };
    try {
      const res = await purchaseNow(data);
      console.log(res);
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }
    // Handle the response as needed
  };

  const sliderRef = useRef(null);
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000, // 3 seconds auto slide
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  const [selectedOption, setSelectedOption] = useState("");
  const router = useRouter();

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedOption) {
      console.log("selectedOption", selectedOption);

      router.push(selectedOption);
    }
  };

  const dispatch = useDispatch();

  // Get compare state from Redux
  const compareCar1 = useSelector((state) => state.compare.car1);
  const compareCar2 = useSelector((state) => state.compare.car2);
  const compareCar3 = useSelector((state) => state.compare.car3);

  // Handle adding cars to specific compare slots
  const handleAddToCompare = (car, slot) => {
    if (slot === 1 && !compareCar1) {
      dispatch(addCompareItem1(car));
    } else if (slot === 2 && !compareCar2) {
      dispatch(addCompareItem2(car));
    } else if (slot === 3 && !compareCar3) {
      dispatch(addCompareItem3(car));
    }
  };

  // Handle removing a car from compare
  const handleRemoveFromCompare = (carId) => {
    dispatch(removeCompareItem({ carId }));
  };

  return (
    <>
      <link rel="stylesheet" href="/flexslider/flexslider.css" />
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Car Details</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="index.html">Home</a>
              </li>
              <li className="active">Car Details</li>
            </ul>
          </div>
        </div>
        <div className="car-item-single bg py-120">
          <div className="container">
            <div className="car-single-wrapper">
              <div className="row">
                <div className="col-lg-8">
                  <div className="car-single-details">
                    <div className="car-single-widget">
                      <div className="car-single-top">
                        <span className="car-status status-1">
                          {car.car_condition}
                        </span>
                        <h3 className="car-single-title">{car.car_name}</h3>
                        <ul className="car-single-meta">
                          <li>
                            <i className="far fa-clock" /> Listed On:{" "}
                            {car.created_at},{/* {car.car_model_year} */}
                          </li>
                          <li>
                            <i className="far fa-eye" /> Views: {car.car_views}
                          </li>
                        </ul>
                      </div>
                      <div className="car-single-slider">
                        <Slider {...settings}>
                          <div>
                            <div className="img-body">
                              <img
                                src={`http://193.203.161.2:8000/images/${car?.image}`}
                                alt={car?.image}
                              />
                            </div>
                          </div>
                          {gallery?.map((item) => (
                            <div key={item}>
                              <div className="img-body">
                                <img
                                  src={`http://193.203.161.2:8000/images/${item}`}
                                  alt={item.alt}
                                />
                              </div>
                              <div>
                                <h2>{item.title}</h2>
                                <p>{item.description}</p>
                              </div>
                            </div>
                          ))}

                          {/* { 
                          gallery.length == 1 ?
                          gallery?.map((item) => (
                            <div key={item}>
                              <div className="img-body">
                                <img
                                  src={`http://193.203.161.2:8000/images/${item}`}
                                  alt={item.alt}
                                />
                              </div>
                              <div>
                                <h2>{item.title}</h2>
                                <p>{item.description}</p>
                              </div>
                            </div>
                          )) : ""
                          } */}
                        </Slider>

                        <button
                          className="arrow-button prev"
                          onClick={() => slider1.slickPrev()}
                        >
                          ‹
                        </button>
                        <button
                          className="arrow-button next"
                          onClick={() => slider1.slickNext()}
                        >
                          ›
                        </button>
                      </div>
                      <div className="thumb-wrapper">
                        <div
                          className={`${currentSlide === 0 ? "active" : null}`}
                          onClick={() => {
                            slider1.slickGoTo(0);
                          }}
                        >
                          <img
                            src={`http://193.203.161.2:8000/images/${car?.image}`}
                            alt={car?.image}
                          />
                          {currentSlide}
                        </div>

                        {gallery?.map((item, idx) => (
                          <div
                            key={item}
                            className={`${
                              currentSlide === idx + 1 ? "active" : null
                            }`}
                            onClick={() => {
                              slider1.slickGoTo(idx + 1);
                            }}
                          >
                            <img
                              src={`http://193.203.161.2:8000/images/${item}`}
                              alt={item.alt}
                            />
                            {currentSlide}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="car-single-widget">
                      <h4 className="mb-4">Key Information</h4>
                      <div className="car-key-info">
                        <div className="row">
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="flaticon-drive" /> */}
                                <FaCarSide size={20} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Body Type</span>
                                <h6>{car.car_type}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="flaticon-drive" /> */}
                                <FaCarSide size={20} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Car model year</span>
                                <h6>{car.car_model_year}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Condition</span>
                                <h6>{car.car_condition}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-speedometer" />
                              </div>
                              <div className="car-key-content">
                                <span>Mileage</span>
                                <h6>{car.Mileage} (Mi)</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="flaticon-settings" /> */}
                                <GiGearStickPattern size={20} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Transmission</span>
                                <h6>{car.car_transmission}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="far fa-calendar-check" />
                              </div>
                              <div className="car-key-content">
                                <span>Year</span>
                                <h6>{car.car_model_year}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-gas-station" />
                              </div>
                              <div className="car-key-content">
                                <span>Fuel Type</span>
                                <h6>{car.car_fuel_type}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="fas fa-broom" />
                              </div>
                              <div className="car-key-content">
                                <span>Color</span>
                                <h6>{car.car_interior_color}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="bi-door-open-fill"/> */}
                                <GiCarDoor size={30} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Doors</span>
                                <h6>{car.car_door} Doors</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="flaticon-drive" /> */}
                                <BiCylinder size={30} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Cylinders</span>
                                <h6>{car.car_cylinder}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                {/* <i className="flaticon-drive" /> */}
                                <FaGears size={20} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Engine Size</span>
                                <h6>{car?.car_engine_capacity} (cc)</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiAirbag}
                                  size={1}
                                  color="#519bdd"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Airbag</span>
                                <h6>{car.airbag}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon path={mdiTire} size={1} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Alloy wheels</span>
                                <h6>{car.alloy_wheels}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiCardAccountDetailsStar}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Additional details</span>
                                <h6>{car.car_additional_details}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Boot space</span>
                                <h6>{car.boot_space}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiMapMarkerOutline}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Address</span>
                                <h6>
                                  {car.car_address ? car.car_address : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiInvertColors}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Body color</span>
                                <h6>{car.car_body_color}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Class</span>
                                <h6>{car.car_class}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Drive type</span>
                                <h6>
                                  {car.car_drive_type
                                    ? car.car_drive_type
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-settings" />
                              </div>
                              <div className="car-key-content">
                                <span>Engine capacity</span>
                                <h6>
                                  {car.car_engine_capacity
                                    ? car.car_engine_capacity
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Extra feature</span>
                                <h6>
                                  {car.car_extra_feature
                                    ? car.car_extra_feature
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Extra features</span>
                                <h6>
                                  {car.car_extra_features
                                    ? car.car_extra_features
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiGauge}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Kilometers</span>
                                <h6>
                                  {car.car_kilometers
                                    ? car.car_kilometers
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <IoPricetagOutline color="#519be4" size={20} />
                              </div>
                              <div className="car-key-content">
                                <span>Price</span>
                                <h6>{car.car_price ? car.car_price : "N/A"}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Reginal specification</span>
                                <h6>
                                  {car.car_reginal_specification
                                    ? car.car_reginal_specification
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Regional specs</span>
                                <h6>
                                  {car.car_regional_specs
                                    ? car.car_regional_specs
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <IoPricetagOutline color="#519be4" size={20} />
                              </div>
                              <div className="car-key-content">
                                <span>Rent price</span>
                                <h6>
                                  {car.car_rent_price
                                    ? car.car_rent_price
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <GiCartwheel size={20} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Rim sizes</span>
                                <h6>
                                  {car.car_rim_sizes
                                    ? car.car_rim_sizes
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon path={mdiSeat} size={1} color="#519be4" />
                              </div>
                              <div className="car-key-content">
                                <span>Seat</span>
                                <h6>{car.car_seat ? car.car_seat : "N/A"}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiHistory}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Service history</span>
                                <h6>
                                  {car.car_service_history
                                    ? car.car_service_history
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Under warranty</span>
                                <h6>
                                  {car.car_under_warranty
                                    ? car.car_under_warranty
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-drive" />
                              </div>
                              <div className="car-key-content">
                                <span>Ground clearance</span>
                                <h6>
                                  {car.ground_clearance
                                    ? car.ground_clearance
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <Icon
                                  path={mdiStorageTankOutline}
                                  size={1}
                                  color="#519be4"
                                />
                              </div>
                              <div className="car-key-content">
                                <span>Tank capacity</span>
                                <h6>
                                  {car.tank_capacity
                                    ? car.tank_capacity
                                    : "N/A"}
                                </h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-settings" />
                              </div>
                              <div className="car-key-content">
                                <span>Torque</span>
                                <h6>{car.torque ? car.torque : "N/A"}</h6>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-3 col-md-4 col-6">
                            <div className="car-key-item">
                              <div className="car-key-icon">
                                <i className="flaticon-settings" />
                              </div>
                              <div className="car-key-content">
                                <span>Exterior</span>
                                <h6>{car.Exterior ? car.Exterior : "N/A"}</h6>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* <div className="car-single-widget">
                      <div className="car-single-overview">
                        <h4 className="mb-3">Customer Discussion</h4>
                        <div className="mb-4">
                          <p>
                            <strong>User xyz:</strong> I checked the
                            manufacturer website and it look that the options on
                            this car were added by the original owner, not by
                            the factory
                          </p>
                        </div>
                        <div className="text-right">
                          <a href="" className="btn btn-primary">
                            New Message
                          </a>
                        </div>
                      </div>
                    </div> */}
                    <Comment Cars={Cars} carId={carId} comments={comments} />
                    {/* <div className="car-single-widget">
                    <div className="car-single-review">
                      <div className="blog-comments mb-0">
                        <h4>User Comments (05)</h4>
                        <div className="blog-comments-wrapper">
                          <div className="blog-comments-single">
                            <img alt="thumb" src="assets/img/blog/com-1.jpg" />
                            <div className="blog-comments-content">
                              <h5>Jesse Sinkler</h5>
                              <span>
                                <i className="far fa-clock" /> January 31, 2023
                              </span>
                              <p>
                                At vero eos et accusamus et iusto odio
                                dignissimos ducimus qui blanditiis praesentium
                                voluptatum deleniti atque corrupti quos dolores
                                et quas molestias excepturi sint occaecati
                                cupiditate non provident.
                              </p>
                            </div>
                          </div>
                          <div className="blog-comments-single">
                            <img alt="thumb" src="assets/img/blog/com-2.jpg" />
                            <div className="blog-comments-content">
                              <h5>Daniel Wellman</h5>
                              <span>
                                <i className="far fa-clock" /> January 31, 2023
                              </span>
                              <p>
                                At vero eos et accusamus et iusto odio
                                dignissimos ducimus qui blanditiis praesentium
                                voluptatum deleniti atque corrupti quos dolores
                                et quas molestias excepturi sint occaecati
                                cupiditate non provident.
                              </p>
                            </div>
                          </div>
                          <div className="blog-comments-single">
                            <img alt="thumb" src="assets/img/blog/com-3.jpg" />
                            <div className="blog-comments-content">
                              <h5>Kenneth Evans</h5>
                              <span>
                                <i className="far fa-clock" /> January 31, 2023
                              </span>
                              <p>
                                At vero eos et accusamus et iusto odio
                                dignissimos ducimus qui blanditiis praesentium
                                voluptatum deleniti atque corrupti quos dolores
                                et quas molestias excepturi sint occaecati
                                cupiditate non provident.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div> */}
                  </div>
                </div>
                <div className="col-lg-4">
                  <div className="car-single-widget">
                    <ul className="car-single-meta mb-3">
                      <li>
                        <a
                          href="#"
                          data-bs-toggle="modal"
                          data-bs-target="#paymentModalLabel"
                        >
                          <i className="fa fa-plus" /> Compare
                        </a>
                      </li>
                      <li>
                      <a
                          href="#"
                          data-bs-toggle="modal"
                          data-bs-target="#ShareModel"
                        >
                          <i className="fa fa-share-alt" /> Share
                        </a>
                      </li>
                      <li>
                        <p onClick={() => handleSave("add")}>
                          <i className={`fa fa-heart ${isFavorite ? "text-danger" : '' }`} /> Save
                        </p>
                      </li>
                    </ul>
                    <h4 className="car-single-price">${car?.car_price}</h4>
                    <div
                      className="mt-3  d-flex"
                      style={{ justifyContent: "space-between" }}
                    >
                      {car.auctionIt ? (
                        <>
                          <a
                            className="btn btn-primary"
                            data-bs-toggle="modal"
                            data-bs-target={`#Buy-popup`}
                          >
                            Buy Now
                          </a>
                          <a
                            className="btn btn-secondary"
                            data-bs-toggle="modal"
                            data-bs-target={`#bid-popup`}
                          >
                            Place Bid
                          </a>
                          <a
                            className="btn btn-warning text-white"
                            data-bs-toggle="modal"
                            data-bs-target={`#offer-popup`}
                          >
                            Give Offer
                          </a>
                        </>
                      ) : (
                        <>
                          <a
                            className="btn btn-primary w-50  mx-1"
                            data-bs-toggle="modal"
                            data-bs-target={`#Buy-popup`}
                          >
                            Buy Now
                          </a>
                          <a
                            className="btn btn-warning text-white w-50 mx-1"
                            data-bs-toggle="modal"
                            data-bs-target={`#offer-popup`}
                          >
                            Give Offer
                          </a>
                        </>
                      )}

                      {/* <a href="" className="btn btn-secondary">
                        Place Bid
                      </a>
                      <a href="" className="btn btn-warning text-white">
                        Give Offer
                      </a> */}
                    </div>
                  </div>
                  {/* <div className="">
                  <button
  className="theme-btn mb-2"
  data-bs-toggle="modal"
  data-bs-target="#paymentModalLabel"
  style={{ width: "300px" }}
>
  Compare this Car
                  </button>

                  </div> */}
                  <div className="car-single-widget">
                    <div className="car-single-author">
                      <img alt="" src="assets/img/car/author.jpg" />
                      <div className="car-single-author-content">
                        <h5>Marid Anderson</h5>
                        <p>
                          Dealer ratings:{" "}
                          <span>
                            <i className="fa fa-star text-warning" /> 4.8{" "}
                          </span>{" "}
                          <span className="text-primary">(1819)</span>
                        </p>
                      </div>
                    </div>
                    <div
                      className="mt-3  d-flex"
                      style={{ justifyContent: "space-between" }}
                    >
                      <a href="" className="mt-3 text-primary">
                        <i className="fa fa-phone" /> 346 335-4980
                      </a>
                      <Link
                        href={`/chat/${car?.dealer}?text=Is your ${car.car_name} available?`}
                        className="theme-btn"
                      >
                        <i className="fa fa-comment" /> Chat With Dealer
                      </Link>
                    </div>
                  </div>
                  <div className="car-single-widget">
                    <h5 className="mb-3">I am Interested In</h5>
                    <div className="car-single-form">
                      <form action="#">
                        <div className="row">
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <input
                                type="radio"
                                id="availability"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Is your ${car.car_name} available?`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="availability"
                                className={`checkbox-label ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Is your ${car.car_name} available?`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                This Vehicle Availability
                              </label>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <input
                                type="radio"
                                id="more-info"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="more-info"
                                className={`checkbox-label ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                More Information
                              </label>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <input
                                type="radio"
                                id="test-drive"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="test-drive"
                                className={`checkbox-label ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                Schedule a Test Drive
                              </label>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <input
                                type="radio"
                                id="history-report"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Can I get Vehicle History Report for your ${car.car_name}.`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="history-report"
                                className={`checkbox-label ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Can I get Vehicle History Report for your ${car.car_name}.`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                Vehicle History Report
                              </label>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <label className="mt-2">
                              Message{" "}
                              <input
                                type="radio"
                                id="edit-inquiry"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="edit-inquiry"
                                className={`checkbox-label checkbox-label-message text-primary ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                Edit Inquiry
                              </label>
                            </label>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <input
                                type="radio"
                                id="hold-1day"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="hold-1day"
                                className={`checkbox-label ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                Hold for 1 Day
                              </label>
                            </div>
                          </div>
                          <div className="form-group col-lg-12">
                            <label>
                              <input
                                type="radio"
                                id="available"
                                name="car-option"
                                value={`/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`}
                                onChange={handleOptionChange}
                                style={{ display: "none" }}
                              />
                              <label
                                htmlFor="available"
                                className={`checkbox-label checkbox-label-text ${
                                  selectedOption ===
                                  `/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`
                                    ? "selected"
                                    : ""
                                }`}
                              >
                                Is your used 2008 {car.car_name} Car listed for
                                $50,560 Still Available?
                              </label>
                            </label>
                          </div>
                          <div className="form-group col-lg-12">
                            <button
                              className="theme-btn  w-100 text-white"
                              onClick={handleSubmit}
                              disabled={!selectedOption}
                            >
                              Send Request to Seller{" "}
                              <i className="fas fa-arrow-right-long" />
                            </button>
                          </div>
                        </div>

                        {/* <div className="row">
      <div className="form-group col-lg-6">
        <div className="checkbox-container d-flex">
          <input
            type="radio"
            id="availability"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Is your ${car.car_name} available?`}
            onChange={handleOptionChange}
          />
          <label htmlFor="availability" className="checkbox-label">
            This Vehicle Availability
          </label>
        </div>
      </div>
      <div className="form-group col-lg-6">
        <div className="checkbox-container">
          <input
            type="radio"
            id="more-info"
            name="car-option"
            value={`/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`}
            onChange={handleOptionChange}
          />
          <label htmlFor="more-info" className="checkbox-label">
            More Information
          </label>
        </div>
      </div>
      <div className="form-group col-lg-6">
        <div className="checkbox-container">
          <input
            type="radio"
            id="test-drive"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`}
            onChange={handleOptionChange}
          />
          <label htmlFor="test-drive" className="checkbox-label">
            Schedule a Test Drive
          </label>
        </div>
      </div>
      <div className="form-group col-lg-6">
        <div className="checkbox-container">
          <input
            type="radio"
            id="history-report"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Can I get Vehicle History Report for your ${car.car_name}.`}
            onChange={handleOptionChange}
          />
          <label htmlFor="history-report" className="checkbox-label">
            Vehicle History Report
          </label>
        </div>
      </div>
      <div className="form-group col-lg-6">
        <label className="mt-2">
          Message{" "}
          <input
            type="radio"
            id="edit-inquiry"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`}
            onChange={handleOptionChange}
          />
          <label htmlFor="edit-inquiry" className="text-primary">
            Edit Inquiry
          </label>
        </label>
      </div>
      <div className="form-group col-lg-6">
        <div className="checkbox-container">
          <input
            type="radio"
            id="hold-1day"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`}
            onChange={handleOptionChange}
          />
          <label htmlFor="hold-1day" className="checkbox-label">
            Hold for 1 Day
          </label>
        </div>
      </div>
      <div className="form-group col-lg-12">
        <label>
          <input
            type="radio"
            id="available"
            name="car-option"
            value={`/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`}
            onChange={handleOptionChange}
          />
          <label htmlFor="available">
            Is your used 2008 {car.car_name} Car listed for $50,560 Still Available?
          </label>
        </label>
      </div>
      <div className="form-group col-lg-12">
        <button className="btn btn-primary" onClick={handleSubmit} disabled={!selectedOption}>
          Submit
        </button>
      </div>
    </div> */}
                        {/* <div className="row">
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <Link className="checkbox-label" href={`/chat/${car?.dealer}?text=Is your ${car.car_name} available?`}>This Vehicle Availability</Link>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <Link className="checkbox-label" href={`/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`}>More Information</Link>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <Link className="checkbox-label" href={`/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`}>Schedule a Test Drive</Link>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <Link className="checkbox-label" href={`/chat/${car?.dealer}?text=Can i get Vehicle History Report for your ${car.car_name}.`}>Vehicle History Report</Link>
                            </div>
                          </div>
                          <div className="form-group col-lg-6">
                            <label className="mt-2">
                              Message{" "}
                              <Link className="text-primary" href={`/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`}>Edit</Link>
                            </label>
                          </div>
                          <div className="form-group col-lg-6">
                            <div className="checkbox-container">
                              <Link className="checkbox-label" href={`/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`}>Hold for 1 Day</Link>
                            </div>
                          </div>
                          <div className="form-group col-lg-12">
                            <label>
                              <Link className="" href={`/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`}>Is your used 2008 ${car.car_name} Car listed for
                              $50,560 Still Available?</Link>
                            </label>
                          </div>
                        </div> */}
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <div className="car-single-related mt-5">
                <h3 className="mb-30">Related Listing</h3>

                <div className="row">
                  <Slider ref={sliderRef} {...sliderSettings}>
                    {cars?.map((item) => (
                      <div
                        key={item._id}
                        className="col-md-6 col-lg-4 col-xl-3"
                      >
                        <div className="car-item card-min-hight">
                          <div className="car-img fixed-height-img">
                            <span className="car-status status-1">
                              {item?.car_condition}
                            </span>{" "}
                            <img
                              alt=""
                              src={`http://193.203.161.2:8000/images/${item?.image}`}
                            />
                            <div className="car-btns">
                              <a href="#">
                                <i className="far fa-heart" />
                              </a>{" "}
                              <a href="#">
                                <i className="far fa-arrows-repeat" />
                              </a>
                            </div>
                          </div>
                          <div className="car-content">
                            <div className="car-top">
                              <h4>
                                <Link href={`/detail/${item?._id}`}>
                                  {item?.car_name}
                                </Link>
                              </h4>
                              {/* <div className="car-rate">
                            <i className="fas fa-star" />{" "}
                            <i className="fas fa-star" />{" "}
                            <i className="fas fa-star" />{" "}
                            <i className="fas fa-star" />{" "}
                            <i className="fas fa-star" />{" "}
                            <span>5.0 (58.5k Review)</span>
                          </div> */}
                            </div>
                            <ul className="car-list">
                              {/* <li>
                            <i className="far fa-steering-wheel" />
                            Automatic
                          </li>
                          <li>
                            <i className="far fa-road" />
                            10.15km / 1-litre
                          </li> */}
                              <li>
                                <i className="far fa-car" />
                                Model: {item?.car_model_year}
                              </li>
                              <li>
                                <i className="far fa-gas-pump" />
                                Hybrid
                              </li>
                            </ul>
                            <div className="car-footer">
                              <span className="car-price">
                                ${item?.car_price}
                              </span>
                              <a className="theme-btn" href="#">
                                <span className="far fa-eye" />
                                Details
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </Slider>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <ToastContainer />

      <div
        className="modal fade"
        id={"bid-popup"}
        tabIndex="-1"
        aria-labelledby={`bid-popupLabel`}
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">Place bid</div>
            {/* Modal Body */}
            <div className="modal-body">
              <form className="row pb-4" onSubmit={handleBid}>
                <div className="col-7">
                  <input
                    onChange={(e) => setBidAmount(e.target.value)}
                    type="number"
                    placeholder="Your Bidding ammount"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div className="col-5">
                  <button
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    type="submit"
                    className="btn btn-secondary"
                  >
                    Place bid
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id={"offer-popup"}
        tabIndex="-1"
        aria-labelledby={`offer-popupLabel`}
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">Place Offer</div>
            {/* Modal Body */}
            <div className="modal-body">
              <form className="row pb-4" onSubmit={handleOffer}>
                <div className="col-7">
                  <input
                    onChange={(e) => setOfferAmount(e.target.value)}
                    type="number"
                    placeholder="Your Offred ammount"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div className="col-5">
                  <button
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    type="submit"
                    className="btn btn-secondary"
                  >
                    Place Offer
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id={"Buy-popup"}
        tabIndex="-1"
        aria-labelledby={`Buy-popupLabel`}
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">
              Buy Car at Current price ( {car?.car_price} ){" "}
            </div>
            {/* Modal Body */}
            <div className="modal-body">
              <form className="row pb-4" onSubmit={handlePurchaseNow}>
                <div className="col-5">
                  <button
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    type="submit"
                    className="btn btn-secondary"
                  >
                    Buy car
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id="paymentModalLabel"
        tabIndex="-1"
        aria-labelledby="paymentModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg" style={{ maxWidth: "1000px" }}>
          <div className="modal-content" style={{ minHeight: "65vh" }}>
            <div className="modal-header">
              <h4 className="modal-title" id="paymentModalLabel">
                Compare
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div
                className="d-flex align-items-center gap-3 p-2"
                style={{ width: "100%", overflowX: "auto" }}
              >
                {/* First Car Slot */}
                <div
                  className="card shadow-sm"
                  style={{
                    width: "250px",
                    padding: "10px",
                    borderRadius: "12px",
                    position: "relative",
                  }}
                >
                  {compareCar1 ? (
                    <>
                      <img
                        src={`http://193.203.161.2:8000/images/${compareCar1?.image}`}
                        alt={compareCar1.car_name}
                        style={{ borderRadius: "8px" }}
                      />
                      <div className="d-flex flex-column mt-2">
                        <span className="fw-bold">
                          Price: ${compareCar1.car_price}
                        </span>
                        <span className="text-muted">
                          Name: {compareCar1.car_name}
                        </span>
                      </div>
                      <button
                        className="btn-close"
                        style={{
                          position: "absolute",
                          top: "10px",
                          right: "10px",
                        }}
                        onClick={() => handleRemoveFromCompare(compareCar1._id)}
                      ></button>
                    </>
                  ) : (
                    <div
                      className="d-flex align-items-center justify-content-center"
                      style={{ height: "120px", background: "#F7F7F7" }}
                      onClick={() => handleAddToCompare(car, 1)} // Pass the car object for slot 1
                    >
                      <span style={{ fontSize: "36px", color: "#888" }}>+</span>
                    </div>
                  )}
                </div>

                {/* Second Car Slot */}
                <div
                  className="card shadow-sm"
                  style={{
                    width: "250px",
                    padding: "10px",
                    borderRadius: "12px",
                    position: "relative",
                  }}
                >
                  {compareCar2 ? (
                    <>
                      <img
                        src={`http://193.203.161.2:8000/images/${compareCar2?.image}`}
                        alt={compareCar2.car_name}
                        style={{ borderRadius: "8px" }}
                      />
                      <div className="d-flex flex-column mt-2">
                        <span className="fw-bold">
                          Price: ${compareCar2.car_price}
                        </span>
                        <span className="text-muted">
                          Name: {compareCar2.car_name}
                        </span>
                      </div>
                      <button
                        className="btn-close"
                        style={{
                          position: "absolute",
                          top: "10px",
                          right: "10px",
                        }}
                        onClick={() => handleRemoveFromCompare(compareCar2._id)}
                      ></button>
                    </>
                  ) : (
                    <div
                      className="d-flex align-items-center justify-content-center"
                      style={{ height: "120px", background: "#F7F7F7" }}
                      onClick={() => handleAddToCompare(car, 2)} // Pass the car object for slot 2
                    >
                      <span style={{ fontSize: "36px", color: "#888" }}>+</span>
                    </div>
                  )}
                </div>

                {/* Third Car Slot */}
                <div
                  className="card shadow-sm"
                  style={{
                    width: "250px",
                    padding: "10px",
                    borderRadius: "12px",
                    position: "relative",
                  }}
                >
                  {compareCar3 ? (
                    <>
                      <img
                        src={`http://193.203.161.2:8000/images/${compareCar3?.image}`}
                        alt={compareCar3.car_name}
                        style={{ borderRadius: "8px" }}
                      />
                      <div className="d-flex flex-column mt-2">
                        <span className="fw-bold">
                          Price: ${compareCar3.car_price}
                        </span>
                        <span className="text-muted">
                          Name: {compareCar3.car_name}
                        </span>
                      </div>
                      <button
                        className="btn-close"
                        style={{
                          position: "absolute",
                          top: "10px",
                          right: "10px",
                        }}
                        onClick={() => handleRemoveFromCompare(compareCar3._id)}
                      ></button>
                    </>
                  ) : (
                    <div
                      className="d-flex align-items-center justify-content-center"
                      style={{ height: "120px", background: "#F7F7F7" }}
                      onClick={() => handleAddToCompare(car, 3)} // Pass the car object for slot 3
                    >
                      <span style={{ fontSize: "36px", color: "#888" }}>+</span>
                    </div>
                  )}
                </div>

                {/* Compare Button */}
                <Link href="/compare">
                  <div
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    className="d-flex align-items-center justify-content-center ms-2 "
                    style={{
                      padding: "8px",
                      background: "#3A6FF7",
                      borderRadius: "12px",
                      color: "#fff",
                      width: "181px",
                    }}
                  >
                    <div className="text-center">
                      <h5
                        className="mb-1"
                        style={{
                          fontSize: "18px",
                          fontWeight: "bold",
                          color: "white",
                        }}
                      >
                        Compare
                      </h5>
                      <span style={{ fontSize: "16px" }}>
                        {
                          [compareCar1, compareCar2, compareCar3].filter(
                            (car) => car
                          ).length
                        }
                        /3
                      </span>
                    </div>
                  </div>
                </Link>
              </div>
            </div>

            {/*

    
      
      */}
          </div>
        </div>
      </div>

{/* for share */}
      <div
        className="modal fade"
        id="ShareModel"
        tabIndex="-1"
        aria-labelledby="ShareModelLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">Share</div>
            {/* Modal Body */}
            <div className="modal-body">
            <div className={` mt-3 d-flex gap-4 justify-content-center`}>
                 <div><a href={`https://api.whatsapp.com/send?text=https://salousi.com/detail/${"car?._id"}`}><BiLogoWhatsapp style={{ fontSize: '40px' }} /> </a></div>
                 <div><a href={`https://www.facebook.com/login.php?skip_api_login=1&api_key=966242223397117&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fsharer.php%3Fu%3Dhttps%253A%252F%252Fsalousi.com%252Fdetail%252F${"car?._id"}&cancel_url=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Fclose_window%2F%3Fapp_id%3D966242223397117%26connect%3D0%23_%3D_&display=popup&locale=en_GB`}><BiLogoFacebook style={{ fontSize: '40px' }} />  </a></div>
                 <div><a href={`https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2FshareArticle%3Furl%3Dhttps%3A%2F%2Fsalousi.com%2Fdetail%2F${"car?._id"}%26title%3Dkundali%2520report`}><BiLogoLinkedin style={{ fontSize: '40px' }} />  </a></div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Detail;
