"use client";
import { cancelBid, getMyBids, ImageUrl, purchaseNow } from "@/utils/carApi";
import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const MyBids = () => {
  const [list, setList] = useState();
  const getData = async () => {
    const res = await getMyBids();
    setList(res?.data);
    console.log(res?.data);
  };
  useEffect(() => {
    getData();
  }, []);

  const handleCancel = async (carId) => {
    const data = {
      carId,
    };
    try {
      const res = await cancelBid(data);
      getData();
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error("An error occurred while processing your request.");
    }
  };

  const handlePurchaseNow = async (carId) => {
    // e.preventDefault();
    // if (!isLoggedIn) {
    //   toast.error("Please Login.");
    //   return;
    // }

    const data = {
      carId: carId,
    };
    try {
      const res = await purchaseNow(data);
      getData();
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }
  };

  return (
    <div className="col-lg-12">
      <div className="row">
        {list?.map((item) => (
          <div key={item?._id} className="col-md-6 col-lg-12">
            <div className="car-item">
              <div className="col-md-3">
                <div className="col-md-12 col-lg-12 mb-2">
                  <h6>
                    <a href="#" className="me-3">
                      {item?.car?.car_name}
                    </a>{" "}
                  </h6>
                </div>
                <div className="">
                  <img
                    alt=""
                    src={ImageUrl() + item?.car?.image}
                    style={{
                      width: "100%",
                      borderRadius: 10,
                    }}
                  />
                </div>
              </div>
              <div className="car-content sideborder col-md-6">
                <div className="car-top">
                  {/* <p>
                    <a href="#">
                      <i className="fa fa-camera" /> Gallery
                    </a>
                  </p> */}
                </div>
                <ul className="car-list">
                  <li>Exterior: {item?.car?.Exterior}</li>
                  <li>Interior: {item?.car?.car_interior_color}</li>
                  <li>Trans.: {item?.car?.car_transmission}</li>
                  <li>Doors: {item?.car?.car_door}</li>
                  <li>Engine: {item?.car?.car_engine_capacity}</li>
                  <li>Mileage: {item?.car?.Mileage}</li>
                  <li>item?.status: {item?.status}</li>
                </ul>
              </div>
              {item?.status === "New Bid" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="text-success">{item?.status}</p>
                    <p className="car-price f-14">
                      <span className="text-primary">Price:</span> $
                      {item?.car?.car_price}
                    </p>
                    <p className="car-price f-14">
                      <span className="text-warning">Your Bid: </span>$
                      {item?.amount}
                    </p>
                  </div>
                  <div className="mb-2 mt-2">
                    <button
                      onClick={() => handleCancel(item?.car?._id)}
                      className="btn btn-danger w-100"
                      >
                      Cancel Bid
                    </button>
                  </div>
                  <div>
                    <button
                     onClick={() => handlePurchaseNow(item?.car?._id)}
                     className="btn btn-primary w-100" href="#">
                      Buy At Full Price
                    </button>
                  </div>
                </div>
              ) : (
                ""
              )}
              {item?.status === "Rejected" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your bid was <br />
                      <span className="text-danger">
                        not accepted <span />
                      </span>
                    </p>
                    <p className="car-price f-14">
                      Add new bid with higher value
                    </p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Current Bid:{" "}
                      <span className="text-primary">{item?.amount}</span>
                    </p>
                  </div>
                  <div>
                    {/* <a className="btn btn-primary w-100" href="#">
                    Adjust Bid{" "}
                  </a> */}
                  </div>
                </div>
              ) : (
                ""
              )}
              {item?.status === "Accepted" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your bid was <br />
                      <span style={{ color: "green" }}>
                        {" "}
                        Accepted <span />
                      </span>
                    </p>
                    <p className="car-price f-14">
                      Please pay ammount and buy car
                    </p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Current Bid:{" "}
                      <span className="text-primary">
                        ${item?.amount}
                        <span>.</span>
                      </span>
                    </p>
                  </div>
                  <div>
                    <a className="btn btn-primary w-100" href="#">
                      {" "}
                      Buy{" "}
                    </a>
                  </div>
                </div>
              ) : (
                ""
              )}
              {item?.status === "Canceled Automatically" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your bid was <br />
                      <span className="text-danger">
                        Canceled Automatically <span />
                      </span>
                    </p>
                    <p className="car-price f-14">Car was sold or removed</p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Price: <br />
                      <span className="text-primary">
                        ${item?.car?.car_price}
                        <span>.</span>
                      </span>
                    </p>
                  </div>
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        ))}
        {/* <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    New 2018 Chrysler 400 C{" "}
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/02.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  Your bid was <br />
                  <span className="text-danger">
                    Canceled Automatically <span />
                  </span>
                </p>
                <p className="car-price f-14">Car was sold or removed</p>
              </div>
              <div className="mb-2 mt-2">
                <p className="car-price f-14">
                  Price: <br />
                  <span className="text-primary">
                    $12150<span>.</span>
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    2New 2018 Chrysler 400 C{" "}
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/03.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  Your bid was <br />
                  <span className="text-danger">
                    not accepted <span />
                  </span>
                </p>
                <p className="car-price f-14">Car was sold or removed</p>
              </div>
              <div className="mb-2 mt-2">
                <p className="car-price f-14">
                  Current Bid:{" "}
                  <span className="text-primary">
                    $12100<span>.</span>
                  </span>
                </p>
              </div>
              <div>
                <a className="btn btn-primary w-100" href="#">
                  Adjust Bid{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-12">
          <div className="car-item">
            <div className="col-md-3">
              <div className="col-md-12 col-lg-12 mb-2">
                <h6>
                  <a href="#" className="me-3">
                    3New 2018 Chrysler 400 C{" "}
                  </a>{" "}
                </h6>
              </div>
              <div className="">
                <img
                  alt=""
                  src="assets/img/car/03.jpg"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
            <div className="car-content sideborder col-md-6">
              <div className="car-top">
                <p>
                  <a href="#">
                    <i className="fa fa-camera" /> Gallery
                  </a>
                </p>
              </div>
              <ul className="car-list">
                <li>Exterior: Velvet Red Pearlcoat</li>
                <li>Interior: Linen/Black W/Leather W/</li>
                <li>Trans.: 6 Speed Automatic</li>
                <li>Doors: Four Door Sedan</li>
                <li>Engine: 6 Cylinder</li>
                <li>Mileage: 18,251</li>
              </ul>
            </div>
            <div className="btnns col-md-3">
              <div>
                <p className="car-price f-14">
                  Your bid was <br />
                  <span style={{ color: "green" }}>
                    {" "}
                    accepted <span />
                  </span>
                </p>
                <p className="car-price f-14">Car was sold or removed</p>
              </div>
              <div className="mb-2 mt-2">
                <p className="car-price f-14">
                  Current Bid:{" "}
                  <span className="text-primary">
                    $12100<span>.</span>
                  </span>
                </p>
              </div>
              <div>
                <a className="btn btn-primary w-100" href="#">
                  {" "}
                  Buy{" "}
                </a>
              </div>
            </div>
          </div>
        </div> */}
      </div>
      <div className="pagination-area">
        <div aria-label="Page navigation example">
          <ul className="pagination">
            <li className="page-item">
              <a aria-label="Previous" className="page-link" href="#">
                <span aria-hidden="true">
                  <i className="far fa-arrow-left" />
                </span>
              </a>
            </li>
            <li className="page-item active">
              <a className="page-link" href="#">
                1
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                2
              </a>
            </li>
            <li className="page-item">
              <a className="page-link" href="#">
                3
              </a>
            </li>
            <li className="page-item">
              <a aria-label="Next" className="page-link" href="#">
                <span aria-hidden="true">
                  <i className="far fa-arrow-right" />
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default MyBids;
