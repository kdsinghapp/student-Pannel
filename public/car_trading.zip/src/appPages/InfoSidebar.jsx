"use client";

import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateUserApi } from "@/utils/authApi";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { LogoutToAll } from "@/utils/authApi";
import Link from "next/link";
const InfoSidebar = ({page}) => {
  const dispatch = useDispatch();
  const userData = useSelector((store) => store.userData);
  const [user, setUser] = useState({
    first_name: "",
    last_name: "",
    profile_image: "",
  });

  useEffect(() => {
    if (userData?.user?.user) {
      setUser(userData.user.user);
    }
  }, [userData]);


  //   for image upload
  const [profileImageFile, setProfileImageFile] = useState(null);
  const [previewImage, setPreviewImage] = useState(""); // Default image preview
  const fileInputRef = useRef(null);

  const handleIconClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    console.log(file.name, "file");
    if (file) {
      setProfileImageFile(file);
      const localImageUrl = URL.createObjectURL(file);
      setPreviewImage(localImageUrl);

      // Automatically upload the image after selecting
      const up = await uploadImage(file);
      console.log(up, "image");
    }
  };

  const uploadImage = async (file) => {
    try {
      const formData = new FormData();
      formData.append("profile_image", file);

      console.log("formData" , formData);
      

      // Make the API call
      const response = await updateUserApi(formData);
      if (response.status === true) {
        const uploadedImageUrl = `http://193.203.161.2:8000/${response?.user?.profile_image}`;
        console.log(uploadedImageUrl, "imagesss");
        setPreviewImage(uploadedImageUrl);
        // toast.success(response.message);
      } else {
        toast.error(response.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleLogoutFromAllDevices = async () => {
    try {
      const token = localStorage.getItem("token");
  
      console.log(token, "tokensss");
  
      const response = await LogoutToAll(token);
  
      console.log(response, "response");
  
        if (response.status) {
          toast.success(response.message, {
            autoClose: 8000, 
          });        
        localStorage.removeItem('token');
        window.location.href = '/signin'; 
      } else {
        toast.error('Failed to log out from all devices.');
      }
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('An error occurred during logout. Please try again.');
    }
  };
  

  

  return (
    <>
      <div className="user-profile-sidebar">
        <div className="user-profile-sidebar-top">
          <div
            className="user-profile-img"
            style={{
              position: "relative",
              width: "130px",
              height: "130px",
              overflow: "hidden",
              borderRadius: "50%",
              border: "2px solid #ccc",
            }}
          >
            {/* Image preview */}
            <img
              alt="User Profile"
              src={`http://193.203.161.2:8000/${user?.profile_image}`}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
              }}
            />{" "}
            <button
              className="profile-img-btn"
              type="button"
              onClick={handleIconClick}
              style={{
                position: "absolute",
                bottom: "10px",
                right: "10px",
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                border: "none",
                color: "white",
                borderRadius: "50%",
                cursor: "pointer",
              }}
            >
              <i className="far fa-camera" />
            </button>{" "}
            {/* Hidden file input */}
            <input
              className="profile-img-file"
              type="file"
              ref={fileInputRef}
              style={{ display: "none" }}
              onChange={handleFileChange}
            />
          </div>
          <h5>{user.first_name}</h5>
        </div>
        <ul className="user-profile-sidebar-list">
          <li>
            <Link href="/myaccount" className={`${page =="account" ?  "active" : ""}`}>
              <i className="far fa-home" /> My Account
            </Link>
          </li>
          <li>
            <Link className={`${page =="profile" ?  "active" : ""}`} href="/my-profile">
              <i className="far fa-user" /> My Profile
            </Link>
          </li>
          <li>
            <Link href="/favourites" className={`${page =="favourites" ?  "active" : ""}`}>
              <i className="fa fa-gavel" /> My favourite
            </Link>
          </li>
          <li>
            <Link href="/mybids" className={`${page =="bids" ?  "active" : ""}`}>
              <i className="fa fa-gavel" /> My Bids
            </Link>
          </li>
          <li>
            <Link href="/myoffer" className={`${page =="offers" ?  "active" : ""}`}>
              <i className="fa fa-gift" /> My offers
            </Link>
          </li>
          <li>
            <Link href="/mypurchase" className={`${page =="purchase" ?  "active" : ""}`}>
              <i className="fa fa-car" /> Under purchase Cars
            </Link>
          </li>
          {/* <li>
            <Link href="/myresrvedcars" className={`disable ${page =="Reserved Cars" ?  "active" : ""}`}>
              <i className="fa fa-car" /> My Reserved Cars
            </Link>
          </li> */}
          <li>
            <Link href="/track-my-car" className={`${page =="Track" ?  "active" : ""}`}>
              <i className="fa fa-car" /> Track My Cars
            </Link>
          </li>
          <li>
            <Link href="/my-buylist" className={`${page =="buy" ?  "active" : ""}`}>
              <i className="fa fa-shopping-cart" /> My Buy List
            </Link>
          </li>
          <li>
            <Link href="/chat" className={`${page =="chat" ?  "active" : ""}`}>
              <i className="fa fa-car" /> Chats
            </Link>
          </li>
          <li>
            <Link href="/valuemycar" className={`${page =="value" ?  "active" : ""}`}>
              <i className="fa fa-car" /> My Car Value
            </Link>
          </li>
          
          {/* <li>
            <Link href="#" onClick={handleLogout}>
              <i className="far fa-sign-out" /> Logout
            </Link>
          </li> */}
          <li>
            <Link href="#" onClick={handleLogoutFromAllDevices}>
              <i className="far fa-sign-out" /> Logout From All Devices
            </Link>
          </li>

        </ul>
        <ToastContainer/>
      </div>
    </>
  );
};

export default InfoSidebar;
