"use client";
import { getAllMessage, sendMessage } from '@/utils/chatApi';
import React, { useEffect, useState } from 'react'

const dummyImage = "https://static.vecteezy.com/system/resources/thumbnails/020/911/732/small/profile-icon-avatar-icon-user-icon-person-icon-free-png.png";


export default function Messages({id, text}) {

//   const messagesEndRef = useRef(null); 

  const [messages, setMessages] = useState([]);
  const [yourId, setYourId] = useState(""); 
  const [user, setUser] = useState(null);
  const [newMessage, setNewMessage] = useState(text || ""); 
  const [isSending, setIsSending] = useState(false); // Track sending state

  const getData = async () => {
    try {
      const res = await getAllMessage(id);
      setMessages(res.messages);
      setYourId(res.yourId);
      setUser(res.user);
    } catch (error) {
      console.log(error);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || isSending) {
      return; 
    }

    // Optimistically clear the input field immediately
    const tempMessage = newMessage;
    setNewMessage("");
    setIsSending(true);

    try {
      const data = {
        dealerId: user._id, 
        message: tempMessage, // Use tempMessage for consistency
      };
      
      const res = await sendMessage(data);
      setMessages([...messages, res.addedMessage]);
      setIsSending(false); // Reset sending state
      
      scrollToBottom(); 
      getData();
      
    } catch (error) {
      console.log(error);
      setIsSending(false); // Reset in case of error
      getData();
    }
  };

  // Send message on pressing Enter key
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   };

  useEffect(() => {
    getData();
  
    const intervalId = setInterval(() => {
      getData();
    }, 5000);
  
    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, []); 

//   useEffect(() => {
//     scrollToBottom(); 
//   }, [isSending]);
    
  return (
    <div className="container shadow-lg p-2" style={{ maxWidth: "100%" }}>
    {/* Chat Header */}
    <div className="card mb-3">
      <div className="card-body d-flex align-items-center">
        <img
          src={user?.profile_image ? ImageUrl() + user.profile_image : dummyImage}
          alt="Profile"
          style={{ height: "25px" }}
          className="rounded-circle me-3"
        />
        <div className="mx-3">
          <h5 className="mb-0">{user?.name || `${user?.first_name} ${user?.last_name}`}</h5>
        </div>
      </div>
    </div>

    {/* Chat Messages */}
    <div className="card p-3 mb-3" style={{ height: "400px", overflowY: "scroll" }}>
      {messages.map((message, index) => (
        <div
          key={index}
          className={`d-flex mb-3 ${message.senderId === yourId ? "justify-content-end" : "justify-content-start"}`}
        >
          <div
            className={`p-2 rounded ${message.senderId === yourId ? "bg-primary text-white" : "bg-light text-dark"}`}
            style={{ maxWidth: "75%" }}
          >
            {message.message}
          </div>
        </div>
      ))}
      <div 
    //   ref={messagesEndRef} 
      /> 
    </div>

    {/* Message Input */}
    <div className="input-group">
      <input
        type="text"
        className="form-control"
        placeholder="Type a message..."
        defaultValue={text}
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
        onKeyPress={handleKeyPress} // Handle Enter key
        disabled={isSending} // Disable input while sending
      />
      <button
        className="btn btn-primary"
        type="button"
        onClick={handleSendMessage}
        disabled={isSending} // Disable button while sending
      >
        {isSending ? "Sending..." : "Send"}
      </button>
    </div>
  </div>
  )
}
