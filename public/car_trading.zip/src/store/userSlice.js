import { createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'userData',
  initialState: { user_detail: {} },
  reducers: {
    set_user_data: (state) => {
      state.user_detail  = action.payload;
    },
  },
});

export const { set_user_data } = userSlice.actions;
export default userSlice.reducer;