import { configureStore } from '@reduxjs/toolkit';
import { createWrapper } from 'next-redux-wrapper';
import userReducer from './features/userSlice';
import carReducer from './features/carSlice';
import compareReducer from './features/compareSlice'


const makeStore = () =>
  configureStore({
     reducer: {
       userData: userReducer, 
       carData: carReducer,
       compare: compareReducer,
     },
  });

export const wrapper = createWrapper(makeStore); // Export wrapper
export const store = makeStore(); // Export store