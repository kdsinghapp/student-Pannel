import { createSlice } from '@reduxjs/toolkit';

const channelSlice = createSlice({
  name: 'counter',
  initialState: { Channel_id_stored: '' },
  reducers: {
    change_channelId: (state,action) => {
      state.Channel_id_stored = action.payload;
    },
  },
});

export const { change_channelId } = channelSlice.actions;
export default channelSlice.reducer;