import { getUserApi, signInUser } from "@/utils/authApi";
import { registerMechanic } from "@/utils/mechanicApi";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: "",
  token: "",
  isLoading: false,
  isError: false,
  isSuccess: false,
};

const userSlice = createSlice({
  name: "userData",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.isLoading = false;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.user = action.payload.user;
        state.token = action.payload.token;
        localStorage.setItem("user", JSON.stringify(action.payload.user));
        localStorage.setItem("token", action.payload.token);
      })
      .addCase(login.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.errorMessage = action.payload;
      })
      .addCase(getUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.user = action.payload;
      })
      .addCase(getUser.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.errorMessage = action.payload;
      })
      .addCase(getMechanic.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
      })
      .addCase(getMechanic.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.user = action.payload;
      })
      .addCase(getMechanic.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.errorMessage = action.payload;
      });
  },
});

export const login = createAsyncThunk("user/login", async (data, thunkAPI) => {
  try {
    return await signInUser(data);
  } catch (error) {
    const massage = error.response.data.message;
    return thunkAPI.rejectWithValue(massage);
  }
});
export const getUser = createAsyncThunk("user/get", async (_, thunkAPI) => {
  try {
    const token = localStorage.getItem("token"); // Retrieve token from local storage
    if (!token) {
      throw new Error("No token found");
    }
    const user = await getUserApi(token); // Send the token to the API
    return user;
  } catch (error) {
    const message = error.response?.data?.message || error.message;
    return thunkAPI.rejectWithValue(message);
  }
});

export const getMechanic = createAsyncThunk("mechanic/register", async (formData, thunkAPI) => {
  try {
    return await registerMechanic(formData);
  } catch (error) {
    const message = error.response?.data?.message || error.message;
    return thunkAPI.rejectWithValue(message);
  }
});

export default userSlice.reducer;
