import { getFilteredCar, getaddlatestCar, filtersCar } from "@/utils/carApi";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  car: [],
  FilterdCar: [],
  FiltersCar: [],
  pagination: {},
  isLoading: false,
  isError: false,
  isSuccess: false,
  errorMessage: "",
};

const adCarSlice = createSlice({
  name: "adCar",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getLetestCar.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.isLoading = false;
      })
      .addCase(getLetestCar.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.car = action.payload.data;
        state.pagination = action.payload.pagination;
      })
      .addCase(getLetestCar.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.errorMessage = action.payload;
      })
    //   .addCase(getFilterdCar.fulfilled, (state, action) => {
    //     state.FilterdCar = action.payload.data;
    //   })
    //   .addCase(getFiltersCar.fulfilled, (state, action) => {
    //     state.FiltersCar = action.payload.data;
    //   });
  },
});

export const getLetestCar = createAsyncThunk("user/adsletestcar", async (data, thunkAPI) => {
  try {
    return await getaddlatestCar(data);
  } catch (error) {
    const massage = error.response.data.message;
    return thunkAPI.rejectWithValue(massage);
  }
});
// export const getFilterdCar = createAsyncThunk("user/Filterd", async (data, thunkAPI) => {
//   try {
//     return await getFilteredCar(data);
//   } catch (error) {
//     const massage = error.response.data.message;
//     return thunkAPI.rejectWithValue(massage);
//   }
// });
// export const getFiltersCar = createAsyncThunk("user/filters", async (data, thunkAPI) => {
//   try {
//     return await filtersCar(data);
//   } catch (error) {
//     const message = error.response.data.message;
//     return thunkAPI.rejectWithValue(message);
//   }
// });

export default adCarSlice.reducer;
