import { createSlice } from '@reduxjs/toolkit';

const compareSlice = createSlice({
  name: 'compare',
  initialState: {
    car1: null,
    car2: null,
    car3: null,
  },
  reducers: {
    addCompareItem1: (state, action) => {
      if (!state.car1) {
        state.car1 = action.payload;
      }
    },
    addCompareItem2: (state, action) => {
      if (!state.car2) {
        state.car2 = action.payload;
      }
    },
    addCompareItem3: (state, action) => {
      if (!state.car3) {
        state.car3 = action.payload;
      }
    },
    removeCompareItem: (state, action) => {
      const { carId } = action.payload;
      if (state.car1 && state.car1._id === carId) {
        state.car1 = null;
      } else if (state.car2 && state.car2._id === carId) {
        state.car2 = null;
      } else if (state.car3 && state.car3._id === carId) {
        state.car3 = null;
      }
    },
    clearCompare: (state) => {
      state.car1 = null;
      state.car2 = null;
      state.car3 = null;
    },
  },
});

export const {
  addCompareItem1,
  addCompareItem2,
  addCompareItem3,
  removeCompareItem,
  clearCompare,
} = compareSlice.actions;

export default compareSlice.reducer;
