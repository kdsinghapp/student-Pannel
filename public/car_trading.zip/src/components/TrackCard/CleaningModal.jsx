import React from 'react'

const CleaningModal = ({ cleanNotes, setClean, handleCleanCheck }) => {
  return (
    <div
    className="modal fade"
    id="cleaningDetailsModal"
    tabIndex="-1"
    aria-labelledby="cleaningDetailsModalLabel"
    aria-hidden="true"
  >
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h4 className="modal-title" id="cleaningDetailsModalLabel">
            Cleaning Details
          </h4>
          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div className="modal-body">
          <div className="mb-3">
            <label htmlFor="mechanicalInput" className="form-label">
              Add Notes
            </label>
            <textarea
              className="form-control"
              id="mechanicalInput"
              rows="4"
              placeholder="Enter notes here"
              value={cleanNotes}
              onChange={(e) => setClean(e.target.value)}
            />
          </div>
        </div>
        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              handleCleanCheck(carIds, soldCarIds);
            }}
          >
            Proceed
          </button>
        </div>
      </div>
    </div>
  </div>
  )
}

export default CleaningModal