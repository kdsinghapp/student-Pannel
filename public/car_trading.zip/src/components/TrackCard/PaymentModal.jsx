import React, { useEffect } from "react";

const PaymentModal = ({
  handleSkipMechanical,
  handleSkipDelivery,
  handleSkipClean,
  carIds,
  soldCarIds,
  selectedItem,
}) => {
  const loadScript = (url) => {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = url;
      script.async = true;

      script.onload = () => resolve();
      script.onerror = () => reject(new Error(`Failed to load script ${url}`));

      document.body.appendChild(script);
    });
  };

  const loadPaymentGatewayScript = async () => {
    try {
      await loadScript("http://localhost:8000/testing/create-payment");
      console.log("Payment gateway script loaded successfully");
    } catch (error) {
      console.error("Failed to load payment gateway script:", error);
    }
  };

  const openPaymentGateway = () => {
    const paymentDetails = {
      amount: selectedItem?.price || 0,
      currency: "SAR",
      customerEmail: "customer@example.com", // Replace with customer email
      callbackUrl: "http://salousi.com", // Replace with your callback URL
    };
    console.log("Payment Gateway modal opened", paymentDetails);
    // Replace 'PaymentGateway' with the actual gateway method/object
    window.PaymentGateway?.initiatePayment(paymentDetails)
      .then((response) => {
        console.log("Payment successful:", response);
        // Handle success, e.g., redirect to success page or update UI
      })
      .catch((error) => {
        console.error("Payment failed:", error);
        // Handle failure, e.g., show an error message
      });
  };

  const handlePurchase = (type) => {
    switch (type) {
      case "Mechanical Check":
        console.log("Proceeding with Mechanical Check");
        break;
      case "Delivery":
        console.log("Proceeding with Delivery Details");
        break;
      case "Cleaning":
        console.log("Proceeding with Cleaning Details");
        break;
      case "Payment":
        console.log("Proceeding to Payment Gateway");
        openPaymentGateway();
        break;
      default:
        console.log("Unknown action");
    }
  };

  useEffect(() => {
    loadPaymentGatewayScript();
  }, []);

  return (
    <div
      className="modal fade"
      id="paymentModalLabel"
      tabIndex="-1"
      aria-labelledby="paymentModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog">
        <div className="modal-content" style={{ minHeight: "65vh" }}>
          <div className="modal-header">
            <h4 className="modal-title" id="paymentModalLabel">
              Pay Amount
            </h4>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body">
            <div className="d-flex flex-row align-items-stretch gap-3 mb-2">
              <button
                className="btn btn-primary"
                data-bs-toggle="modal"
                data-bs-target="#mechanicalCheckModal"
                style={{ width: "200px" }}
              >
                {!selectedItem?.mechanical && selectedItem?.mechanicskip
                  ? "Add Mechanical"
                  : "Mechanical Check"}
              </button>
              <button
                className="btn btn-primary"
                style={{ width: "200px" }}
                data-bs-toggle="modal"
                data-bs-target="#deliveryDetailsModal"
              >
                Delivery Details
              </button>
              <button
                className="btn btn-primary"
                style={{ width: "200px" }}
                data-bs-toggle="modal"
                data-bs-target="#cleaningDetailsModal"
              >
                Cleaning Details
              </button>
            </div>

            <div className="d-flex flex-row align-items-stretch gap-3 mb-2">
              {!selectedItem?.mechanical && selectedItem?.mechanicskip ? (
                <div
                  style={{
                    width: "200px",
                    marginLeft: "10px",
                    color: "black",
                  }}
                >
                  Already Skipped
                </div>
              ) : (
                <button
                  className="btn btn-secondary"
                  style={{ width: "200px" }}
                  onClick={() => handleSkipMechanical(carIds, soldCarIds)}
                >
                  Skip Mechanical
                </button>
              )}
              <button
                className="btn btn-secondary"
                style={{ width: "200px" }}
                onClick={() => handleSkipDelivery(carIds, soldCarIds)}
              >
                Skip Delivery
              </button>
              <button
                className="btn btn-secondary"
                style={{ width: "200px" }}
                onClick={() => handleSkipClean(carIds, soldCarIds)}
              >
                Skip Cleaning
              </button>
            </div>
          </div>
          <div className="modal-footer d-flex justify-content-center">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => handlePurchase("Payment")}
            >
              Proceed To Pay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
