import React from "react";
import SelectMechanic from "../common/MechanicalSteps/SelectMechanic";

const TowingService = ({
  handleTowing,
  // status,
  steps,
  activeStep,
  selectedItem,
  handlePrevStep,
  handleMechanicalCheck,
}) => {
  const status = "Accepted";
  return (
    <div
      className="modal fade"
      id="mechanicalCheckModal"
      tabIndex="-1"
      aria-labelledby="mechanicalCheckModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h4 className="modal-title" id="mechanicalCheckModalLabel">
              Towing Man
            </h4>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>

          <div className="modal-body">
            <p>Details about the Mechanical Check go here.</p>

            <div
              style={{
                textAlign: "center",
                marginBottom: "20px",
                fontSize: "16px",
              }}
            >
              {/* {status}  */}
              Status
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "20px",
                position: "relative",
              }}
            >
              {/* {steps.map((step, index) => (
                <React.Fragment key={step.id}>
                  <div
                    style={{
                      padding: "10px",
                      borderRadius: "50%",
                      backgroundColor:
                        activeStep >= index ? "#0d6efd" : "#e0e0e0",
                      color: activeStep >= index ? "#fff" : "#000",
                      textAlign: "center",
                      width: "40px",
                      height: "40px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      zIndex: 1,
                      position: "relative",
                    }}
                  >
                    <span>{index + 1}</span>
                  </div>

                  {index < steps.length - 1 && (
                    <div
                      style={{
                        flex: 1,
                        height: "2px",
                        backgroundColor:
                          activeStep >= index + 1 ? "#0d6efd" : "#e0e0e0",
                        zIndex: 0,
                        margin: "0 5px",
                      }}
                    />
                  )}
                </React.Fragment>
              ))} */}
            </div>
            {status === "Uploaded" && (
              <div
                style={{
                  textAlign: "center",
                  marginBottom: "20px",
                  fontSize: "16px",
                }}
              >
                Reviewing your payment
              </div>
            )}
            {status === "Accepted" && (
              <div
                style={{
                  textAlign: "center",
                  marginBottom: "20px",
                  fontSize: "16px",
                }}
              >
                Accepted
              </div>
            )}
            {status !== "New Check" &&
              status !== "Uploaded" &&
              status !== "Accepted" &&
              status !== "Report" && <SelectMechanic car={selectedItem} />}

            {status == "New Check" && activeStep === 1 && (
              <>
                <div className="mb-3 text-center">
                  <h5>Amount: ${amount}</h5>
                </div>
              </>
            )}
            {activeStep === 2 && (
              <>
                <div className="mb-3">
                  <label htmlFor="uploadFile" className="form-label">
                    Upload your Payment Proof
                  </label>
                  <input
                    type="file"
                    className="form-control"
                    id="uploadFile"
                    onChange={handleFileChange}
                  />
                </div>
              </>
            )}
          </div>

          {/* Footer with Forward and Backward Buttons */}

          {activeStep !== 3 && (
            <div className="modal-footer d-flex justify-content-between">
              {/* Backward Button */}
              <div style={{ width: "200px" }}>
                {" "}
                {/* Set width here */}
                {activeStep !== 1 && (
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handlePrevStep}
                    disabled={activeStep === 0}
                    style={{ width: "100%" }} // Full width of the div
                  >
                    Back
                  </button>
                )}
              </div>

              {/* Middle Buttons */}
              <div style={{ width: "200px" }}>
                {" "}
                {/* Set width here */}
                {status !== "New Check" &&
                  status !== "Uploaded" &&
                  status !== "Accepted" &&
                  status !== "Report" && (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => {
                        handleMechanicalCheck(carIds, soldCarIds);
                        handleAddNotes();
                      }}
                      style={{ width: "100%" }} // Full width of the div
                    >
                      Add
                    </button>
                  )}
                {activeStep === 1 && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handlePay}
                    style={{ width: "100%" }} // Full width of the div
                  >
                    Pay
                  </button>
                )}
                {activeStep === 2 && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleUpload}
                    style={{ width: "100%" }}
                  >
                    Upload
                  </button>
                )}
              </div>

              {/* Forward Button */}
              <div style={{ width: "200px" }}>
                {" "}
                {/* Set width here */}
                {activeStep !== 0 && activeStep !== 2 && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleNextStep}
                    disabled={activeStep === steps.length - 1}
                    style={{ width: "100%" }}
                  >
                    Forward
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TowingService;
