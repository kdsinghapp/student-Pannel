import React from "react";

const DeliveryDetails = ({
  handleDeliveryCheck,
  pincode,
  handlePincodeChange,
  address,
  handleAddressChange,
  notes,
  handleNotesChange,
}) => {
  return (
    <div
      className="modal fade"
      id="deliveryDetailsModal"
      tabIndex="-1"
      aria-labelledby="deliveryDetailsModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h4 className="modal-title" id="deliveryDetailsModalLabel">
              Delivery Details
            </h4>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body">
            <div className="mb-3">
              <label htmlFor="pincode" className="form-label">
                Enter your Pincode:
              </label>
              <input
                type="text"
                className="form-control"
                id="pincode"
                placeholder="Enter Pincode"
                value={pincode}
                onChange={handlePincodeChange}
                maxLength="6" // Assuming Indian pincode format
              />
            </div>
            <div className="mb-3">
              <label htmlFor="address" className="form-label">
                Enter your Address:
              </label>
              <input
                type="text"
                className="form-control"
                id="address"
                placeholder="Enter Address"
                value={address}
                onChange={handleAddressChange}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="notes" className="form-label">
                Delivery Notes:
              </label>
              <textarea
                className="form-control"
                id="notes"
                rows="3"
                placeholder="Add any special instructions here"
                value={notes}
                onChange={handleNotesChange}
              />
            </div>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                // handlePurchase("Delivery");
                handleDeliveryCheck(carIds, soldCarIds);
              }}
            >
              Proceed
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryDetails;
