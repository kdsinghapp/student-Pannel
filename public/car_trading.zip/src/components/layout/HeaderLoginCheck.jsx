"use client";
import { getUser } from "@/store/features/userSlice";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Logout } from "@/utils/authApi";
const HeaderLoginCheck = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();

  const userData = useSelector((store) => store?.userData);

  const getUserFn = async () => {
    try {
      await dispatch(getUser()).unwrap();
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  useEffect(() => {
    getUserFn();
  }, [router.pathname]); // Run on route change

  useEffect(() => {
    // setTimeout(() => {
    //   console.log("userData?.user?.user1", userData?.user);
    //   if (!userData?.user) {
    //     setIsLoggedIn(false);
    //   } else {
    //     setIsLoggedIn(true);
    //   }
    // }, 2000);
    if (userData?.user) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [userData]);

  // const [isLoggedInUser, setIsLoggedInUser] = useState(false);

  // useEffect(() => {
  //   if (typeof window !== "undefined") {
  //     const user = localStorage.getItem("user");
  //     setIsLoggedIn(!!user);
  //   }
  // }, []);

  const handleLogout = async () => {
    try {
      const token = localStorage.getItem("token");
  
      console.log(token, "tokensss");
  
      const response = await Logout(token);
  
      console.log(response, "response");
  
        if (response.status) {
          toast.success(response.message, {
            autoClose: 8000, 
          });        
        localStorage.removeItem('token');
        window.location.href = '/signin'; 
      } else {
        toast.error('Failed to log out from all devices.');
      }
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('An error occurred during logout. Please try again.');
    }
  };

  return (
    <div className="header-top-link">
      {isLoggedIn ? (
        <>
          <a href="/my-profile">
            <i className="far fa-profile" /> View profile
          </a>{" "}
          <button onClick={handleLogout} className="btn btn-primary">
            Sign Out
          </button>
        </>
      ) : (
        <>
          <Link href="/signin">
            <i className="far fa-arrow-right-to-arc" /> Sign In
          </Link>{" "}
          <Link href="/signup">
            <i className="far fa-user-vneck" /> Sign Up
          </Link>
        </>
      )}
    </div>
  );
};

export default HeaderLoginCheck;
