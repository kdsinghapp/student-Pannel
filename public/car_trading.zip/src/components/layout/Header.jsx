import GetUser from "@/utils/GetUser";
import React from "react";
import HeaderLoginCheck from "./HeaderLoginCheck";
import Link from "next/link";

const Header = () => {
  return (
    <header className="header">
      <GetUser />
      <div className="header-top">
        <div className="container">
          <div className="header-top-wrapper">
            <div className="header-top-left">
              <div className="header-top-contact">
                <ul>
                  <li>
                    <a href="#">
                      <i className="far fa-envelopes" />{" "}
                      <span
                        className="__cf_email__"
                        data-cfemail="dab3b4bcb59abfa2bbb7aab6bff4b9b5b7"
                      >
                        test@mail.com
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:+21236547898">
                      <i className="far fa-phone-volume" /> +XX XXXXXXXXXX
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="header-top-right">
            <HeaderLoginCheck />
            
              <div className="header-top-social">
                <select className="btn btn-secondary">
                  <option>English</option>
                  <option>Arabic</option>
                </select>
              </div>
            </div>
           
          </div>
        </div>
      </div>
      <div className="main-navigation">
        <nav className="navbar navbar-expand-lg">
          <div className="container position-relative">
            <a className="navbar-brand" href="/">
              <h3
                style={{
                  color: "#000",
                  textTransform: "uppercase",
                  fontWeight: "bold",
                }}
              >
                Sayarat
              </h3>
            </a>
            <div className="mobile-menu-right">
              <div className="search-btn">
                <button className="nav-right-link" type="button">
                  <i className="far fa-search" />
                </button>
              </div>
              <button
                aria-expanded="false"
                aria-label="Toggle navigation"
                className="navbar-toggler"
                data-bs-target="#main_nav"
                data-bs-toggle="collapse"
                type="button"
              >
                <span className="navbar-toggler-mobile-icon">
                  <i className="far fa-bars" />
                </span>
              </button>
            </div>
            <div className="collapse navbar-collapse" id="main_nav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" href="/">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" href="#">
                    About Us
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" href="/recently-added-cars">
                    Added Car List
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" href="#">
                    Contact Us
                  </Link>
                </li>
              </ul>
              <div className="nav-right">
                <div className="nav-right-btn mt-2">
                  <a className="theme-btn" href="#">
                    <span className="far fa-car" />
                    Dealer Portal
                  </a>
                </div>
              </div>
            </div>
            <div className="search-area">
              <form action="#">
                <div className="form-group">
                  <input
                    className="form-control"
                    placeholder="Type Keyword..."
                    type="text"
                  />{" "}
                  <button className="search-icon-btn" type="submit">
                    <i className="far fa-search" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
