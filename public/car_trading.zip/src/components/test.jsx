"use client";
import React, { useState } from "react";

const CarValuePredict = () => {
  const [formData, setFormData] = useState({
    location: "",
    condition: "",
    color: "Select One",
    accidentHistory: "Select One",
    rentalCar: "Select One",
    previousOwners: "",
    years: "",
    make: "",
    model: "",
    mileage: "",
    style: "",
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [predictionResult, setPredictionResult] = useState(null);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.location) newErrors.location = "Location is required";
    if (!formData.condition) newErrors.condition = "Condition is required";
    if (formData.color === "Select One") newErrors.color = "Please select a color";
    if (formData.accidentHistory === "Select One") newErrors.accidentHistory = "Please select an option";
    if (formData.rentalCar === "Select One") newErrors.rentalCar = "Please select an option";
    if (!formData.years) newErrors.years = "Year is required";
    if (!formData.make) newErrors.make = "Make is required";
    if (!formData.model) newErrors.model = "Model is required";
    if (!formData.mileage) newErrors.mileage = "Mileage is required";
    if (!formData.style) newErrors.style = "Please select a car style";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      // Replace with your actual API call
      const res = await valuePredictCar(formData);
      setPredictionResult(res.data);
    } catch (error) {
      setErrors({ submit: "Failed to predict value. Please try again." });
    } finally {
      setIsLoading(false);
    }
  };

  // Helper function to render error messages
  const renderError = (fieldName) => {
    return errors[fieldName] ? (
      <div className="text-danger small mt-1">{errors[fieldName]}</div>
    ) : null;
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="row justify-content-center">
        <div className="col-lg-5">
          <div className="row">
            <div className="car-widget">
              {/* Location */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Location</label>
                </div>
                <div className="col-md-8">
                  <input
                    className={`form-control ${errors.location ? "is-invalid" : ""}`}
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                  />
                  {renderError("location")}
                </div>
              </div>

              {/* Condition */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Condition</label>
                </div>
                <div className="col-md-8">
                  <input
                    className={`form-control ${errors.condition ? "is-invalid" : ""}`}
                    type="text"
                    name="condition"
                    value={formData.condition}
                    onChange={handleChange}
                  />
                  {renderError("condition")}
                </div>
              </div>

              {/* Color */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Color</label>
                </div>
                <div className="col-md-8">
                  <select
                    className={`form-control ${errors.color ? "is-invalid" : ""}`}
                    name="color"
                    value={formData.color}
                    onChange={handleChange}
                  >
                    <option>Select One</option>
                    <option>Red</option>
                    <option>Black</option>
                    <option>White</option>
                    <option>Silver</option>
                  </select>
                  {renderError("color")}
                </div>
              </div>

              {/* Accident History */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Had accident</label>
                </div>
                <div className="col-md-8">
                  <select
                    className={`form-control ${errors.accidentHistory ? "is-invalid" : ""}`}
                    name="accidentHistory"
                    value={formData.accidentHistory}
                    onChange={handleChange}
                  >
                    <option>Select One</option>
                    <option>No</option>
                    <option>Yes</option>
                  </select>
                  {renderError("accidentHistory")}
                </div>
              </div>

              {/* Rental Car */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Rental car</label>
                </div>
                <div className="col-md-8">
                  <select
                    className={`form-control ${errors.rentalCar ? "is-invalid" : ""}`}
                    name="rentalCar"
                    value={formData.rentalCar}
                    onChange={handleChange}
                  >
                    <option>Select One</option>
                    <option>No</option>
                    <option>Yes</option>
                  </select>
                  {renderError("rentalCar")}
                </div>
              </div>

              {/* Previous Owner */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Previous owner</label>
                </div>
                <div className="col-md-8">
                  <input
                    className="form-control"
                    type="text"
                    name="previousOwners"
                    value={formData.previousOwners}
                    onChange={handleChange}
                  />
                </div>
              </div>

              {/* Years */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Years</label>
                </div>
                <div className="col-md-8">
                  <div className="year-range-box">
                    <div className="year-range-input">
                      <input
                        className={`form-control ${errors.years ? "is-invalid" : ""}`}
                        id="year"
                        type="text"
                        name="years"
                        value={formData.years}
                        onChange={handleChange}
                      />
                    </div>
                    {renderError("years")}
                    <div className="year-range" />
                  </div>
                </div>
              </div>

              {/* Make */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Make</label>
                </div>
                <div className="col-md-8">
                  <input
                    className={`form-control ${errors.make ? "is-invalid" : ""}`}
                    type="text"
                    name="make"
                    value={formData.make}
                    onChange={handleChange}
                  />
                  {renderError("make")}
                </div>
              </div>

              {/* Model */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Model</label>
                </div>
                <div className="col-md-8">
                  <input
                    className={`form-control ${errors.model ? "is-invalid" : ""}`}
                    type="text"
                    name="model"
                    value={formData.model}
                    onChange={handleChange}
                  />
                  {renderError("model")}
                </div>
              </div>

              {/* Mileage */}
              <div className="form-group mb-3 row">
                <div className="col-md-4">
                  <label>Mileage</label>
                </div>
                <div className="col-md-8">
                  <input
                    className={`form-control ${errors.mileage ? "is-invalid" : ""}`}
                    type="text"
                    name="mileage"
                    value={formData.mileage}
                    onChange={handleChange}
                  />
                  {renderError("mileage")}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Style Selection */}
        <div className="col-lg-7">
          <div className="form-group mb-3 row">
            <div className="col-md-12">
              <label>Style {errors.style && <span className="text-danger">*</span>}</label>
              <div className="row">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => (
                  <div className="col-md-3 col-6" key={`c${num}`}>
                    <div className="checkbox-container mb-2">
                      <input
                        id={`c${num}`}
                        name="style"
                        type="radio"
                        value={`style${num}`}
                        checked={formData.style === `style${num}`}
                        onChange={handleChange}
                      />
                      <label className="checkbox-label" htmlFor={`c${num}`}>
                        <img
                          src={`assets/img/carstyle${num}.png`}
                          alt={`Car style ${num}`}
                        />
                      </label>
                    </div>
                  </div>
                ))}
              </div>
              {renderError("style")}
            </div>
          </div>
        </div>

        {errors.submit && (
          <div className="alert alert-danger">
            {errors.submit}
          </div>
        )}

        {predictionResult && (
          <div className="alert alert-success">
            Estimated Value: ${predictionResult.value}
          </div>
        )}

        <div className="form-group mb-3 mt-3 row">
          <div className="col-md-12 text-center">
            <button
              className="theme-btn w-50"
              type="submit"
              disabled={isLoading}
            >
              {isLoading ? "Valuing..." : "Value my car"}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default CarValuePredict;