import React from 'react'

const AdvertisedCarCard = () => {
  return (
    <div>Advertised Car Card</div>
  )
}

export default AdvertisedCarCard