"use client";

import { changePasswordUserApi } from "@/utils/authApi";
import React, { useState } from "react";
import Swal from "sweetalert2";

const ChangePassword = () => {
  const [formData, setFormData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Validate form before submitting
  const validateForm = () => {
    const { oldPassword, newPassword, confirmPassword } = formData;

    if (!oldPassword || !newPassword || !confirmPassword) {
      Swal.fire("Error", "All fields are required!", "error");
      return false;
    }
    if (newPassword.length < 6) {
      Swal.fire(
        "Error",
        "New password must be at least 6 characters long.",
        "error"
      );
      return false;
    }
    if (newPassword !== confirmPassword) {
      Swal.fire("Error", "Passwords do not match!", "error");
      return false;
    }
    return true;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      const res = await changePasswordUserApi(formData);

      if (res.status) {
        Swal.fire("Success", "Password changed successfully!", "success");
        setFormData({ oldPassword: "", newPassword: "", confirmPassword: "" });
      } else {
        Swal.fire(
          "Error",
          res.message || "Failed to change password.",
          "error"
        );
      }
    } catch (error) {
      Swal.fire(
        "Error",
        "Something went wrong. Please try again later.",
        "error"
      );
    }
  };

  return (
    <div className="user-profile-card">
      <h4 className="user-profile-card-title">Change Password</h4>
      <div className="col-lg-12">
        <div className="user-profile-form">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Old Password</label>
              <input
                className="form-control"
                placeholder="Old Password"
                type="password"
                name="oldPassword"
                value={formData.oldPassword}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <label>New Password</label>
              <input
                className="form-control"
                placeholder="New Password"
                type="password"
                name="newPassword"
                value={formData.newPassword}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <label>Re-Type Password</label>
              <input
                className="form-control"
                placeholder="Re-Type Password"
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
              />
            </div>
            <button className="theme-btn my-3" type="submit">
              <span className="far fa-key" /> Change Password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;
