import React from "react";

const InterestedInFav = ({car,handleOptionChange,handleSubmit}) => {
  return (
    <div className="car-single-widget">
      <h5 className="mb-3">I am Interested In</h5>
      <div className="car-single-form">
        <form action="#">
          <div className="row">
            <div className="form-group col-lg-6">
              <div className="checkbox-container">
                <input
                  type="radio"
                  id="availability"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Is your ${car.car_name} available?`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="availability"
                  className={`checkbox-label ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Is your ${car.car_name} available?`
                      ? "selected"
                      : ""
                  }`}
                >
                  This Vehicle Availability
                </label>
              </div>
            </div>
            <div className="form-group col-lg-6">
              <div className="checkbox-container">
                <input
                  type="radio"
                  id="more-info"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="more-info"
                  className={`checkbox-label ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=I need More Information about ${car.car_name}.`
                      ? "selected"
                      : ""
                  }`}
                >
                  More Information
                </label>
              </div>
            </div>
            <div className="form-group col-lg-6">
              <div className="checkbox-container">
                <input
                  type="radio"
                  id="test-drive"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="test-drive"
                  className={`checkbox-label ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Can you Schedule a Test Drive for your ${car.car_name}.`
                      ? "selected"
                      : ""
                  }`}
                >
                  Schedule a Test Drive
                </label>
              </div>
            </div>
            <div className="form-group col-lg-6">
              <div className="checkbox-container">
                <input
                  type="radio"
                  id="history-report"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Can I get Vehicle History Report for your ${car.car_name}.`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="history-report"
                  className={`checkbox-label ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Can I get Vehicle History Report for your ${car.car_name}.`
                      ? "selected"
                      : ""
                  }`}
                >
                  Vehicle History Report
                </label>
              </div>
            </div>
            <div className="form-group col-lg-6">
              <label className="mt-2">
                Message{" "}
                <input
                  type="radio"
                  id="edit-inquiry"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="edit-inquiry"
                  className={`checkbox-label checkbox-label-message text-primary ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Inquiry for ${car.car_name}.`
                      ? "selected"
                      : ""
                  }`}
                >
                  Edit Inquiry
                </label>
              </label>
            </div>
            <div className="form-group col-lg-6">
              <div className="checkbox-container">
                <input
                  type="radio"
                  id="hold-1day"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="hold-1day"
                  className={`checkbox-label ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Can you hold your ${car.car_name} for 1 Day.`
                      ? "selected"
                      : ""
                  }`}
                >
                  Hold for 1 Day
                </label>
              </div>
            </div>
            <div className="form-group col-lg-12">
              <label>
                <input
                  type="radio"
                  id="available"
                  name="car-option"
                  value={`/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`}
                  onChange={handleOptionChange}
                  style={{ display: "none" }}
                />
                <label
                  htmlFor="available"
                  className={`checkbox-label checkbox-label-text ${
                    selectedOption ===
                    `/chat/${car?.dealer}?text=Is your used 2008 ${car.car_name} Car listed for $50,560 Still Available?`
                      ? "selected"
                      : ""
                  }`}
                >
                  Is your used 2008 {car.car_name} Car listed for $50,560 Still
                  Available?
                </label>
              </label>
            </div>
            <div className="form-group col-lg-12">
              <button
                className="theme-btn  w-100 text-white"
                onClick={handleSubmit}
                disabled={!selectedOption}
              >
                Send Request to Seller <i className="fas fa-arrow-right-long" />
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InterestedInFav;
