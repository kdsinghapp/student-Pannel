import { getCityList } from "@/utils/carApi";
import { getMechanicList, sendRequest } from "@/utils/mechanicApi";
import React, { useEffect, useState } from "react";

export default function SelectMechanic({ car }) {
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);
  const [mechanics, setMechanics] = useState([]);
  const [loadingMechanics, setLoadingMechanics] = useState(false);
  const [selectedMechanic, setSelectedMechanic] = useState(null);
  console.log("Mechanic here:-", mechanics)

  const [hoveredMechanicId, setHoveredMechanicId] = useState(null);
  // Fetch list of cities
  const getData = async () => {
    try {
      const getCities = await getCityList();
      setCities(getCities?.data || []);
    } catch (error) {
      console.error("Error fetching cities:", error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const handleCityChange = async (event) => {
    const city = event.target.value;
    setSelectedCity(city);
    setSelectedMechanic(null);

    if (city) {
      setLoadingMechanics(true);
      try {
        const payload = {
          city,
          vehicleType: car.car?.car_type || "Sedan",
        };
        const response = await getMechanicList(payload);

        // Simulating mechanic data with descriptions for hover
        const mechanicsWithDescriptions = response?.data?.map((mechanic) => ({
          ...mechanic,
          description: `Mechanic ${mechanic.firstName} specializes in ${mechanic.specialization}.`,
          fieldDescription: `Experience: ${mechanic.experience} years. Skill: ${mechanic.skillLevel}`,
        }));

        setMechanics(mechanicsWithDescriptions || []);
      } catch (error) {
        console.error("Error fetching mechanics:", error);
        setMechanics([]);
      } finally {
        setLoadingMechanics(false);
      }
    } else {
      setMechanics([]);
    }
  };

  const handleMechanicSelect = (mechanic) => {
    setSelectedMechanic(mechanic);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const carId = car?.car._id;
    const userId = car?.user;
    const amount = selectedMechanic?.prices[0]?.price;
    const soldId = car?._id;
    const mechanicId = selectedMechanic._id;

    if (!carId || !userId || !amount || !mechanicId) {
      alert("Failed to submit: Missing required information.");
      return;
    }

    const payload = {
      userId,
      carId,
      soldId,
      mechanicId,
      amount,
    };

    try {
      const response = await sendRequest(payload);
      if (response?.status) {
        alert("Mechanic selection submitted successfully.");
      } else {
        alert("Failed to submit mechanic selection.");
      }
    } catch (error) {
      console.error("Error submitting mechanic selection:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* Select City Dropdown */}
      <div className="mb-3">
        <label htmlFor="citySelect" className="form-label">
          Select City
        </label>
        <select
          id="citySelect"
          className="form-select"
          value={selectedCity || ""}
          onChange={handleCityChange}
        >
          <option value="">Choose a city</option>
          {cities.map((city) => (
            <option key={city.id} value={city.city_name}>
              {city.city_name}
            </option>
          ))}
        </select>
      </div>

      {/* Mechanics List */}
      <div className="mechanics-list">
        {loadingMechanics ? (
          <p>Loading mechanics...</p>
        ) : mechanics.length > 0 ? (
          <div className="row">
            {mechanics.map((mechanic) => (
              <div
                key={mechanic.id}
                className="col-md-4 mb-3"
                onClick={() => handleMechanicSelect(mechanic)}
                onMouseEnter={() => setHoveredMechanicId(mechanic._id)}
                onMouseLeave={() => setHoveredMechanicId(null)}
                style={{ position: "relative", cursor: "pointer"}}
              >
                <div
                  className="card ml-4"
                  style={{
                    border:
                      selectedMechanic?.id === mechanic.id
                        ? "2px solid blue"
                        : "1px solid #ddd",
                  }}
                >
                  <div className="card-body text-center">
                    <h5 className="card-title">
                      {mechanic.firstName} {mechanic.lastName}
                    </h5>
                    <p className="card-text">Price: ${mechanic.prices[0].price}</p>
                  </div>
                </div>

                {hoveredMechanicId === mechanic._id && (
                  <div
                    style={{
                      position: "absolute",
                      top: "80%",
                      left: "50%",
                      transform: "translateX(-50%)",
                      backgroundColor: "rgba(0, 0, 0, 0.7)",
                      color: "white",
                      padding: "10px",
                      borderRadius: "6px",
                      whiteSpace: "normal",
                      zIndex: 1000,
                      boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.2)",
                      width: "70%",
                      textAlign: "center",
                    }}
                  >
                    {mechanic.inspection.map((task, index) => (
                      <div key={index} style={{ display: "flex" }}>
                        <p style={{ margin: "5px 0", fontWeight: "bold" }}>
                          {task}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p>No mechanics found for the selected city.</p>
        )}
      </div>

      {mechanics.length > 0 && (
        <div>
          <button
            type="submit"
            className="btn btn-primary mt-3"
            disabled={!selectedMechanic}
          >
            {selectedMechanic ? "Submit Selection" : "Choose a mechanic first"}
          </button>
        </div>
      )}
    </form>
  );
}
