import {
  cancelBid,
  cancelOffer,
  editOffer,
  ImageUrl,
  purchaseNow,
} from "@/utils/carApi";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { proseedBuyUser } from "@/utils/carApi";
const PurchasePageCount = ({ item, getData }) => {
  const [offerAmount, setOfferAmount] = useState("");
  const modalId = `modal-${item?._id}`;
  const [note, setNote] = useState(""); // State to handle the note input

  // Function to handle the purchase process
  const handlePurchase = async (status) => {
    try {
      const data = {
        carId: item?.car?._id, // car ID from item
        status, // Online or Offline
        note, // User's note
      };

      const response = await proseedBuyUser(data);

      if (response.status) {
        toast.success(response.message);
        getData(); // Refresh data after successful purchase
      } else {
        toast.error(response.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.error("Error processing purchase:", error);
    }
  };

  return (
    <>
      <div key={item?._id} className="col-md-6 col-lg-12">
        <div className="car-item">
          <div className="col-md-3">
            <div className="col-md-12 col-lg-12 mb-2">
              <h6>
                <a href="#" className="me-3">
                  {item?.car?.car_name}
                </a>{" "}
              </h6>
            </div>
            <div className="">
              <img
                alt=""
                src={ImageUrl() + item?.car?.image}
                style={{
                  width: "100%",
                  borderRadius: 10,
                }}
              />
            </div>
          </div>
          <div className="car-content sideborder col-md-6">
            <div className="car-top">
              {/* <p>
                <a href="#">
                  <i className="fa fa-camera" /> Gallery
                </a>
              </p> */}
            </div>
            <ul className="car-list">
              <li>Exterior: {item?.car?.Exterior}</li>
              <li>Interior: {item?.car?.car_interior_color}</li>
              <li>Trans.: {item?.car?.car_transmission}</li>
              <li>Doors: {item?.car?.car_door}</li>
              <li>Engine: {item?.car?.car_engine_capacity}</li>
              <li>Mileage: {item?.car?.Mileage}</li>
            </ul>
          </div>
          <div className="btnns col-md-3">
            <div>
              <p className="car-price f-14">
                <span className="text-primary">Amount:</span> $
                {item?.car?.car_price}
              </p>
              <p className="car-price f-14">
                <p>
                  Current Status :{" "}
                  {item?.status === "Price Accepted"
                    ? item?.status + " by user"
                    : item?.status}
                </p>
              </p>
            </div>

            <div>
              <button
                className="btn btn-primary w-100"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target={`#${modalId}`} // Target the unique modal id
                disabled={item?.status == "Buy Offline"}
              >
                {""}
                Buy{""}
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Modal */}
      <div
        className="modal fade"
        id={modalId}
        tabIndex="-1"
        aria-labelledby={`${modalId}Label`}
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">
              <h4 className="modal-title" id={`${modalId}Label`}>
                {item?.car?.car_name}
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            {/* Modal Body */}
            <div className="modal-body">
              <div className="row">
                {/* Price */}
                <div className="col-2">
                  <h6>Price:</h6>
                </div>
                <div className="col-2">
                  <h6>
                    <strong>${item.car.car_price}</strong>
                  </h6>
                </div>

                {/* Dealer Name */}
                <div className="col-2">
                  <h6>Dealer Name:</h6>
                </div>
                <div className="col-2">
                  <h6>
                    <strong>{item.dealer.name}</strong>
                  </h6>
                </div>
              </div>

              {/* Input field for note */}
              <div className="row mt-3">
                <div className="col-12">
                  <label htmlFor="noteInput" className="form-label">
                    Add Note:
                  </label>
                  <textarea
                    id="noteInput"
                    className="form-control"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Enter your note here"
                    rows="4" // Adjust number of rows for the textarea
                  />
                </div>
              </div>

              {/* Buttons for Online/Offline */}
              <div className="row mt-3">
                <div className="col-6 text-center">
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handlePurchase("Online")}
                  >
                    Proceed Online
                  </button>
                </div>
                <div className="col-6 text-center">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => handlePurchase("Offline")}
                  >
                    Proceed Offline
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PurchasePageCount;
