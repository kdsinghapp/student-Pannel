"use client";
var $ = require("jquery");
import dynamic from "next/dynamic";
if (typeof window !== "undefined") {
  window.$ = window.jQuery = require("jquery");
}

import React from "react";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";

const OwlCarousel = dynamic(() => import("react-owl-carousel"), {
  ssr: false,
});

const options = {
  loop: true,
  items: 4,
  autoplay: true,
  // nav: true,
  // dots:true,
  responsive: {
    0: {
      items: 1,
    },
    768: {
      items: 2,
    },
    992: {
      items: 4,
    },
    1200: {
      items: 4,
    },
  },
};

const Testimonials = () => {
  return (
    <div className="testimonial-area bg py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 mx-auto">
            <div className="site-heading text-center">
              <span className="site-title-tagline">
                <i className="flaticon-drive" /> Testimonials
              </span>
              <h2 className="site-title">
                What Our Client <span>Say&apos;s</span>
              </h2>
              <div className="heading-divider" />
            </div>
          </div>
        </div>
        {/* <div className="testimonial-slider row owl-carousel owl-theme">
          <div className="testimonial-single col-lg-3">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/01.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Sylvia H Green</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single col-lg-3">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/02.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Gordo Novak</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single col-lg-3">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/03.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Reid E Butt</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single col-lg-3">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/04.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Parker Jimenez</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single col-lg-3">
              <div className="testimonial-content">
                <div className="testimonial-author-img">
                  <img alt="" src="assets/img/testimonial/05.jpg" />
                </div>
                <div className="testimonial-author-info">
                  <h4>Heruli Nez</h4>
                  <p>Customer</p>
                </div>
              </div>
              <div className="testimonial-quote">
                <span className="testimonial-quote-icon">
                  <i className="flaticon-quote" />
                </span>
                <p>
                  There are many variations of passages available but the majority
                  have suffered to the alteration in some injected.
                </p>
              </div>
              <div className="testimonial-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" />
              </div>
            </div>
        </div> */}
        <OwlCarousel className="owl-theme testimonial-slider" {...options}>
          <div className="testimonial-single mx-2">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/01.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Sylvia H Green</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single mx-2">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/02.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Gordo Novak</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single mx-2">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/03.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Reid E Butt</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single mx-2">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/04.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Parker Jimenez</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
          <div className="testimonial-single mx-2">
            <div className="testimonial-content">
              <div className="testimonial-author-img">
                <img alt="" src="assets/img/testimonial/05.jpg" />
              </div>
              <div className="testimonial-author-info">
                <h4>Heruli Nez</h4>
                <p>Customer</p>
              </div>
            </div>
            <div className="testimonial-quote">
              <span className="testimonial-quote-icon">
                <i className="flaticon-quote" />
              </span>
              <p>
                There are many variations of passages available but the majority
                have suffered to the alteration in some injected.
              </p>
            </div>
            <div className="testimonial-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" />
            </div>
          </div>
        </OwlCarousel>
      </div>
    </div>
  );
};

export default Testimonials;
