"use client";
import { getLetestCar } from "@/store/features/carSlice";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer } from "react-toastify";
import AdvertisedCarCard from "./AdvertisedCarCard";
import { getaddlatestCar } from "@/utils/carApi";

const AdvertisedCars = () => {
  const dispatch = useDispatch();
  const [cars, setCars] = useState([]);
  const adCarData = useSelector((store) => store.adCarData);

  console.log("cars", cars);
  const getCarFn = async () => {
    try {
      const res = await getaddlatestCar()
      console.log("Response:-",res);
      
    } catch (error) {
      
    }
  };

  useEffect(() => {
    getCarFn();
  }, []);

  useEffect(() => {
    setCars(adCarData?.car);
  }, [adCarData]);
  return (
    <div className="row">
      {cars?.map((item) => (
        <AdvertisedCarCard key={item._id} item={item} />
      ))}
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".25s">
          <div className="car-img">
            <span className="car-status status-1">Used</span>{" "}
            <img alt="" src="assets/img/car/01.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">Mercedes Benz Car</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$45,620</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* <ToastContainer /> */}

      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".50s">
          <div className="car-img">
            <img alt="" src="assets/img/car/02.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">Yellow Ferrari 458</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$90,250</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".75s">
          <div className="car-img">
            <img alt="" src="assets/img/car/03.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">Black Audi Q7</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$44,350</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay="1s">
          <div className="car-img">
            <span className="car-status status-2">New</span>{" "}
            <img alt="" src="assets/img/car/04.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">BMW Sports Car</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$78,760</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".25s">
          <div className="car-img">
            <span className="car-status status-1">Used</span>{" "}
            <img alt="" src="assets/img/car/05.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">White Tesla Car</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$64,230</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".50s">
          <div className="car-img">
            <span className="car-status status-2">New</span>{" "}
            <img alt="" src="assets/img/car/06.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">White Nissan Car</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$34,540</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay=".75s">
          <div className="car-img">
            <img alt="" src="assets/img/car/07.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">Mercedes Benz Suv</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$75,820</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6 col-lg-4 col-xl-3">
        <div className="car-item wow fadeInUp" data-wow-delay="1s">
          <div className="car-img">
            <img alt="" src="assets/img/car/08.jpg" />
            <div className="car-btns">
              <a href="#">
                <i className="far fa-heart" />
              </a>{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
            </div>
          </div>
          <div className="car-content">
            <div className="car-top">
              <h4>
                <a href="#">Red Hyundai Car</a>
              </h4>
              <div className="car-rate">
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span>
              </div>
            </div>
            <ul className="car-list">
              <li>
                <i className="far fa-steering-wheel" />
                Automatic
              </li>
              <li>
                <i className="far fa-road" />
                10.15km / 1-litre
              </li>
              <li>
                <i className="far fa-car" />
                Model: 2023
              </li>
              <li>
                <i className="far fa-gas-pump" />
                Hybrid
              </li>
            </ul>
            <div className="car-footer">
              <span className="car-price">$25,620</span>{" "}
              <a
                className="btn btn-primary"
                href="javascript:void();"
                data-bs-toggle="modal"
                data-bs-target="#myModal"
              >
                <span className="far fa-eye" /> Quick View
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvertisedCars;
