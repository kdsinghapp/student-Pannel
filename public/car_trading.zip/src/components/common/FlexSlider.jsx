// components/FlexSlider.js
import { useEffect } from 'react';
import $ from 'jquery';

const FlexSlider = () => {
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Load jQuery
      const jqueryScript = document.createElement('script');
      jqueryScript.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
      jqueryScript.async = true;
      jqueryScript.onload = () => {
        // Load FlexSlider after jQuery
        const flexsliderScript = document.createElement('script');
        flexsliderScript.src = '/assets/js/flex-slider.js';
        flexsliderScript.async = true;
        flexsliderScript.onload = () => {
          console.log('FlexSlider script loaded');
          $('.flexslider').flexslider({
            animation: 'slide',
            controlNav: 'thumbnails',
          });
        };
        document.body.appendChild(flexsliderScript);
      };
      document.body.appendChild(jqueryScript);
    }
  }, []);

  return (
    <>
      <link rel="stylesheet" href="/assets/css/flex-slider.min.css" />
      <div className="item-gallery">
        <div className="flexslider-thumbnails flexslider">
          <ul className="slides">
            <li data-thumb="/assets/img/car/single-1.jpg">
              <img alt="Car 1" src="/assets/img/car/single-1.jpg" />
            </li>
            <li data-thumb="/assets/img/car/single-2.jpg">
              <img alt="Car 2" src="/assets/img/car/single-2.jpg" />
            </li>
            <li data-thumb="/assets/img/car/single-3.jpg">
              <img alt="Car 3" src="/assets/img/car/single-3.jpg" />
            </li>
            <li data-thumb="/assets/img/car/single-4.jpg">
              <img alt="Car 4" src="/assets/img/car/single-4.jpg" />
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default FlexSlider;
