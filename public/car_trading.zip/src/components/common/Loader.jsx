import React from "react";

const Loader = () => {
  return (
    <div className="preloader">
      <div className="loader-ripple">
        <div />
        <div />
      </div>
    </div>
  );
};

export default Loader;
