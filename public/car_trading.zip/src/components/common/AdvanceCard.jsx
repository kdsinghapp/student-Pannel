"use client";

import React, { useState, useRef, useEffect } from "react";
import { getCityList, getMakerList } from "@/utils/carApi";
import { getFiltersCar } from "@/store/features/carSlice";
import { useDispatch, useSelector } from "react-redux";
import CarCard from "./CarCard";
import Slider from "rc-slider";
import "rc-slider/assets/index.css"; // Import rc-slider styles
import Image from "next/image";

const AdvancedSearchForm = () => {
  const dispatch = useDispatch();
  const formRef = useRef();

  const [citys, setCitys] = useState([]);
  const [makers, setMakers] = useState([]);
  const [minPrice, setMinPrice] = useState(0); // Default to 0
  const [maxPrice, setMaxPrice] = useState(100000); // Set a reasonable max value
  const [car_maker_id, setCarMakerId] = useState('');
  const [car_city_id, setCarCityId] = useState('');
  const [car_condition, setCarCondition] = useState('');
  const [cars, setCars] = useState([]);
  const [fuelType, setFuelType] = useState('');
  const [engine_size, setEngineSize] = useState('');
  const [kilometers, setKilometers] = useState('');
  const [transmission, setTransmission] = useState('');
  const [minSeat, setMinSeat] = useState(2);  // Default minimum seat
  const [maxSeat, setMaxSeat] = useState(8);  // Default maximum seat
  const [minYear, setMinYear] = useState(2000); // Set default min year
  const [maxYear, setMaxYear] = useState(2024); // Set default max year
  const [selectedCarStyle, setSelectedCarStyle] = useState("");

  const carData = useSelector((store) => store.carData.FiltersCar);

  // Fetching city and maker data
  const fetchInitialData = async () => {
    try {
      const getmakers = await getMakerList();
      const getcitys = await getCityList();
      setMakers(getmakers?.data || []);
      setCitys(getcitys?.data || []);
    } catch (error) {
      console.error("Error fetching makers and cities data", error);
    }
  };

  useEffect(() => {
    fetchInitialData();
  }, []);

  // Submit handler
  const handleSearch = async (e) => {
    e.preventDefault();

    const data = {
      minYear,
      maxYear,
      minPrice,
      maxPrice,
      car_maker_id,
      car_city_id,
      car_condition,
      car_type: selectedCarStyle,
      fuelType,
      engine_size,
      kilometers,
      transmission,
      minSeat,
      maxSeat
    };



    try {
      console.log(data, "data for filters");

      dispatch(getFiltersCar(data));

    } catch (error) {
      console.error("Error fetching filtered cars data", error);
    }
  };

  useEffect(() => {
    setCars(carData || []);
  }, [carData]);


  const carStyles = [
    // { id: "c1", label: "", imgSrc: "/assets/img/carstyle1.png" },
    { id: "c1", label: "AWD/4WD", imgSrc: "/assets/img/carstyle1.png" },
    { id: "c2", label: "Commercial", imgSrc: "/assets/img/carstyle2.png" },
    { id: "c3", label: "Convertible", imgSrc: "/assets/img/carstyle3.png" },
    { id: "c4", label: "Coupe", imgSrc: "/assets/img/carstyle4.png" },
    { id: "c5", label: "Hatchback", imgSrc: "/assets/img/carstyle5.png" },
    { id: "c6", label: "Hybrid/Electric", imgSrc: "/assets/img/carstyle6.png" },
    { id: "c7", label: "Luxury", imgSrc: "/assets/img/carstyle7.png" },
    { id: "c8", label: "Sedan", imgSrc: "/assets/img/carstyle8.png" },
    { id: "c9", label: "SUV/Crossover", imgSrc: "/assets/img/carstyle9.png" },
    { id: "c10", label: "Truck", imgSrc: "/assets/img/carstyle10.png" },
    { id: "c11", label: "Van/Minivan", imgSrc: "/assets/img/carstyle11.png" },
    { id: "c12", label: "Wagon", imgSrc: "/assets/img/carstyle12.png" }
  ];


  return (
    <>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <div className="card">
              <div className="card-header">
                <h4>Advanced Search</h4>
              </div>
              <form onSubmit={handleSearch}>
                <div className="car-widget">
                  {/* Location (City) Field */}
                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Location</label>
                    </div>
                    <div className="col-md-10">
                      <select className="form-control" value={car_city_id} onChange={(e) => setCarCityId(e.target.value)}>
                        <option value="">Select City</option>
                        {citys.map((city) => (
                          <option key={city._id} value={city._id}>
                            {city?.city_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Condition Field */}
                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Condition</label>
                    </div>
                    <div className="col-md-10">
                      <select className="form-control" value={car_condition} onChange={(e) => setCarCondition(e.target.value)}>
                        <option value="">Select car condition</option>
                        <option value="New">New</option>
                        <option value="Like New">Like New</option>
                        <option value="Very Good">Very Good</option>
                        <option value="Good">Good</option>
                        <option value="Fair">Fair</option>
                        <option value="Salvage">Salvage</option>
                        <option value="Old">Old</option>
                      </select>
                    </div>
                  </div>

                  {/* Price Range Slider */}
                  <div className="form-group mb-3 row">
                    <div className="col-md-12">
                      <label>Price Range</label>
                      <Slider
                        range
                        min={0}
                        max={100000} // Change this to your desired max price
                        value={[minPrice, maxPrice]}
                        onChange={(value) => {
                          setMinPrice(value[0]);
                          setMaxPrice(value[1]);
                        }}
                        railStyle={{ backgroundColor: '#ddd' }}
                        trackStyle={[{ backgroundColor: '#519bdd' }, { backgroundColor: '#519bdd' }]}
                        handleStyle={[{ backgroundColor: '#fff', border: '2px solid #519bdd' }, { backgroundColor: '#fff', border: '2px solid #519bdd' }]}
                      />
                      <div className="price-range-labels">
                        <span>Min Price: ${minPrice}</span>
                        <span className="float-end">Max Price: ${maxPrice}</span>
                      </div>
                    </div>
                  </div>

                  {/* Model Year Field */}
                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Year Range</label>
                    </div>
                    <div className="col-md-10">
                      <Slider
                        range
                        min={1990} // Set your minimum year
                        max={2024} // Set your maximum year
                        defaultValue={[minYear, maxYear]} // Initial values
                        value={[minYear, maxYear]} // Controlled value
                        onChange={([newMinYear, newMaxYear]) => {
                          setMinYear(newMinYear);
                          setMaxYear(newMaxYear);
                        }}
                        trackStyle={[{ backgroundColor: '#519bdd' }]} // Custom track color
                        handleStyle={[
                          { backgroundColor: '#fff', borderColor: '#519bdd' },
                          { backgroundColor: '#fff', borderColor: '#519bdd' },
                        ]} // Custom handle color
                        railStyle={{ backgroundColor: '#ddd' }} // Custom rail color
                      />
                      <div className="year-range-labels">
                        <span>Min Year: {minYear}</span>
                        <span className="float-end">Max Year: {maxYear}</span>
                      </div>
                    </div>
                  </div>



                  {/* Make (Car Maker) Field */}
                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Maker</label>
                    </div>
                    <div className="col-md-10">
                      <select className="form-control" value={car_maker_id} onChange={(e) => setCarMakerId(e.target.value)}>
                        <option value="">Select Maker</option>
                        {makers.map((maker) => (
                          <option key={maker._id} value={maker._id}>
                            {maker?.car_maker_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Fuel Type</label>
                    </div>
                    <div className="col-md-10">
                      <select
                        className="form-control"
                        value={fuelType}
                        onChange={(e) => setFuelType(e.target.value)}
                      >
                        <option value="">Select Fuel Type</option>
                        <option value="Petrol">Petrol</option>
                        <option value="Diesel">Diesel</option>
                        <option value="Hybrid">Hybrid</option>
                        <option value="Electric">Electric</option>
                      </select>
                    </div>
                  </div>


                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Engine Size</label>
                    </div>
                    <div className="col-md-10">
                      <input
                        type="number"
                        className="form-control"
                        placeholder="Enter Engine Size"
                        value={engine_size}
                        onChange={(e) => setEngineSize(e.target.value)}
                      />
                    </div>
                  </div>
                  {/* <div className="form-group mb-3 row">
                    <div className="col-md-2">
                        <label> Car Type</label>
                      </div>
                      <div className="col-md-10">

                        <select
                          className="form-control"
                          value={car_type}
                          onChange={(e) => setCarType(e.target.value)}
                          
                        >
                          <option value="" disabled>
                            Select car type
                          </option>
                          <option value="Passenger Car">Passenger Car</option>
                          <option value="Sports Car">Sports Car</option>
                          <option value="Utility Vehicle">
                            Utility Vehicle
                          </option>
                          <option value="Commercial Vehicle">
                            Commercial Vehicle
                          </option>
                          <option value="Off-Road Vehicle">
                            Off-Road Vehicle
                          </option>
                        </select>
                       </div>
                      </div> */}


                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Kilometers</label>
                    </div>
                    <div className="col-md-10">
                      <input
                        type="number"
                        className="form-control"
                        placeholder="Enter Kilometers"
                        value={kilometers}
                        onChange={(e) => setKilometers(e.target.value)}
                      />
                    </div>
                  </div>


                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Transmission</label>
                    </div>
                    <div className="col-md-10">
                      <select
                        className="form-control"
                        value={transmission}
                        onChange={(e) => setTransmission(e.target.value)}
                      >
                        <option value="">Select Transmission</option>
                        <option value="Manual">Manual</option>
                        <option value="Automatic">Automatic</option>
                        <option value="Semi-Automatic">Semi-Automatic</option>
                        <option value="CVT">
                          CVT (Continuously Variable Transmission)
                        </option>
                        <option value="Dual-Clutch">Dual-Clutch</option>
                      </select>
                    </div>
                  </div>

                  <div className="form-group mb-3 row">
                    <div className="col-md-2">
                      <label>Seat Range</label>
                    </div>
                    <div className="col-md-10">
                      <Slider
                        range
                        min={1} // Set minimum seat value
                        max={8} // Set maximum seat value
                        defaultValue={[minSeat, maxSeat]} // Initial values
                        value={[minSeat, maxSeat]} // Controlled value
                        onChange={([newMinSeat, newMaxSeat]) => {
                          setMinSeat(newMinSeat);
                          setMaxSeat(newMaxSeat);
                        }}
                        trackStyle={[{ backgroundColor: '#519bdd' }]} // Custom track color
                        handleStyle={[
                          { backgroundColor: '#fff', borderColor: '#519bdd' },
                          { backgroundColor: '#fff', borderColor: '#519bdd' },
                        ]} // Custom handle color
                        railStyle={{ backgroundColor: '#ddd' }} // Custom rail color
                      />
                      <div className="seat-range-labels">
                        <span>Min Seats: {minSeat}</span>
                        <span className="float-end">Max Seats: {maxSeat}</span>
                      </div>
                    </div>
                  </div>

                  <div className="form-group mb-3 row">
                    <div className="col-md-12">
                      <label>Style</label>
                      <div className="row">
                        {carStyles.map((style) => (
                          <div className="col-md-3 col-6" key={style.id}>
                            <div className="checkbox-container mb-2">
                              <input
                                type="radio"
                                id={style.id}
                                name="carStyle"
                                value={style.label}
                                checked={selectedCarStyle === style.label}
                                // Step 3: Update state on selection
                                onChange={() => setSelectedCarStyle(style.label)}
                              />
                              <label htmlFor={style.id} className="checkbox-label">
                                <Image width={100} height={100} src={style.imgSrc} alt={style.label} />
                              </label>
                            </div>
                          </div>
                        ))}
                      </div>


                    </div>
                  </div>




                  {/* Submit Button */}
                  <div className="form-group mb-3 mt-5 row">
                    <div className="col-md-12 text-center">
                      <input type="submit" className="theme-btn w-50" value="Search" />
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div className="container">

        <div className="row">
          {cars?.map((item) => (
            <CarCard key={item._id} item={item} />
          ))}
        </div>
      </div>
    </>
  );
};

export default AdvancedSearchForm;
