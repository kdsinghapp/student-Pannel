"use client";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CarCard from "./CarCard";

const FilterCars = () => {
  const dispatch = useDispatch();
  const [cars, setCars] = useState([]);
  const carData = useSelector((store) => store.carData);

  console.log("cars", cars);

  useEffect(() => {
    setCars(carData?.FilterdCar);
  }, [carData]);

  if (cars.length > 0)
    return (
      <div className="car-area bg py-120">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 mx-auto">
              <div className="site-heading text-center">
                <span className="site-title-tagline">
                  <i className="flaticon-drive" /> Your search
                </span>
                <h2 className="site-title">
                <i className="flaticon-search" />  Your Perfect <span>Cars</span>
                </h2>
                <div className="heading-divider" />
              </div>
            </div>
          </div>

          <div className="row">
            {cars?.map((item) => (
              <CarCard key={item._id} item={item} />
            ))}
          </div>
        </div>
      </div>
    );
  else {
    return "";
  }
};

export default FilterCars;
