import { cancelBid, cancelOffer, editOffer, ImageUrl, purchaseNow } from "@/utils/carApi";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const OfferPageCount = ({ item, getData }) => {
  const [offerAmount, setOfferAmount] = useState("");
  
  const handleCancel = async (carId) => {
    const data = {
      carId,
    };
    try {
      const res = await cancelOffer(data);
      getData();
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error("An error occurred while processing your request.");
    }
  };

  const handleOffer = async (e) => {
    e.preventDefault();
    // if (!isLoggedIn) {
    //   toast.error("Please Login.");
    //   return;
    // }

    const data = {
      amount: offerAmount,
      offerId: item?._id,
    };
    try {
      const res = await editOffer(data);
      console.log(res);
      if (res.status) {
        toast.success(res.message);
        getData();
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }

    // Handle the response as needed
  };

  const handlePurchaseNow = async (carId) => {
    // e.preventDefault();
    // if (!isLoggedIn) {
    //   toast.error("Please Login.");
    //   return;
    // }

    const data = {
      carId: carId,
    };
    try {
      const res = await purchaseNow(data);
      getData();
      if (res.status) {
        toast.success(res.message);
      } else {
        toast.error(res.message);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      console.log("error", error);
    }
  };

  return (
    <>
      <div key={item?._id} className="col-md-6 col-lg-12">
        <div className="car-item">
          <div className="col-md-3">
            <div className="col-md-12 col-lg-12 mb-2">
              <h6>
                <a href="#" className="me-3">
                  {item?.car?.car_name}
                </a>{" "}
              </h6>
            </div>
            <div className="">
              <img
                alt=""
                src={ImageUrl() + item?.car?.image}
                style={{
                  width: "100%",
                  borderRadius: 10,
                }}
              />
            </div>
          </div>
          <div className="car-content sideborder col-md-6">
            <div className="car-top">
              {/* <p>
                <a href="#">
                  <i className="fa fa-camera" /> Gallery
                </a>
              </p> */}
            </div>
            <ul className="car-list">
              <li>Exterior: {item?.car?.Exterior}</li>
              <li>Interior: {item?.car?.car_interior_color}</li>
              <li>Trans.: {item?.car?.car_transmission}</li>
              <li>Doors: {item?.car?.car_door}</li>
              <li>Engine: {item?.car?.car_engine_capacity}</li>
              <li>Mileage: {item?.car?.Mileage}</li>
              <li>status: {item?.status}</li>
            </ul>
          </div>
          {item?.status === "New offer" ? (
               <div className="btnns col-md-3">
               <div>
                 <p className="car-price f-14">
                   <span className="text-primary">Price:</span> $
                   {item?.car?.car_price}
                 </p>
                 <p className="car-price f-14">
                   <span className="text-warning">Your Offer: </span>$
                   {item?.amount}
                 </p>
               </div>
   
               <div className="mb-2 mt-2">
                 <a
                   className="btn btn-primary w-100 text-white"
                   data-bs-toggle="modal"
                   data-bs-target={`#${item?._id}`} // Target the unique modal id
                 >
                   Adjust Offer
                 </a>
                 {/* <button
                   onClick={() => handleCancel(item?.car?._id)}
                   className="btn btn-primary w-100"
                 >
                   Adjust Offer
                 </button> */}
               </div>
               <div className="mb-2 mt-2">
                 <button
                   onClick={() => handleCancel(item?.car?._id)}
                   className="btn btn-danger w-100"
                   >
                   Cancel Offer
                 </button>
               </div>
               <div>
                 <button
                   onClick={() => handlePurchaseNow(item?.car?._id)}
                  className="btn btn-primary w-100" href="#">
                   Buy At Full Price
                 </button>
               </div>
             </div>
              ) : (
                ""
              )}
              {item?.status === "Rejected" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your bid was <br />
                      <span className="text-danger">
                        not accepted <span />
                      </span>
                    </p>
                    <p className="car-price f-14">
                      Add new bid with higher value
                    </p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Current Bid:{" "}
                      <span className="text-primary">{item?.amount}</span>
                    </p>
                  </div>
                  <div>
                    {/* <a className="btn btn-primary w-100" href="#">
                    Adjust Bid{" "}
                  </a> */}
                  </div>
                </div>
              ) : (
                ""
              )}
              {item?.status === "Accepted" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your Offer was <br />
                      <span style={{ color: "green" }}>
                        {" "}
                        Accepted <span />
                      </span>
                    </p>
                    <p className="car-price f-14">
                      Pay amount and buy car
                    </p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Offer Amount:{" "}
                      <span className="text-primary">
                        ${item?.amount}
                        <span>.</span>
                      </span>
                    </p>
                  </div>
                  <div>
                    <a className="btn btn-primary w-100" href="#">
                      {" "}
                      Buy{" "}
                    </a>
                  </div>
                </div>
              ) : (
                ""
              )}
              {item?.status === "Canceled Automatically" ? (
                <div className="btnns col-md-3">
                  <div>
                    <p className="car-price f-14">
                      Your bid was <br />
                      <span className="text-danger">
                        Canceled Automatically <span />
                      </span>
                    </p>
                    <p className="car-price f-14">Car was sold or removed</p>
                  </div>
                  <div className="mb-2 mt-2">
                    <p className="car-price f-14">
                      Price: <br />
                      <span className="text-primary">
                        ${item?.car?.car_price}
                        <span>.</span>
                      </span>
                    </p>
                  </div>
                </div>
              ) : (
                ""
              )}
        </div>
      </div>

      <div
        className="modal fade"
        id={item?._id}
        tabIndex="-1"
        aria-labelledby={`${item?._id}Label`}
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">Update Offer</div>
            {/* Modal Body */}
            <div className="modal-body">
              {/* <form className="row pb-4"> */}
                <form className="row pb-4" onSubmit={handleOffer}>
                <div className="col-7">
                  <input
                    onChange={(e) => setOfferAmount(e.target.value)}
                    type="number"
                    // value={item?.amount}
                    placeholder="Your new Offred ammount"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div className="col-5">
                  <button
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    type="submit"
                    className="btn btn-secondary"
                  >
                    Update Offer
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default OfferPageCount;
