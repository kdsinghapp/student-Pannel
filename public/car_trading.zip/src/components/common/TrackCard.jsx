"use client";

import { userBuyList } from "@/utils/carApi";
import React, { useEffect, useState } from "react";
import { ImageUrl } from "@/utils/carApi";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  Mechanical,
  PaymentProof,
  DeliveryCheck,
  CleaningCheck,
} from "@/utils/authApi";
import SelectMechanic from "./MechanicalSteps/SelectMechanic";

const MyTrack = () => {
  const [list, setList] = useState();
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");
  console.log("List",list);
  

  const getData = async () => {
    try {
      const res = await userBuyList();
      setList(res?.data);
      console.log(res?.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getData();
  }, [status]);

  const handlePurchase = (type) => {
    switch (type) {
      case "Mechanical Check":
        console.log("Proceeding with Mechanical Check");
        break;
      case "Delivery":
        console.log("Proceeding with Delivery Details");
        break;
      case "Cleaning":
        console.log("Proceeding with Cleaning Details");
        break;
      case "Payment":
        console.log("Proceeding with Cleaning Details");
        break;
      default:
        console.log("Unknown action");
    }

    // Close modal after action
    const modal = document.querySelector(".modal.show");
    if (modal) {
      const modalInstance = bootstrap.Modal.getInstance(modal);
      modalInstance.hide();
    }
  };

  // JSON data representing step statuses

  const steps = [
    { id: 0, status: "" },
    { id: 1, status: "New Check" },
    { id: 2, status: "Price Accepted" },
    { id: 3, status: "Uploaded" },
    { id: 4, status: "Accepted" },
    { id: 5, status: "Report" },
  ];
  const [activeStep, setActiveStep] = useState(0);
  const [amount, setAmount] = useState(null);
  const [showPayButton, setShowPayButton] = useState(false);
  const [showUploadButton, setShowUploadButton] = useState(false);
  const [isMechanicalSkipped, setIsMechanicalSkipped] = useState(false);
  const [mechanicCheckNote, setMechanicCheckNote] = useState("");
  const [carIds, setCarId] = useState(null);
  const [mechenicalId, setMechenicalId] = useState(null);
  const [DeliveryId, setDeliveryId] = useState(null);
  const [soldCarIds, setSoldCarId] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);

  const [pincode, setPincode] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [cleanNotes, setClean] = useState("");

  const handlePincodeChange = (e) => {
    setPincode(e.target.value);
  };

  const handleAddressChange = (e) => {
    setAddress(e.target.value);
  };

  const handleNotesChange = (e) => {
    setNotes(e.target.value);
  };

  useEffect(() => {
    const stepIndex = steps.findIndex((step) => step.status === status);
    if (stepIndex !== -1) {
      setActiveStep(stepIndex);
    }
  }, [status]);

  const getNextStep = () => {
    const currentStatus = steps[activeStep].status;
    const nextStep = steps.findIndex(
      (step) => step.status === getNextStatus(currentStatus)
    );
    return nextStep !== -1 ? nextStep : activeStep;
  };

  const getPrevStep = () => {
    const currentStatus = status;
    const prevStep = steps.findIndex(
      (step) => step.status === getPrevStatus(currentStatus)
    );
    return prevStep !== -1 ? prevStep : activeStep;
  };

  const getNextStatus = (currentStatus) => {
    const currentIndex = steps.findIndex(
      (step) => step.status === currentStatus
    );
    if (currentIndex < steps.length - 1) {
      return steps[currentIndex + 1].status;
    }
    return currentStatus;
  };

  const getPrevStatus = (currentStatus) => {
    const currentIndex = steps.findIndex(
      (step) => step.status === currentStatus
    );
    if (currentIndex > 0) {
      return steps[currentIndex - 1].status;
    }
    return currentStatus;
  };

  const handleNextStep = () => {
    const nextStep = getNextStep();
    setActiveStep(nextStep);
    setShowPayButton(false);
  };

  const handlePrevStep = () => {
    // Directly move from Step 3 (index 2) to Step 2 (index 1)
    if (activeStep === 2) {
      setActiveStep(1);
      setShowUploadButton(true); // Show the upload button again if coming back from the upload step
    } else {
      const prevStep = getPrevStep();
      setActiveStep(prevStep);
    }
  };
  // Function to handle the "Add" button
  const handleAddNotes = async () => {
    try {
      // Log current status for debugging
      console.log(status, "statusssss");

      // Send mechanical check data first
      await sendMechanicalData(
        carIds,
        soldCarIds,
        mechanicCheckNote,
        100,
        false
      ); // Adjust carIds, soldCarIds, etc., as per your requirements

      // Now fetch updated data from the backend
      await getData();

      // Move to the next step after successfully adding the notes
      const nextStep = getNextStep();
      setActiveStep(nextStep);

      // Set amount and show the "Pay" button after notes are added
      setAmount(100);
      setShowPayButton(true);

      // Optionally, update the status based on the next step
      const updatedStatus = steps[nextStep]?.status || "";
      setStatus(updatedStatus); // Set new status to trigger re-render based on the next step
    } catch (error) {
      console.error("Error adding notes and updating status:", error);
      toast.error("Failed to update notes.");
    }
  };

  // Function to handle the "Pay" button
  const handlePay = () => {
    const nextStep = getNextStep();
    setActiveStep(nextStep);
    setShowPayButton(false); // Hide pay button
    setShowUploadButton(true); // Show the upload button after payment
  };
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  // Function to handle the "Upload" button
  const handleUpload = async () => {
    console.log(file, "file being uploaded");
    try {
      const token = localStorage.getItem("token");

      if (!file) {
        toast.error("Please select an image to upload");
        return;
      }

      // Prepare the form data for file upload
      const formData = new FormData();
      formData.append("image", file); // Append the selected image file
      formData.append("MechenicalId", mechenicalId); // Append the mechanical ID

      // API call to upload the payment proof
      const response = await PaymentProof(formData, token); // Assuming PaymentProof sends the POST request
      console.log(response, "response");

      if (response.status) {
        toast.success("Payment proof uploaded successfully.");

        // Move to the next step (Step 4 in your case)
        const nextStep = getNextStep();
        setActiveStep(nextStep); // This should move from Step 3 to Step 4
        setShowUploadButton(false); // Hide the upload button after upload

        // Optionally, update the status based on the next step
        const updatedStatus = steps[nextStep]?.status || "";
        setStatus(updatedStatus);
        setActiveStep(nextStep); // This should move from Step 3 to Step 4

        // Fetch updated data after uploading proof (optional if needed)
        await getData();
      } else {
        toast.error("Failed to upload proof.");
      }
    } catch (error) {
      console.error("Error uploading payment proof:", error);
      toast.error("Failed to upload proof. Please try again.");
    }
  };

  const sendMechanicalData = async (
    carId,
    SoldCarId,
    mechanicCheckNote,
    amount,
    isSkip
  ) => {
    try {
      const token = localStorage.getItem("token");

      const data = {
        carId,
        SoldCarId,
        mechanicCheckNote,
        amount,
        isSkip,
      };
      const response = await Mechanical(data, token); // Assuming this function sends the data to your API
      console.log(response);
    } catch (error) {
      // toast.error(error.response.data.message);
      // console.log(error);
    }
  };
  const sendDeliveryData = async (
    carId,
    SoldCarId,
    DeliveryNote,
    amount,
    pincode,
    isSkip
  ) => {
    try {
      const token = localStorage.getItem("token");

      const data = {
        carId,
        SoldCarId,
        DeliveryNote,
        amount,
        pincode,
        isSkip,
      };
      const response = await DeliveryCheck(data, token); // Assuming this function sends the data to your API
      toast.success("Delivery check updated successfully!");
      console.log(response);
    } catch (error) {
      // toast.error(error.response.data.message);
      // console.log(error);
    }
  };
  const sendCleaningData = async (
    carId,
    SoldCarId,
    CleaningNote,
    amount,
    isSkip
  ) => {
    try {
      const token = localStorage.getItem("token");

      const data = {
        carId,
        SoldCarId,
        CleaningNote,
        amount,
        isSkip,
      };
      const response = await CleaningCheck(data, token); // Assuming this function sends the data to your API
      toast.success("Cleaning check updated successfully!");
      console.log(response);
    } catch (error) {
      // toast.error(error.response.data.message);
      // console.log(error);
    }
  };

  // Function to handle Mechanical Check
  const handleMechanicalCheck = (carIds, soldCarIds) => {
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const note = mechanicCheckNote;
    const amount = 200;
    sendMechanicalData(carId, SoldCarId, note, amount, false); // isSkip false for check
  };
  const handleDeliveryCheck = (carIds, soldCarIds) => {
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const note = notes;
    const amount = 200;
    // const address = address;
    const pincode1 = pincode;
    sendDeliveryData(carId, SoldCarId, note, amount, pincode1, false); // isSkip false for check
  };
  const handleCleanCheck = (carIds, soldCarIds) => {
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const CleaningNote = cleanNotes;
    const amount = 200;
    sendCleaningData(carId, SoldCarId, CleaningNote, amount, false); // isSkip false for check
  };

  // Function to handle Skip Mechanical
  const handleSkipMechanical = (carIds, soldCarIds) => {
    console.log(carIds, soldCarIds, "idss");
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const note = notes;
    const amount = 200;
    sendMechanicalData(carId, SoldCarId, note, amount, true); // isSkip true for skip
  };
  const handleSkipDelivery = (carIds, soldCarIds) => {
    console.log(carIds, soldCarIds, "idss");
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const note = mechanicCheckNote;
    const amount = 0;
    sendDeliveryData(carId, SoldCarId, note, amount, true); // isSkip true for skip
  };
  const handleSkipClean = (carIds, soldCarIds) => {
    console.log(carIds, soldCarIds, "idss");
    const carId = carIds;
    const SoldCarId = soldCarIds;
    const CleaningNote = cleanNotes;
    const amount = 0;
    sendDeliveryData(carId, SoldCarId, CleaningNote, amount, true); // isSkip true for skip
  };

  const handleNoteChange = (e) => {
    setMechanicCheckNote(e.target.value); // Update note state as the user types
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="col-lg-12">
      <div className="row">
        {list?.map((item) => (
          <div key={item?._id} className="col-md-6 col-lg-12">
            <div className="car-item">
              <div className="col-md-3">
                <div className="col-md-12 col-lg-12 mb-2">
                  <h6>
                    <a href="#" className="me-3">
                      {item?.car?.car_name}
                    </a>
                  </h6>
                </div>
                <div>
                  <img
                    alt=""
                    src={ImageUrl() + item?.car?.image}
                    style={{ width: "100%", borderRadius: 10 }}
                  />
                </div>
              </div>
              <div className="car-content sideborder col-md-6">
                <ul className="car-list">
                  <li>Exterior: {item?.car?.Exterior}</li>
                  <li>Interior: {item?.car?.car_interior_color}</li>
                  <li>Trans.: {item?.car?.car_transmission}</li>
                  <li>Doors: {item?.car?.car_door}</li>
                  <li>Engine: {item?.car?.car_engine_capacity}</li>
                  <li>Mileage: {item?.car?.Mileage}</li>
                </ul>
                <ul>
                  <li> {formatDate(item?.date)} </li>
                </ul>
                {item.status === "Online purchase" && (
                  <p className="car-price f-14">
                    Current Status:{" "}
                    {item?.status === "Price Accepted"
                      ? item?.status + " by user"
                      : item?.status}
                  </p>
                )}
                {item.status === "Online purchase" && (
                  <button
                    className="btn btn-primary mb-2"
                    data-bs-toggle="modal"
                    data-bs-target="#paymentModalLabel"
                    style={{ width: "200px" }}
                    onClick={() => {
                      setSoldCarId(item._id); // Set soldCarId based on item
                      setCarId(item.car._id);
                      setMechenicalId(item?.machenical?._id); // Set carId based on item
                      setIsMechanicalSkipped(item?.mechanicskip);
                      setSelectedItem(item);
                      setStatus(item?.machenical?.status);
                    }}
                  >
                    Pay Amount
                  </button>
                )}
              </div>

              <div className="btnns col-md-3">
                <div>
                  <p className="car-price f-14">
                    <span className="text-primary">Amount:</span> $
                    {item?.car?.car_price}
                  </p>
                  {item.status !== "Online purchase" && (
                    <p className="car-price f-14">
                      Current Status:{" "}
                      {item?.status === "Price Accepted"
                        ? item?.status + " by user"
                        : item?.status}
                    </p>
                  )}
                </div>

                {item.status === "Online purchase" && (
                  <div className="d-flex flex-column align-items-stretch">
                    <button
                      className="btn btn-primary mb-2"
                      data-bs-toggle="modal"
                      data-bs-target="#mechanicalCheckModal"
                      style={{ width: "200px" }}
                      onClick={() => {
                        setSoldCarId(item._id); // Set soldCarId based on item
                        setCarId(item.car._id);
                        setMechenicalId(item?.machenical?._id); // Set carId based on item
                        setIsMechanicalSkipped(item?.mechanicskip);
                        setSelectedItem(item);
                        setStatus(item?.machenical?.status);
                      }}
                    >
                      {item
                        ? // Check if 'item' exists
                        !item.machenical && item.mechanicskip
                          ? "Add Mechanical" // If 'machenical' is false and 'mechanicskip' is true
                          : "Mechanical Check" // If 'machenical' is false and 'mechanicskip' is false
                        : item?.machenical && !item?.mechanicskip
                          ? "Check Status" // If 'machenical' is true and 'mechanicskip' is false
                          : null // Handle cases where neither condition is met
                      }
                    </button>
                    <button
                      className="btn btn-primary mb-2"
                      data-bs-toggle="modal"
                      data-bs-target="#deliveryDetailsModal"
                      style={{ width: "200px" }}
                      onClick={() => {
                        setSoldCarId(item._id); // Set soldCarId based on item
                        setCarId(item.car._id);
                        setDeliveryId(item?.delivery?._id); // Set carId based on item
                        setSelectedItem(item);
                      }}
                    >
                      Delivery Details
                    </button>
                    <button
                      className="btn btn-primary mb-2"
                      data-bs-toggle="modal"
                      data-bs-target="#cleaningDetailsModal"
                      style={{ width: "200px" }}
                      onClick={() => {
                        setSoldCarId(item._id); // Set soldCarId based on item
                        setCarId(item.car._id);
                        setSelectedItem(item);
                      }}
                    >
                      Cleaning Details
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mechanical Check Modal */}
      <div
        className="modal fade"
        id="mechanicalCheckModal"
        tabIndex="-1"
        aria-labelledby="mechanicalCheckModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title" id="mechanicalCheckModalLabel">
                Mechanical Check
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            <div className="modal-body">
              <p>Details about the Mechanical Check go here.</p>

              {/* Stepper component */}
              <div
                style={{
                  textAlign: "center",
                  marginBottom: "20px",
                  fontSize: "16px",
                }}
              >
                {status}
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "20px",
                  position: "relative",
                }}
              >
                {steps.map((step, index) => (
                  <React.Fragment key={step.id}>
                    {/* Render the circle */}
                    <div
                      style={{
                        padding: "10px",
                        borderRadius: "50%",
                        backgroundColor:
                          activeStep >= index ? "#0d6efd" : "#e0e0e0",
                        color: activeStep >= index ? "#fff" : "#000",
                        textAlign: "center",
                        width: "40px",
                        height: "40px",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        zIndex: 1,
                        position: "relative",
                      }}
                    >
                      <span>{index + 1}</span>
                    </div>

                    {/* Render the connecting line, except after the last step */}
                    {index < steps.length - 1 && (
                      <div
                        style={{
                          flex: 1,
                          height: "2px",
                          backgroundColor:
                            activeStep >= index + 1 ? "#0d6efd" : "#e0e0e0",
                          zIndex: 0,
                          margin: "0 5px",
                        }}
                      />
                    )}
                  </React.Fragment>
                ))}
              </div>
              {status === "Uploaded" && (
                <div
                  style={{
                    textAlign: "center",
                    marginBottom: "20px",
                    fontSize: "16px",
                  }}
                >
                  Reviewing your payment
                </div>
              )}
              {status === "Accepted" && (
                <div
                  style={{
                    textAlign: "center",
                    marginBottom: "20px",
                    fontSize: "16px",
                  }}
                >
                  Accepted
                </div>
              )}
              {/* Add Notes section */}
              {status !== "New Check" &&
                status !== "Uploaded" &&
                status !== "Accepted" &&
                status !== "Report" && (
                  // <div className="mb-3">
                  //   <label htmlFor="mechanicalInput" className="form-label">
                  //     Add Notes
                  //   </label>
                  //   <textarea
                  //     className="form-control"
                  //     id="mechanicalInput"
                  //     rows="4"
                  //     placeholder="Enter notes here"
                  //     value={mechanicCheckNote}
                  //     onChange={handleNoteChange}
                  //   />
                  // </div>
                  <SelectMechanic car={selectedItem} />
                )}


              {status == "New Check" && activeStep === 1 && (
                <>
                  <div className="mb-3 text-center">
                    <h5>Amount: ${amount}</h5>
                  </div>
                </>
              )}

              {activeStep === 2 && (
                <>
                  <div className="mb-3">
                    <label htmlFor="uploadFile" className="form-label">
                      Upload your Payment Proof
                    </label>
                    <input
                      type="file"
                      className="form-control"
                      id="uploadFile"
                      onChange={handleFileChange} // Capture the selected file
                    />
                  </div>
                </>
              )}
            </div>

            {/* Footer with Forward and Backward Buttons */}

            {activeStep !== 3 && (
              <div className="modal-footer d-flex justify-content-between">
                {/* Backward Button */}
                <div style={{ width: "200px" }}>
                  {" "}
                  {/* Set width here */}
                  {activeStep !== 1 && (
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={handlePrevStep}
                      disabled={activeStep === 0}
                      style={{ width: "100%" }} // Full width of the div
                    >
                      Back
                    </button>
                  )}
                </div>

                {/* Middle Buttons */}
                <div style={{ width: "200px" }}>
                  {" "}
                  {/* Set width here */}
                  {status !== "New Check" &&
                    status !== "Uploaded" &&
                    status !== "Accepted" &&
                    status !== "Report" && (
                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={() => {
                          handleMechanicalCheck(carIds, soldCarIds);
                          handleAddNotes();
                        }}
                        style={{ width: "100%" }} // Full width of the div
                      >
                        Add
                      </button>
                    )}
                  {activeStep === 1 && (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={handlePay}
                      style={{ width: "100%" }} // Full width of the div
                    >
                      Pay
                    </button>
                  )}
                  {activeStep === 2 && (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={handleUpload}
                      style={{ width: "100%" }} // Full width of the div
                    >
                      Upload
                    </button>
                  )}
                </div>

                {/* Forward Button */}
                <div style={{ width: "200px" }}>
                  {" "}
                  {/* Set width here */}
                  {activeStep !== 0 && activeStep !== 2 && (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={handleNextStep}
                      disabled={activeStep === steps.length - 1}
                      style={{ width: "100%" }} // Full width of the div
                    >
                      Forward
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Delivery Details Modal */}
      <div
        className="modal fade"
        id="deliveryDetailsModal"
        tabIndex="-1"
        aria-labelledby="deliveryDetailsModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title" id="deliveryDetailsModalLabel">
                Delivery Details
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label htmlFor="pincode" className="form-label">
                  Enter your Pincode:
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="pincode"
                  placeholder="Enter Pincode"
                  value={pincode}
                  onChange={handlePincodeChange}
                  maxLength="6" // Assuming Indian pincode format
                />
              </div>
              <div className="mb-3">
                <label htmlFor="address" className="form-label">
                  Enter your Address:
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="address"
                  placeholder="Enter Address"
                  value={address}
                  onChange={handleAddressChange}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="notes" className="form-label">
                  Delivery Notes:
                </label>
                <textarea
                  className="form-control"
                  id="notes"
                  rows="3"
                  placeholder="Add any special instructions here"
                  value={notes}
                  onChange={handleNotesChange}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  // handlePurchase("Delivery");
                  handleDeliveryCheck(carIds, soldCarIds);
                }}
              >
                Proceed
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Cleaning Details Modal */}
      <div
        className="modal fade"
        id="cleaningDetailsModal"
        tabIndex="-1"
        aria-labelledby="cleaningDetailsModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title" id="cleaningDetailsModalLabel">
                Cleaning Details
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label htmlFor="mechanicalInput" className="form-label">
                  Add Notes
                </label>
                <textarea
                  className="form-control"
                  id="mechanicalInput"
                  rows="4"
                  placeholder="Enter notes here"
                  value={cleanNotes}
                  onChange={(e) => setClean(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  handleCleanCheck(carIds, soldCarIds);
                }}
              >
                Proceed
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* payment  Modal */}
      <div
        className="modal fade"
        id="paymentModalLabel"
        tabIndex="-1"
        aria-labelledby="paymentModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content" style={{ minHeight: "65vh" }}>
            <div className="modal-header">
              <h4 className="modal-title" id="paymentModalLabel">
                Pay Amount
              </h4>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <div className="d-flex flex-row align-items-stretch gap-3 mb-2">
                <button
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#mechanicalCheckModal"
                  style={{ width: "200px" }}
                // onClick={()=>handleMechanicalCheck(carIds, soldCarIds)}
                // disabled={isMechanicalSkipped}
                >
                  {!selectedItem?.machenical && selectedItem?.mechanicskip
                    ? "Add Mechanical"
                    : "Mechanical Check"}
                </button>
                <button
                  className="btn btn-primary"
                  style={{ width: "200px" }}
                  data-bs-toggle="modal"
                  data-bs-target="#deliveryDetailsModal"
                >
                  Delivery Details
                </button>
                <button
                  className="btn btn-primary"
                  style={{ width: "200px" }}
                  data-bs-toggle="modal"
                  data-bs-target="#cleaningDetailsModal"
                >
                  Cleaning Details
                </button>
              </div>

              {/* Skip Buttons Row */}
              <div className="d-flex flex-row align-items-stretch gap-3 mb-2">
                {!selectedItem?.machenical && selectedItem?.mechanicskip ? (
                  <div
                    style={{
                      width: "200px",
                      marginLeft: "10px",
                      color: "black",
                    }}
                  >
                    Already Skipped
                  </div>
                ) : (
                  <button
                    className="btn btn-secondary"
                    style={{ width: "200px" }}
                    onClick={() => handleSkipMechanical(carIds, soldCarIds)} // Pass the state values correctly
                  >
                    Skip Mechanical
                  </button>
                )}

                <button
                  className="btn btn-secondary"
                  style={{ width: "200px" }}
                  onClick={() => handleSkipDelivery(carIds, soldCarIds)} // Pass the state values correctly
                >
                  Skip Delivery
                </button>
                <button
                  className="btn btn-secondary"
                  style={{ width: "200px" }}
                  onClick={() => handleSkipClean(carIds, soldCarIds)}
                >
                  Skip Cleaning
                </button>
              </div>
            </div>
            <div className="modal-footer d-flex justify-content-center">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => handlePurchase("Payment")}
              >
                Proceed To Pay
              </button>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer />
    </div>
  );
};

export default MyTrack;
