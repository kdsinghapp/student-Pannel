import React, { useEffect, useState } from "react";
import { getLetestCar } from "@/store/features/carSlice";
import Link from "next/link";
import { favorites, ImageUrl } from "@/utils/carApi";
import { useDispatch, useSelector } from "react-redux";
import { toast  } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const CarBigCard = ({ item }) => {
    const modalId = `modal-${item?._id}`;

    const dispatch = useDispatch()
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const userData = useSelector((store) => store?.userData);
    useEffect(() => {
      console.log("userData?.user?.user", userData?.user);
      if (userData?.user) {
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
      }
    }, [userData]);
    // if (!isLoggedIn) {
    //   toast.error('Please Login.');
    //   return;
    // }
  
    const handleSave = async (action) => {
      if (!isLoggedIn) {
        toast.error('Please Login.');
        return;
      }
      const data = {
        carId: item?._id,
        action: action // 'add' or 'remove'
      };
    
      try {
        const res = await favorites(data);
        console.log(res,"response")
        if (res.status) {
          toast.success(res.message);
          console.log("favorite")
          dispatch(getLetestCar());
        } else {
          console.log(res.message,"false")
          toast.error(res.message);
        }
      } catch (error) {
        toast.error("An error occurred while processing your request.");
      }
    };
  
  return (
    <>
    <div className="col-md-6 col-lg-12">
      <div className="car-item" style={{height:"180px"}}>
        <div className="car-img">
          <span className="car-status status-1">{item?.car_condition}</span>{" "}
          <img alt="" src={`${ImageUrl()+item?.image}`} />
          <div className="car-btns">
              {
                !item?.isFavorite == true ? (
              <a onClick={() =>handleSave("add")}>
                <i className="far fa-heart text-white" />
              </a>
                ) : (
                  <a className="bg-danger" onClick={() =>handleSave("remove")}>
                  <i className="far fa-heart text-white" />
                </a>
                )
              }{" "}
              <a href="#">
                <i className="far fa-arrows-repeat" />
              </a>
          </div>
        </div>
        <div className="car-content">
          <div className="car-top">
            <h4>
              <a href="#">{item?.car_name}</a>
            </h4>
            <div className="car-rate">
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
              {/* <i className="fas fa-star" /> <span>5.0 (58.5k Review)</span> */}
            </div>
            <span className="car-price">${item?.car_price}</span>
          </div>
          <ul className="car-list">
            <li>Condition: {item?.car_condition}</li>
            <li>Fuel:{item?.car_fuel_type}</li>
            <li>Trans.: {item?.car_transmission}</li>
            <li>Kilometers: {item?.car_kilometers}km</li>
       
          </ul>
        </div>
        <div className="btnns">
          <div>
            <a
              className="btn btn-primary"
              href="javascript:void();"
              data-bs-toggle="modal"
              data-bs-target={`#${modalId}`}
            >
              <span className="far fa-eye" /> Quick View
            </a>
          </div>
        </div>
      </div>
    </div>

    <div className="modal fade" id={modalId} tabIndex="-1" aria-labelledby={`${modalId}Label`} aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">
              <h4 className="modal-title" id={`${modalId}Label`}>{item?.car_name}</h4>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {/* Modal Body */}
            <div className="modal-body">
              <div className="row pb-4">
                <div className="col-lg-5">
                  <h5 className="mb-2">Price: ${item?.car_price}</h5>
                  <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                    <div className="card-body">
                      <p><strong>Dealer Name:</strong>{item?.dealer?.name}</p>
                      <p><strong>Address:</strong>{item?.car_address}</p>
                      <p><strong>Phone:</strong>{item?.dealer?.number}</p>
                    </div>
                  </div>
                  <p data-bs-dismiss="modal" aria-label="Close">

                  <Link className="theme-btn" href={`/detail/${item?._id}`} > Click For Full Details</Link>
                  </p>
                </div>
                <div className="col-lg-7">
                  {/* Carousel */}
                  <div id={`carousel-${modalId}`} className="carousel slide" data-bs-ride="carousel">
                    {/* Indicators/dots */}
                    <div className="carousel-indicators">
                      <button type="button" data-bs-target={`#carousel-${modalId}`} data-bs-slide-to={0} className="active"></button>
                      <button type="button" data-bs-target={`#carousel-${modalId}`} data-bs-slide-to={1}></button>
                      <button type="button" data-bs-target={`#carousel-${modalId}`} data-bs-slide-to={2}></button>
                    </div>
                    {/* The slideshow/carousel */}
                    <div className="carousel-inner">
                    {item?.gallery?.map((image, index) => (
                        <div key={index} className={`carousel-item ${index === 0 ? "active" : ""}`}>
                          <img
                            src={`http://193.203.161.2:8000/images/${image}`}
                            alt={`car ${index}`}
                            className="d-block w-100"
                          />
                        </div>
                      ))}

                      {/* <div className="carousel-item">
                        <img src={`http://193.203.161.2:8000/images/${item?.image}`} alt="car" className="d-block w-100" />
                      </div>
                      <div className="carousel-item">
                        <img src="/assets/img/car/02.jpg" alt="car" className="d-block w-100" />
                      </div>
                      <div className="carousel-item">
                        <img src="/assets/img/car/03.jpg" alt="car" className="d-block w-100" />
                      </div> */}
                    </div>
                    {/* Carousel controls */}
                    <button className="carousel-control-prev" type="button" data-bs-target={`#carousel-${modalId}`} data-bs-slide="prev">
                      <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span className="visually-hidden">Previous</span>
                    </button>
                    <button className="carousel-control-next" type="button" data-bs-target={`#carousel-${modalId}`} data-bs-slide="next">
                      <span className="carousel-control-next-icon" aria-hidden="true"></span>
                      <span className="visually-hidden">Next</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CarBigCard;
