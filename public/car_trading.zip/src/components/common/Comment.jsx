import { addComment, getCar } from "@/utils/carApi";
import { isEmptyObject } from "jquery";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Comment = ({ comments, carId, Cars }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const userData = useSelector((store) => store?.userData);
  useEffect(() => {
    // console.log("userData?.user?.user", userData?.user);
    if (userData?.user) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [userData]);

  // const GetComment = async () => {
  //   try {
  //     const data = {
  //       car_id: carId,
  //     };
  //     const res = await getCar(data);
  //   } catch (erro) {
  //     console.log(erro);
  //   }
  // };

  // useEffect(() => {
  //   GetComment();
  // }, []);

  const [commentText, setCommentText] = useState('');

  const handleCommentChange = (e) => {
    setCommentText(e.target.value);
  };

  const handleAddComment = async () => {
    try {
      if (!commentText.trim()) {
        toast.error('Please enter a comment.');
        return;
      }
      
      if (!isLoggedIn) {
        toast.error('Please Login.');
        return;
      }

      const data = {
        carId: carId,
        text: commentText
      };

      const res = await addComment(data);
      
      if (res.status === true) {
        toast.success('Comment added successfully');
        Cars()
        setCommentText(''); // Clear the input after successful comment
      } else {
        toast.error(res.message || 'Failed to add comment');
      }
    } catch (error) {
      console.log(error);
      toast.error('An error occurred while adding the comment.');
    }
  };

  

  return (
    <div className="car-single-widget">
        <div className="car-single-overview">
          <h4 className="mb-3">Add Comment</h4>
          <input value={commentText}
          onChange={handleCommentChange} className="form-control mb-1" type="text" placeholder="Type your comment here" />
          <div className="text-right">
          <button onClick={handleAddComment} className="btn btn-primary">
            Add Comment
          </button>
          </div>
        </div>
      <div className="car-single-review">
        <div className="blog-comments mb-0">
          <h4>User Comments ({comments?.length})</h4>
          <div className="blog-comments-wrapper">
            {comments?.map((item) => (
              <div key={item?._id} className="blog-comments-single">
                {/* <img alt="thumb" src={`http://193.203.161.2:8000/${item?.userId?.profile_image}`} /> */}
                <div className="blog-comments-content">
                  <h5>
                    {item?.userId?.first_name} {item?.userId?.last_name}
                  </h5>
                  <span>
                    <i className="far fa-clock" /> {item?.createdAt}
                  </span>
                  <p>{item?.text}</p>
                </div>
              </div>
            ))}
            {/* <div className="blog-comments-single">
              <img alt="thumb" src="assets/img/blog/com-1.jpg" />
              <div className="blog-comments-content">
                <h5>Jesse Sinkler</h5>
                <span>
                  <i className="far fa-clock" /> January 31, 2023
                </span>
                <p>
                  At vero eos et accusamus et iusto odio dignissimos ducimus qui
                  blanditiis praesentium voluptatum deleniti atque corrupti quos
                  dolores et quas molestias excepturi sint occaecati cupiditate
                  non provident.
                </p>
              </div>
            </div>
            <div className="blog-comments-single">
              <img alt="thumb" src="assets/img/blog/com-2.jpg" />
              <div className="blog-comments-content">
                <h5>Daniel Wellman</h5>
                <span>
                  <i className="far fa-clock" /> January 31, 2023
                </span>
                <p>
                  At vero eos et accusamus et iusto odio dignissimos ducimus qui
                  blanditiis praesentium voluptatum deleniti atque corrupti quos
                  dolores et quas molestias excepturi sint occaecati cupiditate
                  non provident.
                </p>
              </div>
            </div>
            <div className="blog-comments-single">
              <img alt="thumb" src="assets/img/blog/com-3.jpg" />
              <div className="blog-comments-content">
                <h5>Kenneth Evans</h5>
                <span>
                  <i className="far fa-clock" /> January 31, 2023
                </span>
                <p>
                  At vero eos et accusamus et iusto odio dignissimos ducimus qui
                  blanditiis praesentium voluptatum deleniti atque corrupti quos
                  dolores et quas molestias excepturi sint occaecati cupiditate
                  non provident.
                </p>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Comment;
