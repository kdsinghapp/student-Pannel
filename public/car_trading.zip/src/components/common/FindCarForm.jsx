"use client";
import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { getFilterdCar } from "@/store/features/carSlice";
import { Dropdown as CDropdown, DropdownToggle as CDropdownToggle, DropdownMenu as CDropdownMenu, DropdownItem as CDropdownItem } from 'reactstrap';
import { getCityList, getMakerList,getCarModel } from "@/utils/carApi";
import Link from "next/link";

const FindCarForm = () => {
  const dispatch = useDispatch();
  const formRef = useRef();
  const [makers, setMakers] = useState([]);
  const [citys, setCitys] = useState([]);
  const [selectedModel, setSelectedModel] = useState({});
  // const [selectedMaker, setSelectedMaker] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [priceRange, setPriceRange] = useState('');
  // const [model,setModel] = useState([])
  const [id,setId] = useState("")
  const [selectedMaker, setSelectedMaker] = useState('');
const [selectedMakerId, setSelectedMakerId] = useState('');
const [carModels, setCarModels] = useState([]); // To store car models based on selected maker

  const [dropdownOpen, setDropdownOpen] = useState({
    make: false,
    model: false,
    price: false,
    city: false
  });
  const [selectedItems, setSelectedItems] = useState([]);

  const Carsmodel = async(id) =>{
    try{
      const data = {
        _id:id
  }
  console.log(data,"data")

  const Carmodel = await getCarModel(data);
  console.log("Carmodel",Carmodel)
  setModel(Carmodel?.data)


    }catch(error){
      console.log(error,"error")
    }
  }
  // Fetch data from APIs
  const getData = async () => {
    try {

      const getmakers = await getMakerList();
      const getcitys = await getCityList();
      console.log("makers response", getmakers);
      console.log("citys response", getcitys);
      setMakers(getmakers?.data || []);
      setCitys(getcitys?.data || []);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  

  useEffect(() => {
    getData();
  }, []);


  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(Infinity);
  const [car_maker_id, setCarMakerId] = useState("");
  const [car_model_id, setCarModelId] = useState("");
  const [car_city_id, setCarCityId] = useState("");

  const handlePriceChange = (event) => {
    const value = event.target.value;

    console.log(11111111111)
    if (value) {
      const [min, max] = value.split("-").map(Number);
      setMinPrice(min);
      setMaxPrice(max);      
    } else {
      setMinPrice(0);
      setMaxPrice(Infinity);
    }
  };

  const handleCarMakerChange = (event) => {
    setCarMakerId(event.target.value);
  };
  
  const handleCarModelChange = (event) => {
    setCarModelId(event.target.value);
  };
  
  const handleCarCityChange = (event) => {
    setCarCityId(event.target.value);
  };

  const getCars = async () => {
    try {
      const data = {
        minPrice: priceRange.split('-')[0] || 0,
        maxPrice: priceRange.split('-')[1] || Infinity,
        car_maker_id: selectedMakerId,
        car_model_id: selectedModel?._id || '',
        car_city_id: selectedCity?._id || ''
      };
      console.log(data);
      dispatch(getFilterdCar(data));
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    getCars();
  };

  const toggleDropdown = (key) => {
    setDropdownOpen(prevState => ({
      ...prevState,
      [key]: !prevState[key]
    }));
  };

  const handleChange = (name) => {
    setSelectedItems(prev =>
      prev.includes(name)
        ? prev.filter(item => item !== name)
        : [...prev, name]
    );
  };

  return (
    <>
      <div className="col-md-12 col-lg-6 App">
        <div className="hero-right">
          <div className="find-car">
            <div className="container">
              <div className="find-car-form">
                <h4 className="find-car-title">
                  Let&apos;s Find Your Perfect Car
                </h4>
                <form ref={formRef} onSubmit={handleSubmit} action="#">
                  <div className="row">
                    <div className="col-lg-6">
                      <div className="form-group">
                        <label>Make</label>
                        <CDropdown isOpen={dropdownOpen.make} toggle={() => toggleDropdown('make')}>
                          <CDropdownToggle 
                            style={{ backgroundColor: 'white', borderColor: '#ced4da', color: '#757F95', width: '100%', borderRadius: '10px', height: '55px',
                              display: 'flex', 
                              justifyContent: 'space-between', 
                              alignItems: 'center',  // Centers text vertically if needed
                              padding: '0 1rem'       }}
                            caret
                          >
                            {selectedMaker || 'All Brand'}
                          </CDropdownToggle>
                          <CDropdownMenu 
                          style={{
                            width:"100%",
                            maxHeight:"200px",
                            overflowY:"scroll"
                          }}
                          >
                            {makers.map((maker) => (
                              <CDropdownItem 
                                key={maker?.car_maker_id}
                                onClick={async () => {
                                  setSelectedMaker(maker?.car_maker_name);
                                  setSelectedMakerId(maker?._id);
                                  const data = {
                                    car_maker_id : maker?._id
                                  };
                                  try {
                                    const Carmodel = await getCarModel(data);
                                    setCarModels(Carmodel?.data || []);
                                  } catch (error) {
                                    console.error("Error fetching car models", error);
                                  }
                                }}
                                style={{ cursor: 'pointer' }}
                              >
                                {maker?.car_maker_name}
                              </CDropdownItem>
                            ))}
                          </CDropdownMenu>
                        </CDropdown>
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group">
                        <label>Car Model</label>
                        <CDropdown isOpen={dropdownOpen.model} toggle={() => toggleDropdown('model')}>
                          <CDropdownToggle 
                            style={{ backgroundColor: 'white', borderColor: '#ced4da', color: '#757F95', width: '100%', borderRadius: '10px', height: '55px',
                              display: 'flex', 
                              justifyContent: 'space-between', 
                              alignItems: 'center',  // Centers text vertically if needed
                              padding: '0 1rem'      
                             }}
                            caret
                          >
                            {selectedModel?.car_model_name || 'All Model' }
                          </CDropdownToggle>
                          <CDropdownMenu
                            style={{
                              width:"100%",
                              maxHeight:"200px",
                              overflowY:"scroll"
                            }}
                          >
                            {carModels.map((name,i) => (
                              <CDropdownItem 
                                key={i}
                                onClick={() =>  setSelectedModel(name)}
                                style={{ cursor: 'pointer' }}
                              > 
                                {name.car_model_name}
                              </CDropdownItem>
                            ))}
                          </CDropdownMenu>
                        </CDropdown>
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group">
                        <label>Price</label>
                        <CDropdown isOpen={dropdownOpen.price} toggle={() => toggleDropdown('price')}>
                          <CDropdownToggle 
                            style={{ backgroundColor: 'white', borderColor: '#ced4da', color: '#757F95', width: '100%', borderRadius: '10px', height: '55px', 

                              display: 'flex', 
                              justifyContent: 'space-between', 
                              alignItems: 'center',  // Centers text vertically if needed
                              padding: '0 1rem'      
                            }}
                            caret
                          >
                            {priceRange || 'All Price'}
                          </CDropdownToggle>
                          <CDropdownMenu
                            style={{
                              width:"100%",
                              maxHeight:"200px",
                              overflowY:"scroll"
                            }}
                          >
                            <CDropdownItem onClick={() => setPriceRange('25000-30000')}>$25,000 - $30,000</CDropdownItem>
                            <CDropdownItem onClick={() => setPriceRange('30000-50000')}>$30,000 - $50,000</CDropdownItem>
                            <CDropdownItem onClick={() => setPriceRange('50000-100000')}>$50,000 - $100,000</CDropdownItem>
                            <CDropdownItem onClick={() => setPriceRange('70000-300000')}>$70,000 - $300,000</CDropdownItem>
                          </CDropdownMenu>
                        </CDropdown>
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group">
                        <label>City</label>
                        <CDropdown isOpen={dropdownOpen.city} toggle={() => toggleDropdown('city')}>
                          <CDropdownToggle 
                            style={{ backgroundColor: 'white', borderColor: '#ced4da', color: '#757F95', width: '100%', borderRadius: '10px', height: '55px',
                              display: 'flex', 
                              justifyContent: 'space-between', 
                              alignItems: 'center',  // Centers text vertically if needed
                              padding: '0 1rem'      
                             }}
                            caret
                          >
                            {selectedCity?.city_name || 'All City'}
                          </CDropdownToggle>
                          <CDropdownMenu
                            style={{
                              width:"100%",
                              maxHeight:"200px",
                              overflowY:"scroll"
                            }}
                          >
                            {citys.map((city) => (
                              <CDropdownItem 
                                key={city?.city_id}
                                onClick={() => setSelectedCity(city)}
                                style={{ cursor: 'pointer' }}
                              >
                                {city?.city_name}
                              </CDropdownItem>
                            ))}
                          </CDropdownMenu>
                        </CDropdown>
                      </div>
                    </div>
                    <div className="col-lg-12 mt-3">
                      <button className="theme-btn" type="submit">
                        <span className="far fa-search" /> Search
                      </button>
                    </div>
                    <Link href={"/advance-search"}>
                    <div className="col-lg-12 mt-3">
                      <button className="theme-btn" type="submit">
                        <span className="far fa-search" /> Advance Search
                      </button>
                    </div>
                    </Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FindCarForm;
