"use client";

import InfoSidebar from "@/appPages/InfoSidebar";
import { valuePredictCar } from "@/utils/carApi";
import React, { useState, useEffect, useRef  } from "react";
import Swal from "sweetalert2";
import { useRouter } from "next/navigation";

const CarValuePredict = () => {
  const router = useRouter();
  const modalRef = useRef(null);
  const [formData, setFormData] = useState({
    location: "",
    condition: "",
    color: "Select One",
    accidentHistory: "Select One",
    rentalCar: "Select One",
    previousOwners: "",
    years: "",
    make: "",
    model: "",
    mileage: "",
    style: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [predictionResult, setPredictionResult] = useState(null);
  const [error, setError] = useState(null);
  const [isClient, setIsClient] = useState(false);
  
  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedPrediction = localStorage.getItem("predictionResult");
      if (savedPrediction) {
        setPredictionResult(JSON.parse(savedPrediction));
      }
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const requiredFields = [
      "location", "condition", "color", "accidentHistory", "rentalCar",
      "previousOwners", "years", "make", "model", "mileage", "style"
    ];

    const emptyFields = requiredFields.filter((field) => {
      if (["color", "accidentHistory", "rentalCar"].includes(field)) {
        return formData[field] === "Select One";
      }
      return !formData[field];
    });

    if (emptyFields.length > 0) {
      await Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please fill all required fields",
        confirmButtonColor: "#3085d6",
      });
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const res = await valuePredictCar(formData);
      setPredictionResult(res.estimatedValue);

      if (isClient) {
        try {
          localStorage.setItem("predictionResult", JSON.stringify(res.estimatedValue));
          localStorage.setItem("carAdvertisementData", JSON.stringify(formData));
        } catch (storageError) {
          console.error("LocalStorage Error:", storageError);
          await Swal.fire({
            icon: "error",
            title: "Storage Error",
            text: "Could not save data to localStorage. Please try again.",
          });
        }

        if (modalRef.current) {
          try {
            const bootstrap = await import("bootstrap");
            new bootstrap.Modal(modalRef.current).show();
          } catch (err) {
            console.error("Bootstrap Modal Error:", err);
            await Swal.fire({
              icon: "info",
              title: "Results Ready",
              text: "Your car valuation is complete!",
              confirmButtonColor: "#3085d6",
            });
          }
        }
      }

      setFormData({
        location: "",
        condition: "",
        color: "Select One",
        accidentHistory: "Select One",
        rentalCar: "Select One",
        previousOwners: "",
        years: "",
        make: "",
        model: "",
        mileage: "",
        style: "",
      });

    } catch (err) {
      console.error("Prediction Error:", err);
      setError(err.message);
      await Swal.fire({
        icon: "error",
        title: "Error",
        text: "Failed to predict vehicle value. Please try again.",
        confirmButtonColor: "#3085d6",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">My Account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="/">Home</a>
              </li>
              <li className="active">My Car value</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <div className="col-lg-3">
                <InfoSidebar page={"value"} />
              </div>
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          My Car value
                        </h4>
                        <div className="car-area list p-0">
                          <div className="container">
                            <form onSubmit={handleSubmit}>
                              <div className="row justify-content-center">
                                <div className="col-lg-5">
                                  <div className="row">
                                    <div className="car-widget">
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Location</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="location"
                                            value={formData.location}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Condition</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="condition"
                                            value={formData.condition}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Color</label>
                                        </div>
                                        <div className="col-md-8">
                                          <select
                                            className="form-control"
                                            name="color"
                                            value={formData.color}
                                            onChange={handleChange}
                                          >
                                            <option>Select One</option>
                                            <option>Red</option>
                                            <option>Black</option>
                                            <option>White</option>
                                            <option>Silver</option>
                                          </select>
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Had accient</label>
                                        </div>
                                        <div className="col-md-8">
                                          <select
                                            className="form-control"
                                            name="accidentHistory"
                                            value={formData.accidentHistory}
                                            onChange={handleChange}
                                          >
                                            <option>Select One</option>
                                            <option>No</option>
                                            <option>Yes</option>
                                          </select>
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Rental car</label>
                                        </div>
                                        <div className="col-md-8">
                                          <select
                                            className="form-control"
                                            name="rentalCar"
                                            value={formData.rentalCar}
                                            onChange={handleChange}
                                          >
                                            <option>Select One</option>
                                            <option>No</option>
                                            <option>Yes</option>
                                          </select>
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Previous owner</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="previousOwners"
                                            value={formData.previousOwners}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Years</label>
                                        </div>
                                        <div className="col-md-8">
                                          <div className="year-range-box">
                                            <input
                                              className="form-control"
                                              id="year"
                                              type="text"
                                              name="years"
                                              value={formData.years}
                                              onChange={handleChange}
                                            />
                                            <div className="year-range" />
                                          </div>
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Make</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="make"
                                            value={formData.make}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Model</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="model"
                                            value={formData.model}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                      <div className="form-group mb-3 row">
                                        <div className="col-md-4">
                                          <label>Mileage</label>
                                        </div>
                                        <div className="col-md-8">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="mileage"
                                            value={formData.mileage}
                                            onChange={handleChange}
                                          />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-lg-7">
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-12">
                                      <label>Style</label>
                                      <div className="row">
                                        {[
                                          1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
                                        ].map((num) => (
                                          <div
                                            className="col-md-3 col-6"
                                            key={`c${num}`}
                                          >
                                            <div className="checkbox-container mb-2">
                                              <input
                                                id={`c${num}`}
                                                name="style"
                                                type="radio"
                                                value={`style${num}`}
                                                checked={
                                                  formData.style ===
                                                  `style${num}`
                                                }
                                                onChange={handleChange}
                                              />
                                              <label
                                                className="checkbox-label"
                                                htmlFor={`c${num}`}
                                              >
                                                <img
                                                  src={`assets/img/carstyle${num}.png`}
                                                  alt={`Car style ${num}`}
                                                />
                                              </label>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                {error && (
                                  <div className="alert alert-danger">
                                    {error}
                                  </div>
                                )}
                                <div className="form-group mb-3 mt-3 row">
                                  <div className="col-md-12 text-center">
                                    <button
                                      className="theme-btn w-50"
                                      type="submit"
                                      disabled={isLoading}
                                    >
                                      {isLoading
                                        ? "Valuing..."
                                        : "Value my car"}
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <div className="modal value" ref={modalRef} id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">My Car Value</h4>
              <button
                className="btn-close"
                data-bs-dismiss="modal"
                type="button"
              />
            </div>
            <div className="modal-body">
              <div className="row pb-4">
                <div className="col-lg-12 text-center">
                  <div className="card mb-5 border-0">
                    <div className="card-body text-center">
                      <h4 className="mb-3">Our AI model says:</h4>
                      <h6 className="text-primary">
                        Your car value is {predictionResult || "0"}
                      </h6>
                    </div>
                  </div>
                  <h5>Do you want to create an ad to sell your vehicle?</h5>
                  <div className="d-flex justify-content-center mt-3">
                    <button
                      className="theme-btn me-3"
                      data-bs-dismiss="modal"
                      onClick={() => router.push("/create-ad")}
                    >
                      Yes
                    </button>
                    <button className="theme-btn" data-bs-dismiss="modal">
                      No
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CarValuePredict;
