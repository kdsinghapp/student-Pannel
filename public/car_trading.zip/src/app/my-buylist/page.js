import InfoSidebar from '@/appPages/InfoSidebar';
import React from 'react';

const Page = () => {
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">My Account</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">My Buy List</li>
        </ul>
      </div>
    </div>
    <div className="user-profile py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-3">
          <InfoSidebar page={"buy"} />
          </div>
          <div className="col-lg-9">
            <div className="user-profile-wrapper">
              <div className="row">
                <div className="col-lg-12">
                  <div className="user-profile-card">
                    <h4 className="user-profile-card-title">Manage My buy products</h4>
                    <div className="car-area list p-0">
                      <div className="container">
                        <div className="row justify-content-center">
                          <div className="col-lg-12">
                            <div className="row">
                              <div className="col-md-6 col-lg-12">
                                <div className="car-item">
                                  <div className="col-md-3">
                                    <div className="col-md-12 col-lg-12 mb-2">
                                      <h6>
                                        <a href="#" className="me-3">
                                          Mercedes Benz Car
                                        </a>{" "}
                                      </h6>
                                    </div>
                                    <div className="">
                                      <img
                                        alt=""
                                        src="assets/img/car/01.jpg"
                                        style={{
                                          width: "100%",
                                          borderRadius: 10
                                        }}
                                      />
                                    </div>
                                  </div>
                                  <div className="car-content sideborder col-md-6">
                                    <div className="car-top">
                                      <p>
                                        <a href="#">
                                          <i className="fa fa-camera" /> Gallery
                                        </a>
                                      </p>
                                    </div>
                                    <ul className="car-list">
                                      <li>Exterior: Velvet Red Pearlcoat</li>
                                      <li>
                                        Interior: Linen/Black W/Leather W/
                                      </li>
                                      <li>Trans.: 6 Speed Automatic</li>
                                      <li>Doors: Four Door Sedan</li>
                                      <li>Engine: 6 Cylinder</li>
                                      <li>Mileage: 18,251</li>
                                    </ul>
                                  </div>
                                  <div className="btnns col-md-3">
                                    <div>
                                      <p className="car-price f-14">
                                        <span className="text-primary">
                                          Price:
                                        </span>{" "}
                                        $45,620
                                      </p>
                                      <p className="car-price f-14">
                                        <span className="text-warning">
                                          Your price:{" "}
                                        </span>
                                        $32,500
                                      </p>
                                    </div>
                                    <div className="mb-2 mt-2">
                                      <a
                                        className="btn btn-danger w-100"
                                        href="#"
                                      >
                                        Cancel buy
                                      </a>
                                    </div>
                                    <div>
                                      <a
                                        className="btn btn-primary w-100"
                                        href="#"
                                      >
                                        Buy At Full Price
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6 col-lg-12">
                                <div className="car-item">
                                  <div className="col-md-3">
                                    <div className="col-md-12 col-lg-12 mb-2">
                                      <h6>
                                        <a href="#" className="me-3">
                                          New 2018 Chrysler 400 C{" "}
                                        </a>{" "}
                                      </h6>
                                    </div>
                                    <div className="">
                                      <img
                                        alt=""
                                        src="assets/img/car/02.jpg"
                                        style={{
                                          width: "100%",
                                          borderRadius: 10
                                        }}
                                      />
                                    </div>
                                  </div>
                                  <div className="car-content sideborder col-md-6">
                                    <div className="car-top">
                                      <p>
                                        <a href="#">
                                          <i className="fa fa-camera" /> Gallery
                                        </a>
                                      </p>
                                    </div>
                                    <ul className="car-list">
                                      <li>Exterior: Velvet Red Pearlcoat</li>
                                      <li>
                                        Interior: Linen/Black W/Leather W/
                                      </li>
                                      <li>Trans.: 6 Speed Automatic</li>
                                      <li>Doors: Four Door Sedan</li>
                                      <li>Engine: 6 Cylinder</li>
                                      <li>Mileage: 18,251</li>
                                    </ul>
                                  </div>
                                  <div className="btnns col-md-3">
                                    <div>
                                      <p className="car-price f-14">
                                        Your buying was <br />
                                        <span className="text-danger">
                                          Canceled Automatically <span />
                                        </span>
                                      </p>
                                      <p className="car-price f-14">
                                        Car was sold or removed
                                      </p>
                                    </div>
                                    <div className="mb-2 mt-2">
                                      <p className="car-price f-14">
                                        Price: <br />
                                        <span className="text-primary">
                                          $12150<span>.</span>
                                        </span>
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6 col-lg-12">
                                <div className="car-item">
                                  <div className="col-md-3">
                                    <div className="col-md-12 col-lg-12 mb-2">
                                      <h6>
                                        <a href="#" className="me-3">
                                          New 2018 Chrysler 400 C{" "}
                                        </a>{" "}
                                      </h6>
                                    </div>
                                    <div className="">
                                      <img
                                        alt=""
                                        src="assets/img/car/03.jpg"
                                        style={{
                                          width: "100%",
                                          borderRadius: 10
                                        }}
                                      />
                                    </div>
                                  </div>
                                  <div className="car-content sideborder col-md-6">
                                    <div className="car-top">
                                      <p>
                                        <a href="#">
                                          <i className="fa fa-camera" /> Gallery
                                        </a>
                                      </p>
                                    </div>
                                    <ul className="car-list">
                                      <li>Exterior: Velvet Red Pearlcoat</li>
                                      <li>
                                        Interior: Linen/Black W/Leather W/
                                      </li>
                                      <li>Trans.: 6 Speed Automatic</li>
                                      <li>Doors: Four Door Sedan</li>
                                      <li>Engine: 6 Cylinder</li>
                                      <li>Mileage: 18,251</li>
                                    </ul>
                                  </div>
                                  <div className="btnns col-md-3">
                                    <div>
                                      <p className="car-price f-14">
                                        Your buying was <br />
                                        <span className="text-danger">
                                          not accepted <span />
                                        </span>
                                      </p>
                                      <p className="car-price f-14">
                                        Car was sold or removed
                                      </p>
                                    </div>
                                    <div className="mb-2 mt-2">
                                      <p className="car-price f-14">
                                        Current buy price:{" "}
                                        <span className="text-primary">
                                          $12100<span>.</span>
                                        </span>
                                      </p>
                                    </div>
                                    <div>
                                      <a
                                        className="btn btn-primary w-100"
                                        href="#"
                                      >
                                        Adjust buy price{" "}
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6 col-lg-12">
                                <div className="car-item">
                                  <div className="col-md-3">
                                    <div className="col-md-12 col-lg-12 mb-2">
                                      <h6>
                                        <a href="#" className="me-3">
                                          New 2018 Chrysler 400 C{" "}
                                        </a>{" "}
                                      </h6>
                                    </div>
                                    <div className="">
                                      <img
                                        alt=""
                                        src="assets/img/car/03.jpg"
                                        style={{
                                          width: "100%",
                                          borderRadius: 10
                                        }}
                                      />
                                    </div>
                                  </div>
                                  <div className="car-content sideborder col-md-6">
                                    <div className="car-top">
                                      <p>
                                        <a href="#">
                                          <i className="fa fa-camera" /> Gallery
                                        </a>
                                      </p>
                                    </div>
                                    <ul className="car-list">
                                      <li>Exterior: Velvet Red Pearlcoat</li>
                                      <li>
                                        Interior: Linen/Black W/Leather W/
                                      </li>
                                      <li>Trans.: 6 Speed Automatic</li>
                                      <li>Doors: Four Door Sedan</li>
                                      <li>Engine: 6 Cylinder</li>
                                      <li>Mileage: 18,251</li>
                                    </ul>
                                  </div>
                                  <div className="btnns col-md-3">
                                    <div>
                                      <p className="car-price f-14">
                                        Your buying was <br />
                                        <span style={{ color: "green" }}>
                                          {" "}
                                          accepted <span />
                                        </span>
                                      </p>
                                      <p className="car-price f-14">
                                        Car was sold or removed
                                      </p>
                                    </div>
                                    <div className="mb-2 mt-2">
                                      <p className="car-price f-14">
                                        Current buying price:{" "}
                                        <span className="text-primary">
                                          $12100<span>.</span>
                                        </span>
                                      </p>
                                    </div>
                                    <div>
                                      <a
                                        className="btn btn-primary w-100"
                                        href="#"
                                      >
                                        {" "}
                                        Buy{" "}
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="pagination-area">
                              <div aria-label="Page navigation example">
                                <ul className="pagination">
                                  <li className="page-item">
                                    <a
                                      aria-label="Previous"
                                      className="page-link"
                                      href="#"
                                    >
                                      <span aria-hidden="true">
                                        <i className="far fa-arrow-left" />
                                      </span>
                                    </a>
                                  </li>
                                  <li className="page-item active">
                                    <a className="page-link" href="#">
                                      1
                                    </a>
                                  </li>
                                  <li className="page-item">
                                    <a className="page-link" href="#">
                                      2
                                    </a>
                                  </li>
                                  <li className="page-item">
                                    <a className="page-link" href="#">
                                      3
                                    </a>
                                  </li>
                                  <li className="page-item">
                                    <a
                                      aria-label="Next"
                                      className="page-link"
                                      href="#"
                                    >
                                      <span aria-hidden="true">
                                        <i className="far fa-arrow-right" />
                                      </span>
                                    </a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  {/* The Modal */}
  <div className="modal" id="myModal">
    <div className="modal-dialog">
      <div className="modal-content">
        {/* Modal Header */}
        <div className="modal-header">
          <h4 className="modal-title">Mercedes Benz Car</h4>
          <button className="btn-close" data-bs-dismiss="modal" type="button" />
        </div>
        {/* Modal body */}
        <div className="modal-body">
          <div className="row pb-4">
            <div className="col-lg-5">
              <h5 className="mb-2">Price: $45,360</h5>
              <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                <div className="card-body">
                  <p>
                    <strong>Dealer Name:</strong> John Doe
                  </p>
                  <p>
                    <strong>Address:</strong> 123A/21, Near old garden, Indore
                  </p>
                  <p>
                    <strong>Phone:</strong> 7798797XXXXX
                  </p>
                </div>
              </div>
              <a className="theme-btn" href="details">
                Click For Full Details
              </a>
            </div>
            <div className="col-lg-7">
              {/* Carousel */}
              <div className="carousel slide" data-bs-ride="carousel" id="demo">
                {/* Indicators/dots */}
                <div className="carousel-indicators">
                  <button
                    className="active"
                    data-bs-slide-to={0}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={1}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={2}
                    data-bs-target="#demo"
                    type="button"
                  />
                </div>
                {/* The slideshow/carousel */}
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/01.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/02.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/03.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</>

    );
}

export default Page;
