import InfoSidebar from '@/appPages/InfoSidebar';
import Messages from '@/appPages/Messages';
import React from 'react';

const Page = ({ params, searchParams }) => {
  const messageText = searchParams.text || '';

  console.log(params.id);
  
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">My Account</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">My Buy List</li>
        </ul>
      </div>
    </div>
    <div className="user-profile py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-3">
          <InfoSidebar page={"chat"} />
          </div>
          <div className="col-lg-9">
            <div className="user-profile-wrapper">
              <div className="row">
                <div className="col-lg-12">
                  <div className="user-profile-card">
                    <h4 className="user-profile-card-title">Manage My buy products</h4>
                   <Messages id={params.id} text={messageText}/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

</>

    );
}

export default Page;
