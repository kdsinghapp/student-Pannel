import RecentlyAddedCars from "@/appPages/RecentlyAddedCars";
import React from "react";

const Page = () => {
  return (
    <>
      
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">Recently added cars</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="/">Home</a>
              </li>
              <li className="active">Car List</li>
            </ul>
          </div>
        </div>
       <RecentlyAddedCars />
      </main>
    
      {/* The Modal */}
     
     
    </>
  );
};

export default Page;
