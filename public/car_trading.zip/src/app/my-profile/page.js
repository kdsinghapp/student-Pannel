import InfoSidebar from "@/appPages/InfoSidebar";
import Info from "@/appPages/ProfileInfo";
import React from "react";

const Page = () => {
  return (
    <>
      <main className="main">
        <div
          className="site-breadcrumb"
          style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
        >
          <div className="container">
            <h2 className="breadcrumb-title">My Account</h2>
            <ul className="breadcrumb-menu">
              <li>
                <a href="/">Home</a>
              </li>
              <li className="active">My Profile</li>
            </ul>
          </div>
        </div>
        <div className="user-profile py-120">
          <div className="container">
            <div className="row">
              <div className="col-lg-3">
                {/* <div className="user-profile-sidebar">
              <div className="user-profile-sidebar-top">
                <div className="user-profile-img">
                  <img alt="" src="assets/img/account/user.jpg" />{" "}
                  <button className="profile-img-btn" type="button">
                    <i className="far fa-camera" />
                  </button>{" "}
                  <input className="profile-img-file" type="file" />
                </div>
                <h5>John Doe</h5>
              </div>
              <ul className="user-profile-sidebar-list">
                <li>
                  <a href="myaccount">
                    <i className="far fa-home" /> My Account
                  </a>
                </li>
                <li>
                  <a className="active" href="my-profile">
                    <i className="far fa-user" /> My Profile
                  </a>
                </li>
                <li>
                  <a href="mybids">
                    <i className="fa fa-gavel" /> My Bids
                  </a>
                </li>
                <li>
                  <a href="myoffer">
                    <i className="fa fa-gift" /> My offers
                  </a>
                </li>
                <li>
                  <a href="myresrvedcars">
                    <i className="fa fa-car" /> My Reserved Cars
                  </a>
                </li>
                <li>
                  <a href="my-buylist">
                    <i className="fa fa-shopping-cart" /> My Buy List
                  </a>
                </li>
                <li>
                  <a href="valuemycar">
                    <i className="fa fa-car" /> My Car Value
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="far fa-sign-out" /> Logout
                  </a>
                </li>
              </ul>
            </div> */}
                <InfoSidebar page={"profile"} />
              </div>
              <div className="col-lg-9">
                <div className="user-profile-wrapper">
                  <div className="row">
                    <div className="col-lg-12">
                      <Info />
                    </div>
                    <div className="col-lg-12">
                      <div className="user-profile-card">
                        <h4 className="user-profile-card-title">
                          Change Password
                        </h4>
                        <div className="col-lg-12">
                          <div className="user-profile-form">
                            <form action="#">
                              <div className="form-group">
                                <label>Old Password</label>{" "}
                                <input
                                  className="form-control"
                                  placeholder="Old Password"
                                  type="password"
                                />
                              </div>
                              <div className="form-group">
                                <label>New Password</label>{" "}
                                <input
                                  className="form-control"
                                  placeholder="New Password"
                                  type="password"
                                />
                              </div>
                              <div className="form-group">
                                <label>Re-Type Password</label>{" "}
                                <input
                                  className="form-control"
                                  placeholder="Re-Type Password"
                                  type="password"
                                />
                              </div>
                              <button className="theme-btn my-3" type="button">
                                <span className="far fa-key" /> Change Password
                              </button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      {/* The Modal */}
      <div className="modal" id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
            {/* Modal Header */}
            <div className="modal-header">
              <h4 className="modal-title">Mercedes Benz Car</h4>
              <button
                className="btn-close"
                data-bs-dismiss="modal"
                type="button"
              />
            </div>
            {/* Modal body */}
            <div className="modal-body">
              <div className="row pb-4">
                <div className="col-lg-5">
                  <h5 className="mb-2">Price: $45,360</h5>
                  <div
                    className="card mb-5"
                    style={{ border: "1px solid #eee" }}
                  >
                    <div className="card-body">
                      <p>
                        <strong>Dealer Name:</strong> John Doe
                      </p>
                      <p>
                        <strong>Address:</strong> 123A/21, Near old garden,
                        Indore
                      </p>
                      <p>
                        <strong>Phone:</strong> 7798797XXXXX
                      </p>
                    </div>
                  </div>
                  <a className="theme-btn" href="details">
                    Click For Full Details
                  </a>
                </div>
                <div className="col-lg-7">
                  {/* Carousel */}
                  <div
                    className="carousel slide"
                    data-bs-ride="carousel"
                    id="demo"
                  >
                    {/* Indicators/dots */}
                    <div className="carousel-indicators">
                      <button
                        className="active"
                        data-bs-slide-to={0}
                        data-bs-target="#demo"
                        type="button"
                      />{" "}
                      <button
                        data-bs-slide-to={1}
                        data-bs-target="#demo"
                        type="button"
                      />{" "}
                      <button
                        data-bs-slide-to={2}
                        data-bs-target="#demo"
                        type="button"
                      />
                    </div>
                    {/* The slideshow/carousel */}
                    <div className="carousel-inner">
                      <div className="carousel-item active">
                        <img
                          alt="car"
                          className="d-block"
                          src="assets/img/car/01.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div className="carousel-item">
                        <img
                          alt="car"
                          className="d-block"
                          src="assets/img/car/02.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                      <div className="carousel-item">
                        <img
                          alt="car"
                          className="d-block"
                          src="assets/img/car/03.jpg"
                          style={{ width: "100%" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Page;
