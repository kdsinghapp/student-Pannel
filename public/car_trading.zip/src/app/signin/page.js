import SignIn from '@/appPages/SignIn';
import React from 'react';

const Page = () => {
    return (
        <main className="main">
        <div className="login-area mt-5 mb-5">
          <div className="container">
            <div className="col-md-5 mx-auto">
              <div className="login-form">
                <div className="login-header">
                  <h3>Sign In</h3>
                  <p>Sign In with your account</p>
                </div>
                <SignIn />
              </div>
            </div>
          </div>
        </div>
      </main>
      
    );
}

export default Page;
