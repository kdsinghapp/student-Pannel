import React from 'react';
import Detail from '@/appPages/Detail';


const Page = ({params}) => {
    return (
        <Detail carId={params.carId} />
    );
}

export default Page;
