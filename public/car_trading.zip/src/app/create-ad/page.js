import FillCarAd from "@/appPages/FillCarAd";
import React from "react";

const Page = () => {
  return (
    <>
      <FillCarAd />
    </>
  );
};

export default Page;
