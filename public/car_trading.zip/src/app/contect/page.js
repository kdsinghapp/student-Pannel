import React from 'react';

const Page = () => {
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">Contact Us</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">Contact Us</li>
        </ul>
      </div>
    </div>
    <div className="contact-area py-120">
      <div className="container">
        <div className="contact-content">
          <div className="row">
            <div className="col-md-3">
              <div className="contact-info">
                <div className="contact-info-icon">
                  <i className="fal fa-map-location-dot" />
                </div>
                <div className="contact-info-content">
                  <h5>Office Address</h5>
                  <p>25/B Milford, Lorem Ipsum, HOHHF</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="contact-info">
                <div className="contact-info-icon">
                  <i className="fal fa-phone-volume" />
                </div>
                <div className="contact-info-content">
                  <h5>Call Us</h5>
                  <p>+X XXX XXXX XXXX</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="contact-info">
                <div className="contact-info-icon">
                  <i className="fal fa-envelopes" />
                </div>
                <div className="contact-info-content">
                  <h5>Email Us</h5>
                  <p>
                    <a className="" href="">
                      test@mail.com
                    </a>
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="contact-info">
                <div className="contact-info-icon">
                  <i className="fal fa-alarm-clock" />
                </div>
                <div className="contact-info-content">
                  <h5>Open Time</h5>
                  <p>Mon - Sat (10.00AM - 05.30PM)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="contact-wrapper">
          <div className="row">
            <div className="col-lg-6 align-self-center">
              <div className="contact-img">
                <img alt="" src="assets/img/contact/01.jpg" />
              </div>
            </div>
            <div className="col-lg-6 align-self-center">
              <div className="contact-form">
                <div className="contact-form-header">
                  <h2>Get In Touch</h2>
                  <p>
                    It is a long established fact that a reader will be
                    distracted by the readable content of a page randomised
                    words which don&apos;t look even slightly when looking at its
                    layout.
                  </p>
                </div>
                <form
                  action="#"
                  id="contact-form"
                  method="post"
                  name="contact-form"
                >
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <input
                          className="form-control"
                          name="name"
                          placeholder="Your Name"
                          required=""
                          type="text"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <input
                          className="form-control"
                          name="email"
                          placeholder="Your Email"
                          required=""
                          type="email"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group">
                    <input
                      className="form-control"
                      name="subject"
                      placeholder="Your Subject"
                      required=""
                      type="text"
                    />
                  </div>
                  <div className="form-group">
                    <textarea
                      className="form-control"
                      cols={30}
                      name="message"
                      placeholder="Write Your Message"
                      rows={5}
                      defaultValue={""}
                    />
                  </div>
                  <button className="theme-btn" type="submit">
                    Send Message <i className="far fa-paper-plane" />
                  </button>
                  <div className="col-md-12 mt-3">
                    <div className="form-messege text-success" />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  {/* The Modal */}
  <div className="modal" id="myModal">
    <div className="modal-dialog">
      <div className="modal-content">
        {/* Modal Header */}
        <div className="modal-header">
          <h4 className="modal-title">Mercedes Benz Car</h4>
          <button className="btn-close" data-bs-dismiss="modal" type="button" />
        </div>
        {/* Modal body */}
        <div className="modal-body">
          <div className="row pb-4">
            <div className="col-lg-5">
              <h5 className="mb-2">Price: $45,360</h5>
              <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                <div className="card-body">
                  <p>
                    <strong>Dealer Name:</strong> John Doe
                  </p>
                  <p>
                    <strong>Address:</strong> 123A/21, Near old garden, Indore
                  </p>
                  <p>
                    <strong>Phone:</strong> 7798797XXXXX
                  </p>
                </div>
              </div>
              <a className="theme-btn" href="details">
                Click For Full Details
              </a>
            </div>
            <div className="col-lg-7">
              {/* Carousel */}
              <div className="carousel slide" data-bs-ride="carousel" id="demo">
                {/* Indicators/dots */}
                <div className="carousel-indicators">
                  <button
                    className="active"
                    data-bs-slide-to={0}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={1}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={2}
                    data-bs-target="#demo"
                    type="button"
                  />
                </div>
                {/* The slideshow/carousel */}
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/01.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/02.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/03.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</>

    );
}

export default Page;
