import AdvertisedCars from "@/components/common/AdvertisedCars";
import HomeletestCars from "@/components/common/HomeletestCars";
import React from "react";

const page = () => {
  return (
    <>
      <main className="main">
        <div className="car-area bg py-60 mt-5">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 mx-auto">
                <div className="site-heading text-center">
                  <span className="site-title-tagline">
                    <i className="flaticon-drive" /> All Best Selling Vehicles
                  </span>
                  <h2 className="site-title">
                    Let&apos;s Check Latest <span>Cars</span>
                  </h2>
                  <div className="heading-divider" />
                </div>
              </div>
            </div>

            <AdvertisedCars />
          </div>
        </div>
      </main>

      {/* The Modal */}
    </>
  );
};

export default page;
