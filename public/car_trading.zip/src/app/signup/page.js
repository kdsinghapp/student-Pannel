import Signup from "@/appPages/Signup";
import React from "react";

const Page = () => {
  return (
    <>
      <main className="main">
        <div className="login-area mt-5 mb-5">
          <div className="container">
            <div className="col-md-5 mx-auto">
              <div className="login-form">
                <div className="login-header">
                  <h3>Sign Up</h3>
                  <p>Create your account</p>
                </div>

                <Signup />

                <div className="login-footer">
                  <p>
                    Already have an account? <a href="signin">Sign In.</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default Page;
