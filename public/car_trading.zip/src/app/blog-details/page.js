import React from 'react';

const Page = () => {
    return (
        <>
        <main className="main">
          <div
            className="site-breadcrumb"
            style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
          >
            <div className="container">
              <h2 className="breadcrumb-title">Blog details</h2>
              <ul className="breadcrumb-menu">
                <li>
                  <a href="/">Home</a>
                </li>
                <li className="active">Blog details</li>
              </ul>
            </div>
          </div>
          <div className="blog-single-area pt-120 pb-120">
            <div className="container">
              <div className="row">
                <div className="col-lg-8">
                  <div className="blog-single-wrapper">
                    <div className="blog-single-content">
                      <div className="blog-thumb-img">
                        <img alt="thumb" src="assets/img/blog/single.jpg" />
                      </div>
                      <div className="blog-info">
                        <h3 className="blog-details-title mb-20">
                          It is a long established fact that a reader
                        </h3>
                        <div className="blog-meta">
                          <div className="blog-meta-right">
                            <a className="share-btn" href="#">
                              <i className="far fa-share-alt" />
                              Share
                            </a>
                          </div>
                        </div>
                        <div className="blog-details">
                          <p className="mb-10">
                            Sed ut perspiciatis unde omnis iste natus error sit
                            voluptatem accusantium doloremque laudantium, totam rem
                            aperiam, eaque ipsa quae ab illo inventore veritatis et
                            quasi architecto beatae vitae dicta sunt explicabo. Nemo
                            enim ipsam voluptatem quia voluptas sit aspernatur aut
                            odit aut fugit, sed quia consequuntur magni dolores eos
                            qui ratione voluptatem sequi nesciunt. Neque porro
                            quisquam est, qui dolorem ipsum quia dolor sit amet,
                            consectetur, adipisci velit, sed quia non numquam eius
                            modi tempora incidunt ut labore et dolore magnam aliquam
                            quaerat voluptatem.
                          </p>
                          <p className="mb-10">
                            But I must explain to you how all this mistaken idea of
                            denouncing pleasure and praising pain was born and I will
                            give you a complete account of the system, and expound the
                            actual teachings of the great explorer of the truth, the
                            master-builder of human happiness. No one rejects,
                            dislikes, or avoids pleasure itself, because it is
                            pleasure, but because those who do not know how to pursue
                            pleasure rationally encounter consequences that are
                            extremely painful.
                          </p>
                          <p className="mb-20">
                            In a free hour when our power of choice is untrammelled
                            and when nothing prevents our being able to do what we
                            like best, every pleasure is to be welcomed and every pain
                            avoided. But in certain circumstances and owing to the
                            claims of duty or the obligations of business it will
                            frequently occur that pleasures have to be repudiated and
                            annoyances accepted. The wise man therefore always holds
                            in these matters to this principle of selection.
                          </p>
                          <p className="mb-20">
                            Power of choice is untrammelled and when nothing prevents
                            our being able to do what we like best, every pleasure is
                            to be welcomed and every pain avoided. But in certain
                            circumstances and owing to the claims of duty or the
                            obligations of business it will frequently occur that
                            pleasures have to be repudiated and annoyances accepted.
                            The wise man therefore always holds in these matters to
                            this principle of selection.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4">
                  <aside className="sidebar">
                    <div className="widget search">
                      <h5 className="widget-title">Search</h5>
                      <form className="search-form">
                        <input
                          className="form-control"
                          placeholder="Search Here..."
                          type="text"
                        />{" "}
                        <button type="submit">
                          <i className="far fa-search" />
                        </button>
                      </form>
                    </div>
                    <div className="widget recent-post">
                      <h5 className="widget-title">Recent Post</h5>
                      <div className="recent-post-single">
                        <div className="recent-post-img">
                          <img alt="thumb" src="assets/img/blog/bs-1.jpg" />
                        </div>
                        <div className="recent-post-bio">
                          <h6>
                            <a href="#">
                              At vero accusa iusto odio dignis ducimu bland
                            </a>
                          </h6>
                          <span>
                            <i className="far fa-clock" />
                            January 31, 2023
                          </span>
                        </div>
                      </div>
                      <div className="recent-post-single">
                        <div className="recent-post-img">
                          <img alt="thumb" src="assets/img/blog/bs-2.jpg" />
                        </div>
                        <div className="recent-post-bio">
                          <h6>
                            <a href="#">
                              At vero accusa iusto odio dignis ducimu bland
                            </a>
                          </h6>
                          <span>
                            <i className="far fa-clock" />
                            January 31, 2023
                          </span>
                        </div>
                      </div>
                      <div className="recent-post-single">
                        <div className="recent-post-img">
                          <img alt="thumb" src="assets/img/blog/bs-3.jpg" />
                        </div>
                        <div className="recent-post-bio">
                          <h6>
                            <a href="#">
                              At vero accusa iusto odio dignis ducimu bland
                            </a>
                          </h6>
                          <span>
                            <i className="far fa-clock" />
                            January 31, 2023
                          </span>
                        </div>
                      </div>
                    </div>
                  </aside>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* The Modal */}
        <div className="modal" id="myModal">
          <div className="modal-dialog">
            <div className="modal-content">
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Mercedes Benz Car</h4>
                <button className="btn-close" data-bs-dismiss="modal" type="button" />
              </div>
              {/* Modal body */}
              <div className="modal-body">
                <div className="row pb-4">
                  <div className="col-lg-5">
                    <h5 className="mb-2">Price: $45,360</h5>
                    <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                      <div className="card-body">
                        <p>
                          <strong>Dealer Name:</strong> John Doe
                        </p>
                        <p>
                          <strong>Address:</strong> 123A/21, Near old garden, Indore
                        </p>
                        <p>
                          <strong>Phone:</strong> 7798797XXXXX
                        </p>
                      </div>
                    </div>
                    <a className="theme-btn" href="details">
                      Click For Full Details
                    </a>
                  </div>
                  <div className="col-lg-7">
                    {/* Carousel */}
                    <div className="carousel slide" data-bs-ride="carousel" id="demo">
                      {/* Indicators/dots */}
                      <div className="carousel-indicators">
                        <button
                          className="active"
                          data-bs-slide-to={0}
                          data-bs-target="#demo"
                          type="button"
                        />{" "}
                        <button
                          data-bs-slide-to={1}
                          data-bs-target="#demo"
                          type="button"
                        />{" "}
                        <button
                          data-bs-slide-to={2}
                          data-bs-target="#demo"
                          type="button"
                        />
                      </div>
                      {/* The slideshow/carousel */}
                      <div className="carousel-inner">
                        <div className="carousel-item active">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/01.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                        <div className="carousel-item">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/02.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                        <div className="carousel-item">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/03.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>      
    );
}

export default Page;
