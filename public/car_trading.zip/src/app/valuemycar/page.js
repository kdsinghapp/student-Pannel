import InfoSidebar from '@/appPages/InfoSidebar';
import React from 'react';

const Page = () => {
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">My Account</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">My Car value</li>
        </ul>
      </div>
    </div>
    <div className="user-profile py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-3">
          <InfoSidebar page={"value"} />
          </div>
          <div className="col-lg-9">
            <div className="user-profile-wrapper">
              <div className="row">
                <div className="col-lg-12">
                  <div className="user-profile-card">
                    <h4 className="user-profile-card-title">My Car value</h4>
                    <div className="car-area list p-0">
                      <div className="container">
                        <form action="#" method="post">
                          <div className="row justify-content-center">
                            <div className="col-lg-5">
                              <div className="row">
                                <div className="car-widget">
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Location</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Condition</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Color</label>
                                    </div>
                                    <div className="col-md-8">
                                      <select className="form-control">
                                        <option>Select One</option>
                                        <option>Red</option>
                                        <option>Black</option>
                                        <option>White</option>
                                        <option>Silver</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Had accient</label>
                                    </div>
                                    <div className="col-md-8">
                                      <select className="form-control">
                                        <option>Select One</option>
                                        <option>No</option>
                                        <option>Yes</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Rental car</label>
                                    </div>
                                    <div className="col-md-8">
                                      <select className="form-control">
                                        <option>Select One</option>
                                        <option>No</option>
                                        <option>Yes</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Previous owner</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Years</label>
                                    </div>
                                    <div className="col-md-8">
                                      <div className="year-range-box">
                                        <div className="year-range-input">
                                          <input
                                            id="year"
                                            readOnly=""
                                            type="text"
                                          />
                                        </div>
                                        <div className="year-range" />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Make</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Model</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                  <div className="form-group mb-3 row">
                                    <div className="col-md-4">
                                      <label>Mileage</label>
                                    </div>
                                    <div className="col-md-8">
                                      <input
                                        className="form-control"
                                        type="text"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="col-lg-7">
                              <div className="form-group mb-3 row">
                                <div className="col-md-12">
                                  <label>Style</label>
                                  <div className="row">
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c1"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c1"
                                        >
                                          <img src="assets/img/carstyle1.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c2"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c2"
                                        >
                                          <img
                                            src="assets/img/carstyle2.png"
                                            style={{ width: 135 }}
                                          />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c3"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c3"
                                        >
                                          <img src="assets/img/carstyle3.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c4"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c4"
                                        >
                                          <img src="assets/img/carstyle4.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c5"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c5"
                                        >
                                          <img src="assets/img/carstyle5.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c6"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c6"
                                        >
                                          <img src="assets/img/carstyle6.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c7"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c7"
                                        >
                                          <img src="assets/img/carstyle7.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c8"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c8"
                                        >
                                          <img src="assets/img/carstyle8.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c9"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c9"
                                        >
                                          <img src="assets/img/carstyle9.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c10"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c10"
                                        >
                                          <img src="assets/img/carstyle10.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c11"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c11"
                                        >
                                          <img src="assets/img/carstyle11.png" />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-6">
                                      <div className="checkbox-container mb-2">
                                        <input
                                          id="c12"
                                          name="check"
                                          type="radio"
                                        />{" "}
                                        <label
                                          className="checkbox-label"
                                          htmlFor="c12"
                                        >
                                          <img src="assets/img/carstyle12.png" />
                                        </label>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="form-group mb-3 mt-3 row">
                              <div className="col-md-12 text-center">
                                <input
                                  className="theme-btn w-50"
                                  type="button"
                                  defaultValue="Value my car"
                                  data-bs-toggle="modal"
                                  data-bs-target="#myModal"
                                />
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  {/* The Modal */}
  <div className="modal value" id="myModal">
    <div className="modal-dialog">
      <div className="modal-content">
        {/* Modal Header */}
        <div className="modal-header">
          <h4 className="modal-title">My Car Value</h4>
          <button className="btn-close" data-bs-dismiss="modal" type="button" />
        </div>
        {/* Modal body */}
        <div className="modal-body">
          <div className="row pb-4">
            <div className="col-lg-12  text-center">
              <div className="card mb-5 border-0">
                <div className="card-body text-center">
                  <h4 className="mb-3">Our AI model says:</h4>
                  <h6 className="text-primary">Your car value is $24873.00</h6>
                </div>
              </div>
              <a className="theme-btn" data-bs-dismiss="modal">
                Okay
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</>
    );
}

export default Page;
