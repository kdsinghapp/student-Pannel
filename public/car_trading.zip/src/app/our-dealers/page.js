import React from 'react';

const Page = () => {
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">Dealers</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">Dealers</li>
        </ul>
      </div>
    </div>
    <div className="car-area bg py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <div className="row">
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/01.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Automotive Gear</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/02.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Keithson Car</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/03.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Superious Automotive</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/04.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Racing Gear Car</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/05.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Car Showromio</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/06.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Fastspeedio Car</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/07.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Star AutoMall</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/08.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Superspeed Auto</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="dealer-item">
                  <div className="dealer-img">
                    {" "}
                    <img alt="" src="assets/img/dealer/05.png" />
                  </div>
                  <div className="dealer-content">
                    <h4>
                      <a href="#">Car Showromio</a>
                    </h4>
                    <ul>
                      <li>
                        <i className="far fa-location-dot" /> 25/B Milford Road,
                        New York
                      </li>
                      <li>
                        <i className="far fa-phone" />{" "}
                        <a href="tel:+21236547898">+2 123 654 7898</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="pagination-area">
              <div aria-label="Page navigation example">
                <ul className="pagination">
                  <li className="page-item">
                    <a aria-label="Previous" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-left" />
                      </span>
                    </a>
                  </li>
                  <li className="page-item active">
                    <a className="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li className="page-item">
                    <a aria-label="Next" className="page-link" href="#">
                      <span aria-hidden="true">
                        <i className="far fa-arrow-right" />
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  {/* The Modal */}
  <div className="modal" id="myModal">
    <div className="modal-dialog">
      <div className="modal-content">
        {/* Modal Header */}
        <div className="modal-header">
          <h4 className="modal-title">Mercedes Benz Car</h4>
          <button className="btn-close" data-bs-dismiss="modal" type="button" />
        </div>
        {/* Modal body */}
        <div className="modal-body">
          <div className="row pb-4">
            <div className="col-lg-5">
              <h5 className="mb-2">Price: $45,360</h5>
              <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                <div className="card-body">
                  <p>
                    <strong>Dealer Name:</strong> John Doe
                  </p>
                  <p>
                    <strong>Address:</strong> 123A/21, Near old garden, Indore
                  </p>
                  <p>
                    <strong>Phone:</strong> 7798797XXXXX
                  </p>
                </div>
              </div>
              <a className="theme-btn" href="details">
                Click For Full Details
              </a>
            </div>
            <div className="col-lg-7">
              {/* Carousel */}
              <div className="carousel slide" data-bs-ride="carousel" id="demo">
                {/* Indicators/dots */}
                <div className="carousel-indicators">
                  <button
                    className="active"
                    data-bs-slide-to={0}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={1}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={2}
                    data-bs-target="#demo"
                    type="button"
                  />
                </div>
                {/* The slideshow/carousel */}
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/01.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/02.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/03.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</>

    );
}

export default Page;
