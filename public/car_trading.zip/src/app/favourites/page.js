import Favourites from '@/appPages/Favourites';
import InfoSidebar from '@/appPages/InfoSidebar';
import React from 'react';

const Page = () => {
    return (
        <>
  <main className="main">
    <div
      className="site-breadcrumb"
      style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
    >
      <div className="container">
        <h2 className="breadcrumb-title">My Account</h2>
        <ul className="breadcrumb-menu">
          <li>
            <a href="/">Home</a>
          </li>
          <li className="active">My Favourites</li>
        </ul>
      </div>
    </div>
    <div className="user-profile py-120">
      <div className="container">
        <div className="row">
          <div className="col-lg-3">
          <InfoSidebar page={"favourites"} />
          </div>
          <div className="col-lg-9">
            <div className="user-profile-wrapper">
              <div className="row">
                <div className="col-lg-12">
                  <div className="user-profile-card">
                    <h4 className="user-profile-card-title">My Favourites</h4>
                    <div className="car-area list p-0">
                      <div className="container">
                        <div className="row justify-content-center">
                          <Favourites/>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  {/* The Modal */}
  <div className="modal" id="myModal">
    <div className="modal-dialog">
      <div className="modal-content">
        {/* Modal Header */}
        <div className="modal-header">
          <h4 className="modal-title">Mercedes Benz Car</h4>
          <button className="btn-close" data-bs-dismiss="modal" type="button" />
        </div>
        {/* Modal body */}
        <div className="modal-body">
          <div className="row pb-4">
            <div className="col-lg-5">
              <h5 className="mb-2">Price: $45,360</h5>
              <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                <div className="card-body">
                  <p>
                    <strong>Dealer Name:</strong> John Doe
                  </p>
                  <p>
                    <strong>Address:</strong> 123A/21, Near old garden, Indore
                  </p>
                  <p>
                    <strong>Phone:</strong> 7798797XXXXX
                  </p>
                </div>
              </div>
              <a className="theme-btn" href="details">
                Click For Full Details
              </a>
            </div>
            <div className="col-lg-7">
              {/* Carousel */}
              <div className="carousel slide" data-bs-ride="carousel" id="demo">
                {/* Indicators/dots */}
                <div className="carousel-indicators">
                  <button
                    className="active"
                    data-bs-slide-to={0}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={1}
                    data-bs-target="#demo"
                    type="button"
                  />{" "}
                  <button
                    data-bs-slide-to={2}
                    data-bs-target="#demo"
                    type="button"
                  />
                </div>
                {/* The slideshow/carousel */}
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/01.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/02.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      alt="car"
                      className="d-block"
                      src="assets/img/car/03.jpg"
                      style={{ width: "100%" }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</>

    );
}

export default Page;
