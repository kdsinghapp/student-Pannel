import Image from "next/image";
import Loader from "@/components/common/Loader";
import FindCarForm from "@/components/common/FindCarForm";
import HomeletestCars from "@/components/common/HomeletestCars";
import Testimonials from "@/components/common/Testimonials";
import FilterCars from "@/components/common/FilterCars";


export default function Home() {
  return (
    <>
      {/* <Loader/> */}

      <main className="main">
        <div className="hero-section">
          <div className="">
            <div
              className="hero-single"
              style={{ background: "url(assets/img/slider/slider-1.jpg)" }}
            >
              <div className="container">
                <div className="row align-items-center">
                  <div className="col-md-12 col-lg-6">
                    <div className="hero-content">
                      <h6
                        className="hero-sub-title"
                        data-animation="fadeInUp"
                        data-delay=".25s"
                      >
                        Welcome To Us!
                      </h6>
                      <h1
                        className="hero-title"
                        data-animation="fadeInRight"
                        data-delay=".50s"
                      >
                        Best Way To Find Your <span>Dream</span> Car
                      </h1>
                      <div
                        className="hero-btn"
                        data-animation="fadeInUp"
                        data-delay="1s"
                      >
                        <a className="theme-btn" href="#">
                          About More
                          <i className="fas fa-arrow-right-long" />
                        </a>{" "}
                        <a className="theme-btn theme-btn2" href="#">
                          Learn More
                          <i className="fas fa-arrow-right-long" />
                        </a>
                      </div>
                    </div>
                  </div>
                  <FindCarForm />
                  {/* <div className="col-md-12 col-lg-6">
                  <div className="hero-right">
                    <div className="find-car">
                      <div className="container">
                        <div className="find-car-form">
                          <h4 className="find-car-title">
                            Let's Find Your Perfect Car
                          </h4>
                          <form action="#">
                            <div className="row">
                              <div className="col-lg-6">
                                <div className="form-group">
                                  <label>Make</label>{" "}
                                  <select className="select">
                                    <option value={1}>All Brand</option>
                                    <option value={2}>BMW</option>
                                    <option value={3}>Ferrari</option>
                                    <option value={4}>Marcediz Benz</option>
                                    <option value={5}>Hyundai</option>
                                    <option value={6}>Nissan</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-lg-6">
                                <div className="form-group">
                                  <label>Car Model</label>{" "}
                                  <select className="select">
                                    <option value={1}>All Model</option>
                                    <option value={2}>3-Series</option>
                                    <option value={3}>Carrera</option>
                                    <option value={4}>G-TR</option>
                                    <option value={3}>Macan</option>
                                    <option value={3}>N-Series</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-lg-6">
                                <div className="form-group">
                                  <label>Price</label>{" "}
                                  <select className="select">
                                    <option value={1}>All Price</option>
                                    <option value={2}>$1,000 - $5,000</option>
                                    <option value={3}>$5,000 - $10,000</option>
                                    <option value={4}>$15,000 - $20,000</option>
                                    <option value={5}>$20,000 - $25,000</option>
                                    <option value={6}>$25,000 - $30,000</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-lg-6">
                                <div className="form-group">
                                  <label>City</label>{" "}
                                  <select className="select">
                                    <option value={1}>Dubai</option>
                                    <option value={2}>Mumbai</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-lg-12 mt-3">
                                <button className="theme-btn" type="submit">
                                  <span className="far fa-search" /> Search
                                </button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        <FilterCars />
        <div className="car-area bg py-120">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 mx-auto">
                <div className="site-heading text-center">
                  <span className="site-title-tagline">
                    <i className="flaticon-drive" /> Latest Added Cars
                  </span>
                  <h2 className="site-title">
                    Let&apos;s Check Latest <span>Cars</span>
                  </h2>
                  <div className="heading-divider" />
                </div>
              </div>
            </div>

            <HomeletestCars />

            <div className="text-center mt-4">
              <a className="theme-btn" href="#">
                Load More <i className="far fa-arrow-rotate-right" />
              </a>
            </div>
          </div>
        </div>
        <div className="choose-area py-120">
          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-6">
                <div className="choose-content">
                  <div
                    className="site-heading wow fadeInDown"
                    data-wow-delay=".25s"
                  >
                    <span className="site-title-tagline text-white justify-content-start">
                      <i className="flaticon-drive" /> Why Choose Us
                    </span>
                    <h2 className="site-title text-white mb-10">
                      We are dedicated <span>to provide</span> quality service
                    </h2>
                    <p className="text-white">
                      There are many variations of passages available but the
                      majority have suffered alteration in some form going to use a
                      passage by injected humour randomised words which don&apos;t look
                      even slightly believable.
                    </p>
                  </div>
                  <div className="choose-img wow fadeInUp" data-wow-delay=".25s">
                    <img alt="" src="assets/img/choose/01.png" />
                  </div>
                </div>
              </div>
              <div className="col-lg-6">
                <div
                  className="choose-content-wrapper wow fadeInRight"
                  data-wow-delay=".25s"
                >
                  <div className="row">
                    <div className="col-md-6 col-lg-6 mt-lg-5">
                      <div className="choose-item">
                        <span className="choose-count">01</span>
                        <div className="choose-item-icon">
                          <i className="flaticon-car" />
                        </div>
                        <div className="choose-item-info">
                          <h3>Best Quality Cars</h3>
                          <p>
                            There are many variations of the passages available but
                            the majo have suffered fact that reader will be dist
                            alteration.
                          </p>
                        </div>
                      </div>
                      <div className="choose-item mb-lg-0">
                        <span className="choose-count">03</span>
                        <div className="choose-item-icon">
                          <i className="flaticon-drive-thru" />
                        </div>
                        <div className="choose-item-info">
                          <h3>Popular Brands</h3>
                          <p>
                            There are many variations of the passages available but
                            the majo have suffered fact that reader will be dist
                            alteration.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6 col-lg-6">
                      <div className="choose-item">
                        <span className="choose-count">02</span>
                        <div className="choose-item-icon">
                          <i className="flaticon-chauffeur" />
                        </div>
                        <div className="choose-item-info">
                          <h3>Certified Mechanics</h3>
                          <p>
                            There are many variations of the passages available but
                            the majo have suffered fact that reader will be dist
                            alteration.
                          </p>
                        </div>
                      </div>
                      <div className="choose-item mb-lg-0">
                        <span className="choose-count">04</span>
                        <div className="choose-item-icon">
                          <i className="flaticon-online-payment" />
                        </div>
                        <div className="choose-item-info">
                          <h3>Reasonable Price</h3>
                          <p>
                            There are many variations of the passages available but
                            the majo have suffered fact that reader will be dist
                            alteration.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Testimonials />
        <div className="blog-area py-120">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 mx-auto">
                <div className="site-heading text-center">
                  <span className="site-title-tagline">
                    <i className="flaticon-drive" /> Our Blog
                  </span>
                  <h2 className="site-title">
                    Latest News &amp; <span>Blog</span>
                  </h2>
                  <div className="heading-divider" />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6 col-lg-4">
                <div className="blog-item wow fadeInUp" data-wow-delay=".25s">
                  <div className="blog-item-img">
                    <img alt="Thumb" src="assets/img/blog/01.jpg" />
                  </div>
                  <div className="blog-item-info">
                    <div className="blog-item-meta">
                      <ul>
                        <li>
                          <a href="#">
                            <i className="far fa-user-circle" /> By Alicia Davis
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <i className="far fa-calendar-alt" /> January 29, 2023
                          </a>
                        </li>
                      </ul>
                    </div>
                    <h4 className="blog-title">
                      <a href="#">
                        There are many variations of passage available.
                      </a>
                    </h4>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="blog-item wow fadeInUp" data-wow-delay=".50s">
                  <div className="blog-item-img">
                    <img alt="Thumb" src="assets/img/blog/02.jpg" />
                  </div>
                  <div className="blog-item-info">
                    <div className="blog-item-meta">
                      <ul>
                        <li>
                          <a href="#">
                            <i className="far fa-user-circle" /> By Alicia Davis
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <i className="far fa-calendar-alt" /> January 29, 2023
                          </a>
                        </li>
                      </ul>
                    </div>
                    <h4 className="blog-title">
                      <a href="#">
                        There are many variations of passage available.
                      </a>
                    </h4>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="blog-item wow fadeInUp" data-wow-delay=".75s">
                  <div className="blog-item-img">
                    <img alt="Thumb" src="assets/img/blog/03.jpg" />
                  </div>
                  <div className="blog-item-info">
                    <div className="blog-item-meta">
                      <ul>
                        <li>
                          <a href="#">
                            <i className="far fa-user-circle" /> By Alicia Davis
                          </a>
                        </li>
                        <li>
                          <a href="#">
                            <i className="far fa-calendar-alt" /> January 29, 2023
                          </a>
                        </li>
                      </ul>
                    </div>
                    <h4 className="blog-title">
                      <a href="#">
                        There are many variations of passage available.
                      </a>
                    </h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* The Modal */}


    </>

  );
}
