import MechanicRegister from '@/appPages/MechanicRegister'
import React from 'react'

const page = () => {
    return (
        <main className="main">
            <div className="login-area mt-5 mb-5">
                <div className="container">
                    <div className="col-md-12 mx-auto">
                        <div className="login-form">
                            <MechanicRegister />
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}

export default page