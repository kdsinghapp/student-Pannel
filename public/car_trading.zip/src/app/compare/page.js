import React from "react";
import Compare from "../../appPages/Compare";

const ComparePage = () => {
  return (
    <div className="container">
      <h1 className="text-center my-4">Car Comparison</h1>
      <Compare />
    </div>
  );
};

export default ComparePage;
