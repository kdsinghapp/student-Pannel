import React from 'react';

const Page = () => {
    return (
        <>
        <main className="main">
          <div
            className="site-breadcrumb"
            style={{ background: "url(assets/img/breadcrumb/01.jpg)" }}
          >
            <div className="container">
              <h2 className="breadcrumb-title">About Us</h2>
              <ul className="breadcrumb-menu">
                <li>
                  <a href="/">Home</a>
                </li>
                <li className="active">About Us</li>
              </ul>
            </div>
          </div>
          <div className="about-area py-120">
            <div className="container">
              <div className="row align-items-center">
                <div className="col-lg-6">
                  <div
                    className="about-left wow fadeInLeft"
                    data-wow-delay=".25s"
                    style={{
                      visibility: "visible",
                      animationDelay: "0.25s",
                      animationName: "fadeInLeft"
                    }}
                  >
                    <div className="about-img">
                      <img alt="" src="assets/img/choose/01.png" />
                    </div>
                    <div className="about-experience">
                      <div className="about-experience-icon">
                        <i className="flaticon-car" />
                      </div>
                      <b>
                        30 Years Of
                        <br />
                        Quality Service
                      </b>
                    </div>
                  </div>
                </div>
                <div className="col-lg-6">
                  <div
                    className="about-right wow fadeInRight"
                    data-wow-delay=".25s"
                    style={{
                      visibility: "visible",
                      animationDelay: "0.25s",
                      animationName: "fadeInRight"
                    }}
                  >
                    <div className="site-heading mb-3">
                      <span className="site-title-tagline justify-content-start">
                        <i className="flaticon-drive" /> About Us
                      </span>
                      <h2 className="site-title">
                        World Largest <span>Car Dealer</span> Marketplace.
                      </h2>
                    </div>
                    <p className="about-text">
                      There are many variations of passages of Lorem Ipsum available,
                      but the majority have suffered alteration in some form, by
                      injected humour.
                    </p>
                    <p className="about-text">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                      enim ad minim veniam, quis nostrud exercitation ullamco laboris
                      nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                      in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                      nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                      sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="counter-area pt-30 pb-30">
            <div className="container">
              <div className="row">
                <div className="col-lg-3 col-sm-6">
                  <div className="counter-box">
                    <div className="icon">
                      <i className="flaticon-car-rental" />
                    </div>
                    <div>
                      <span
                        className="counter"
                        data-count="+"
                        data-speed={3000}
                        data-to={500}
                      >
                        500
                      </span>
                      <h6 className="title">+ Available Cars</h6>
                    </div>
                  </div>
                </div>
                <div className="col-lg-3 col-sm-6">
                  <div className="counter-box">
                    <div className="icon">
                      <i className="flaticon-car-key" />
                    </div>
                    <div>
                      <span
                        className="counter"
                        data-count="+"
                        data-speed={3000}
                        data-to={900}
                      >
                        900
                      </span>
                      <h6 className="title">+ Happy Clients</h6>
                    </div>
                  </div>
                </div>
                <div className="col-lg-3 col-sm-6">
                  <div className="counter-box">
                    <div className="icon">
                      <i className="flaticon-screwdriver" />
                    </div>
                    <div>
                      <span
                        className="counter"
                        data-count="+"
                        data-speed={3000}
                        data-to={1500}
                      >
                        1500
                      </span>
                      <h6 className="title">+ Team Workers</h6>
                    </div>
                  </div>
                </div>
                <div className="col-lg-3 col-sm-6">
                  <div className="counter-box">
                    <div className="icon">
                      <i className="flaticon-review" />
                    </div>
                    <div>
                      <span
                        className="counter"
                        data-count="+"
                        data-speed={3000}
                        data-to={30}
                      >
                        30
                      </span>
                      <h6 className="title">+ Years Of Experience</h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="testimonial-area bg py-120">
            <div className="container">
              <div className="row">
                <div className="col-lg-6 mx-auto">
                  <div className="site-heading text-center">
                    <span className="site-title-tagline">
                      <i className="flaticon-drive" /> Testimonials
                    </span>
                    <h2 className="site-title">
                      What Our Client <span>Say&apos;s</span>
                    </h2>
                    <div className="heading-divider" />
                  </div>
                </div>
              </div>
              <div className="testimonial-slider owl-carousel owl-theme">
                <div className="testimonial-single">
                  <div className="testimonial-content">
                    <div className="testimonial-author-img">
                      <img alt="" src="assets/img/testimonial/01.jpg" />
                    </div>
                    <div className="testimonial-author-info">
                      <h4>Sylvia H Green</h4>
                      <p>Customer</p>
                    </div>
                  </div>
                  <div className="testimonial-quote">
                    <span className="testimonial-quote-icon">
                      <i className="flaticon-quote" />
                    </span>
                    <p>
                      There are many variations of passages available but the majority
                      have suffered to the alteration in some injected.
                    </p>
                  </div>
                  <div className="testimonial-rate">
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" />
                  </div>
                </div>
                <div className="testimonial-single">
                  <div className="testimonial-content">
                    <div className="testimonial-author-img">
                      <img alt="" src="assets/img/testimonial/02.jpg" />
                    </div>
                    <div className="testimonial-author-info">
                      <h4>Gordo Novak</h4>
                      <p>Customer</p>
                    </div>
                  </div>
                  <div className="testimonial-quote">
                    <span className="testimonial-quote-icon">
                      <i className="flaticon-quote" />
                    </span>
                    <p>
                      There are many variations of passages available but the majority
                      have suffered to the alteration in some injected.
                    </p>
                  </div>
                  <div className="testimonial-rate">
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" />
                  </div>
                </div>
                <div className="testimonial-single">
                  <div className="testimonial-content">
                    <div className="testimonial-author-img">
                      <img alt="" src="assets/img/testimonial/03.jpg" />
                    </div>
                    <div className="testimonial-author-info">
                      <h4>Reid E Butt</h4>
                      <p>Customer</p>
                    </div>
                  </div>
                  <div className="testimonial-quote">
                    <span className="testimonial-quote-icon">
                      <i className="flaticon-quote" />
                    </span>
                    <p>
                      There are many variations of passages available but the majority
                      have suffered to the alteration in some injected.
                    </p>
                  </div>
                  <div className="testimonial-rate">
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" />
                  </div>
                </div>
                <div className="testimonial-single">
                  <div className="testimonial-content">
                    <div className="testimonial-author-img">
                      <img alt="" src="assets/img/testimonial/04.jpg" />
                    </div>
                    <div className="testimonial-author-info">
                      <h4>Parker Jimenez</h4>
                      <p>Customer</p>
                    </div>
                  </div>
                  <div className="testimonial-quote">
                    <span className="testimonial-quote-icon">
                      <i className="flaticon-quote" />
                    </span>
                    <p>
                      There are many variations of passages available but the majority
                      have suffered to the alteration in some injected.
                    </p>
                  </div>
                  <div className="testimonial-rate">
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" />
                  </div>
                </div>
                <div className="testimonial-single">
                  <div className="testimonial-content">
                    <div className="testimonial-author-img">
                      <img alt="" src="assets/img/testimonial/05.jpg" />
                    </div>
                    <div className="testimonial-author-info">
                      <h4>Heruli Nez</h4>
                      <p>Customer</p>
                    </div>
                  </div>
                  <div className="testimonial-quote">
                    <span className="testimonial-quote-icon">
                      <i className="flaticon-quote" />
                    </span>
                    <p>
                      There are many variations of passages available but the majority
                      have suffered to the alteration in some injected.
                    </p>
                  </div>
                  <div className="testimonial-rate">
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" /> <i className="fas fa-star" />{" "}
                    <i className="fas fa-star" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* The Modal */}
        <div className="modal" id="myModal">
          <div className="modal-dialog">
            <div className="modal-content">
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Mercedes Benz Car</h4>
                <button className="btn-close" data-bs-dismiss="modal" type="button" />
              </div>
              {/* Modal body */}
              <div className="modal-body">
                <div className="row pb-4">
                  <div className="col-lg-5">
                    <h5 className="mb-2">Price: $45,360</h5>
                    <div className="card mb-5" style={{ border: "1px solid #eee" }}>
                      <div className="card-body">
                        <p>
                          <strong>Dealer Name:</strong> John Doe
                        </p>
                        <p>
                          <strong>Address:</strong> 123A/21, Near old garden, Indore
                        </p>
                        <p>
                          <strong>Phone:</strong> 7798797XXXXX
                        </p>
                      </div>
                    </div>
                    <a className="theme-btn" href="details">
                      Click For Full Details
                    </a>
                  </div>
                  <div className="col-lg-7">
                    {/* Carousel */}
                    <div className="carousel slide" data-bs-ride="carousel" id="demo">
                      {/* Indicators/dots */}
                      <div className="carousel-indicators">
                        <button
                          className="active"
                          data-bs-slide-to={0}
                          data-bs-target="#demo"
                          type="button"
                        />{" "}
                        <button
                          data-bs-slide-to={1}
                          data-bs-target="#demo"
                          type="button"
                        />{" "}
                        <button
                          data-bs-slide-to={2}
                          data-bs-target="#demo"
                          type="button"
                        />
                      </div>
                      {/* The slideshow/carousel */}
                      <div className="carousel-inner">
                        <div className="carousel-item active">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/01.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                        <div className="carousel-item">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/02.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                        <div className="carousel-item">
                          <img
                            alt="car"
                            className="d-block"
                            src="assets/img/car/03.jpg"
                            style={{ width: "100%" }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
      
    );
}

export default Page;
