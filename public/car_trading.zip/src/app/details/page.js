import React from "react";

const Page = () => {
  return (
   <>
   <h1>coming soon</h1>
   </>
  );
};

export default Page;
