import axios from "axios";

const API_URL = "http://localhost:8000"
// const API_URL = "http://193.203.161.2:8000";

export const registerMechanic = async (formData) => {
  try {
    const res = await axios.post(`${API_URL}/mechanic/apply-mechanic`, formData, {
      headers: {
        "Content-Type": "application/json",
      }
    })
    console.log("working");
    return (res.data)
  } catch (error) {
    console.error("Error Register Mechanic:", error);
    throw error;
  }
}

export const getMechanicList = async (data) => {
  const token = localStorage.getItem("token");
  try {
    const res = await axios.post(`${API_URL}/buyer/find-mechanics`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const sendRequest = async (data) => {
  const token = localStorage.getItem("token");
  try {
    const res = await axios.post(`${API_URL}/buyer/request-mechanic`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    console.log(res.data);
    return res.data
  } catch (error) {
    console.error("Error Sending Request:", error);
    throw error;
  }
}