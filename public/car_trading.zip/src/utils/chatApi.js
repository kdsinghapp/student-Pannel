import axios from "axios";

// const API_URL = "/api/customer";
const API_URL = "http://193.203.161.2:8000";
// const API_URL = "http://localhost:8000";

export const ImageUrl = () => {
  // return "http://localhost:8000/images/";
  return "http://193.203.161.2:8000/images/";
};

export const getAllMessage = async (dealerId) => {
  try {
    const token = localStorage.getItem("token")
    const res = await axios.get(`${API_URL}/chat/user-messages/${dealerId}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};
export const getChatList = async () => {
  try {
    const token = localStorage.getItem("token")
    const res = await axios.get(`${API_URL}/chat/user/rooms`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const sendMessage = async (data) => {
  try {
    const token = localStorage.getItem('token');
    // Make the API call to fetch cars
    const response = await axios.post(`${API_URL}/chat/send`,data, {
      headers: {
        "Content-Type": "application/json",
         "Authorization": `Bearer ${token}`
      },
    });

    // Return the car data and pagination info
    return response.data;
  } catch (error) {
    console.error("Error fetching cars:", error);
    throw error;
  }
};
