"use client";
import { getUser } from "@/store/features/userSlice";
import React, { useEffect } from "react";
import { useDispatch } from "react-redux";

const GetUser = () => {
    const dispatch = useDispatch();

    const getUserFn = async () => {
      dispatch(getUser());
    };
  
    useEffect(() => {
      getUserFn();
    }, []);
  return <div></div>;
};

export default GetUser;
