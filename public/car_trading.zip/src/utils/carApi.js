import axios from "axios";

// const API_URL = "/api/customer";
const API_URL = "http://193.203.161.2:8000";
// const API_URL = "http://localhost:8000";

export const ImageUrl = () => {
  // return "http://localhost:8000/images/";
  return "http://193.203.161.2:8000/images/";
};

export const getlatestCar = async (data) => {
  try {
    const user = localStorage.getItem("user");
    const res = await axios.get(`${API_URL}/buyer/car/get`, {
      // const res = await axios.get(`${API_URL}/buyer/car/get?sendnew=true`, {
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        data,
        userId: JSON.parse(user)?._id,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const getMakerList = async () => {
  try {
    const res = await axios.get(`${API_URL}/car-makers/get-maker`, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};
export const getCityList = async () => {
  try {
    const res = await axios.get(`${API_URL}/admin/get-citys`, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};
export const getFilteredCar = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/buyer/car/filterCars`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};
export const getCarModel = async (data) => {
  try {
    console.log(data, "carmodels");

    // Pass the data object as params to axios.get
    const res = await axios.get(`${API_URL}/car-makers/get-model`, {
      headers: {
        "Content-Type": "application/json",
      },
      params: data, // this is where the query parameters are added
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const getCar = async (data) => {
  try {
    const { car_id ,addView } = data;
    const token = localStorage.getItem("token");
    const user = localStorage.getItem("user");
    console.log(user);
    
    const res = await axios.get(
      `${API_URL}/buyer/car/detail-car-view/${car_id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
       params: {
        ...data,
        userId: JSON.parse(user)?._id,
      },
      }
    );

    // console.log(addView, "detail data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const addComment = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(`${API_URL}/buyer/car/add-comment`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const favorites = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/favorites/setfavorite`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const getFavorites = async () => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${API_URL}/buyer/favorites/my-favorites`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const getMyBids = async () => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${API_URL}/buyer/bid/mybids`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const AddBid = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/bid`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const cancelBid = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/bid/cancel-bid`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const getMyOffer = async () => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${API_URL}/buyer/offer/myoffers`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const AddOffer = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/offer`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const cancelOffer = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/offer/cancel-offer`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const editOffer = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/offer/edit-offer`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const purchaseNow = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/car/buy`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};
export const getMyPurchase = async () => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${API_URL}/buyer/car/getpurchase`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const proseedBuyUser = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/purchase/proseed-buy`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // console.log(res.data, "data for car");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const userBuyList = async () => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${API_URL}/buyer/purchase/my-buying-list`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log(res.data, "userBuyList");
    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

export const filtersCar = async (data) => {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.post(
      `${API_URL}/buyer/car/filtersCar`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    return res.data;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw error;
  }
};

/*

{cartid: "0"
catid: "5"
extratopupid: ["8100"]
foodid: "45"
quantity: "1"
restId: "2"
type: "delivery"
typeid: "463"
userid: "20"}

*/

