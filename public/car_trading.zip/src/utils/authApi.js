import axios from "axios";

// const API_URL = "/api/customer";
const API_URL = "http://193.203.161.2:8000/buyer/user";
// const API_URL = "http://localhost:8000/buyer/user";
const API_URL1 = "http://193.203.161.2:8000/buyer/purchase";
// const storedUser = JSON.parse(localStorage.getItem("user"));

// export const review = async (data) => {
//   try {
//     const res = await axios.post(`${API_URL}/givereviewandrating`, data, {
//       headers: {
//         "Content-Type": "application/json",
//       },
//     });
//     console.log(res.data);
//     return res.data;
//   } catch (error) {
//     console.error("Error fetching restaurants:", error);
//     throw error;
//   }
// };
export const signUpUser = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/create`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    // console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};

export const signInUser = async (data) => {
  try {
    const res = await axios.post(`${API_URL}/login`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    // console.log(res.data);
    return res.data;
  } catch (error) {
    console.error("Error fetching restaurants:", error);
    throw error;
  }
};
export const getUserApi = async (token) => {
  try {
    const res = await axios.get(`${API_URL}/getuser`, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`, // Include token in the Authorization header
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};

export const updateUserApi = async (data) => {
  try {
    const token = localStorage.getItem("token")

    const res = await axios.put(`${API_URL}/update`, data, {
      headers: {
        "Content-Type": "multipart/form-data",
        "Authorization": `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};

export const LogoutToAll = async (token) => {
  try {
    const res = await axios.post(
      `${API_URL}/logout-all`,
      {}, // Sending an empty object since no data is required in the body
      {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
      }
    );
    return res.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};

export const Logout = async (token) => {
  try {
    const res = await axios.get(
      `${API_URL}/logout`,
      // Sending an empty object since no data is required in the body
      {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
      }
    );
    return res.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};

export const Mechanical = async (data, token) => {
  try {
    const res = await axios.post(`${API_URL1}/add-machenicl-check`, data, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
    });
    return res.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};
export const PaymentProof = async (data, token) => {
  try {
    const res = await axios.post(`${API_URL1}/add-machenical-pay-proof`, data, {
      headers: {
        "Content-Type": "multipart/form-data",
        "Authorization": `Bearer ${token}`,
      },
    });
    return res.data;

  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error;
  }
};

export const findUser = async (data) => {
  const user = {
    userId: data._id,
  };
  try {
    const res = await axios.post(`http://localhost:8000/buyer/find-user`, user, {
      headers: {
        "Content-Type": "application/json",
      },
    })
    return res.data;
  } catch (error) {
    console.error("Error fetching user:", error);
    throw error;
  }
}
