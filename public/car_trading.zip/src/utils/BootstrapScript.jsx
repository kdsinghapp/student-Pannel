"use client";
import { useEffect } from 'react';

const BootstrapScript = () => {
  useEffect(() => {
    // Import Bootstrap JS only on the client side
    import('bootstrap/dist/js/bootstrap.bundle.min').then(() => {
      // Bootstrap JS has been loaded
    });
  }, []);

  return null; // This component does not render anything
};

export default BootstrapScript;
