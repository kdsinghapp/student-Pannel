// /** @type {import('next').NextConfig} */
// const nextConfig = {
//   reactStrictMode: true,
//   swcMinify: true, // Optional: enables SWC minification
//   experimental: {
//     appDir: true, // Ensure this is enabled if you are using the `app` directory structure
//   },
//   source: "/api/:path*",
//   destination: "http://localhost:8000/testing/create-payment",
//   // Additional configurations can be added here
// };

// export default nextConfig;

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  experimental: {
    appDir: true,
  },
  source: "/api/:path*",
  destination: "http://localhost:8000/testing/create-payment",
};

export default nextConfig;
